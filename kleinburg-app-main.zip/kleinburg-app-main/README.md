# Kleinburg

Marka dokümanlarını 9 adımlı bir akışla sosyal medya kampanyasına çeviren, çok kiracılı
içerik motoru. Next.js 15 + TypeScript, Postgres, OpenRouter üzerinden LLM erişimi.

Akış: belge yükleme → marka bağlamı → araştırma → ek girdi → yaratıcı kıvılcımlar →
platform seçimi → içerik sütunları → gönderiler → içerik takvimi (CSV/XLSX dışa aktarım).

## Depo ve dallar

Canonical repo: **`elifc/kleinburg-app`** (standalone, fork değil). Dallar: `rebuild` = prod,
`test` = staging, `main` = dokunulmamış legacy Streamlit. Akış: feature → `test` → `rebuild`;
`rebuild`'e doğrudan push kapalı (PR şart).

**CI GitHub'da kapalı** (`web-ci` workflow'u devre dışı, dosya duruyor). Doğrulama lokalde:
`npm run lint && npm run typecheck && npm run build && npm run test:db`. Ayrıntı: `CLAUDE.md`.

Canlı ortam artık Render'da değil — hosting hedefi yeniden belirlenecek. Eski Render
kurulumu (`render.yaml`, `docs/DEPLOY_RENDER.md`) kaldırıldı; yeni hosting netleşince
buraya ve `CLAUDE.md`'ye yazılacak.

Geçmiş arşivi: **[`elifc/kleinburg`](https://github.com/elifc/kleinburg)** (eski fork, read-only).
Kapalı issue geçmişi, PR'lar ve eski `#NN` referanslarının redirect'leri orada. 24 Tem 2026'da
fork'tan bu standalone repoya taşındı (fork'ta GitHub ruleset'e izin vermiyordu).

## Çalıştırma

```bash
nvm use                    # Node sürümü kökteki .nvmrc'de sabit (22, CI ile aynı)
cd web && npm ci
npm run db:up && npm run db:migrate
npm run seed demo          # yerel hesap + 9 adımı yürünebilir bir proje
npm run dev                # http://localhost:3000
```

Giriş: `demo` / `demo12345678`. `seed demo` idempotenttir, bozduktan sonra tekrar koş.
**Yalnızca yerel veritabanında çalışır** — parolası kaynak kodda yazılı olduğu için uzak bir
veritabanına karşı çalışmayı reddeder.

Model çağrısı yapmaz: `OPENROUTER_API_KEY` yoksa üretim adımları "servis yapılandırılmamış"
hatası verir, ama seed'lenen proje sayesinde bütün arayüz gezilebilir.

Node kurmak istemiyorsan (ya da makinedeki sürüm sabitlenen major değilse) uygulama
container içinde de koşar — `web/docker-compose.dev.yml` içindeki `web` servisi:

```bash
cd web && npm run dev:docker    # Postgres + Next.js dev server, http://localhost:3000
docker compose -f docker-compose.dev.yml exec web npm run seed demo
```

Bağımlılıkları ve migration'ları kendisi kurar; kaynak ağacı bind-mount olduğu için
düzenlemeler container içinde yeniden derlenir. `npm run db:up` yalnızca veritabanını
kaldırır, bu servisi başlatmaz.

```bash
npm test                   # DATABASE_URL kabukta yoksa DB testleri atlanır (uyarı basar)
npm run test:db            # tam suite (~26 sn)
npm run lint && npm run typecheck && npm run build
```

## Canlı ortam

Hosting hedefi belirlenmedi (eski Render kurulumu kaldırıldı). Yeni hedef netleşince
buraya bir runbook eklenecek.

Kullanıcı açmak, rol vermek, marka erişimi tanımlamak ve harcama tavanı koymak için
**terminal gerekmez** — hepsi admin panelinde (`/admin`). Panelden açılan kullanıcı ilk
girişte parolasını değiştirmek zorundadır.

## Repoda ne nerede

| Yol | Ne |
|---|---|
| `web/` | Uygulamanın tamamı |
| `web/prompts/` | Uygulamanın okuduğu prompt'lar (`.md`, frontmatter'lı, versiyonlu) |
| `design/tokens.json` | Temanın tek kaynağı; `npm run build:theme` bunu okur |
| `prompts/` | Legacy'nin orijinal `.txt` prompt'ları. Uygulama okumaz; taşınmış prompt'ların `source:` alanı buraya işaret eder ve bir test o işaretin çözüldüğünü doğrular |
| `docs/` | Legacy analizi (deploy runbook'u kaldırıldı — yeni hosting belirlenince eklenecek) |

Legacy Streamlit uygulaması bu daldan kaldırıldı. `main` dalında ve `legacy-snapshot`
tag'inde bütün hâliyle duruyor.

## Çalışma kuralları

[`CLAUDE.md`](CLAUDE.md) — esnemez kurallar (marka izolasyonu, yapılandırılmış çıktı,
sessiz hata yasağı) ve teslim öncesi öz-denetim listesi. **Kod değiştirmeden önce okunmalı.**

En sık tekrarlanan hata sınıfı şudur: bir davranış değişir, o davranışı anlatan yorum
değişmez, ve sonraki okuyucu artık yalan söyleyen bir cümleye güvenerek karar verir.
Bir davranışı değiştirdiğinde onun hakkındaki her cümleyi ara ve düzelt.

Kodda ve commit'lerde **"Elif'in kararı"** diye işaretli yerler var. Elif projenin ürün
sahibiydi; bu işaretler "burada bilinçli bir tercih yapıldı" demektir. Çoğu bug gibi görünüp
bilerek öyle bırakılmış davranışlardır — değiştirmek serbest, ama gerekçesi yazılarak.

## Açık işler

GitHub Issues (numaralar `elifc/kleinburg-app`; fork'tan taşınırken yeniden atandı, eşleme
[`docs/DEVIR.md`](docs/DEVIR.md)'de). Devir sırasında açık olanlar:

- **#1** — Playwright E2E ve uçtan uca canlı üretim turu. Tur elle koşuldu ve çalışıyor;
  otomatik E2E ve maliyet ölçümü tamamlanmadı.
- **#3** — Beş model çağrısında `maxTokens` yok. Ölçülmüş bir vaka var: iki tam sayı
  üretmesi gereken bir adım 65.536 token yakıp kesilmişti. Marka başına aylık tavan
  (arşiv fork #51) üst sınırı tutuyor, yani açık uçlu değil.
- **#4** — Takvimde kayıtsız platform etiketli gönderiler sessizce düşüyor; çözülemeyen
  pillar yalnız sunucu loguna yazılıyor.
- **#5** — Beş test, koruduğunu iddia ettiği şeyi gerçekten sabitlemiyor.
- **#6** — Bir kez görülüp tekrar üretilemeyen test hatası. Arşiv fork #89'daki paralellik
  düzeltmesi aynı sınıf olabilir, kanıtlanmadı.
- **#7** — Adımdan ayrılıp dönünce devam eden üretim görünmez oluyor; iş sunucuda
  koşmaya devam eder ama arayüz onu unutur.

Devir sonrası açılanlar:

- **#24** — Uçtan uca akış ~13-15 dakika sürüyor; darboğaz `sm_pillars` ve `sm_posts` adımları.

Takip: GitHub Issues **ve** [Project board #3](https://github.com/users/elifc/projects/3)
("Kleinburg Rebuild"). Açık issue'ların tamamı board'da; durum sütununu değiştirmek için
`.claude/board.sh <issue-no> <Todo|In Progress|Done>`. Board hem bu reponun hem arşiv fork'un
kalemlerini taşıdığı ve numaralar çakıştığı için betik sorguyu `elifc/kleinburg-app` ile
filtreler. Yeni bir issue board'da yoksa önce eklenir:
`gh project item-add 3 --owner elifc --url <issue-url>`.

Kalıcı ilerleme kaydı: pinned issue **#2**.
İlk gün, mimari, erişimler ve operasyon: [`docs/DEVIR.md`](docs/DEVIR.md).
