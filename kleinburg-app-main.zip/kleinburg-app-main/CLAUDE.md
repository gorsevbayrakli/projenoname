# CLAUDE.md — Kleinburg Rebuild

Uygulamanın tamamı **`web/`** altında: Next.js 15 + TypeScript.

Kökte kalan üç dizin de canlı olarak kullanılıyor, artık değil:

- **`design/`** — `tokens.json` temanın tek kaynağı; `npm run build:theme` bunu okur.
- **`prompts/`** — legacy'nin orijinal `.txt` prompt'ları. Uygulama bunları **okumaz**
  (o iş `web/prompts/*.md`'de), ama taşınmış prompt'ların frontmatter'ındaki `source:`
  alanı buraya işaret eder ve bir test o işaretin çözüldüğünü doğrular. Yani provenance
  kaydı: "bu prompt nereden geldi". Silinirse o referanslar boşa düşer.
- **`docs/`** — tasarım spec'i, plan, legacy analizi.

Branch modeli: **`rebuild`** = uygulama (prod), **`test`** = staging, `main` = dokunulmamış
legacy Streamlit uygulaması (Azure'da ayrı çalışır). Akış: feature → `test` (test ortamında
dene) → `rebuild` (prod).

**Hosting: belirlenmedi.** Render kurulumu (render.yaml, docs/DEPLOY_RENDER.md) tamamen
kaldırıldı — sistem bambaşka bir yere deploy edilecek. Yeni hedef netleşince: bu bölüm,
"Canlı ortam" bölümü ve bir deploy runbook'u yeniden yazılacak. O ana kadar `rebuild`/`test`
dalları sadece branch modeli anlamında var, otomatik deploy hedefleri yok.

**CI: GitHub'da kapalı (6 Eki 2026).** `web-ci` workflow'u `abayrakli/kleinburg-app` reposunda
devre dışı bırakıldı; doğrulama lokalde yapılır (bkz. "CI ve doğrulama" aşağıda). Aşağıdaki
`elifc/kleinburg-app` ruleset anlatımı o reponun geçmiş durumudur ve `ci` check'i artık hiçbir
yerde otomatik koşmaz.

Canonical repo **`elifc/kleinburg-app`** (standalone, fork DEĞİL). `rebuild` ve `test` dalları
GitHub ruleset'leriyle korumalı: `rebuild`'e doğrudan push kapalı (PR şart; eskiden yeşil `ci` de şarttı).
24 Tem'de fork'tan çıkıldı çünkü GitHub bir fork'ta ruleset'i kapatıyor. Eski fork
`elifc/kleinburg` **arşiv**: kapalı issue geçmişi, PR'lar, `legacy-snapshot` tag'i ve eski
`#NN` referanslarının redirect'leri orada. Silinmez.

**Legacy Python kökten kaldırıldı** (95 dosya, ~17k satır). Kaybolmadı: `main` dalında ve
`legacy-snapshot` tag'inde bütün hâliyle duruyor, `git show legacy-snapshot:app.py` gibi
her an okunabilir. Davranış karşılaştırması gerekirse `git checkout main` yeterli.
Not: `rebuild` bir gün `main`'e terfi ettirilirse bu silme de oraya taşınır — legacy'nin
Azure'daki deploy'u o noktada ayrıca düşünülmeli.

## Branch akışı ve katkı

Üç kalıcı dal, her biri bir ortama bağlı:

| Dal | Ortam | Deploy |
|---|---|---|
| `rebuild` | prod | hosting belirlenmedi |
| `test` | staging | hosting belirlenmedi |
| `main` | yok (dokunulmamış legacy referansı) | deploy yok |

**Değişiklik akışı — istisnasız feature → test → rebuild:**

1. `test`'ten feature dalı aç: `git checkout test && git pull && git checkout -b <konu>`.
2. Değişikliği yap, commit'le (İngilizce mesaj, sonda `Co-Authored-By`).
3. PR aç, base **`test`**. PR'dan ÖNCE lokalde koş: `npm run lint && npm run typecheck && npm run build && npm run test:db` (CI kapalı, bu adımı atlamak her şeyi atlamak demek).
4. Merge → `test`'e gider. **Test ortamında dene** (hosting belirlenince otomatik deploy geri gelecek).
5. Onaylanınca PR aç, base **`rebuild`**. Lokal doğrulamayı tekrar koş; **yeşil olmadan merge etme.**
6. Merge → prod'a gider (hosting belirlenince otomatik deploy geri gelecek).

**`rebuild` (prod) korumalı** (GitHub ruleset `protect-rebuild-prod`, `elifc/kleinburg-app` üzerinde): doğrudan push kapalı,
PR zorunlu, force-push ve dal silme yasak (eskiden `ci` check yeşil şartı da vardı; CI kapalı olduğu için bu şart artık işlemez). `test` de force-push/silmeye
kapalı ama doğrudan push serbest (deneme alanı). Tek kişilik onay yeterli — PR'ı açan kendi
merge edebilir. Acil prod erişimi gerekirse ruleset'e bypass actor eklenir (repo → Settings → Rules).

**CI ve doğrulama.** `.github/workflows/web-ci.yml` repoda duruyor ama GitHub'da **devre dışı**
(`gh workflow disable web-ci`; geri açmak için `gh workflow enable web-ci`). Dosya bilerek
silinmedi: `web/src/test/nvmrc-sync.test.ts` onu okuyup Node sürümünü doğruluyor, silinirse o test kırılır.
Workflow açıkken `main`/`rebuild`/`test` push'larında ve tüm PR'larda koşardı (job adı `ci`,
lint + typecheck + build + migrate + test). `build` dahildi, çünkü bir edge-runtime hatası
typecheck'ten temiz geçip build'de patlamıştı: lokal doğrulamada da `npm run build` atlanmaz.
"Yeşil" = suite gerçekten koştu demek, ötesi değil; lokalde tam suite `npm run test:db`.

Ekibe devir ve operasyon runbook'u: [`docs/DEVIR.md`](docs/DEVIR.md).

## Ne inşa ediyoruz

Marka dokümanlarını 9 adımlı akışla sosyal medya kampanyasına çeviren, çok kiracılı
(brand → project → content) bir içerik motoru. Adım sayısının tek kaynağı
`web/src/lib/workflow-steps.ts` içindeki `TOTAL_STEPS`. Tek web servisi + Postgres (hosting
belirlenmedi); LLM erişimi OpenRouter üzerinden; uzun üretimler pg-boss iş kuyruğunda (aynı süreç).

Kanonik dokümanlar (uzlaşmazlıkta öncelik sırası):
1. **Kod ve içindeki açıklamalar.** Bu repo alışılmadık ölçüde yorumlu ve yorumlar bir
   kararın *gerekçesini* taşıyor. Bir davranış tuhaf göründüğünde önce yanındaki yorumu oku.
2. `README.md` — ne olduğu, nasıl çalıştırıldığı, neyin açık kaldığı.
3. `docs/legacy-analysis.md` — legacy sistemin analizi (neden yeniden yazıldı).

(Eski madde 3, `docs/DEPLOY_RENDER.md`, kaldırıldı — hosting Render'dan taşınıyor. Yeni
hosting netleşince buraya bir runbook eklenip sıra yeniden numaralanacak.)

Kurulum sırasındaki tasarım spec'i ve 24 kalemlik plan **kaldırıldı**: uygulama artık
9 adımlı, spec ise 8 adımlı bir akış anlatıyordu. Bayat bir kanonik doküman, hiç doküman
olmamasından zararlıdır (bkz. öz-denetim maddesi 1). Gerekirse git geçmişinde duruyor:
`git log --diff-filter=D -- docs/superpowers`.

İş takibi: GitHub Issues + [Project board #3](https://github.com/users/elifc/projects/3).
Durum sütunu `.claude/board.sh <issue-no> <Todo|In Progress|Done>` ile değişir; board'da
olmayan yeni issue önce `gh project item-add 3 --owner elifc --url <issue-url>` ile eklenir.

## Komutlar (web/ içinde)

```bash
npm run dev          # dev server
npm run build        # production build
npm run lint         # ESLint
npm run typecheck    # tsc --noEmit
npm test             # Vitest — `.env` OKUNMAZ; DATABASE_URL'i kabukta zaten
                     # export ettiysen DB testleri yine de koşar
npm run test:db      # TAM suite: .env yüklenir, DB testleri de koşar (Node >=22.9)
npm run build:theme  # design/tokens.json -> src/app/theme.generated.css
npm run db:up        # docker compose ile local Postgres 16 (YALNIZ postgres servisi)
npm run dev:docker   # dev server'ı container'da koş (Node kurulu olmayan makine için)
npm run db:generate  # Drizzle migration üret
npm run db:migrate   # migration uygula
npm run seed demo    # local demo hesabı + yürünebilir proje (SADECE local DB)
```

Local DB: `web/.env` içinde `DATABASE_URL` (bkz. `.env.example`). CI workflow'u (şu an GitHub'da
kapalı) efemeral Postgres 16'ya karşı lint+typecheck+migrate+test koşacak şekilde yazılı
(`.github/workflows/web-ci.yml`); aynı doğrulamayı lokalde `npm run db:up && npm run test:db` yapar.

## Yerel çalıştırma

Sıfırdan çalışan bir ortam:

```bash
nvm use                                  # kökte de .nvmrc var (aşağıya bak)
cd web && npm ci
npm run db:up && npm run db:migrate
npm run seed demo
npm run dev                              # http://localhost:3000
```

Giriş: **`demo` / `demo12345678`**.

`seed demo` idempotenttir; sihirbazı tıklayıp bozduktan sonra sıfırlamanın normal
yolu komutu tekrar koşmaktır. Kurduğu şey: `demo` kullanıcısı, `Demo Marka`
markası, aralarındaki üyelik ve 9 adımın tamamı **hiçbir model çağrısı olmadan**
yürünebilecek kadar doldurulmuş bir proje (adım 9 zaten kodda kuruluyor). İçerik
uydurma bir markaya ait — gerçek müşteri materyali değil.

**Neden var:** local veritabanında HİÇ kullanıcı yoktu, dolayısıyla sihirbaz
yerelde hiç yürünemiyordu ve test ortamı fiilen production olmuştu. Bu haftaki
üç kaçak hatanın ikisi doğrudan bundan çıktı: adım 7 UX sorunu canlı koşuda
bulundu, bir UI değişikliği görsel olarak doğrulanmadan çıktı.

**`seed demo` yalnızca LOCAL veritabanında çalışır ve bunun esnetilebilir bir
yanı yoktur.** Parolası kaynak kodda yazılı; bunu kabul edilebilir kılan tek şey
`web/src/core/db/local-only.ts` guard'ı. `NODE_ENV=production` reddedilir;
`DATABASE_URL`'in host'u küçük bir izin listesinde (localhost, 127.0.0.1, ::1,
docker compose host'ları) değilse reddedilir — Render'ın dahili host adı
(`dpg-…-a`) bakışta uzak görünmediği ve kimse URL'i yapıştırdığı kabukta
`NODE_ENV` set etmediği için asıl iş bu ikinci kontrolde. Belirsiz her durum
(URL yok, parse edilemiyor) **kapalı tarafa düşer**. Bayrak, env değişkeni ya da
override YOKTUR ve eklenmemelidir. Gerçek bir veritabanında hesap gerekiyorsa
`npm run seed -- create-admin <username>` zaten var ve parolayı sorar.

**Node sürümü sabitlenmiştir.** `.nvmrc` artık hem `web/` içinde hem de **repo
kökünde** var (kök olan, `web/.nvmrc`'ye bir symlink — sayı tek yerde durur).
Kökte `.nvmrc` olmaması bu hafta bir hatayı sakladı: .pptx yükleme hatası Node
22'de (Render, CI) düşüyor, Node 24'te geçiyordu, ve kökte açılan bir kabuk
makinenin varsayılanını (24) alıyordu. Kökte `nvm use` artık doğru sürümü seçer.
Sürümün dört kopyası (kök `.nvmrc`, `web/.nvmrc`, CI workflow'u, `package.json`
engines) `web/src/test/nvmrc-sync.test.ts` ile senkron tutulur — symlink'i düz
dosyayla değiştirmek bile testi kırar.

`DATABASE_URL` yokken 13 test dosyası (tenancy, marka izolasyonu, pipeline, jobs,
auth, şema) kendini atlar ama özet yine yeşil görünür. Bu yüzden gate kapalıyken
koşu sonunda gürültülü bir uyarı basılır (`web/src/test/db-gate-reporter.ts`).
**Uyarıyı gördüysen tam suite'i koşmamışsındır** — `npm run db:up && npm run test:db`.

Uyarının verdiği sayı yalnızca DB gate'inin kapattığı testleri sayar: hangi
suite'lerin gate'e bağlı olduğu `db-gate-reporter.ts` içindeki açık listede durur
ve o liste kaynak ağacındaki `skipIf(!hasDb)` kullanımlarıyla bir testle
senkron tutulur. `RUN_PGBOSS_TEST` gibi başka nedenlerle atlanan testler bu
sayıya girmez. Uyarı sadece koşu yeşil bittiğinde basılır; kırmızı koşuda gerçek
hataları gömmemek için susar.

CI'da değişken her zaman set olduğu için uyarı hiç çıkmaz. `GITHUB_ACTIONS` set
iken (yani gerçekten bu reponun CI'ında) `DATABASE_URL` eksikse koşu sert hata
verir — genel `CI` değişkenine bakılmaz, çünkü onu Docker build'leri, husky ve
pek çok kabuk da set ediyor. Actions üzerinde bilerek DB'siz koşmak gerekirse
`ALLOW_MISSING_DATABASE_URL=1`.

O liste ikinci bir iş daha yapıyor: **suite iki projeye bölünmüş durumda**
(`web/vitest.config.ts`). Veritabanına dokunan 28 dosya **teker teker** koşar,
geri kalan 64 dosya paralel. Sebebi hız değil, doğruluk: hepsi TEK bir Postgres'i
paylaşıyor, dolayısıyla "sistemde kaç aktif admin var" gibi GLOBAL bir olguya
bakan her iddia, başka dosyalar tam o satırları yazarken doğrulanıyor. Ölçüldü:
son-admin testi 6 tam koşunun 3'ünde kırmızıydı, tek başına her seferinde yeşil.
Testin kendi içinde çözülemez — araya giren satırlar önceki testlerden KALAN
değil, eşzamanlı YAZILAN satırlar. Bedeli 10s yerine ~26s; yarısında kırmızı
yanan bir suite insana okumayı değil tekrar koşmayı öğretir, gerçek bir hata da
oradan geçer. Ayrıntılı gerekçe config dosyasının başında.

Seri koşacak dosya listesi elle tutulmuyor: `DB_GATED_SUITES` registry'sinden
türetiliyor, o da yukarıdaki testle `skipIf(!hasDb)` gate'lerine bağlı. Yani yeni
bir DB testi eklemek registry'ye kayıt olmayı zorunlu kılıyor, kayıt da onu
otomatik seri hale getiriyor. **Elle güncellenecek ikinci bir liste yok.**

## Hard rules (esnemez)

1. **`web/src/core/` hiçbir UI modülü import edemez** (react/next yasak — ESLint
   `no-restricted-imports` ile zorlanır). Motor UI'dan bağımsız test edilebilir kalır.
2. **Marka izolasyonu kutsaldır.** Proje-kapsamlı her okuma/yazma `requireProjectAccess`
   üzerinden geçer (T7); scope'suz sorgu yazmak bug'dır.
3. **Tema elle düzenlenmez.** Tek kaynak `design/tokens.json`; `theme.generated.css`
   üretilir, `globals.css`'teki `@theme inline` eşlemesi senkron testiyle korunur
   (`themeSync.test.ts`). `inline` anahtar sözcüğü load-bearing — kaldırma.
4. **Yapılandırılmış çıktı tek yoldur.** LLM çıktıları Zod şemasıyla doğrulanır;
   regex/prose parsing yazılmaz. Şemayı geçmeyen çıktı = başarısız iş; kısmi içerik
   kaydedilmez, sahte başarı gösterilmez.
5. **Sessiz hata yutma yasak.** Her üretim işi succeeded/failed + gerçek neden.
6. **Prompt'ların yaratıcı çekirdeği** legacy'den birebir taşınır (T11); değişiklik
   ancak ürün sahibinin onayıyla ve `version` artırılarak yapılır.

## Teslim öncesi öz-denetim (atlanmaz)

Bir oturumda sekiz iş yapıldı, her biri incelemeden geçti ve **incelemeler aynı beş hata
sınıfını tekrar tekrar buldu**. Aşağıdakiler o bulguların genellemesi; sonraki haftalar
hepsini yeniden doğruladı. İşi "bitti" diye
raporlamadan ÖNCE beşini de kendin koş — inceleme bunları yakalamak için değil, bunların
kaçırdıklarını yakalamak için var.

**1. Yazdığın iddia, kodun yaptığı şey mi?** (Bu oturumun EN SIK bulgusu — yedi kez.)
Yorumlar, modül başlıkları, dokümanlar ve commit mesajları eskir; eskidiklerinde sessizce
yalan söylemeye başlarlar ve sonraki oturum onlara güvenip karar verir. Somut örnekler:
#51'de modül başlığı "harmanlanmış oran yanlış olur" diye uyarıp üç satır altında tam onu
yapıyordu; #50'de harcama testinin başlığı "admin bir bypass DEĞİLDİR" diyordu ve o commit
tam tersini yapmıştı; #41'de "okumalar asla kaydedilmez" maddesi ve migration'daki
"sıradan uygulama kimlikleriyle atlanamaz" cümlesi yanlıştı.

→ Bir davranışı değiştirdiğinde, o davranış hakkındaki HER cümleyi ara ve düzelt.
`grep` ile modül adını, fonksiyon adını, kuralın adını tara. **Yumuşatma — doğru yap.**
Doğruluğunu yitirmiş bir güvenlik iddiası, hiç iddia olmamasından zararlıdır.

**2. Testin sahte mi?** (Dört kez.) Bir fikstür, hem doğru hem bozuk uygulamayı tatmin
ediyorsa hiçbir şey kanıtlamaz. #42'de sıralama testinin değerleri metin olarak da sayı
olarak da aynı sıralanıyordu; #43'te izolasyon testindeki bütün projeleri aynı kullanıcı
yazmıştı; #41'de parola maskeleme testi sırrı yanlış alana koyuyordu.

→ Sözleşmeyi kasten boz, **kırmızıya döndüğünü gör**, sonra geri al. Fikstürü, doğru ve
yanlış uygulamanın **farklı DURUMLARA** düştüğü şekilde seç (ok/blocked gibi), sadece farklı
sayı üretmesi yetmez.

**3. Yeni kodda sessiz hata var mı?** (Beş kez — hard rule 5 zaten varken.) Yutulan
`catch`, loglanmayan 500, `undefined` dönen switch, sıfır sayılan bilinmeyen maliyet.
#43'te dil değiştirme yutması **eskiden doğruydu**, aynı commit'in getirdiği öncelik kuralı
onu yanlış hale getirdi.

→ Her yeni hata yolunda sor: kullanıcı ne görüyor, operatör logda ne buluyor? İkisi de
boşsa hard rule 5 ihlali. Ve bir yutmayı miras aldıysan, **gerekçesinin hâlâ geçerli
olduğunu** doğrula.

**4. Özellik ikinci hafta çalışıyor mu?** (Üç kez.) Birinci gün akışı çalışıp ikinci hafta
çöken özellik yarım özelliktir. #40'ta parola sıfırlama arka uçta vardı ama arayüz onu hiç
çağırmıyordu (yani "terminale dön" işi geri geliyordu) ve `/change-password` çıkışsız bir
kapandı. #51'de sihirbaz tavan uyarısı göstermiyor, yani kullanıcı 8 adımlık projeye
başlayıp 6. adımda reddedilebiliyor.

→ Mutlu yolu değil, **ikinci hafta senaryosunu** yürü: biri şifresini unutursa, biri yanlış
yazarsa, bir sınıra yaklaşırsa ne oluyor? Çıkmaz var mı?

**5. Bu iş neyi bozar?** (Dört kez.) Hata tek bir işin içinde değil, **iki işin
kesişiminde** doğuyor ve ikisine ayrı bakınca görünmüyor. #47'nin kaynaksız URL'si tek
sütunda sığıyordu, #44'ün grid'inde komşu kartın üstüne taştı. #41 ve #43 aynı anda aynı
migration numarasını üretti (ikisi ayrı ayrı çalışıyordu, birlikte sıfırdan uygulanamazdı).
#51'de sıradan bir proje silme, bütün markanın üretimini durdurabiliyordu.

→ Aynı veriyi okuyan/yazan başka ne var? Aynı kaynağı (migration numarası, dil anahtarı,
gezinme satırı) başka kim üretiyor? Yeni bir "reddet" kuralı yazdıysan: bu duruma sıradan
bir kullanıcı sokabilir mi?

**Mekanik > sözleşme.** Bu oturumun en dayanıklı düzeltmeleri kural yazmak değil, kuralı
kod olarak zorlamaktı: `core/` dışına import'u yasaklayan ESLint kuralı, `jobId`siz
`generateStructured` çağrısını yakalayan kaynak taraması testi, `access.ts` metnini
sabitleyen test, DB-gate kayıt testi. Bir kuralı yoruma yazacaksan, **önce onu bozan bir
testin yazılıp yazılamayacağına bak.**

## Konvansiyonlar

- Commit mesajları İngilizce, sonunda: `Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>`
- Kullanıcıya dönük metinler ve issue yorumları Türkçe.
- Font: Space Grotesk (Baikal'in açık kaynak vekili — lisans gelirse
  `design/tokens.json` typography token'ından değiştirilir).
- Marka primary: `--color-accent` (= purple.600 `#6642FF`).

## Kodda geçen "Elif'in kararı" ne demek

Kaynak kodda, commit mesajlarında ve migration yorumlarında **"Elif'in kararı"** ya da
**"Elif'in onayı"** diye işaretlenmiş yerler var. Elif projenin ürün sahibiydi; bu işaretler
"burada bir tercih yapıldı ve gerekçesi tartışıldı" anlamına gelir.

Pratik karşılığı: **bu noktalar tuhaf göründüğü için sessizce düzeltilmez.** Çoğu, bug gibi
duran ama bilerek öyle bırakılmış davranışlardır (7. adımda seçim mantığı, harcama tavanının
kapalı gelmesi, denetim kaydının süresiz saklanması gibi). Değiştirmek serbesttir, ama
bilinçli olarak ve gerekçesi yazılarak — yorumu güncellemeden davranışı değiştirmek bu
repoda en sık tekrarlanan hata sınıfı (bkz. öz-denetim maddesi 1).

Prompt dosyalarının yaratıcı çekirdeği (`web/prompts/`) ayrı bir durumdur: hard rule 6 gereği
değişiklik ürün sahibinin onayıyla ve `version` alanı artırılarak yapılır.

## Açık işler

GitHub Issues'ta, **`elifc/kleinburg-app`** üzerinde. Devir sırasında açık kalanlar, taşıma
sonrası yeni numaralarıyla: canlı üretim turu + E2E (#1), kapsız model çağrıları (#3),
takvimde kayıtsız platform etiketi (#4), dişsiz testler (#5), tekrar üretilemeyen tek test
hatası (#6), devam eden üretimin adım değişince görünmez olması (#7). Durum kaydı: #2.

**Çıplak `#NN` yazarken dikkat:** taşıma numaraları yeniden atadı ve iki repo çakışıyor.
Eski fork'taki `#24` T24 planı, yeni repodaki `#24` bir performans issue'su. Arşivdeki bir
issue'ya atıf yapıyorsan `elifc/kleinburg#NN` diye tam yaz.

## Bu kurallar ne zaman silinebilir

Yukarıdaki kuralların her biri somut bir olaydan doğdu, ama hiçbiri kendiliğinden ölmüyor:
dosya yalnızca büyüyor ve her oturumda baştan okunuyor. Bir kuralı yazarken onu gereksiz
kılacak koşulu da yaz. **Kural yerine mekanizma geçtiyse kural gider** — "mekanik > sözleşme"
maddesinin doğal sonucu bu. Silinen kural, unutulan kural değildir.

| Kural | Neden var (hangi olay) | Ne olursa kaldırılabilir |
|---|---|---|
| Öz-denetim 1 — iddia kodun yaptığı şey mi | Bir oturumda 7 kez: #51 modül başlığı üç satır altında kendi uyarısını çiğniyordu, #50 test başlığı commit'in tersini söylüyordu | İddiaları koda bağlayan senkron testleri (`themeSync`, `nvmrc-sync`, `access.ts` metni) iddia yüzeyinin tamamını kapsarsa |
| Öz-denetim 2 — sahte test | 4 kez: #42'de fikstür hem doğru hem bozuk sıralamayı geçiriyordu, #43'te izolasyon testinin bütün projelerini aynı kullanıcı yazmıştı | Mutasyon testi (mutation testing) CI'a girerse — sahte testi o zaman makine yakalar, insan değil |
| Öz-denetim 3 — sessiz hata | 5 kez, hard rule 5 zaten yazılıyken | Yutulan `catch`'i ve loglanmayan 500'ü yakalayan bir ESLint kuralı eklenirse |
| Öz-denetim 4 — ikinci hafta senaryosu | #40'ta parola sıfırlama arka uçta vardı ama arayüz çağırmıyordu; #51'de kullanıcı 6. adımda tavana çarpıyordu | E2E akışı (#1) mutlu yolu değil mutsuz yolları kapsarsa |
| Öz-denetim 5 — bu iş neyi bozar | #47 ile #44 çakıştı, #41 ile #43 aynı migration numarasını üretti | **Kalır.** İki işin kesişiminde doğan hatayı yakalayan mekanik yok; tek savunma insan dikkati |
| DB gate uyarısı (`db-gate-reporter.ts`) | `DATABASE_URL` yokken 13 dosya sessizce atlanıp özet yeşil görünüyordu | Testler veritabanını kendi ayağa kaldırırsa (testcontainers) — o zaman gate'in kendisi gereksizleşir |
| DB testlerinin seri koşması | Son-admin testi 6 tam koşunun 3'ünde kırmızıydı, tek başına hep yeşildi | Her test dosyası kendi şemasında koşarsa; paylaşılan tek Postgres kalktığı an bedeli de kalkar |
| Kök `.nvmrc` + dört kopya senkron testi | .pptx yükleme hatası Node 22'de düşüyor, 24'te geçiyordu; kökte açılan kabuk 24 alıyordu | Sürüm tek yerden okunursa (yalnız `package.json` engines) ya da doğrulama üretimin konteynerinde koşarsa |
| `seed demo` local-only guard | Yerel veritabanında hiç kullanıcı yoktu, test ortamı fiilen production olmuştu; parola kaynak kodda yazılı | Demo parolası kaynaktan çıkarsa. Guard'ın kendisi **bayrakla esnetilmez** — bkz. yukarısı |
| Bu tablonun kendisi | Kurallar tek yönlü büyüyordu, bugüne kadar hiçbiri kaldırılmamıştı | Hiçbir zaman: tablo boşaldıysa dosya da boşalmıştır |
