CREATE TYPE "public"."audit_action" AS ENUM('brand_create', 'user_create', 'user_password_reset', 'membership_grant', 'membership_revoke', 'auth_login', 'auth_login_failed', 'auth_logout', 'user_password_change', 'generation_start', 'content_edit', 'content_select', 'content_download');--> statement-breakpoint
CREATE TABLE "audit_events" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"occurred_at" timestamp with time zone DEFAULT now() NOT NULL,
	"action" "audit_action" NOT NULL,
	"actor_user_id" uuid,
	"actor_username" text NOT NULL,
	"target_user_id" uuid,
	"target_username" text,
	"brand_id" uuid,
	"brand_name" text,
	"project_id" uuid,
	"project_name" text,
	"step" "workflow_step",
	"metadata" jsonb DEFAULT '{}'::jsonb NOT NULL
);
--> statement-breakpoint
CREATE INDEX "audit_events_occurred_at_idx" ON "audit_events" USING btree ("occurred_at" DESC NULLS LAST);--> statement-breakpoint
CREATE INDEX "audit_events_actor_idx" ON "audit_events" USING btree ("actor_user_id","occurred_at" DESC NULLS LAST);--> statement-breakpoint
CREATE INDEX "audit_events_coalesce_idx" ON "audit_events" USING btree ("actor_user_id","project_id","action","occurred_at" DESC NULLS LAST);--> statement-breakpoint
--
-- APPEND-ONLY ENFORCEMENT (T41). Hand-written: Drizzle does not model triggers,
-- so this block is maintained by hand. A future `db:generate` will not know
-- about it and will not remove it — it only ever emits NEW migration files.
--
-- The application layer already exports no update and no delete path
-- (core/audit/service.ts). This is the layer that covers what the application
-- cannot see: a stray migration, a psql session, a future ORM call that does not
-- go through that module.
--
-- It RAISES rather than using a `DO INSTEAD NOTHING` rule. A rule that silently
-- discarded the write would leave the caller believing it succeeded, which is
-- precisely the silent failure CLAUDE.md hard rule 5 forbids — and in an audit
-- table, a caller who thinks they deleted a row and did not is arguably worse
-- off than one who gets an error.
--
-- Scope of the promise: triggers fire for the table owner and for a superuser,
-- so this is not bypassed by ordinary application credentials. It IS bypassed by
-- anyone able to run DDL (`ALTER TABLE ... DISABLE TRIGGER`, `DROP TRIGGER`) or
-- to set `session_replication_role = replica`. That is unavoidable inside the
-- audited database; the value is that erasure now requires a deliberate,
-- privileged, conspicuous act instead of a one-line UPDATE.
--
CREATE OR REPLACE FUNCTION audit_events_append_only() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION
    'audit_events is append-only: % is not permitted', TG_OP
    USING ERRCODE = 'restrict_violation';
END;
$$ LANGUAGE plpgsql;--> statement-breakpoint
CREATE TRIGGER audit_events_no_update_or_delete
  BEFORE UPDATE OR DELETE ON "audit_events"
  FOR EACH ROW EXECUTE FUNCTION audit_events_append_only();--> statement-breakpoint
--
-- TRUNCATE does not fire a row-level trigger, so it gets a statement-level one.
-- Without this, `TRUNCATE audit_events` would empty the table past every guard
-- above — the single cheapest way to erase the whole trail.
--
CREATE TRIGGER audit_events_no_truncate
  BEFORE TRUNCATE ON "audit_events"
  FOR EACH STATEMENT EXECUTE FUNCTION audit_events_append_only();
