CREATE INDEX "documents_project_idx" ON "documents" USING btree ("project_id","created_at");--> statement-breakpoint
CREATE INDEX "sessions_user_idx" ON "sessions" USING btree ("user_id");