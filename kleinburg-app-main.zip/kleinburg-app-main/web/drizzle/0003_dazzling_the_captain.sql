ALTER TABLE "projects" ADD COLUMN "platforms" text[] DEFAULT '{}' NOT NULL;
--> statement-breakpoint
-- Backfill (hand-added to the generated migration): projects created before
-- this column were implicitly generating Instagram, and some also Facebook. An
-- empty array means "not chosen yet" and blocks the pillars step, so leaving
-- these empty would strand every existing project behind a step that did not
-- exist when they were created.
--
-- Derived from what each project actually generated rather than guessed: the
-- distinct platform tags on its stored sm_posts. Projects that never reached
-- step 7 fall back to instagram, which is what they would have produced.
UPDATE "projects" p
SET "platforms" = COALESCE(
  (
    SELECT array_agg(DISTINCT lower(trim(post->>'platform')))
    FROM "step_contents" sc,
         jsonb_array_elements(sc."content"->'posts') AS post
    WHERE sc."project_id" = p."id"
      AND sc."step" = 'sm_posts'
      AND jsonb_typeof(sc."content"->'posts') = 'array'
      AND post->>'platform' IS NOT NULL
      AND lower(trim(post->>'platform')) IN ('instagram', 'facebook')
  ),
  ARRAY['instagram']
);
