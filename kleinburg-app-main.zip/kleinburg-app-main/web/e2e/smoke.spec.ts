import { test, expect } from "@playwright/test";

/**
 * Post-Render-removal integrity smoke test. Confirms the golden path still
 * works end to end after the render.yaml / docs cleanup: login, dashboard,
 * brand visibility, and the admin panel (which the doc edits touched
 * indirectly by referencing it).
 */
test("login, dashboard and admin panel golden path", async ({ page }) => {
  await page.goto("/login");
  await expect(page.getByRole("heading", { name: "Giriş yap" })).toBeVisible();

  await page.getByLabel("Kullanıcı adı").fill("test");
  await page.getByLabel("Şifre").fill("test12345678");
  await page.getByRole("button", { name: "Giriş yap" }).click();

  await expect(page).toHaveURL(/\/projects/);
  await expect(page.getByRole("heading", { name: "Merhaba, test" })).toBeVisible();
  await expect(page.locator("main").getByText("Test Marka")).toBeVisible();

  await page.getByRole("link", { name: "Yönetim paneli" }).click();
  await expect(page).toHaveURL(/\/admin/);
  await expect(page.getByRole("heading", { name: "Markalar" })).toBeVisible();
  await expect(page.getByRole("button", { name: "Test Marka" })).toBeVisible();
});
