This is a [Next.js](https://nextjs.org) project bootstrapped with [`create-next-app`](https://nextjs.org/docs/app/api-reference/cli/create-next-app).

## Testing

```bash
npm test        # non-DB suites only unless DATABASE_URL is already in the environment
npm run test:db # the FULL suite: loads web/.env, so the DB-backed tests run too
```

Roughly a third of the suite (tenancy and brand isolation, pipeline steps, jobs,
auth sessions, schema constraints) needs a real Postgres and is gated on
`DATABASE_URL` via `describe.skipIf(!hasDb)`. `npm test` does **not** read
`web/.env`, so those suites skip unless you exported the variable yourself — and a
run with dozens of files skipped still prints a green summary. No count is quoted
here on purpose: the banner below prints the live one, and a hardcoded number in
prose goes stale silently.

To avoid mistaking that for a passing full suite, a run with the gate closed ends
in a loud banner naming how many files and tests were skipped, and which areas
they covered. If you see it, the run you just did was not the full suite. Start
the local database and use the explicit command:

```bash
npm run db:up && npm run test:db
```

`npm run test:db` uses `node --env-file-if-exists`, which needs **Node >= 22.9**
(see `engines` in `package.json` and `.nvmrc`). `nvm use` picks it up in `web/`
**and at the repo root** — the root `.nvmrc` is a symlink to this one, so there
is a single copy of the number. It was added because a shell opened at the root
used to get the machine default (Node 24 on the dev machine) while CI
runs 22, which is how a .pptx bug that only fails on 22 reached production.
`src/test/nvmrc-sync.test.ts` fails if the root file, this one, the CI workflow
and `engines` stop agreeing.

The banner's numbers are meant to be taken literally: the count it prints is the
count that becomes passing when you run the command it suggests. It therefore
counts only skips attributable to the DB gate. The gated suites are listed
explicitly in `src/test/db-gate-reporter.ts`, and `db-gate-reporter.test.ts`
reads every `skipIf(!hasDb)` out of the source tree and fails if the list has
drifted. Skips with another cause — `worker.test.ts` also gates its pg-boss round
trip on `RUN_PGBOSS_TEST=1`, which stays skipped even with Postgres up — are not
counted, and the areas named in the banner are derived from the gates that
actually closed, so a filtered run names only what that run skipped. The banner
is suppressed on failed and interrupted runs, where burying real failures under
it would be the opposite of helpful.

The CI workflow (`.github/workflows/web-ci.yml`, currently disabled on GitHub) sets
`DATABASE_URL` as a job-level `env:`, so the banner never fires there once it is re-enabled. A missing variable while `GITHUB_ACTIONS` is set
is a hard failure instead — the check deliberately does **not** look at the generic
`CI` variable, which Docker builds, husky hooks and many shells also set (and
`CI=false` would be truthy). To run without a database on Actions on purpose, set
`ALLOW_MISSING_DATABASE_URL=1`. See `src/test/db-gate.ts`.

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

## Fonts and theme

The typeface is **Space Grotesk**, loaded through `next/font/google` in
`src/lib/fonts.ts` as a stand-in for Baikal (commercial). It is not chosen there:
`design/tokens.json` is the theme's single source, and `npm run build:theme`
regenerates `src/app/theme.generated.css` from it. Edit the token, not the CSS.

## Deployment

Hosting is undetermined — the previous Render setup (`render.yaml`,
`docs/DEPLOY_RENDER.md`) was removed while a new target is chosen. One web
service plus Postgres, migrations run before the server starts; a runbook for
the new host belongs here once it's picked.
