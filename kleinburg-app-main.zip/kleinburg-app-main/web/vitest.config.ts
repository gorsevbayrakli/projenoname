import { fileURLToPath } from "node:url";

import { defineConfig } from "vitest/config";

import { DB_GATED_SUITES, DbGateReporter } from "./src/test/db-gate-reporter";

// Match the tsconfig "@/*" path alias so tests can import source the same way
// app code does (Next/tsc resolve it; vitest needs it spelled out here).
const resolve = {
  alias: {
    "@": fileURLToPath(new URL("./src", import.meta.url)),
  },
};

// Use the automatic JSX runtime (react/jsx-runtime) when transforming *.tsx.
// App components are authored Next-style with no `import React`, so the
// default classic runtime would throw "React is not defined". This keeps
// component tests working without a Babel-based React plugin (which conflicts
// with shadcn's pinned @babel/core). The global test env stays `node`; only
// *.test.tsx opt into jsdom via a per-file `// @vitest-environment` pragma.
const esbuild = {
  jsx: "automatic",
  jsxImportSource: "react",
} as const;

/**
 * ── WHY THE SUITE IS SPLIT IN TWO ────────────────────────────────────────
 * Every test file below runs against ONE shared Postgres. Vitest runs files in
 * parallel by default, so any assertion about a GLOBAL fact — how many active
 * admins exist, how many audit rows a table holds — is being asserted while
 * other FILES are concurrently creating exactly those rows.
 *
 * That is not hypothetical and it is not fixable inside the test. It was
 * measured: `admin/service.test.ts`'s "REFUSES to demote the last remaining
 * admin" failed in 3 of 6 full runs and passed every time in isolation, because
 * seven other files (`admin-spend`, `cap-enforcement`,
 * `admin-spend-fail-closed`, `roles`, `spend`, `audit/service`,
 * `admin/audit-rollback`) create admin users of their own. The test's
 * quarantine-and-restore in beforeEach/afterEach cannot help: it clears rows
 * left behind by EARLIER tests, and these arrive DURING the assertion.
 *
 * The reason this matters more than the seconds it costs: a suite that fails
 * half the time teaches the next person to re-run it rather than to read it,
 * and that is the habit through which a real regression gets waved past. A slow
 * green suite is worth more than a fast one nobody believes.
 *
 * So DB-touching files run one at a time (`fileParallelism: false`), and
 * everything else keeps running in parallel. Measured on this machine: all
 * files parallel 10s but flaky, ALL files serial 40s, this split 25s and
 * stable. The pure-unit majority is where the parallelism was actually paying.
 *
 * ── WHERE THE LIST COMES FROM, AND WHY IT IS NOT A LIST ──────────────────
 * The serial project's `include` is derived from `DB_GATED_SUITES`, the
 * registry that already exists to explain the closed-gate banner. It is NOT a
 * second copy maintained by hand, and that is the whole point: a hand-kept list
 * of database files would silently rot the first time someone added one, and
 * the symptom would be this same intermittent failure, arriving months later
 * with no obvious cause.
 *
 * `db-gate-reporter.test.ts` already fails when the registry and the
 * `skipIf(!hasDb)` gates in the source tree disagree, in either direction. So a
 * new DB-backed test file cannot be added without registering it, and
 * registering it serialises it here automatically. The mechanism enforces the
 * rule; nobody has to remember it.
 */
const dbTestFiles = [...new Set(DB_GATED_SUITES.map((s) => s.module))];

export default defineConfig({
  resolve,
  esbuild,
  test: {
    // Without DATABASE_URL the DB-backed suites skip themselves and the run
    // still reads as a success. DbGateReporter is listed after `default` so its
    // banner lands under the summary (see the caveat on the class — the order
    // is conventional, not contractual); globalSetup turns the same condition
    // into a hard failure on this repo's CI. See src/test/db-gate.ts.
    //
    // Both stay at the ROOT rather than moving into the projects below:
    // reporters and globalSetup are per-RUN concerns, and duplicating them per
    // project would print the banner twice and run the CI check twice.
    reporters: ["default", new DbGateReporter()],
    globalSetup: ["./src/test/db-gate.ts"],
    projects: [
      {
        resolve,
        esbuild,
        test: {
          name: "db",
          environment: "node",
          include: dbTestFiles,
          // The one setting this whole comment block is about.
          fileParallelism: false,
        },
      },
      {
        resolve,
        esbuild,
        test: {
          name: "unit",
          environment: "node",
          include: ["src/**/*.test.{ts,tsx}", "scripts/**/*.test.{ts,tsx}"],
          exclude: dbTestFiles,
        },
      },
    ],
  },
});
