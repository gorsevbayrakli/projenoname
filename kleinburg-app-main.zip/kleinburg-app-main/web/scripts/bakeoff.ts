/**
 * Model bake-off harness — runs the whole generative pipeline against a FIXED
 * brief and dumps every step's output to disk, so two models can be compared
 * on identical inputs.
 *
 * Usage:
 *   npx tsx scripts/bakeoff.ts --brief <path> --label <name> [--platforms instagram,linkedin] [--posts 10]
 *
 * The model is whatever OPENROUTER_MODEL says (see core/llm/models.ts), so a
 * comparison run is:
 *   OPENROUTER_MODEL=anthropic/claude-sonnet-5 npx tsx scripts/bakeoff.ts --brief b.txt --label sonnet5
 *   OPENROUTER_MODEL=openai/gpt-5.4          npx tsx scripts/bakeoff.ts --brief b.txt --label gpt54
 * then diff the two run directories.
 *
 * COSTS REAL MONEY. Every step is a live OpenRouter call. Not part of the test
 * suite, like scripts/llm-smoke.ts, and for the same reason.
 *
 * WHY IT WRITES TO THE DATABASE: the pipeline reads each step's input from
 * step_contents (see core/pipeline/inputs.ts gatherVars), so there is no way to
 * run step 7 without step 2's output being stored. The harness therefore creates
 * a throwaway brand + project, runs through it, and leaves the rows behind for
 * inspection. Pass --cleanup to delete the brand (cascades) when done.
 *
 * SELECTIONS ARE LEFT NULL on purpose. `selectItems` treats null as "all items
 * selected", so every generated item flows into the next step. That is the
 * deterministic choice: a human picking a subset is exactly the variable a
 * model comparison must hold constant.
 */
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

import { eq } from "drizzle-orm";

import { closeDb, getDb } from "../src/core/db/client";
import {
  brands,
  documents,
  generationJobs,
  llmCalls,
  projects,
  type WorkflowStep,
} from "../src/core/db/schema";
import { createJob, markFailed, markSucceeded } from "../src/core/jobs/jobs";
import { defaultModel } from "../src/core/llm/models";
import { recommendPostCounts } from "../src/core/pipeline/cadence";
import { upsertStepContent } from "../src/core/pipeline/inputs";
import { runStep } from "../src/core/pipeline/run-step";
import { sortPlatforms, type Platform } from "../src/core/platforms";

try {
  process.loadEnvFile();
} catch {
  // no .env file present; rely on the process environment
}

// ── args ───────────────────────────────────────────────────────────────────

function arg(name: string, fallback?: string): string {
  const i = process.argv.indexOf(`--${name}`);
  const value = i >= 0 ? process.argv[i + 1] : undefined;
  if (value === undefined || value.startsWith("--")) {
    if (fallback !== undefined) return fallback;
    throw new Error(`--${name} gerekli`);
  }
  return value;
}

const hasFlag = (name: string) => process.argv.includes(`--${name}`);

// ── run ────────────────────────────────────────────────────────────────────

interface StepRecord {
  step: string;
  ok: boolean;
  ms: number;
  error?: string;
}

async function main() {
  if (!process.env.OPENROUTER_API_KEY) {
    console.error("OPENROUTER_API_KEY yok. web/.env içine koyun.");
    process.exit(1);
  }

  const briefPath = arg("brief");
  const label = arg("label");
  const brief = readFileSync(briefPath, "utf8");
  const userInput = hasFlag("user-input")
    ? readFileSync(arg("user-input"), "utf8")
    : arg("user-input-text", "Bu marka için bir aylık sosyal medya içerik planı hazırla.");
  const platforms = sortPlatforms(
    arg("platforms", "instagram,linkedin").split(","),
  ) as Platform[];
  const postsPerPlatform = Number(arg("posts", "10"));
  const language = arg("language", "tr");

  const model = defaultModel();
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const outDir = join(arg("out", "bakeoff-runs"), `${label}-${stamp}`);
  mkdirSync(outDir, { recursive: true });

  const dump = (name: string, data: unknown) =>
    writeFileSync(
      join(outDir, `${name}.json`),
      JSON.stringify(data, null, 2),
      "utf8",
    );

  console.log(`Model:      ${model}`);
  console.log(`Brief:      ${briefPath} (${brief.length} karakter)`);
  console.log(`Platforms:  ${platforms.join(", ")} @ ${postsPerPlatform} post`);
  console.log(`Çıktı:      ${outDir}\n`);

  const db = getDb();
  const runName = `bakeoff-${label}-${stamp}`;

  const [brand] = await db.insert(brands).values({ name: runName }).returning();
  const [project] = await db
    .insert(projects)
    .values({
      brandId: brand.id,
      name: runName,
      language: language as "tr" | "en",
      platforms,
      postCounts: Object.fromEntries(
        platforms.map((p) => [p, postsPerPlatform]),
      ),
      createdBy: null,
    })
    .returning();
  // `kind` records where the text came from. The harness is handed ALREADY
  // EXTRACTED text (it does not run document_processor), so a .txt brief is
  // labelled by its real origin where the extension says so, and "docx"
  // otherwise — the format brand documents actually arrive in.
  const ext = (briefPath.split(".").pop() ?? "").toLowerCase();
  const kind = (["pdf", "docx", "pptx", "url"] as const).includes(
    ext as "pdf" | "docx" | "pptx" | "url",
  )
    ? (ext as "pdf" | "docx" | "pptx" | "url")
    : ("docx" as const);

  await db.insert(documents).values({
    projectId: project.id,
    filename: briefPath.split("/").pop() ?? "brief.txt",
    kind,
    extractedText: brief,
  });

  console.log(`Proje: ${project.id}\n`);

  const records: StepRecord[] = [];

  /**
   * Run one generative step inside a real generation_jobs row, so its
   * llm_calls rows carry a job_id and the cost report below is complete.
   * `recordLlmCall` returns early without one (see core/llm/openrouter.ts).
   */
  async function step(
    name: WorkflowStep,
    jobInput: Record<string, unknown> = {},
    saveAs: WorkflowStep = name,
  ): Promise<unknown> {
    const started = Date.now();
    process.stdout.write(`→ ${name}${jobInput.platform ? ` (${jobInput.platform})` : ""} ... `);
    const job = await createJob(project.id, name, jobInput, null);
    try {
      const output = await runStep(project.id, name, jobInput, job.id);
      await markSucceeded(job.id, output);
      await upsertStepContent(project.id, saveAs, output);
      const ms = Date.now() - started;
      records.push({ step: name, ok: true, ms });
      console.log(`ok (${(ms / 1000).toFixed(1)}s)`);
      return output;
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      await markFailed(job.id, message);
      const ms = Date.now() - started;
      records.push({ step: name, ok: false, ms, error: message });
      console.log(`HATA: ${message}`);
      throw err;
    }
  }

  try {
    // 1/8 — brand context (reads the uploaded brief)
    dump("01-brand_context", await step("brand_context"));

    // 2+3/8 — secondary data: retrieval (sonar) + writing (default model)
    dump("02-03-secondary_data", await step("secondary_data"));

    // step 4 is the human's own text — fixed, no model call
    await upsertStepContent(project.id, "user_input", { text: userInput });
    writeFileSync(join(outDir, "04-user_input.txt"), userInput, "utf8");

    // 4/8 — creative sparks
    dump("05-creative_sparks", await step("creative_sparks"));

    // 5/8 — cadence advice. Not a wizard step and not routed through runStep;
    // it opens its own synthetic job (see core/pipeline/cadence.ts).
    process.stdout.write("→ platform_cadence ... ");
    const cadenceStart = Date.now();
    const cadence = await recommendPostCounts(project.id, platforms, null);
    const cadenceMs = Date.now() - cadenceStart;
    records.push({ step: "platform_cadence", ok: true, ms: cadenceMs });
    console.log(`ok (${(cadenceMs / 1000).toFixed(1)}s)`);
    dump("06-platform_cadence", cadence);
    // NOT applied to the project: the comparison holds post counts constant.

    // 6/8 — pillars
    dump("07-sm_pillars", await step("sm_pillars"));

    // 7/8 — posts, one call per platform (they merge into one stored row)
    for (const platform of platforms) {
      dump(
        `08-sm_posts-${platform}`,
        await step("sm_posts", { platform }),
      );
    }

    // 8/8 — calendar
    dump("09-content_calendar", await step("content_calendar"));
  } catch (err) {
    // NEVER swallow the reason. The first baseline run printed only "Run yarıda
    // kesildi" and the actual cause — a step burning the provider's default
    // completion ceiling — had to be dug out of generation_jobs afterwards.
    // A harness that hides why it stopped is worse than one that crashes.
    const message = err instanceof Error ? err.message : String(err);
    console.log(`\nRun yarıda kesildi: ${message}`);
    console.log("O ana kadarki çıktılar kaydedildi.");
  }

  // ── cost + token report ──────────────────────────────────────────────────
  // llm_calls has no project_id of its own; it is reached through the job.
  const calls = await db
    .select({
      step: generationJobs.step,
      model: llmCalls.model,
      promptTokens: llmCalls.promptTokens,
      completionTokens: llmCalls.completionTokens,
      costUsd: llmCalls.costUsd,
      durationMs: llmCalls.durationMs,
    })
    .from(llmCalls)
    .innerJoin(generationJobs, eq(llmCalls.jobId, generationJobs.id))
    .where(eq(generationJobs.projectId, project.id));

  const meta = {
    label,
    model,
    briefPath,
    platforms,
    postsPerPlatform,
    language,
    projectId: project.id,
    startedAt: stamp,
    steps: records,
    llmCalls: calls,
  };
  dump("00-meta", meta);

  const totalCost = meta.llmCalls.reduce(
    (sum, c) => sum + Number(c.costUsd ?? 0),
    0,
  );
  const totalOut = meta.llmCalls.reduce(
    (sum, c) => sum + Number(c.completionTokens ?? 0),
    0,
  );
  console.log(
    `\nToplam: ${meta.llmCalls.length} çağrı, ${totalOut} çıktı token, $${totalCost.toFixed(4)}`,
  );
  console.log(`Çıktılar: ${outDir}`);

  if (hasFlag("cleanup")) {
    await db.delete(brands).where(eq(brands.id, brand.id));
    console.log("Veritabanı satırları silindi (--cleanup).");
  } else {
    console.log(`Proje veritabanında bırakıldı: ${project.id}`);
  }

  await closeDb();
}

main().catch(async (err) => {
  console.error(err);
  await closeDb();
  process.exit(1);
});
