/**
 * Manual live check — needs OPENROUTER_API_KEY; costs a few tokens.
 * Run: npm run llm:smoke
 *
 * Makes one tiny real structured call (asks the model for "2+2") and prints the
 * parsed result plus token usage. Intentionally NOT part of the test suite: it
 * hits the live OpenRouter API and spends money.
 */
import { z } from "zod";

import { generateStructured } from "../src/core/llm/openrouter";
import { defaultModel } from "../src/core/llm/models";

try {
  process.loadEnvFile();
} catch {
  // no .env file present; rely on the process environment
}

async function main() {
  if (!process.env.OPENROUTER_API_KEY) {
    console.error(
      "OPENROUTER_API_KEY is not set. Set it in web/.env (or the environment) before running this live smoke check.",
    );
    process.exit(1);
  }

  const schema = z.object({ answer: z.number() });
  const model = defaultModel();

  console.log(`Calling ${model} for a structured {answer:number}...`);
  const result = await generateStructured({
    prompt: "What is 2 + 2? Respond as JSON matching the schema.",
    schema,
    model,
    // `unrecorded`: a connectivity smoke test has no job row to bill against.
    unrecorded: true,
  });

  console.log("Result:", result);
  console.log("(no jobId passed, so no usage row was recorded)");
}

main().catch((err) => {
  console.error("llm:smoke failed:", err);
  process.exit(1);
});
