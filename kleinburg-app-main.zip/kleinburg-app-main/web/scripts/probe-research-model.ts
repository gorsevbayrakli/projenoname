/**
 * Live probe for candidate secondary_data RETRIEVAL models.
 *
 * Answers three questions the OpenRouter catalogue cannot, in one cheap call
 * per model:
 *   1. does the account's data policy / allowlist let us reach it at all?
 *   2. does it honour `json_schema` strict mode with the step's REAL schema?
 *   3. does it actually search — i.e. come back with citations?
 *
 * Why a probe rather than reading the catalogue: OpenRouter reports
 * `structured_outputs: false` for BOTH perplexity/sonar (which works in
 * production today) and perplexity/sonar-reasoning-pro, so the flag does not
 * distinguish them. Only a real call does.
 *
 * The reasoning-model hazard this is really looking for: a reasoning model
 * emits a think block before the JSON and `response_format` is not documented
 * to strip it, which would surface here as a JSON/schema error rather than a
 * transport error. The two are reported separately below for that reason.
 *
 * Run: npx tsx scripts/probe-research-model.ts [model ...]
 * Costs a few cents. Never part of the test suite.
 */
import { generateStructured } from "../src/core/llm/openrouter";
import { RESEARCH_MODEL } from "../src/core/llm/models";
import { renderPrompt } from "../src/core/pipeline/prompts";
import { researchRetrievalSchema } from "../src/core/pipeline/schemas";

try {
  process.loadEnvFile();
} catch {
  // no .env file present; rely on the process environment
}

const CANDIDATES =
  process.argv.slice(2).length > 0
    ? process.argv.slice(2)
    : [RESEARCH_MODEL, "perplexity/sonar-reasoning-pro"];

/**
 * A real brand context, not "test": a search model given a placeholder returns
 * nothing to cite, which would look identical to a model that cannot search.
 */
const BRAND_CONTEXT = `Marka: Doğadan
Kategori: Bitki çayı ve sıcak içecek.
Pazar: Türkiye. Hedef kitle: 25-45 yaş, sağlıklı yaşam ve doğal ürünlere ilgi duyan tüketiciler.
Konum: Doğal, katkısız, Anadolu bitkilerinden.`;

async function probe(model: string) {
  const started = Date.now();
  process.stdout.write(`\n── ${model}\n`);

  const citations: string[] = [];
  try {
    const output = await generateStructured({
      prompt: renderPrompt("secondarydata_retrieval_prompt", {
        BRAND_CONTEXT,
        language: "Turkish",
      }),
      schema: researchRetrievalSchema,
      model,
      onCitations: (list) => citations.push(...list.map((c) => c.url)),
      // `unrecorded`: an operator probe run from a terminal has no job row to
      // bill against. Listed by name in every-call-recorded.test.ts (#68).
      unrecorded: true,
    });

    const findings = output.findings ?? [];
    console.log(`   ERİŞİM      : ok (${((Date.now() - started) / 1000).toFixed(1)}s)`);
    console.log(`   ŞEMA        : ok — ${findings.length} bulgu`);
    console.log(
      `   ARAMA       : ${citations.length > 0 ? `ok — ${citations.length} atıf` : "ATIF YOK (aramamış olabilir)"}`,
    );
    const first = findings[0]?.note ?? "";
    console.log(`   İlk not     : ${first.slice(0, 110)}${first.length > 110 ? "…" : ""}`);
    // The defect that split this step in two (#52): the retrieval model mangles
    // non-ASCII letters. Reported even though these notes are never shown to a
    // user, because a model that survives it could carry the writing call too.
    const nonAscii = /[^\x00-\x7F]/.test(findings.map((f) => f.note).join(""));
    console.log(`   Not dili    : ${nonAscii ? "ASCII dışı karakter var" : "saf ASCII (beklenen)"}`);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    // Split the two failure modes, because they mean opposite things: a
    // transport/404 is an access problem (policy, allowlist), while a JSON or
    // schema error is the model failing to honour strict mode — the reasoning
    // think-block hazard.
    const kind = /schema|JSON|parse|truncat/i.test(message)
      ? "ŞEMA/JSON HATASI (strict mode tutmadı)"
      : "ERİŞİM/TRANSPORT HATASI";
    console.log(`   ${kind}`);
    console.log(`   ${message.slice(0, 400)}`);
  }
}

async function main() {
  if (!process.env.OPENROUTER_API_KEY) {
    console.error("OPENROUTER_API_KEY yok (web/.env).");
    process.exit(1);
  }
  console.log(`Aday modeller: ${CANDIDATES.join(", ")}`);
  for (const model of CANDIDATES) await probe(model);
  console.log("");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
