/**
 * Seed CLI for local/ops bootstrapping.
 *
 * Usage:
 *   npm run seed -- create-admin <username> [password]
 *   npm run seed -- create-user <username> [password]
 *   npm run seed -- set-password <username> [password]
 *   npm run seed -- create-brand <name>
 *   npm run seed -- grant-access <username> <brandName>
 *   npm run seed demo                                  (LOCAL DATABASES ONLY)
 *
 * Omit the password and it is prompted for without echoing. Prefer that: a
 * password passed as an argv lands in the shell history (and in any screenshot
 * of the session), which is how the first production admin credential leaked.
 *
 * ── `demo` AND THE RULE ABOVE ────────────────────────────────────────────
 * `demo` breaks that rule on purpose: its password is a constant in
 * `src/lib/demo-seed.ts`, which is worse than shell history — it is public,
 * permanent, and identical on every machine. It is allowed to exist for exactly
 * one reason: `assertLocalDatabase` (src/core/db/local-only.ts) refuses to run
 * it against anything but a local database, so the credential it plants cannot
 * reach a database where knowing it would matter.
 *
 * That guard is the whole justification. There is no flag, env var or override
 * that relaxes it, and adding one would remove the reason `demo` was accepted
 * in the first place. If somebody genuinely needs an account on a real
 * database, `create-admin` above already prompts for a password nobody else
 * knows — that is the answer, not a `--force` on this command.
 *
 * WHY IT EXISTS: the local database had zero users, so the wizard could not be
 * walked locally at all and production had become the test environment. Three
 * bugs in one week were found only in production because of it.
 *
 * SCOPE NOTE (T40): this CLI is now the BOOTSTRAP path only — enough to create
 * the first super admin, who then does everything else from /admin in the app.
 * The two differ in one deliberate way: accounts made here are NOT flagged
 * `must_change_password`, because whoever runs `create-admin` is typing their
 * own password at the prompt, while the panel's admin types a password for
 * somebody else. If `create-user` here ever becomes a routine way to onboard
 * other people, it should set that flag too.
 */
import { createInterface } from "node:readline";
import { and, eq } from "drizzle-orm";
import { closeDb, getDb } from "../src/core/db/client";
import {
  brands,
  documents,
  projects,
  stepContents,
  userBrands,
  users,
} from "../src/core/db/schema";
import { hashPassword } from "../src/core/auth/password";
import { assertLocalDatabase } from "../src/core/db/local-only";
import {
  DEMO_BRAND_CONTEXT,
  DEMO_BRAND_NAME,
  DEMO_CREATIVE_SPARKS,
  DEMO_DOCUMENT,
  DEMO_PASSWORD,
  DEMO_PILLARS,
  DEMO_PILLAR_SELECTED_INDICES,
  DEMO_PLATFORMS,
  DEMO_POSTS,
  DEMO_POST_COUNTS,
  DEMO_PROJECT_NAME,
  DEMO_SECONDARY_DATA,
  DEMO_USERNAME,
  DEMO_USER_INPUT,
} from "../src/lib/demo-seed";

// getDb() reads DATABASE_URL; load .env the same way drizzle.config.ts does.
try {
  process.loadEnvFile();
} catch {
  // no .env file present; rely on the process environment
}

const USAGE = `Usage:
  seed create-admin <username> [password]
  seed create-user <username> [password]
  seed set-password <username> [password]
  seed create-brand <name>
  seed grant-access <username> <brandName>
  seed demo                                  (LOCAL DATABASES ONLY)

Omit [password] to be prompted for it without echoing (keeps it out of shell history).`;

/**
 * Read a password from stdin without echoing it. On a TTY we mute the output
 * stream while typing; when stdin is a pipe (CI, `echo … | seed`) there is
 * nothing to mute and we just read the line.
 */
let rlSingleton: ReturnType<typeof createInterface> | null = null;

/**
 * One readline interface for the whole process. Opening a fresh one per prompt
 * looks tidier but breaks on piped stdin: the first interface consumes the
 * stream and every later prompt hangs, exiting silently with code 0.
 */
function getReadline(): ReturnType<typeof createInterface> {
  if (rlSingleton) return rlSingleton;
  const isTty = Boolean(process.stdin.isTTY);
  const rl = createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: isTty,
  });
  if (isTty) {
    // Swallow the echoed characters; keep the newline so the cursor moves on.
    const write = process.stdout.write.bind(process.stdout);
    (rl as unknown as { _writeToOutput: (s: string) => void })._writeToOutput = (
      s: string,
    ) => {
      if (s.includes("\n")) write("\n");
    };
  }
  rlSingleton = rl;
  return rl;
}

function closeReadline(): void {
  rlSingleton?.close();
  rlSingleton = null;
}

/** Lines already read from stdin but not yet consumed by a prompt. */
const pending: string[] = [];
/** A prompt waiting for a line that has not arrived yet. */
let waiter: ((line: string | null) => void) | null = null;
let ended = false;

let reading = false;

function startReading(): void {
  if (reading) return;
  reading = true;
  const rl = getReadline();
  rl.on("line", (line: string) => {
    if (waiter) {
      const w = waiter;
      waiter = null;
      w(line);
    } else {
      // Piped input delivers every line in one tick, well before the later
      // prompts ask for them. Queue them instead of dropping them.
      pending.push(line);
    }
  });
  rl.on("close", () => {
    ended = true;
    if (waiter) {
      const w = waiter;
      waiter = null;
      w(null);
    }
  });
}

function nextLine(): Promise<string | null> {
  const queued = pending.shift();
  if (queued !== undefined) return Promise.resolve(queued);
  if (ended) return Promise.resolve(null);
  return new Promise((resolve) => {
    waiter = resolve;
  });
}

async function promptPassword(label: string): Promise<string> {
  startReading();
  process.stdout.write(`${label}: `);
  const line = await nextLine();
  if (line === null) throw new Error(`no input for "${label}"`);
  const trimmed = line.trim();
  if (!trimmed) throw new Error("password must not be empty");
  return trimmed;
}

/** Take the password from argv when given, otherwise prompt for it. */
async function resolvePassword(fromArgv: string | undefined): Promise<string> {
  if (fromArgv) return fromArgv;
  const password = await promptPassword("Password");
  const confirm = await promptPassword("Confirm password");
  if (password !== confirm) throw new Error("passwords do not match");
  return password;
}

async function createUser(
  username: string,
  password: string,
  role: "admin" | "user",
): Promise<string> {
  const db = getDb();
  const existing = await db.query.users.findFirst({
    where: eq(users.username, username),
  });
  if (existing) {
    throw new Error(`user "${username}" already exists`);
  }
  const passwordHash = await hashPassword(password);
  const [row] = await db
    .insert(users)
    .values({ username, passwordHash, role })
    .returning();
  return `Created ${role} "${row.username}" (id ${row.id})`;
}

async function createBrand(name: string): Promise<string> {
  const db = getDb();
  const existing = await db.query.brands.findFirst({
    where: eq(brands.name, name),
  });
  if (existing) {
    throw new Error(`brand "${name}" already exists`);
  }
  const [row] = await db.insert(brands).values({ name }).returning();
  return `Created brand "${row.name}" (id ${row.id})`;
}

/**
 * Rotate an existing user's password. Sessions are NOT invalidated here — the
 * sessions table cascades on user delete, not on password change — so an
 * already-signed-in browser stays signed in until its session expires.
 */
async function setPassword(
  username: string,
  password: string,
): Promise<string> {
  const db = getDb();
  const user = await db.query.users.findFirst({
    where: eq(users.username, username),
  });
  if (!user) throw new Error(`user "${username}" not found`);
  const passwordHash = await hashPassword(password);
  await db.update(users).set({ passwordHash }).where(eq(users.id, user.id));
  return `Password updated for "${username}"`;
}

async function grantAccess(
  username: string,
  brandName: string,
): Promise<string> {
  const db = getDb();
  const user = await db.query.users.findFirst({
    where: eq(users.username, username),
  });
  if (!user) throw new Error(`user "${username}" not found`);
  const brand = await db.query.brands.findFirst({
    where: eq(brands.name, brandName),
  });
  if (!brand) throw new Error(`brand "${brandName}" not found`);

  const inserted = await db
    .insert(userBrands)
    .values({ userId: user.id, brandId: brand.id })
    .onConflictDoNothing()
    .returning();
  return inserted.length > 0
    ? `Granted "${username}" access to brand "${brandName}"`
    : `"${username}" already has access to brand "${brandName}" (no change)`;
}

/**
 * Everything needed to walk the wizard locally, in one idempotent command.
 *
 * ── IDEMPOTENT, NOT "CREATE ONCE" ────────────────────────────────────────
 * Every write is an upsert or a conflict-tolerant insert, so re-running is
 * safe and is the normal way to reset the demo project after clicking through
 * it. The other commands in this file throw on an existing row; that is right
 * for them (creating an admin that already exists is a mistake worth hearing
 * about) and wrong for this one, whose whole job is to reach a known state.
 *
 * ── WHAT IT SEEDS AND WHY THAT LIST ──────────────────────────────────────
 * Steps 1-8, plus the project's platform choice (step 6, which lives on
 * `projects` rather than `step_contents`). Step 9 is assembled in code from the
 * approved posts, so it needs nothing seeded and will build itself when opened
 * — with no model call, which is the point of the whole exercise.
 *
 * `documents` and `user_input` are seeded even though they are USER actions
 * with no model call behind them: without a documents row the wizard
 * forward-locks at step 1 and nothing downstream is reachable, which would
 * leave the command short of its one promise. Uploading a real file on top of
 * the seeded one still works and is still the way to exercise the extractors.
 */
async function seedDemo(): Promise<string> {
  // FIRST STATEMENT IN THE FUNCTION, before getDb() and before any write.
  // See the module header: this is the only reason the demo password is
  // allowed to be a constant in the source.
  assertLocalDatabase({
    nodeEnv: process.env.NODE_ENV,
    databaseUrl: process.env.DATABASE_URL,
  });

  const db = getDb();
  const created: string[] = [];

  // ── User ───────────────────────────────────────────────────────────────
  // The password is re-hashed and re-applied on every run, so a demo account
  // whose password was changed by hand comes back to the documented one.
  const passwordHash = await hashPassword(DEMO_PASSWORD);
  const [user] = await db
    .insert(users)
    .values({
      username: DEMO_USERNAME,
      passwordHash,
      role: "user",
      displayName: "Demo Kullanıcı",
    })
    .onConflictDoUpdate({
      target: users.username,
      set: { passwordHash, isActive: true },
    })
    .returning();
  created.push(`user      "${user.username}" (id ${user.id})`);

  // ── Brand + membership ─────────────────────────────────────────────────
  const [brand] = await db
    .insert(brands)
    .values({ name: DEMO_BRAND_NAME })
    .onConflictDoUpdate({ target: brands.name, set: { isActive: true } })
    .returning();
  created.push(`brand     "${brand.name}" (id ${brand.id})`);

  await db
    .insert(userBrands)
    .values({ userId: user.id, brandId: brand.id })
    .onConflictDoNothing();
  created.push(`access    "${user.username}" -> "${brand.name}"`);

  // ── Project ────────────────────────────────────────────────────────────
  // `platforms` and `postCounts` are what completes wizard step 6; they live on
  // the project, not in step_contents.
  const [project] = await db
    .insert(projects)
    .values({
      brandId: brand.id,
      name: DEMO_PROJECT_NAME,
      language: "tr",
      platforms: DEMO_PLATFORMS,
      postCounts: DEMO_POST_COUNTS,
      createdBy: user.id,
    })
    .onConflictDoUpdate({
      target: [projects.brandId, projects.name],
      set: {
        language: "tr",
        platforms: DEMO_PLATFORMS,
        postCounts: DEMO_POST_COUNTS,
      },
    })
    .returning();
  created.push(`project   "${project.name}" (id ${project.id})`);

  // ── Step 1: one document ───────────────────────────────────────────────
  // `documents` has no unique constraint to conflict on (a project may hold
  // many files), so re-running would stack duplicates. Check first.
  const existingDoc = await db.query.documents.findFirst({
    where: and(
      eq(documents.projectId, project.id),
      eq(documents.filename, DEMO_DOCUMENT.filename),
    ),
  });
  if (!existingDoc) {
    await db.insert(documents).values({ projectId: project.id, ...DEMO_DOCUMENT });
  }
  created.push(
    `document  "${DEMO_DOCUMENT.filename}"${existingDoc ? " (already present)" : ""}`,
  );

  // ── Steps 2-5, 7, 8: step_contents ─────────────────────────────────────
  // Unique on (project_id, step), so one upsert per row.
  const rows = [
    {
      step: "brand_context" as const,
      content: { brandContext: DEMO_BRAND_CONTEXT },
      selections: null,
      label: "step 2  brand_context",
    },
    {
      step: "secondary_data" as const,
      content: { items: DEMO_SECONDARY_DATA },
      // Step 3 completes on >=1 SELECTED index, not on the row existing.
      selections: {
        selectedIndices: DEMO_SECONDARY_DATA.map((_, i) => i),
      },
      label: "step 3  secondary_data",
    },
    {
      step: "user_input" as const,
      content: { text: DEMO_USER_INPUT },
      selections: null,
      label: "step 4  user_input",
    },
    {
      step: "creative_sparks" as const,
      content: { items: DEMO_CREATIVE_SPARKS },
      selections: {
        selectedIndices: DEMO_CREATIVE_SPARKS.map((_, i) => i),
      },
      label: "step 5  creative_sparks",
    },
    {
      step: "sm_pillars" as const,
      content: { pillars: DEMO_PILLARS },
      // THE POINT OF THE FIXTURE: step 7 opens with these already checked
      // (2026-07-21), and this is the state that could not be inspected
      // locally before. A strict subset, so unchecked cards are visible too.
      selections: { selectedIndices: DEMO_PILLAR_SELECTED_INDICES },
      label: "step 7  sm_pillars",
    },
    {
      step: "sm_posts" as const,
      content: { posts: DEMO_POSTS },
      selections: null,
      label: "step 8  sm_posts",
    },
  ];

  for (const row of rows) {
    await db
      .insert(stepContents)
      .values({
        projectId: project.id,
        step: row.step,
        content: row.content,
        selections: row.selections,
      })
      .onConflictDoUpdate({
        target: [stepContents.projectId, stepContents.step],
        set: { content: row.content, selections: row.selections },
      });
  }
  for (const row of rows) created.push(`content   ${row.label}`);

  const summary = created.map((line) => `  ${line}`).join("\n");
  return [
    "Seeded the local demo environment:",
    summary,
    "",
    `  step 6  platforms: ${DEMO_PLATFORMS.join(", ")} ` +
      `(${DEMO_PLATFORMS.map((p) => `${p}=${DEMO_POST_COUNTS[p]}`).join(", ")})`,
    "  step 9  content_calendar is assembled in code — open it, no model call needed.",
    "",
    `Log in at http://localhost:3000 with  ${DEMO_USERNAME} / ${DEMO_PASSWORD}`,
    "",
    "Local database only. Re-run any time to reset the demo project.",
  ].join("\n");
}

async function main(): Promise<string> {
  const [command, ...args] = process.argv.slice(2);

  switch (command) {
    case "create-admin":
    case "create-user": {
      const [username, password] = args;
      if (!username) throw new Error(USAGE);
      const role = command === "create-admin" ? "admin" : "user";
      return createUser(username, await resolvePassword(password), role);
    }
    case "set-password": {
      const [username, password] = args;
      if (!username) throw new Error(USAGE);
      return setPassword(username, await resolvePassword(password));
    }
    case "create-brand": {
      const [name] = args;
      if (!name) throw new Error(USAGE);
      return createBrand(name);
    }
    case "grant-access": {
      const [username, brandName] = args;
      if (!username || !brandName) throw new Error(USAGE);
      return grantAccess(username, brandName);
    }
    case "demo":
      return seedDemo();
    default:
      throw new Error(USAGE);
  }
}

main()
  .then((message) => {
    console.log(message);
  })
  .catch((error: unknown) => {
    console.error(error instanceof Error ? error.message : String(error));
    process.exitCode = 1;
  })
  .finally(async () => {
    closeReadline();
    await closeDb();
  });
