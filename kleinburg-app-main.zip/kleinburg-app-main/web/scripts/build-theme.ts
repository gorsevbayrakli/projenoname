/**
 * Thin CLI wrapper: design/tokens.json -> src/app/theme.generated.css
 * Run with `npm run build:theme` (tsx). Pure transforms live in
 * src/core/theme/buildTheme.ts so they stay unit-testable.
 */
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { buildThemeCss, type DesignTokens } from "../src/core/theme/buildTheme";

const webRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const tokensPath = resolve(webRoot, "..", "design", "tokens.json");
const outPath = resolve(webRoot, "src", "app", "theme.generated.css");

const tokens = JSON.parse(readFileSync(tokensPath, "utf8")) as DesignTokens;
writeFileSync(outPath, buildThemeCss(tokens), "utf8");
console.log(`build-theme: wrote ${outPath}`);
