import type { AuditLang } from "./rubric";
import type { JudgeResult } from "./schemas";
import type { RunResult } from "./report";

export type GeneratedRun = {
  lang: AuditLang;
  model: string;
  content: string;
};

export type JudgeFn = (
  lang: AuditLang,
  content: string
) => Promise<JudgeResult>;

export async function auditRuns(
  runs: GeneratedRun[],
  judge: JudgeFn
): Promise<RunResult[]> {
  const results: RunResult[] = [];

  for (const run of runs) {
    try {
      const judgeResult = await judge(run.lang, run.content);
      results.push({
        lang: run.lang,
        model: run.model,
        judge: judgeResult,
      });
    } catch (err) {
      // Isolate the failure to this one run — a single bad judge call (parse
      // failure after retry, or a raw network/API error) must not abort the
      // whole batch and lose every other already-judged (or worse,
      // already-generated) run. See task-7 final-review fix.
      results.push({
        lang: run.lang,
        model: run.model,
        judge: null,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  return results;
}
