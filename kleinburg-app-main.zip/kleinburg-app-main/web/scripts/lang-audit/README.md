# Lang-audit harness

Measures whether the generative pipeline produces native-quality German,
Italian, French and Spanish output — not whether the prompts are "good" in the
abstract. The audit measures first; fixing the engine's prompts based on what
it finds is explicitly out of scope for this task (see
`.superpowers/sdd/task-7-brief.md`).

Modules (all unit-tested, see their own `*.test.ts`):

- `rubric.ts` — `BANNED_TERMS` per language, `buildJudgePrompt`.
- `schemas.ts` — `JudgeResult` / `JudgeResultSchema` (Zod).
- `judge.ts` — `makeJudge(callModel)`: prompts the judge, validates the
  reply, retries once on a malformed response.
- `audit.ts` — `auditRuns(runs, judge)`: runs the judge over each generated
  run.
- `verdict.ts` / `report.ts` — weighted scoring and the Markdown report.
- `fixture/{de,it,fr,es}.txt` — four native Köken briefs. **Native review of
  these fixtures is still pending** — they were written to read as native
  brand documents, but nobody with native fluency has signed off on them yet.
  A finding of "poor nativeTone" from a run against a non-reviewed fixture
  should be treated with that caveat in mind.
- `run.ts` — the CLI this file documents.

## What `run.ts` does, and what it costs

`run.ts` runs the **whole 8-step generative pipeline** (mirroring
`scripts/bakeoff.ts`'s throwaway brand+project scaffolding) once per
`language × model` combination, against that language's native brief, then
sends the concatenated output to a real `openai/gpt-4.1` judge call and writes
a report.

**This spends real OpenRouter credit on every run.** Every generation step and
every judge call is a live API call — nothing here is mocked or cached.

Measured ceiling: **~$18** for the default scope (2 models × 4 languages,
`--posts 5 --platforms instagram`), derived from real per-step costs recorded
in `web/bakeoff-runs/*/00-meta.json` for the same pipeline. Actual cost scales
with `--posts`, the number of `--platforms`, and which models you pass via
`--models` — check current OpenRouter pricing for anything other than the
default two.

**Claude does not execute this script.** It is Elif's trigger — an operator
runs it manually and reviews the report, the same way `scripts/bakeoff.ts` and
`scripts/llm-smoke.ts` are handled.

## Running it

```bash
cd web
npm run db:up   # local Postgres, if not already running
export DATABASE_URL=postgres://kleinburg:kleinburg@localhost:5432/kleinburg
npx tsx scripts/lang-audit/run.ts
```

Flags (all optional):

```bash
npx tsx scripts/lang-audit/run.ts \
  --langs de,it,fr,es \
  --models anthropic/claude-sonnet-5,moonshotai/kimi-k3 \
  --posts 5 \
  --platforms instagram \
  --cleanup
```

- `--langs` — comma-separated subset of `de,it,fr,es` (default: all four).
- `--models` — comma-separated OpenRouter model ids (default:
  `anthropic/claude-sonnet-5,moonshotai/kimi-k3`). Fewer models or languages
  is the cheapest way to shrink the bill for a first look — e.g.
  `--langs de --models anthropic/claude-sonnet-5` runs one lang×model
  combination instead of eight.
- `--posts` — posts per platform (default `5`, matching the measured
  ceiling above; bakeoff.ts itself defaults to 10).
- `--platforms` — comma-separated platform codes (default `instagram`).
- `--cleanup` — delete the throwaway brands (cascades to projects/documents)
  when done. Without it, every run's brand+project is left in the database
  for manual inspection, same as bakeoff.ts.

`run.ts` logs the resolved language list, model list, judge model and an
**estimated call count before it makes a single call**, so the operator sees
the scope before any money is spent. It requires `OPENROUTER_API_KEY` in the
environment (or `web/.env`) and fails immediately if it is missing.

## Output

Written to `web/audits/lang-audit-<timestamp>/`:

- `report.md` — the audit report (`buildReport` output): an executive summary
  table, per-language/per-model dimension breakdowns with evidence quotes,
  and a model-comparison section.
- `results.json` — the raw `RunResult[]` behind the report.
- `<lang>-<model>/generated.md` — the concatenated, step-tagged content that
  was actually judged for that run.
- `<lang>-<model>/steps.json` — per-step timing/success record.
- `<lang>-<model>/meta.json` — per-run generation cost (from `llm_calls`,
  joined through `generation_jobs`, exactly like bakeoff.ts's cost report).

## The judge model must be allowlisted

The judge calls `openai/gpt-4.1` directly through `getOpenRouterClient()` —
**not** through `resolveModel`/`STEP_MODEL_OVERRIDES`, because the judge is
not a pipeline step. The OpenRouter account keeps "paid endpoints that may
train on request data" **off** (see the comment on `DEFAULT_MODEL` in
`src/core/llm/models.ts`), which filters out endpoints for models not on the
account's allowlist. **A non-allowlisted model 404s** with a message that
names both the guardrail and the allowlist without saying which one refused
(see the `RESEARCH_MODEL` history in `models.ts` for a prior instance of this
exact trap). Confirm `openai/gpt-4.1` is on the account's allowed-models list
in the OpenRouter dashboard before running this script — don't diagnose a 404
here as a guardrail problem without checking the allowlist first.

## Sanity-probe the judge before the full run

Before spending the full ~$18, it is worth spending a few cents to confirm the
judge call itself works — model reachable, JSON mode returns something
`JudgeResultSchema` can parse, banned-term detection fires — using output that
already exists and costs nothing new to generate:

1. Pick an existing directory under `web/bakeoff-runs/*` (any prior bakeoff
   run) and read one of its `NN-sm_posts-<platform>.json` files.
2. Write a tiny throwaway script (or a REPL/`tsx -e` one-liner) that imports
   `buildJudgePrompt` from `./rubric.ts`, `makeJudge` from `./judge.ts`, wires
   the same `callModel` shown below against `getOpenRouterClient()`, and
   calls the judge once with that file's content and any of `de/it/fr/es` as
   the language (the language argument only changes which banned-terms list
   is checked and what the prompt asks for — it will still return a
   structured, parseable result against non-matching content).
3. Confirm the result validates against `JudgeResultSchema` and that
   `bannedTermsFound` behaves sanely (e.g. inject one of the banned words into
   the test content and confirm it gets flagged).

This catches "the model id is wrong" or "the allowlist blocks it" or "the
judge prompt/schema don't line up with what gpt-4.1 actually returns" for the
cost of one API call, before running the full generation-heavy harness.

## The judge wiring, exactly

```ts
import { getOpenRouterClient } from "../../src/core/llm/openrouter";

const client = getOpenRouterClient();
const callModel = async (prompt: string): Promise<string> => {
  const res = await client.chat.completions.create({
    model: "openai/gpt-4.1",
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" },
  });
  return res.choices[0]?.message.content ?? "";
};
const judge = makeJudge(callModel);
```

`res.usage?.cost` is summed across judge calls and reported alongside the
generation cost at the end of the run.
