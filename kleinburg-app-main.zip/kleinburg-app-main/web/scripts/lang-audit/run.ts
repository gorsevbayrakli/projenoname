/**
 * Language-audit harness: generation + judge + report (Task 7 of the
 * lang-audit SDD, see .superpowers/sdd/task-7-brief.md).
 *
 * For each `lang ∈ {de,it,fr,es}` and each `model` given, runs the whole
 * generative pipeline against that language's native brief
 * (fixture/<lang>.txt) — mirroring scripts/bakeoff.ts's throwaway
 * brand+project scaffolding exactly, DO NOT modify bakeoff.ts — collects
 * every step's output into one `content` string tagged by step, then judges
 * each run with a real `openai/gpt-4.1` call through the OpenRouter client
 * (rubric.ts + judge.ts + audit.ts, all already unit-tested) and writes a
 * Markdown report (report.ts).
 *
 * COSTS REAL MONEY. Every generation step AND every judge call is a live
 * OpenRouter call — two models × four languages at the defaults below is a
 * measured ceiling of ~$18 (see README.md in this folder). Not part of the
 * test suite, like scripts/bakeoff.ts and scripts/llm-smoke.ts, and for the
 * same reason.
 *
 * THIS SCRIPT IS ELIF'S TRIGGER. Claude does not execute it — see README.md.
 *
 * Usage:
 *   npx tsx scripts/lang-audit/run.ts \
 *     [--langs de,it,fr,es] [--models anthropic/claude-sonnet-5,moonshotai/kimi-k3] \
 *     [--posts 5] [--platforms instagram] [--cleanup]
 *
 * WHY IT WRITES TO THE DATABASE: same reason as bakeoff.ts — runStep reads
 * each step's input from step_contents (core/pipeline/inputs.ts gatherVars),
 * so there is no way to run e.g. sm_pillars without sm_pillars' upstream
 * steps having been stored first. The harness creates one throwaway
 * brand+project PER lang×model run and leaves the rows behind for
 * inspection unless --cleanup is passed.
 *
 * SELECTIONS ARE LEFT NULL on purpose, exactly as in bakeoff.ts: null means
 * "all items selected" in selectItems, so every generated item flows into
 * the next step with no human picking a subset — the audit holds that
 * variable constant across languages and models.
 */
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

import { eq } from "drizzle-orm";

import { closeDb, getDb } from "../../src/core/db/client";
import {
  brands,
  documents,
  generationJobs,
  llmCalls,
  projects,
  type WorkflowStep,
} from "../../src/core/db/schema";
import { createJob, markFailed, markSucceeded } from "../../src/core/jobs/jobs";
import { getOpenRouterClient } from "../../src/core/llm/openrouter";
import { recommendPostCounts } from "../../src/core/pipeline/cadence";
import { upsertStepContent } from "../../src/core/pipeline/inputs";
import { runStep } from "../../src/core/pipeline/run-step";
import { sortPlatforms, type Platform } from "../../src/core/platforms";

import { auditRuns, type GeneratedRun } from "./audit";
import { makeJudge } from "./judge";
import { buildReport } from "./report";
import type { AuditLang } from "./rubric";

try {
  process.loadEnvFile();
} catch {
  // no .env file present; rely on the process environment
}

// Tell the pipeline this is the language-audit harness: the exact pillar/post
// count quota and the tight cadence token ceiling are production rules that
// truncate audit runs before the post step. They are relaxed only when this is
// set; production never sets it, so the live app is unaffected. See checkCounts
// in core/pipeline/run-step.ts and cadenceMaxTokens in core/pipeline/cadence.ts.
process.env.LANG_AUDIT = "1";

// ── args ───────────────────────────────────────────────────────────────────

function arg(name: string, fallback?: string): string {
  const i = process.argv.indexOf(`--${name}`);
  const value = i >= 0 ? process.argv[i + 1] : undefined;
  if (value === undefined || value.startsWith("--")) {
    if (fallback !== undefined) return fallback;
    throw new Error(`--${name} gerekli`);
  }
  return value;
}

const hasFlag = (name: string) => process.argv.includes(`--${name}`);

const ALL_LANGS: AuditLang[] = ["de", "it", "fr", "es", "tr"];
const DEFAULT_MODELS = ["anthropic/claude-sonnet-5", "moonshotai/kimi-k3"];
const JUDGE_MODEL = "openai/gpt-4.1";

/**
 * `user_input` (workflow step 3) is free text a human normally types into the
 * wizard — there is no native version of it in the fixtures, only the brand
 * brief. Rather than leaving a stray Turkish/English sentence sitting inside
 * an otherwise-native run (which would itself be a register inconsistency
 * the judge could reasonably flag), each language gets a short native
 * instruction with the same meaning as bakeoff.ts's default.
 */
const USER_INPUT_TEXT: Record<AuditLang, string> = {
  de: "Erstelle einen einmonatigen Social-Media-Content-Plan für diese Marke.",
  it: "Crea un piano di contenuti social di un mese per questo marchio.",
  fr: "Crée un plan de contenu social d'un mois pour cette marque.",
  es: "Crea un plan de contenido social de un mes para esta marca.",
  tr: "Bu marka için bir aylık sosyal medya içerik planı oluştur.",
};

interface StepRecord {
  step: string;
  ok: boolean;
  ms: number;
  error?: string;
}

async function main() {
  if (!process.env.OPENROUTER_API_KEY) {
    console.error("OPENROUTER_API_KEY yok. web/.env içine koyun.");
    process.exit(1);
  }

  const langs = arg("langs", ALL_LANGS.join(",")).split(",") as AuditLang[];
  for (const lang of langs) {
    if (!ALL_LANGS.includes(lang)) {
      throw new Error(
        `Bilinmeyen --langs değeri "${lang}"; şunlardan biri olmalı: ${ALL_LANGS.join(", ")}`,
      );
    }
  }
  const models = arg("models", DEFAULT_MODELS.join(","))
    .split(",")
    .map((m) => m.trim())
    .filter(Boolean);
  const postsPerPlatform = Number(arg("posts", "5"));
  const platforms = sortPlatforms(
    arg("platforms", "instagram").split(","),
  ) as Platform[];

  // Rough call-count estimate to size cost BEFORE spending anything. Per
  // lang×model run: brand_context(1) + secondary_data(2: retrieval+writing)
  // + creative_sparks(1) + platform_cadence(1) + sm_pillars(1) +
  // sm_posts(1 per platform), plus one judge call. Actual count can differ
  // (the judge retries once on a malformed reply — see judge.ts). This is an
  // operator-facing estimate, not a billing guarantee; see README.md for the
  // measured $ ceiling from real bakeoff runs.
  const callsPerRun = 6 + platforms.length + 1;
  const totalRuns = langs.length * models.length;
  const estimatedCalls = callsPerRun * totalRuns;

  console.log(`Diller:     ${langs.join(", ")}`);
  console.log(`Modeller:   ${models.join(", ")}`);
  console.log(`Judge:      ${JUDGE_MODEL}`);
  console.log(
    `Platforms:  ${platforms.join(", ")} @ ${postsPerPlatform} post`,
  );
  console.log(`Koşu sayısı: ${totalRuns} (dil × model)`);
  console.log(
    `Tahmini çağrı sayısı: ~${estimatedCalls} (üretim + judge). Gerçek maliyet için README.md'deki ölçülmüş tavana bakın.\n`,
  );

  const db = getDb();
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const outDir = join("audits", `lang-audit-${stamp}`);
  mkdirSync(outDir, { recursive: true });

  const client = getOpenRouterClient();
  let judgeCostUsd = 0;
  const callModel = async (prompt: string): Promise<string> => {
    const res = await client.chat.completions.create({
      model: JUDGE_MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });
    judgeCostUsd += res.usage?.cost ?? 0;
    return res.choices[0]?.message.content ?? "";
  };
  const judge = makeJudge(callModel);

  const runs: GeneratedRun[] = [];
  const createdBrandIds: string[] = [];
  let generationCostUsd = 0;

  for (const lang of langs) {
    const briefPath = join(__dirname, "fixture", `${lang}.txt`);
    const brief = readFileSync(briefPath, "utf8");

    for (const model of models) {
      console.log(`\n=== ${lang} × ${model} ===`);
      process.env.OPENROUTER_MODEL = model;

      const modelSlug = model.replace(/[^a-zA-Z0-9]/g, "-");
      const runLabel = `lang-audit-${lang}-${modelSlug}-${stamp}`;

      const [brand] = await db
        .insert(brands)
        .values({ name: runLabel })
        .returning();
      createdBrandIds.push(brand.id);

      const [project] = await db
        .insert(projects)
        .values({
          brandId: brand.id,
          name: runLabel,
          language: lang,
          platforms,
          postCounts: Object.fromEntries(
            platforms.map((p) => [p, postsPerPlatform]),
          ),
          createdBy: null,
        })
        .returning();

      await db.insert(documents).values({
        projectId: project.id,
        filename: `${lang}.txt`,
        kind: "docx",
        extractedText: brief,
      });

      console.log(`Proje: ${project.id}`);

      const records: StepRecord[] = [];
      const contentParts: string[] = [];

      const addContent = (heading: string, output: unknown) => {
        contentParts.push(`## ${heading}\n\n${JSON.stringify(output, null, 2)}`);
      };

      /** Mirrors bakeoff.ts's `step` helper exactly (see that file for why). */
      async function step(
        name: WorkflowStep,
        jobInput: Record<string, unknown> = {},
        saveAs: WorkflowStep = name,
      ): Promise<unknown> {
        const started = Date.now();
        process.stdout.write(
          `→ ${name}${jobInput.platform ? ` (${jobInput.platform})` : ""} ... `,
        );
        const job = await createJob(project.id, name, jobInput, null);
        try {
          const output = await runStep(project.id, name, jobInput, job.id);
          await markSucceeded(job.id, output);
          await upsertStepContent(project.id, saveAs, output);
          const ms = Date.now() - started;
          records.push({ step: name, ok: true, ms });
          console.log(`ok (${(ms / 1000).toFixed(1)}s)`);
          return output;
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          await markFailed(job.id, message);
          const ms = Date.now() - started;
          records.push({ step: name, ok: false, ms, error: message });
          console.log(`HATA: ${message}`);
          throw err;
        }
      }

      try {
        addContent("brand_context", await step("brand_context"));
        addContent("secondary_data", await step("secondary_data"));

        // step 3 is the human's own text — fixed, no model call (see
        // USER_INPUT_TEXT above for why it is not a bare English string).
        await upsertStepContent(project.id, "user_input", {
          text: USER_INPUT_TEXT[lang],
        });

        addContent("creative_sparks", await step("creative_sparks"));

        // Cadence advice: not a wizard step and not routed through runStep;
        // it opens its own synthetic job (core/pipeline/cadence.ts). NOT
        // applied to the project — the audit holds post counts constant,
        // same rationale as bakeoff.ts.
        process.stdout.write("→ platform_cadence ... ");
        const cadenceStart = Date.now();
        await recommendPostCounts(project.id, platforms, null);
        const cadenceMs = Date.now() - cadenceStart;
        records.push({ step: "platform_cadence", ok: true, ms: cadenceMs });
        console.log(`ok (${(cadenceMs / 1000).toFixed(1)}s)`);

        addContent("sm_pillars", await step("sm_pillars"));

        for (const platform of platforms) {
          addContent(
            `sm_posts (${platform})`,
            await step("sm_posts", { platform }),
          );
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        console.log(`\n${lang} × ${model} koşusu yarıda kesildi: ${message}`);
        console.log("O ana kadarki çıktılar denetime dahil edilecek.");
      }

      const runOutDir = join(outDir, `${lang}-${modelSlug}`);
      mkdirSync(runOutDir, { recursive: true });
      writeFileSync(
        join(runOutDir, "steps.json"),
        JSON.stringify(records, null, 2),
        "utf8",
      );

      const content = contentParts.join("\n\n---\n\n");
      writeFileSync(join(runOutDir, "generated.md"), content, "utf8");

      // Cost report for this run's generation calls (llm_calls has no
      // project_id of its own; it is reached through the job — same query as
      // bakeoff.ts's cost report).
      const calls = await db
        .select({
          step: generationJobs.step,
          model: llmCalls.model,
          promptTokens: llmCalls.promptTokens,
          completionTokens: llmCalls.completionTokens,
          costUsd: llmCalls.costUsd,
          durationMs: llmCalls.durationMs,
        })
        .from(llmCalls)
        .innerJoin(generationJobs, eq(llmCalls.jobId, generationJobs.id))
        .where(eq(generationJobs.projectId, project.id));
      const runCost = calls.reduce((sum, c) => sum + Number(c.costUsd ?? 0), 0);
      generationCostUsd += runCost;
      writeFileSync(
        join(runOutDir, "meta.json"),
        JSON.stringify(
          { lang, model, projectId: project.id, steps: records, llmCalls: calls, costUsd: runCost },
          null,
          2,
        ),
        "utf8",
      );
      console.log(`Üretim maliyeti (bu koşu): $${runCost.toFixed(4)}`);

      if (contentParts.length === 0) {
        // Hard rule 5: no silent swallowing. An empty run is not sent to the
        // judge — a judge call on empty content would burn money to validate
        // nothing and would otherwise fail JudgeResultSchema anyway.
        console.log(
          `UYARI: ${lang} × ${model} hiç içerik üretmedi, judge'a gönderilmiyor.`,
        );
        continue;
      }

      runs.push({ lang, model, content });
    }
  }

  console.log(`\n=== Judging (${JUDGE_MODEL}) ===`);
  const results = await auditRuns(runs, judge);

  const report = buildReport(results);
  writeFileSync(join(outDir, "report.md"), report, "utf8");
  writeFileSync(
    join(outDir, "results.json"),
    JSON.stringify(results, null, 2),
    "utf8",
  );

  console.log(
    `\nToplam maliyet: üretim $${generationCostUsd.toFixed(4)} + judge $${judgeCostUsd.toFixed(4)} = $${(generationCostUsd + judgeCostUsd).toFixed(4)}`,
  );
  console.log(`Rapor: ${join(outDir, "report.md")}`);

  if (hasFlag("cleanup")) {
    for (const id of createdBrandIds) {
      await db.delete(brands).where(eq(brands.id, id));
    }
    console.log("Veritabanı satırları silindi (--cleanup).");
  } else {
    console.log(
      `Projeler veritabanında bırakıldı: ${createdBrandIds.join(", ")}`,
    );
  }

  await closeDb();
}

main().catch(async (err) => {
  console.error(err);
  await closeDb();
  process.exit(1);
});
