import { z } from "zod";

export const DIMENSIONS = ["nativeTone", "cultural", "register", "brandVoice"] as const;
export type Dimension = (typeof DIMENSIONS)[number];

export const WEIGHTS: Record<Dimension, number> = {
  nativeTone: 0.35,
  cultural: 0.15,
  register: 0.2,
  brandVoice: 0.3,
};

export const DimensionScoreSchema = z.object({
  score: z.number().int().min(1).max(5),
  rationale: z.string().min(1),
  evidence: z.string().min(1),
  suggestedFix: z.string().nullable(),
});

export type DimensionScore = z.infer<typeof DimensionScoreSchema>;

export const JudgeResultSchema = z.object({
  // Explicit object, NOT z.record(enum, …): a Zod record over an enum key does
  // not require every key, so a judge reply missing a dimension would validate
  // and then crash computeVerdict on `undefined.score`. All four are required.
  scores: z.object({
    nativeTone: DimensionScoreSchema,
    cultural: DimensionScoreSchema,
    register: DimensionScoreSchema,
    brandVoice: DimensionScoreSchema,
  }),
  bannedTermsFound: z.array(z.string()),
  summary: z.string().min(1),
});

export type JudgeResult = z.infer<typeof JudgeResultSchema>;
