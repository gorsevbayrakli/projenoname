import { describe, expect, it } from "vitest";

import { JudgeResultSchema } from "./schemas";

const dim = { score: 4, rationale: "r", evidence: "e", suggestedFix: null };
const full = {
  scores: { nativeTone: dim, cultural: dim, register: dim, brandVoice: dim },
  bannedTermsFound: [],
  summary: "s",
};

describe("JudgeResultSchema", () => {
  it("accepts a result with all four dimensions", () => {
    expect(JudgeResultSchema.safeParse(full).success).toBe(true);
  });

  it("REJECTS a result missing a dimension (the guarantee computeVerdict relies on)", () => {
    const partial = { ...full, scores: { nativeTone: dim } };
    expect(JudgeResultSchema.safeParse(partial).success).toBe(false);
  });

  it("rejects a score outside 1..5", () => {
    const bad = { ...full, scores: { ...full.scores, register: { ...dim, score: 6 } } };
    expect(JudgeResultSchema.safeParse(bad).success).toBe(false);
  });
});
