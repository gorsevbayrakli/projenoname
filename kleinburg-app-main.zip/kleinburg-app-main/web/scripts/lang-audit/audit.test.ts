import { describe, expect, it, vi } from "vitest";
import { auditRuns, type GeneratedRun, type JudgeFn } from "./audit";
import type { JudgeResult } from "./schemas";

const stub: JudgeResult = {
  scores: {
    nativeTone: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    cultural: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    register: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    brandVoice: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
  },
  bannedTermsFound: [],
  summary: "s",
};

it("judges every generated run and preserves lang+model", async () => {
  const judge = vi.fn<JudgeFn>().mockResolvedValue(stub);
  const runs: GeneratedRun[] = [
    { lang: "de", model: "claude-sonnet-5", content: "DE-A" },
    { lang: "fr", model: "kimi-k3", content: "FR-B" },
  ];
  const results = await auditRuns(runs, judge);
  expect(judge).toHaveBeenCalledTimes(2);
  expect(judge).toHaveBeenCalledWith("de", "DE-A");
  expect(results.map((r) => `${r.lang}:${r.model}`)).toEqual([
    "de:claude-sonnet-5",
    "fr:kimi-k3",
  ]);
  expect(results[0].judge).toEqual(stub);
});

it("isolates a failing judge: the bad run is marked, the rest still judged, no throw", async () => {
  const judge = vi
    .fn<JudgeFn>()
    .mockRejectedValueOnce(new Error("boom")) // first run fails
    .mockResolvedValueOnce(stub); // second run ok
  const runs: GeneratedRun[] = [
    { lang: "de", model: "m1", content: "A" },
    { lang: "fr", model: "m2", content: "B" },
  ];
  const results = await auditRuns(runs, judge);
  expect(results).toHaveLength(2);
  expect(results[0].judge).toBeNull();
  expect(results[0].error).toContain("boom");
  expect(results[1].judge).toEqual(stub);
});
