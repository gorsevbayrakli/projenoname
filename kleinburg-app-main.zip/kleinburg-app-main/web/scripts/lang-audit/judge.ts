import { buildJudgePrompt, type AuditLang } from "./rubric";
import { JudgeResultSchema, type JudgeResult } from "./schemas";
import type { JudgeFn } from "./audit";

export function makeJudge(
  callModel: (prompt: string) => Promise<string>
): JudgeFn {
  return async (lang: AuditLang, content: string): Promise<JudgeResult> => {
    const prompt = buildJudgePrompt(lang, content);

    // First attempt
    let response = await callModel(prompt);
    let parseResult = tryParseAndValidate(response);

    if (parseResult.success) {
      return parseResult.data;
    }

    // Retry once on failure
    response = await callModel(prompt);
    parseResult = tryParseAndValidate(response);

    if (parseResult.success) {
      return parseResult.data;
    }

    // Both attempts failed, throw
    throw new Error(
      `Judge validation failed: ${parseResult.error?.message || "Unknown error"}`
    );
  };
}

function tryParseAndValidate(response: string) {
  try {
    // Strip markdown code fences if present
    let json = response.trim();
    if (json.startsWith("```json")) {
      json = json.slice(7); // Remove ```json
    } else if (json.startsWith("```")) {
      json = json.slice(3); // Remove ```
    }

    if (json.endsWith("```")) {
      json = json.slice(0, -3); // Remove trailing ```
    }

    json = json.trim();

    const parsed = JSON.parse(json);
    return JudgeResultSchema.safeParse(parsed);
  } catch (err) {
    // JSON parse error or Zod validation error. `false as const` (not a bare
    // `false`) is load-bearing: without it TS widens the literal to `boolean`,
    // which breaks discriminated-union narrowing on `parseResult.success` at
    // both call sites above (tsc: "Property 'data' does not exist on type
    // '... | { success: boolean; error: ... }'"). Pre-existing bug from the
    // original judge.ts commit; fixed here as a type-only, zero-behavior-change
    // edit because it otherwise fails `npm run typecheck` for the whole repo.
    return {
      success: false as const,
      error: {
        message:
          err instanceof Error ? err.message : "Failed to parse response",
      },
    };
  }
}
