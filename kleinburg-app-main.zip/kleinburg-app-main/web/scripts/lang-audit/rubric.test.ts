import { describe, expect, it } from "vitest";
import { BANNED_TERMS, buildJudgePrompt } from "./rubric";

describe("rubric", () => {
  it("carries the banned-term list for every audit language", () => {
    for (const lang of ["de", "it", "fr", "es"] as const) {
      expect(BANNED_TERMS[lang].length).toBeGreaterThan(0);
    }
    expect(BANNED_TERMS.de).toContain("Superfood");
    expect(BANNED_TERMS.fr).toContain("superaliment");
  });

  it("builds a judge prompt that names the four dimensions and the language's banned terms", () => {
    const p = buildJudgePrompt("de", "GENERATED_CONTENT_HERE");
    for (const marker of ["nativeTone", "cultural", "register", "brandVoice"]) {
      expect(p).toContain(marker);
    }
    expect(p).toContain("Superfood");
    expect(p).toContain("GENERATED_CONTENT_HERE");
    // evidence must be verbatim, original-language
    expect(p.toLowerCase()).toContain("verbatim");
  });
});
