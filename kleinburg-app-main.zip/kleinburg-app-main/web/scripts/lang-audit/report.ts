import { DIMENSIONS, type JudgeResult } from "./schemas";
import { computeVerdict } from "./verdict";
import type { AuditLang } from "./rubric";

export type RunResult = {
  lang: AuditLang;
  model: string;
  judge: JudgeResult | null; // null = the judge call failed for this run
  error?: string;
};

export function buildReport(results: RunResult[]): string {
  // Group results by language. Built lazily from whatever languages are present
  // so adding an audit language never needs a second edit here.
  const byLang = {} as Record<AuditLang, RunResult[]>;
  const allLangs = new Set<AuditLang>();
  const allModels = new Set<string>();

  for (const result of results) {
    (byLang[result.lang] ??= []).push(result);
    allLangs.add(result.lang);
    allModels.add(result.model);
  }

  const langs = Array.from(allLangs).sort();
  const models = Array.from(allModels).sort();

  // Section 1: Executive Summary Table
  let report = "# Language Audit Report\n\n";
  report += "## Executive Summary\n\n";
  report += "| Language | ";
  report += models.map((m) => m).join(" | ");
  report += " |\n";
  report += "|----------|";
  report += models.map(() => "-------").join("|");
  report += "|\n";

  for (const lang of langs) {
    report += `| ${lang.toUpperCase()} |`;
    for (const model of models) {
      const result = byLang[lang].find((r) => r.model === model);
      if (!result) {
        report += " — |";
      } else if (result.judge === null) {
        report += ` **JUDGE FAILED** |`;
      } else {
        const { verdict, weightedTotal } = computeVerdict(result.judge);
        // Make RED visually unmistakable
        const verdictText = verdict === "RED" ? `**RED**` : verdict;
        report += ` ${verdictText} (${weightedTotal.toFixed(2)}) |`;
      }
    }
    report += "\n";
  }

  report += "\n";

  // Section 2: Per-Language Details
  report += "## Per-Language Breakdown\n\n";

  for (const lang of langs) {
    report += `### ${lang.toUpperCase()}\n\n`;

    for (const runResult of byLang[lang]) {
      if (runResult.judge === null) {
        report += `#### ${runResult.model} — **JUDGE FAILED**\n\n`;
        report += `⚠️ Judge failed: ${runResult.error ?? "unknown error"}\n\n`;
        continue;
      }

      const { verdict, weightedTotal } = computeVerdict(runResult.judge);
      const verdictText = verdict === "RED" ? `**RED**` : verdict;

      report += `#### ${runResult.model} — ${verdictText} (${weightedTotal.toFixed(2)})\n\n`;

      // Dimension breakdown
      for (const dim of DIMENSIONS) {
        const score = runResult.judge.scores[dim];
        report += `**${dim}:** ${score.score}/5\n`;
        report += `- Rationale: ${score.rationale}\n`;
        report += `- Evidence: "${score.evidence}"\n`;
        if (score.suggestedFix) {
          report += `- Suggested fix: ${score.suggestedFix}\n`;
        }
        report += "\n";
      }

      // Summary
      report += `**Summary:** ${runResult.judge.summary}\n\n`;

      // Banned terms
      if (runResult.judge.bannedTermsFound.length > 0) {
        report += `**Banned Terms Found:** ${runResult.judge.bannedTermsFound.join(", ")}\n\n`;
      }
    }
  }

  // Section 3: Model Comparison Summary
  report += "## Model Comparison\n\n";

  for (const lang of langs) {
    // A failed judge has no verdict to compare — exclude it from "strongest
    // model" comparisons rather than crashing or silently picking it by
    // default array order.
    const langResults = byLang[lang].filter(
      (r): r is RunResult & { judge: JudgeResult } => r.judge !== null,
    );
    if (langResults.length > 1) {
      // Find the strongest model for this language
      let strongest = langResults[0];
      let strongestVerdict = computeVerdict(strongest.judge);

      for (const result of langResults.slice(1)) {
        const verdict = computeVerdict(result.judge);
        if (verdict.weightedTotal > strongestVerdict.weightedTotal) {
          strongest = result;
          strongestVerdict = verdict;
        }
      }

      report += `**${lang.toUpperCase()}:** ${strongest.model} is strongest (${strongestVerdict.verdict}, ${strongestVerdict.weightedTotal.toFixed(2)})\n\n`;
    }
  }

  return report;
}
