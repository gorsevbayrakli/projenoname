import { DIMENSIONS } from "./schemas";

export type AuditLang = "de" | "it" | "fr" | "es" | "tr";

export const BANNED_TERMS: Record<AuditLang, string[]> = {
  de: ["natürlich", "ohne Zusätze", "100%", "Superfood", "Detox", "Wunder"],
  fr: ["naturel", "sans additifs", "100%", "superaliment", "détox", "miracle"],
  it: ["naturale", "senza additivi", "100%", "superfood", "detox", "miracolo"],
  es: ["natural", "sin aditivos", "100%", "superalimento", "detox", "milagro"],
  // Turkish is the source language of the Köken brief; the banned list is the
  // brief's own "KULLANMADIĞIMIZ KELİMELER" verbatim (adds "atalık", which has
  // no equivalent in the other markets).
  tr: ["doğal", "katkısız", "%100", "süper gıda", "detoks", "mucize", "atalık"],
};

export function buildJudgePrompt(lang: AuditLang, generated: string): string {
  const bannedTermsList = BANNED_TERMS[lang].join(", ");

  return `You are a demanding native-speaker editor judging multilingual marketing content. Evaluate the generated content below against four dimensions. Score each 1 (poor) to 5 (flawless).

**Scoring calibration — be discriminating, do NOT default to 5:**
- 5 = indistinguishable from a skilled native writer; you found nothing to improve.
- 4 = strong, but with at least one minor slip (a slightly off collocation, a small register wobble, one phrase a native would rewrite). This is the ceiling for content that is merely "good".
- 3 = understandable but noticeably non-native in places (translation-smell, stiff idiom, inconsistent register).
- 1–2 = clearly translated or wrong.
A uniform top score is itself suspect: actively hunt for the weakest phrase in each dimension and let it pull the score down. If you give a 5, your rationale must justify why nothing could be improved.

**Dimensions:**
- nativeTone: reads as written by a native speaker, not translated from English/Turkish (idiom, rhythm).
- cultural: idiom/reference/humour natural for the language; nothing taboo or awkward.
- register: matches the register the BRIEF declared and stays consistent throughout (formal vs informal, and its agreement).
- brandVoice: faithful to the brand's declared voice; the banned words below must NOT appear.

**Content to evaluate:**
${generated}

**Banned terms for this language:** ${bannedTermsList}

**Instructions:**
0. LANGUAGE OF THE REPORT: write EVERY \`rationale\`, \`summary\` and \`suggestedFix\` in ENGLISH, no matter what language the content is in. The ONLY text that stays in the original language is the \`evidence\` field, which is a verbatim quote.
1. Score each dimension 1–5. Provide a one-line rationale (in English) for each score.
2. For evidence, provide a verbatim quote in the original language of the content. When a dimension scores below 4, also provide a suggestedFix (in English, though it may contain the original-language phrasing it proposes).
3. List any banned terms found in the content (bannedTermsFound).
4. Provide a 2-sentence summary of the overall quality.
5. Return ONLY valid JSON with exactly this structure (no markdown, no additional text):
{
  "scores": {
    "nativeTone": { "score": <1-5>, "rationale": "<string>", "evidence": "<verbatim quote in original language>", "suggestedFix": "<string or null>" },
    "cultural": { "score": <1-5>, "rationale": "<string>", "evidence": "<verbatim quote in original language>", "suggestedFix": "<string or null>" },
    "register": { "score": <1-5>, "rationale": "<string>", "evidence": "<verbatim quote in original language>", "suggestedFix": "<string or null>" },
    "brandVoice": { "score": <1-5>, "rationale": "<string>", "evidence": "<verbatim quote in original language>", "suggestedFix": "<string or null>" }
  },
  "bannedTermsFound": [<array of strings>],
  "summary": "<2-sentence summary>"
}`;
}
