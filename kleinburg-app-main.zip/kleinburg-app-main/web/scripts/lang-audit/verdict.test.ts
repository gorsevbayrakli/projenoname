import { describe, expect, it } from "vitest";
import { computeVerdict } from "./verdict";
import type { JudgeResult } from "./schemas";

function res(scores: [number, number, number, number], banned: string[] = []): JudgeResult {
  const [nativeTone, cultural, register, brandVoice] = scores;
  const mk = (score: number) => ({ score, rationale: "r", evidence: "e", suggestedFix: null });
  return {
    scores: { nativeTone: mk(nativeTone), cultural: mk(cultural), register: mk(register), brandVoice: mk(brandVoice) },
    bannedTermsFound: banned,
    summary: "s",
  };
}

describe("computeVerdict", () => {
  it("RED when a banned term is found, regardless of scores", () => {
    expect(computeVerdict(res([5, 5, 5, 5], ["Superfood"])).verdict).toBe("RED");
  });
  it("RED when any dimension is <=2", () => {
    expect(computeVerdict(res([5, 5, 2, 5])).verdict).toBe("RED");
  });
  it("RED when the weighted total is <3.0", () => {
    // 3,3,3,2 -> .35*3+.15*3+.20*3+.30*2 = 2.7
    expect(computeVerdict(res([3, 3, 3, 2])).verdict).toBe("RED");
  });
  it("YELLOW for a mid run (total 3.0–3.9, no dim <=2, no banned)", () => {
    // 4,3,3,4 -> 1.4+.45+.6+1.2 = 3.65
    expect(computeVerdict(res([4, 3, 3, 4])).verdict).toBe("YELLOW");
  });
  it("GREEN only when total >=4.0 AND no dimension <4", () => {
    expect(computeVerdict(res([4, 4, 4, 4])).verdict).toBe("GREEN");
  });
  it("not GREEN if a dimension is 3 even when the total is >=4.0", () => {
    // 5,5,3,5 -> 1.75+.75+.6+1.5 = 4.6 total, but register=3 -> YELLOW
    expect(computeVerdict(res([5, 5, 3, 5])).verdict).toBe("YELLOW");
  });
});
