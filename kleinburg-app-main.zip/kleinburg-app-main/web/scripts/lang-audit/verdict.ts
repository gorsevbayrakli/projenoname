import { DIMENSIONS, WEIGHTS, type JudgeResult } from "./schemas";

export function computeVerdict(result: JudgeResult): {
  verdict: "GREEN" | "YELLOW" | "RED";
  weightedTotal: number;
} {
  const weightedTotal = DIMENSIONS.reduce(
    (sum, d) => sum + result.scores[d].score * WEIGHTS[d],
    0,
  );
  const anyLow = DIMENSIONS.some((d) => result.scores[d].score <= 2);
  const anyBelow4 = DIMENSIONS.some((d) => result.scores[d].score < 4);
  if (result.bannedTermsFound.length > 0 || anyLow || weightedTotal < 3.0) {
    return { verdict: "RED", weightedTotal };
  }
  if (weightedTotal >= 4.0 && !anyBelow4) return { verdict: "GREEN", weightedTotal };
  return { verdict: "YELLOW", weightedTotal };
}
