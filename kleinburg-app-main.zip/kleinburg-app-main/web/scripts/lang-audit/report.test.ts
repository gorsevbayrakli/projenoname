import { describe, expect, it } from "vitest";
import { buildReport, type RunResult } from "./report";
import type { JudgeResult } from "./schemas";

const green: JudgeResult = {
  scores: {
    nativeTone: { score: 5, rationale: "reads native", evidence: "»Ihre Marke«", suggestedFix: null },
    cultural: { score: 4, rationale: "ok", evidence: "x", suggestedFix: null },
    register: { score: 4, rationale: "Sie throughout", evidence: "y", suggestedFix: null },
    brandVoice: { score: 4, rationale: "on voice", evidence: "z", suggestedFix: null },
  },
  bannedTermsFound: [],
  summary: "Solid German run.",
};
const red: JudgeResult = { ...green, bannedTermsFound: ["Superfood"], summary: "Banned term used." };

it("renders a lang×model matrix and surfaces RED verdicts", () => {
  const results: RunResult[] = [
    { lang: "de", model: "claude-sonnet-5", judge: green },
    { lang: "de", model: "kimi-k3", judge: red },
  ];
  const md = buildReport(results);
  expect(md).toContain("GREEN");
  expect(md).toContain("RED");
  expect(md).toContain("Superfood"); // banned term surfaced
  expect(md).toContain("»Ihre Marke«"); // verbatim evidence, original language
  expect(md).toContain("claude-sonnet-5");
  expect(md).toContain("kimi-k3");
});

it("renders a failed judge run without crashing and marks it distinctly", () => {
  const results: RunResult[] = [
    { lang: "de", model: "claude-sonnet-5", judge: green },
    { lang: "de", model: "kimi-k3", judge: null, error: "openrouter 500" },
  ];
  const md = buildReport(results);
  expect(md).toContain("JUDGE FAILED");
  expect(md).toContain("openrouter 500");
  expect(md).toContain("GREEN"); // the good run still rendered
});
