import { describe, expect, it, vi } from "vitest";
import { makeJudge } from "./judge";

const valid = JSON.stringify({
  scores: {
    nativeTone: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    cultural: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    register: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    brandVoice: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
  },
  bannedTermsFound: [],
  summary: "s",
});

it("validates the judge JSON and returns the parsed result", async () => {
  const judge = makeJudge(vi.fn().mockResolvedValue(valid));
  const out = await judge("de", "content");
  expect(out.scores.nativeTone.score).toBe(4);
});

it("retries once on a schema-invalid response, then succeeds", async () => {
  const call = vi.fn().mockResolvedValueOnce('{"scores":{}}').mockResolvedValueOnce(valid);
  const judge = makeJudge(call);
  await judge("de", "content");
  expect(call).toHaveBeenCalledTimes(2);
});

it("throws after a second invalid response (no silent partial)", async () => {
  const call = vi.fn().mockResolvedValue('{"nope":true}');
  const judge = makeJudge(call);
  await expect(judge("de", "content")).rejects.toThrow();
  expect(call).toHaveBeenCalledTimes(2);
});
