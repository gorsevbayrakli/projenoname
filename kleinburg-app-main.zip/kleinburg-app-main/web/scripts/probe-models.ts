/**
 * Live access + capability probe for the account's allowed models.
 *
 * Answers, per model, the two things that decide whether a model can serve a
 * wizard step at all — and that neither the OpenRouter catalogue nor any
 * benchmark can tell you about THIS account:
 *
 *   1. ACCESS   — does the data policy / allowlist let the request through?
 *                 A blocked model returns 404 "no endpoints available", which
 *                 is what eliminated Gemini 2.5 Pro and sonar-pro before.
 *   2. ŞEMA     — does it honour `json_schema` strict mode? Every step in this
 *                 app is a structured call (hard rule 4), so a model that
 *                 cannot hold a schema cannot serve any step, however good its
 *                 prose is.
 *
 * It also reports whether Turkish survived the round trip, because the app's
 * main market writes Turkish and at least one model in production (sonar)
 * mangles non-ASCII letters. The fixture asks for a sentence containing every
 * Turkish-specific character, so a model that strips or transliterates them
 * fails visibly rather than at a client demo.
 *
 * Run: npx tsx scripts/probe-models.ts [model ...]
 * Costs a few cents in total. Never part of the test suite.
 */
import { z } from "zod";

import { generateStructured } from "../src/core/llm/openrouter";

try {
  process.loadEnvFile();
} catch {
  // no .env file present; rely on the process environment
}

/** The account's allowed models, as OpenRouter ids. */
const DEFAULT_CANDIDATES = [
  "anthropic/claude-sonnet-5",
  "openai/gpt-4.1",
  "google/gemini-2.5-pro",
  "google/gemini-2.5-flash",
  "moonshotai/kimi-k3",
  "perplexity/sonar",
  "perplexity/sonar-reasoning-pro",
];

const CANDIDATES =
  process.argv.slice(2).length > 0 ? process.argv.slice(2) : DEFAULT_CANDIDATES;

/**
 * Deliberately shaped like a real step's output rather than `{answer: number}`:
 * an array of objects with several string fields is what every wizard step
 * asks for, and it is where schema adherence actually breaks.
 */
const schema = z.object({
  items: z.array(
    z.object({
      title: z.string(),
      description: z.string(),
    }),
  ),
});

/**
 * Words the model is told to reproduce EXACTLY, together covering every letter
 * Turkish has and English does not (ç ğ ı ö ş ü İ).
 *
 * Checked as whole words, not as a set of letters, and the difference is the
 * whole test. An earlier version asked only whether each letter appeared
 * SOMEWHERE in the output, and it passed this real sonar response:
 *
 *   "Doşadan gelen ışikle güçlü bir çiçķın şifa veren özel ürün, İyi gönyle."
 *
 * Every Turkish letter is present in that sentence. Almost every required word
 * is destroyed — Doğadan→Doşadan, çiçek→çiçķın (a letter Turkish does not
 * have), gönül→gönyle. Letter-presence is satisfied by mangled text, so it
 * cannot distinguish a model that writes Turkish from one that produces
 * Turkish-shaped noise.
 *
 * A model may legitimately reword its sentence, so a miss is reported as a
 * count rather than treated as proof — but a model that returns most of these
 * intact is doing something categorically different from one that returns none.
 */
const REQUIRED_WORDS = [
  "Doğadan",
  "ışığı",
  "güçlü",
  "çiçek",
  "şifa",
  "ürün",
  "İyi",
  "özel",
  "gönül",
];

const PROMPT = `Bir bitki çayı markası için iki kısa içerik fikri yaz.

Kurallar:
- Tamamen Türkçe yaz.
- \`title\` kısa bir başlık, \`description\` tek cümlelik açıklama olsun.
- Açıklamaların birinde şu kelimeler AYNEN geçsin: "Doğadan", "ışığı", "güçlü", "çiçek", "şifa", "ürün", "İyi", "özel", "gönül".

Şemaya uyan JSON döndür.`;

async function probe(model: string) {
  const started = Date.now();
  process.stdout.write(`\n── ${model}\n`);
  try {
    const out = await generateStructured({
      prompt: PROMPT,
      schema,
      model,
      // `unrecorded`: an operator probe run from a terminal has no job row to
      // bill against. Listed by name in every-call-recorded.test.ts (#68).
      unrecorded: true,
    });
    const seconds = ((Date.now() - started) / 1000).toFixed(1);
    const text = out.items.map((i) => `${i.title} ${i.description}`).join(" ");
    const missing = REQUIRED_WORDS.filter((w) => !text.includes(w));
    const kept = REQUIRED_WORDS.length - missing.length;

    console.log(`   ERİŞİM : ok (${seconds}s)`);
    console.log(`   ŞEMA   : ok — ${out.items.length} öğe`);
    console.log(
      `   TÜRKÇE : ${kept}/${REQUIRED_WORDS.length} kelime birebir korundu` +
        (missing.length > 0 ? `  — bozulan/atlanan: ${missing.join(", ")}` : ""),
    );
    console.log(`   Örnek  : ${(out.items[0]?.description ?? "").slice(0, 90)}`);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    // Access and schema failures mean opposite things: a 404 is this account's
    // policy (fixable in settings, or by choosing another model), a JSON/schema
    // error is the model failing strict mode (not fixable at all).
    const schemaFailure = /schema|JSON|parse|truncat/i.test(message);
    console.log(`   ${schemaFailure ? "ŞEMA HATASI" : "ERİŞİM ENGELİ"}`);
    console.log(`   ${message.slice(0, 220)}`);
  }
}

async function main() {
  if (!process.env.OPENROUTER_API_KEY) {
    console.error("OPENROUTER_API_KEY yok (web/.env).");
    process.exit(1);
  }
  for (const model of CANDIDATES) await probe(model);
  console.log("");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
