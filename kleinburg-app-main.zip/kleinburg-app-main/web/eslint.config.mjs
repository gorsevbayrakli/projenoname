import { dirname } from "path";
import { fileURLToPath } from "url";
import { FlatCompat } from "@eslint/eslintrc";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const compat = new FlatCompat({
  baseDirectory: __dirname,
});

const eslintConfig = [
  ...compat.extends("next/core-web-vitals", "next/typescript"),
  {
    /**
     * Hard rule 1, made directional (#43 review, "also worth doing").
     *
     * The original rule banned `react`, `react-dom` and `next` BY NAME. That
     * is a list of three packages, not a direction: `core/` importing
     * `@/lib/auth-server`, `@/components/...` or `../../i18n/locales` would
     * have passed lint while inverting the dependency the rule exists to
     * protect. The engine has stayed clean by everyone remembering, exactly
     * like the audit-insert rule below before it was mechanised.
     *
     * So the shape is now an ALLOW-LIST: from `src/core`, the only reachable
     * modules are `src/core` itself, node/third-party packages, and the test
     * harness. The harness exception is real and narrow — `@/test/db-gate` is
     * what makes the DB-backed core suites skip themselves, it imports
     * nothing from the app, and the alternative is a second copy of it inside
     * core.
     *
     * Relative escapes are covered as well as alias ones, because `../../lib/x`
     * and `@/lib/x` are the same dependency. Core is two levels deep at most,
     * so `../../` and beyond always leaves it; the depth-1 files get their own
     * block below. As a side effect this also mechanises the review's style
     * nit (finding 6): `../../test/db-gate` no longer lints, so the harness
     * can only be reached by its alias.
     */
    files: ["src/core/**"],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          paths: [
            {
              name: "react",
              message: "src/core must stay framework-neutral",
            },
            {
              name: "react-dom",
              message: "src/core must stay framework-neutral",
            },
            {
              name: "next",
              message: "src/core must stay framework-neutral",
            },
          ],
          patterns: [
            {
              group: ["next/*", "react/*", "react-dom/*"],
              message: "src/core must stay framework-neutral",
            },
            {
              // Alias imports: everything under @/ except core and the harness.
              // The bare directory negations are load-bearing: gitignore
              // semantics refuse to re-include anything under an excluded
              // DIRECTORY, so `!@/core/**` alone never fires.
              group: [
                "@/**",
                "!@/core",
                "!@/core/**",
                "!@/test",
                "!@/test/**",
              ],
              message:
                "src/core may not import the application layer (hard rule 1). The engine is the dependency, not the dependent: move the shared piece into src/core, or have the app call core instead. Only @/core/** and the @/test/** harness are reachable from here.",
            },
            {
              // Relative escapes out of src/core. Core is at most two levels
              // deep, so anything starting `../../` has left it.
              group: ["../../**", "../../../**", "../../../../**"],
              message:
                "src/core may not import the application layer (hard rule 1). This path leaves src/core. Use @/core/** for a sibling module, or @/test/** for the DB gate.",
            },
          ],
        },
      ],
    },
  },
  {
    /**
     * The three files that sit directly in `src/core` (platforms.ts and its
     * tests). One `../` already leaves the engine for them, so their escape
     * prefix is shorter than everybody else's and needs its own block.
     */
    files: ["src/core/*.ts", "src/core/*.tsx"],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          paths: [
            { name: "react", message: "src/core must stay framework-neutral" },
            {
              name: "react-dom",
              message: "src/core must stay framework-neutral",
            },
            { name: "next", message: "src/core must stay framework-neutral" },
          ],
          patterns: [
            {
              group: ["next/*", "react/*", "react-dom/*"],
              message: "src/core must stay framework-neutral",
            },
            {
              // The bare directory negations are load-bearing: gitignore
              // semantics refuse to re-include anything under an excluded
              // DIRECTORY, so `!@/core/**` alone never fires.
              group: [
                "@/**",
                "!@/core",
                "!@/core/**",
                "!@/test",
                "!@/test/**",
              ],
              message:
                "src/core may not import the application layer (hard rule 1). Only @/core/** and the @/test/** harness are reachable from here.",
            },
            {
              group: ["../**"],
              message:
                "src/core may not import the application layer (hard rule 1). From a file directly in src/core, one `../` already leaves the engine. Use @/core/** or @/test/**.",
            },
          ],
        },
      ],
    },
  },
  {
    /**
     * The audit trail's sanitisation guarantee, made mechanical (#41 review,
     * finding 8).
     *
     * Every audit row is supposed to pass through `toRow` in
     * `core/audit/service.ts`, which is where `sanitizeAuditMetadata` and
     * `sanitizeAuditName` run — the functions that keep content bodies and
     * credential material out of a table with no DELETE path. Nothing enforced
     * that: a future `db.insert(auditEvents).values({ ... })` written anywhere
     * else would compile, pass review, and silently write unsanitised text into
     * a permanent row. The guarantee was a convention held up by everyone
     * remembering it.
     *
     * This makes it a lint error instead. `core/audit/**` is exempt below,
     * because that is the module the rule exists to funnel everything through.
     */
    files: ["src/**/*.ts", "src/**/*.tsx"],
    rules: {
      "no-restricted-syntax": [
        "error",
        {
          selector:
            "CallExpression[callee.property.name='insert'] > Identifier[name='auditEvents']",
          message:
            "Do not insert into auditEvents directly: go through recordAuditEvent / recordAuditEventTx / recordContentAuditEvent in core/audit/service.ts, which is where sanitizeAuditMetadata and sanitizeAuditName run. A raw insert writes unsanitised text into a table that has no DELETE path.",
        },
      ],
    },
  },
  {
    files: ["src/core/audit/**"],
    rules: {
      // The one module allowed to write the table it owns.
      "no-restricted-syntax": "off",
    },
  },
  {
    ignores: [
      "node_modules/**",
      ".next/**",
      "out/**",
      "build/**",
      "next-env.d.ts",
    ],
  },
];

export default eslintConfig;
