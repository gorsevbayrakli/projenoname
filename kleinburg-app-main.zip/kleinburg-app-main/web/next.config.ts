import type { NextConfig } from "next";
import createNextIntlPlugin from "next-intl/plugin";

// T25: UI i18n. The plugin only wires src/i18n/request.ts into the server
// runtime — there is NO locale URL prefix and no middleware matcher change, so
// routing, Link hrefs and the auth middleware are untouched. The locale is read
// from the kb_locale cookie inside request.ts.
const withNextIntl = createNextIntlPlugin();

const nextConfig: NextConfig = {
  // Keep the job-queue stack (pg / pg-boss) out of the bundler. They use Node
  // built-ins (fs, net, …) and must load as native modules on the server. This
  // is what lets src/instrumentation.ts pull in the worker without webpack
  // trying to bundle pg for the edge runtime.
  serverExternalPackages: ["pg", "pg-boss"],
  webpack: (config, { nextRuntime }) => {
    // instrumentation.ts is compiled for every runtime, including edge. The
    // worker it imports is guarded to the Node.js runtime and never executes on
    // edge, so treat the queue stack as external there to keep webpack from
    // trying (and failing) to bundle pg's Node built-ins for the edge bundle.
    //
    // The worker also reaches the T12 pipeline (run-step -> prompts), which reads
    // prompt files with node:fs/path/url at runtime. Those code paths never run
    // on edge (the runtime guard returns first), but webpack still traces them
    // into the edge bundle, where the node: schemes are unresolvable — so mark
    // them external there too.
    if (nextRuntime === "edge") {
      config.externals = [
        ...(config.externals ?? []),
        "pg",
        "pg-boss",
        "pgpass",
        {
          "node:fs": "node-commonjs node:fs",
          "node:path": "node-commonjs node:path",
          "node:url": "node-commonjs node:url",
        },
      ];
    }
    return config;
  },
};

export default withNextIntl(nextConfig);
