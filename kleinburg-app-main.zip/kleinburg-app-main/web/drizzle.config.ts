import { defineConfig } from "drizzle-kit";

// drizzle-kit does not auto-load .env; use Node's built-in loader (Node >= 20.12).
// In CI there is no .env file and DATABASE_URL comes from the environment.
try {
  process.loadEnvFile();
} catch {
  // no .env file present; rely on the process environment
}

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/core/db/schema.ts",
  out: "./drizzle",
  dbCredentials: {
    url: process.env.DATABASE_URL ?? "",
  },
});
