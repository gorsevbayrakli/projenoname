import { defineConfig } from "@playwright/test";

/**
 * Ad-hoc E2E config for a post-cleanup integrity smoke test (no jobId, no
 * server auto-start — expects `npm run dev` already running against the
 * seeded local DB). Not wired into CI; see issue #1 for the real automated
 * E2E task this stands in for today.
 */
export default defineConfig({
  testDir: "./e2e",
  timeout: 30_000,
  use: {
    baseURL: "http://localhost:3000",
    screenshot: "only-on-failure",
  },
  reporter: [["list"]],
});
