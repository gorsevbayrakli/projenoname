import { NextResponse, type NextRequest } from "next/server";

import { SESSION_COOKIE } from "@/lib/session-cookie";

/**
 * Lightweight edge guard: a *presence* check only. If no session cookie is
 * attached to a protected request, bounce to /login. Real validation (DB +
 * sliding expiry) happens in getCurrentUser() on the page/route, because the
 * edge runtime can't reach Postgres. Public paths and static assets are
 * excluded via the matcher below.
 */
export function middleware(request: NextRequest) {
  const hasSession = request.cookies.has(SESSION_COOKIE);
  if (hasSession) return NextResponse.next();

  const loginUrl = new URL("/login", request.url);
  return NextResponse.redirect(loginUrl);
}

export const config = {
  // Run on everything except the PUBLIC pages, the auth API, and static assets.
  //
  // The leading `$` excludes the root path exactly (and only the root): since
  // T45 `/` renders the sign-in screen, so a visitor with no cookie must be
  // able to load it. Without this they would be bounced to /login and shown
  // the identical page at a different address.
  matcher: [
    "/((?!$|login|api/auth|_next/static|_next/image|favicon.ico|.*\\.[^/]+$).*)",
  ],
};
