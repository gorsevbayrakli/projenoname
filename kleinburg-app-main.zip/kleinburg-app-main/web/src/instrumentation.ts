/**
 * Next.js instrumentation hook. Runs once when the server process boots. We use
 * it to start pg-boss and register the generation worker in the SAME process as
 * the web server (single Render web service, per the design spec).
 *
 * Guarded to the Node.js runtime so it never runs on the edge runtime, where
 * pg / node built-ins are unavailable.
 */
export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  // Report a configured-but-unregistered OPENROUTER_MODEL here, at boot. This
  // is now the ONLY place it gets reported: maxOutputFor's runtime warning
  // fires when something asks for an output ceiling, and since the calendar
  // became deterministic nothing does. Warns, never throws — see the rationale
  // in models.ts, which also explains what the warning does and does not claim.
  const { validateConfiguredModels } = await import("./core/llm/models");
  validateConfiguredModels();

  // Refuse to boot a production instance without AUDIT_MASK_KEY (#55). The
  // first use of that key is a FAILED LOGIN, so leaving the check to runtime
  // would surface a config error at 3am rather than at deploy time — and the
  // only other option, quietly falling back to the public development key,
  // would reopen exactly the hole the keyed mask closes while looking fixed.
  // Render keeps the previous instance serving when a deploy fails to boot,
  // so failing closed here costs a failed deploy, not downtime. Outside
  // production this warns and uses the development key, so local dev and CI
  // need no configuration — full rationale in mask-key.ts.
  //
  // It is mask-key.ts and not events.ts on purpose: this file is bundled for
  // the EDGE runtime too, and events.ts imports node:crypto, which fails the
  // edge bundle at `next build`. A dynamic import does not help — app source
  // gets bundled rather than externalised, unlike the pg-boss import below.
  const { validateAuditMaskKey } = await import("./core/audit/mask-key");
  validateAuditMaskKey();

  // Dynamic import so edge/build bundling never pulls in pg-boss.
  const { registerWorker } = await import("./core/jobs/worker");
  await registerWorker();
}
