import Link from "next/link";

/**
 * The typographic logo (T45): the product name set in the app font.
 *
 * There is no image asset and deliberately so — Elif's decision was that the
 * mark IS the name "Kleinburg" typeset in Space Grotesk (the open-source
 * stand-in for Baikal, already the app font via `lib/fonts.ts`). The only
 * colour is the existing brand token `--color-accent` (#6642FF), reached
 * through the generated theme's `text-accent` utility. No new token, so
 * nothing here touches `design/tokens.json` (hard rule 3).
 *
 * One component, two sizes: `lg` is the login page hero, `sm` is the header
 * lockup in the signed-in app. Keeping them in one file is what stops the two
 * from drifting apart.
 */

const SIZE_CLASSES = {
  sm: "text-lg",
  lg: "text-4xl sm:text-5xl",
} as const;

export function Wordmark({
  size = "sm",
  href,
  className = "",
}: {
  size?: keyof typeof SIZE_CLASSES;
  /** Renders the mark as a link when set — the header's "home" affordance. */
  href?: string;
  className?: string;
}) {
  const mark = (
    <span
      className={`font-semibold tracking-tight text-fg ${SIZE_CLASSES[size]} ${className}`}
    >
      Kleinburg
      {/* Decorative: the brand colour's only appearance in the mark. Hidden
          from assistive tech so the logo announces as "Kleinburg", not
          "Kleinburg period". */}
      <span aria-hidden="true" className="text-accent">
        .
      </span>
    </span>
  );

  if (!href) return mark;

  return (
    <Link href={href} className="inline-flex transition-opacity hover:opacity-80">
      {mark}
    </Link>
  );
}
