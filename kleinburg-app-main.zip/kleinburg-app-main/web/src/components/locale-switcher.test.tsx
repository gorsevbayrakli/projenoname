// @vitest-environment jsdom
/**
 * The switcher's failure behaviour (#43 review, finding 1).
 *
 * The account preference beats the cookie, so when the preference write fails
 * nothing about the interface changes. The one thing that must NOT happen is
 * the silent version of that: a click, a refresh, and the same language, with
 * no explanation. These tests assert the user is told, in real Turkish from
 * messages/tr.json.
 */
import { cleanup, fireEvent, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { renderWithIntl } from "@/test/render-with-intl";

const refresh = vi.fn();
vi.mock("next/navigation", () => ({
  useRouter: () => ({ refresh, push: vi.fn() }),
}));

const setLocale = vi.fn();
vi.mock("@/i18n/set-locale", () => ({
  setLocale: (value: string) => setLocale(value),
}));

const { LocaleSwitcher } = await import("./locale-switcher");

const FAILURE_TEXT = "Dil tercihiniz kaydedilemedi. Lütfen tekrar deneyin.";

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

describe("LocaleSwitcher", () => {
  it("lists all six interface languages as options", () => {
    setLocale.mockResolvedValue({ ok: true });
    renderWithIntl(<LocaleSwitcher />);
    const options = screen.getAllByRole("option");
    expect(options).toHaveLength(6);
    expect(options.map((o) => (o as HTMLOptionElement).value)).toEqual([
      "tr", "en", "fr", "it", "es", "de",
    ]);
  });

  it("switches and says nothing when the preference is stored", async () => {
    setLocale.mockResolvedValue({ ok: true });
    renderWithIntl(<LocaleSwitcher />);

    fireEvent.change(screen.getByRole("combobox"), {
      target: { value: "en" },
    });

    await waitFor(() => expect(refresh).toHaveBeenCalled());
    expect(setLocale).toHaveBeenCalledWith("en");
    expect(screen.queryByRole("alert")).toBeNull();
  });

  it("tells the user when the preference could not be saved", async () => {
    setLocale.mockResolvedValue({
      ok: false,
      reason: "PREFERENCE_WRITE_FAILED",
    });
    renderWithIntl(<LocaleSwitcher />);

    fireEvent.change(screen.getByRole("combobox"), {
      target: { value: "en" },
    });

    const alert = await screen.findByRole("alert");
    expect(alert.textContent).toBe(FAILURE_TEXT);
  });

  it("tells the user when the server action itself throws", async () => {
    setLocale.mockRejectedValue(new Error("boom"));
    renderWithIntl(<LocaleSwitcher />);

    fireEvent.change(screen.getByRole("combobox"), {
      target: { value: "en" },
    });

    const alert = await screen.findByRole("alert");
    expect(alert.textContent).toBe(FAILURE_TEXT);
  });
});
