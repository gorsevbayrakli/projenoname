"use client";

import { useLocale, useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import { useId, useState, useTransition } from "react";

import { LOCALES, type Locale } from "@/i18n/locales";
import { setLocale } from "@/i18n/set-locale";

/**
 * Six-language interface-language dropdown (T25, converted from a TR/EN
 * toggle to a native `<select>` in T60 once LOCALES grew to six).
 *
 * Placed in the /projects sidebar footer, the wizard rail (desktop + mobile
 * bar) and the login page. Changing the locale writes the kb_locale cookie via
 * a server action and then router.refresh()es: the refresh is what re-renders
 * the SERVER components (page headings, the rail's step labels) in the new
 * language — without it only client components would switch.
 *
 * This switches the INTERFACE language only. The CONTENT language of a project
 * (projects.language) is a separate, unrelated setting on the project itself.
 *
 * A native `<select>` is used deliberately instead of a styled listbox
 * (e.g. Radix Select): Radix's Select is flaky under jsdom in tests.
 *
 * ── WHY A FAILURE IS VISIBLE HERE (#43 review, finding 1) ────────────────
 * Since T43 the stored account preference OUTRANKS the cookie, so a preference
 * write that fails means the language does not change at all. Without this
 * message the user would click, watch the page refresh, and see the same
 * language with no reason given. `setLocale` reports the failure rather than
 * swallowing it, and this is where the report becomes something a person reads.
 */
export function LocaleSwitcher({ className = "" }: { className?: string }) {
  const t = useTranslations("locale");
  const active = useLocale() as Locale;
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [failed, setFailed] = useState(false);
  // Unique per instance: the switcher renders twice at once in the wizard rail
  // (mobile bar + desktop aside), so a fixed id would duplicate in the DOM and
  // the label's htmlFor would bind only the first.
  const selectId = useId();

  function choose(next: Locale) {
    if (next === active || isPending) return;
    startTransition(async () => {
      let ok = false;
      try {
        // A thrown action (transport, redeploy mid-flight) is the same story
        // for the user as a rejected write: the preference did not stick.
        ok = (await setLocale(next)).ok;
      } catch (e) {
        console.error("[i18n] setLocale action failed", e);
      }
      setFailed(!ok);
      // Only refresh on success; re-rendering after a failure would repaint the
      // page in the unchanged language and make the change look accepted.
      if (ok) router.refresh();
    });
  }

  return (
    <div className={"inline-flex flex-col items-start gap-1 " + className}>
      <label htmlFor={selectId} className="sr-only">
        {t("label")}
      </label>
      <select
        id={selectId}
        aria-label={t("label")}
        value={active}
        disabled={isPending}
        onChange={(e) => choose(e.target.value as Locale)}
        className="rounded-lg border border-border bg-bg px-2 py-1 text-xs font-medium text-fg outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:opacity-60"
      >
        {LOCALES.map((locale) => (
          <option key={locale} value={locale}>
            {t(`${locale}Full`)}
          </option>
        ))}
      </select>
      {failed ? (
        <p role="alert" className="text-xs text-destructive">
          {t("saveFailed")}
        </p>
      ) : null}
    </div>
  );
}
