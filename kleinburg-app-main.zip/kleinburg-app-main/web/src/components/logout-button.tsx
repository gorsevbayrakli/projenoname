"use client";

import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import { useState } from "react";

import { Button } from "@/components/ui/button";

/**
 * Sign out, from anywhere.
 *
 * Lives in `components/` rather than beside /projects because it is also the
 * only way OUT of /change-password (#40 review, finding 2): that page sits
 * outside the (app) group precisely so the forced-change redirect cannot loop,
 * which also means none of the group's chrome — including this button — is
 * there unless it is placed explicitly.
 */
export function LogoutButton({ className = "w-full" }: { className?: string }) {
  const t = useTranslations("auth");
  const router = useRouter();
  const [pending, setPending] = useState(false);

  async function onLogout() {
    setPending(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      router.push("/login");
      router.refresh();
    } finally {
      setPending(false);
    }
  }

  return (
    <Button
      variant="outline"
      className={className}
      onClick={onLogout}
      disabled={pending}
    >
      {pending ? t("loggingOut") : t("logout")}
    </Button>
  );
}
