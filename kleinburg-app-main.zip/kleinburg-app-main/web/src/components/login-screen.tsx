import { getTranslations } from "next-intl/server";
import { redirect } from "next/navigation";

import { LocaleSwitcher } from "@/components/locale-switcher";
import { Wordmark } from "@/components/wordmark";
import { LoginForm } from "@/app/login/login-form";
import { signedInDestination } from "@/lib/auth-redirect";
import { getCurrentUser } from "@/lib/auth-server";

/**
 * The sign-in screen, shared by `/` and `/login` (T45).
 *
 * The root URL used to show a create-next-app leftover. It is now the front
 * door: the typographic logo, a one-line product description, and the form.
 * `/login` still exists and renders exactly this — every redirect in the app
 * (middleware, the (app) layout, logout) points there, and one component means
 * the two entry points cannot drift apart.
 *
 * AUTH. This does not weaken anything. The session check below is the same
 * server-side `getCurrentUser` the app uses; it only redirects someone who is
 * ALREADY signed in away from a page they have no use for, and it defers to
 * the forced-password-change gate rather than routing around it (see
 * `signedInDestination`). A visitor with no session sees the form, which is
 * the point — the page must work with no cookie at all, including no
 * `kb_locale` (the locale falls back to Turkish in `i18n/request.ts`).
 */
export async function LoginScreen() {
  const user = await getCurrentUser();
  const destination = signedInDestination(user);
  if (destination) redirect(destination);

  const t = await getTranslations("auth");

  return (
    // Single column, generous but not fussy; max-w-sm keeps the form usable at
    // 375px with the same px-6 gutter the rest of the app uses (T22).
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center gap-10 px-6 py-16">
      <div className="flex items-start justify-between gap-4">
        <Wordmark size="lg" />
        {/* T25: the switcher is reachable BEFORE signing in — the interface
            locale lives in a cookie, not on the user, so it works with no
            session at all. */}
        <LocaleSwitcher />
      </div>

      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-xl font-semibold tracking-tight text-fg">
            {t("title")}
          </h1>
          {/*
            Product-owner approved copy (Elif, 2026-07-20). It shipped as a
            marked draft first, on the rule that nobody but the owner writes the
            sentence describing the product. Any future edit is hers too.
          */}
          <p className="mt-2 text-sm text-fg-muted">{t("productDescription")}</p>
        </div>
        <LoginForm />
      </div>
    </main>
  );
}
