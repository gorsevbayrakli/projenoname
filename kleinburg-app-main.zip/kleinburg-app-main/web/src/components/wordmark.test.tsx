// @vitest-environment jsdom
//
// T45. The typographic logo: the product name "Kleinburg" set in the app font
// (Space Grotesk). Same harness convention as the other component tests —
// React.createElement (aliased `h`) so no JSX transform is needed here.

import { cleanup, screen } from "@testing-library/react";
import { createElement as h } from "react";
import { afterEach, describe, expect, it } from "vitest";

import { renderWithIntl as render } from "@/test/render-with-intl";

import { Wordmark } from "./wordmark";

afterEach(cleanup);

describe("Wordmark", () => {
  it("reads as the product name, with no decoration in the accessible name", () => {
    render(h(Wordmark, {}));
    // The accent dot is decorative; the logo must still announce as
    // "Kleinburg" and nothing else.
    expect(screen.getByText("Kleinburg")).toBeTruthy();
  });

  it("is a link when given a destination, plain text otherwise", () => {
    const { unmount } = render(h(Wordmark, { href: "/projects" }));
    expect(screen.getByRole("link").getAttribute("href")).toBe("/projects");
    unmount();

    render(h(Wordmark, {}));
    expect(screen.queryByRole("link")).toBeNull();
  });

  it("renders the hero size larger than the header size", () => {
    // The same mark serves the login page and the app header; the size prop is
    // the only difference, so a typo that silently drops it is worth catching.
    const { container, unmount } = render(h(Wordmark, { size: "lg" }));
    const big = container.innerHTML;
    unmount();

    const { container: small } = render(h(Wordmark, { size: "sm" }));
    expect(big).not.toBe(small.innerHTML);
  });
});
