// @vitest-environment jsdom
//
// The two shared state surfaces from T22. Same harness convention as the step
// component tests: React.createElement (aliased `h`) so no JSX transform is
// needed for the test file itself.

import { cleanup, fireEvent, screen } from "@testing-library/react";

// T25: rendered through renderWithIntl, which wraps the component in
// NextIntlClientProvider with the REAL Turkish catalog — so every assertion
// below still checks the exact Turkish a user reads.
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { EmptyState } from "./empty-state";
import { ErrorNotice } from "./error-notice";

afterEach(cleanup);

describe("ErrorNotice", () => {
  it("announces as an alert and shows the friendly message + raw reason", () => {
    render(
      h(ErrorNotice, {
        message: "Bağlantı sorunu. Tekrar deneyin.",
        reason: "OpenRouter isteği 3 denemeden sonra başarısız oldu",
      }),
    );

    const alert = screen.getByRole("alert");
    expect(alert.textContent).toContain("Bağlantı sorunu. Tekrar deneyin.");
    // Hard rule 5: the honest reason is never hidden behind the friendly copy.
    expect(alert.textContent).toContain(
      "OpenRouter isteği 3 denemeden sonra başarısız oldu",
    );
  });

  it("fires the retry callback from the Tekrar dene button", () => {
    const onRetry = vi.fn();
    render(h(ErrorNotice, { message: "Hata", onRetry }));

    fireEvent.click(screen.getByRole("button", { name: "Tekrar dene" }));
    expect(onRetry).toHaveBeenCalledTimes(1);
  });

  it("renders no retry button when no callback is given", () => {
    render(h(ErrorNotice, { message: "Hata" }));
    expect(screen.queryByRole("button")).toBeNull();
  });
});

describe("EmptyState", () => {
  it("renders the title, the explanatory line and the action slot", () => {
    render(
      h(EmptyState, {
        title: "Henüz marka bağlamı yok",
        description: "Marka bağlamını üretmek için başlayın.",
        action: h("button", { type: "button" }, "Üret"),
      }),
    );

    expect(screen.getByText("Henüz marka bağlamı yok")).toBeTruthy();
    expect(
      screen.getByText("Marka bağlamını üretmek için başlayın."),
    ).toBeTruthy();
    expect(screen.getByRole("button", { name: "Üret" })).toBeTruthy();
  });

  it("is not an alert — an empty step is a normal state, not a failure", () => {
    render(h(EmptyState, { title: "Henüz belge yok" }));
    expect(screen.queryByRole("alert")).toBeNull();
  });
});
