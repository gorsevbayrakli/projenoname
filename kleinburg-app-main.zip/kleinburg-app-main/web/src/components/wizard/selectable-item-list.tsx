"use client";

import { useTranslations } from "next-intl";

import type { ItemSource } from "@/core/pipeline/schemas";

import { cardGridClass, selectableCardClass, type CardGridColumns } from "./card-grid";
import { SourceLinks } from "./source-links";

/**
 * Reusable selectable card list for the generative wizard steps.
 *
 * Renders a list of `{ title, description }` items as cards, each with a
 * selection checkbox, an editable title (input) and description (textarea), plus
 * "Tümünü seç" / "Temizle" bulk controls. Purely presentational: it owns NO
 * persistence — it emits `onItemsChange` on an inline edit and
 * `onSelectionChange` on a checkbox toggle / bulk action, and the parent is
 * responsible for (debounced) auto-save.
 *
 * Selection is expressed as an array of item indices (`selectedIndices`), the
 * exact shape stored in step_contents.selections.selectedIndices. The parent
 * seeds it to [] for a fresh generation (none selected).
 *
 * Established by T16 (secondary_data); reused verbatim by T18 (creative_sparks)
 * — both use the {title, description} item shape — and adapted by T19 (pillars).
 */

export interface TitledItem {
  title: string;
  description: string;
  /**
   * The documents behind this item (#47). Only secondary_data has them —
   * creative_sparks and pillars are reasoning, not retrieval — so the field is
   * optional and rendering it is opt-in via `showSources`.
   */
  sources?: ItemSource[];
}

export function SelectableItemList({
  items,
  selectedIndices,
  onItemsChange,
  onSelectionChange,
  emptyHint,
  showSources = false,
  columns = 3,
}: {
  items: TitledItem[];
  selectedIndices: number[];
  onItemsChange: (items: TitledItem[]) => void;
  onSelectionChange: (indices: number[]) => void;
  emptyHint?: string;
  /**
   * Show each item's sources, and mark the ones that have none (#47).
   *
   * OPT-IN, not inferred from `item.sources` being empty: the "no source" mark
   * is a claim about a step that was supposed to retrieve something, and it
   * would be nonsense on creative_sparks, which never had sources to lack.
   */
  showSources?: boolean;
  /**
   * Max grid columns at the widest breakpoint (#44). DEFAULT 3: these cards are
   * a short title plus a description, so three across is readable and turns a
   * 30-item scroll into a comparable set. Always one column on phones.
   */
  columns?: CardGridColumns;
}) {
  const t = useTranslations("itemList");
  const tCommon = useTranslations("common");
  const selected = new Set(selectedIndices);

  function toggle(index: number) {
    const next = new Set(selected);
    if (next.has(index)) {
      next.delete(index);
    } else {
      next.add(index);
    }
    onSelectionChange([...next].sort((a, b) => a - b));
  }

  function selectAll() {
    onSelectionChange(items.map((_, i) => i));
  }

  function clear() {
    onSelectionChange([]);
  }

  /**
   * Apply an inline edit to one item, DROPPING its sources (#47 review).
   *
   * `sources` is an assertion about the text it sits under: these documents
   * were retrieved for a run that produced THIS claim. Rewrite the claim and the
   * assertion is no longer about anything. Carrying it over let a user replace
   * an item's text wholesale while the link, the retrieved publication title and
   * the downstream `[sources: …]` marker all survived — so arbitrary typed text
   * arrived at the post step licensed as a researched finding, which is the
   * exact laundering path this whole change exists to close.
   *
   * ANY edit clears, not just a "material" one. There is no honest way to tell a
   * typo fix from a claim change here — a single digit is the difference between
   * 4% and 40% — and the two failure directions are not symmetric: a needlessly
   * cleared source costs a re-generation, an incorrectly kept one puts a real
   * publication's name behind a sentence it never supported.
   *
   * Visible, not silent: the item immediately renders the `noSource` warning in
   * <SourceLinks>, so the user sees what their edit cost at the moment it
   * happens. `title` and `description` are treated identically — both are the
   * claim, and the title is what the pillar/post prompts read first.
   */
  function editItem(index: number, patch: Partial<TitledItem>) {
    onItemsChange(
      items.map((it, i) => {
        if (i !== index) return it;
        // Only items that HAVE the field lose it. An item with no `sources` at
        // all (creative_sparks, and secondary_data stored before #47) keeps its
        // exact stored shape — this edit path also serves steps that never had
        // sources, and adding an empty array to them would write a field the
        // step's own schema does not define.
        const cleared = it.sources === undefined ? {} : { sources: [] };
        return { ...it, ...patch, ...cleared };
      }),
    );
  }

  function editTitle(index: number, title: string) {
    editItem(index, { title });
  }

  function editDescription(index: number, description: string) {
    editItem(index, { description });
  }

  if (items.length === 0) {
    return (
      <p className="text-sm text-fg-muted">
        {emptyHint ?? t("empty")}
      </p>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-2">
        <span className="text-sm text-fg-muted">
          {tCommon("selectedCount", {
            selected: selectedIndices.length,
            total: items.length,
          })}
        </span>
        <div className="ml-auto flex items-center gap-2">
          <button
            type="button"
            onClick={selectAll}
            className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
          >
            {tCommon("selectAll")}
          </button>
          <button
            type="button"
            onClick={clear}
            className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
          >
            {tCommon("clear")}
          </button>
        </div>
      </div>

      <ul className={cardGridClass(columns)}>
        {items.map((item, index) => {
          const isSelected = selected.has(index);
          return (
            <li key={index} className={selectableCardClass(isSelected)}>
              <input
                type="checkbox"
                checked={isSelected}
                onChange={() => toggle(index)}
                aria-label={t("select", { n: index + 1 })}
                className="mt-1 h-4 w-4 shrink-0 accent-accent"
              />
              {/* min-w-0: in a narrow grid column a flex child would otherwise
                  refuse to shrink below its inputs' intrinsic width and push the
                  card past its track. */}
              <div className="flex min-w-0 flex-1 flex-col gap-2">
                <input
                  type="text"
                  value={item.title}
                  onChange={(e) => editTitle(index, e.target.value)}
                  aria-label={t("title", { n: index + 1 })}
                  className="w-full rounded-md border border-border bg-bg px-2 py-1 text-sm font-medium text-fg outline-none focus-visible:border-accent"
                />
                <textarea
                  value={item.description}
                  onChange={(e) => editDescription(index, e.target.value)}
                  aria-label={t("description", { n: index + 1 })}
                  rows={3}
                  className="w-full resize-y rounded-md border border-border bg-bg px-2 py-1 text-sm leading-relaxed text-fg outline-none focus-visible:border-accent"
                />
                {showSources ? <SourceLinks sources={item.sources} /> : null}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
