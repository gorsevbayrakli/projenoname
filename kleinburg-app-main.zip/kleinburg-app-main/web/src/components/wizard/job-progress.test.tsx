// @vitest-environment jsdom
//
// #56 / #63: JobProgress must never confuse TRANSPORT state with JOB state.
// A dropped SSE connection says nothing about the generation behind it, and a
// cancelled job must say it was superseded rather than "Bağlantı kesildi".
//
// Same harness convention as the other wizard component tests:
// React.createElement (aliased `h`), and the REAL Turkish catalog through
// renderWithIntl, so every assertion below is the exact sentence a user reads.

import { act, cleanup, screen } from "@testing-library/react";
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const CONNECTING = 0;
const OPEN = 1;
const CLOSED = 2;

/**
 * EventSource is not in jsdom. This stub also models the one property the
 * component now has to read: readyState. A real browser sets it to CONNECTING
 * while it retries a dropped stream by itself, and only to CLOSED when it has
 * given up for good.
 */
const sources: FakeEventSource[] = [];
class FakeEventSource {
  readyState = OPEN;
  closeCalls = 0;
  onmessage: ((e: MessageEvent) => void) | null = null;
  onerror: (() => void) | null = null;
  constructor(readonly url: string) {
    sources.push(this);
  }
  close() {
    this.closeCalls += 1;
    this.readyState = CLOSED;
  }
}
vi.stubGlobal("EventSource", FakeEventSource);

import { JobProgress } from "./job-progress";

/** Push one SSE frame into the live stream, exactly as the route would. */
async function frame(payload: unknown): Promise<void> {
  await act(async () => {
    sources[0].onmessage?.({ data: JSON.stringify(payload) } as MessageEvent);
  });
}

/** A transient drop: the browser is already reconnecting on its own. */
async function transientDrop(): Promise<void> {
  await act(async () => {
    sources[0].readyState = CONNECTING;
    sources[0].onerror?.();
  });
}

/** A permanent failure: the browser will not retry this stream. */
async function permanentDrop(): Promise<void> {
  await act(async () => {
    sources[0].readyState = CLOSED;
    sources[0].onerror?.();
  });
}

beforeEach(() => {
  sources.length = 0;
});
afterEach(cleanup);

describe("JobProgress transport vs job state (#56, #60)", () => {
  it("does not report a running generation as failed when the connection drops", async () => {
    const onDone = vi.fn();
    render(h(JobProgress, { jobId: "j1", onDone }));
    await frame({ status: "running" });

    await transientDrop();

    // The job is still running server-side; nothing terminal may be claimed.
    expect(onDone).not.toHaveBeenCalled();
    // And the pill must not flip to the failure copy.
    expect(screen.queryByText("Hata")).toBeNull();
    expect(screen.getByText("Üretiliyor")).toBeTruthy();
  });

  it("keeps the stream open across a drop so the browser can reconnect", async () => {
    render(h(JobProgress, { jobId: "j1" }));
    await frame({ status: "running" });

    await transientDrop();

    // Calling close() here is what defeats EventSource's own retry.
    expect(sources[0].closeCalls).toBe(0);
  });

  it("recovers silently when the reconnected stream reports success", async () => {
    const onDone = vi.fn();
    render(h(JobProgress, { jobId: "j1", onDone }));
    await frame({ status: "running" });
    await transientDrop();

    await frame({ status: "succeeded", output: { ok: true } });

    expect(onDone).toHaveBeenCalledTimes(1);
    expect(onDone.mock.calls[0][0].status).toBe("succeeded");
  });

  it("treats a streamClosed frame as a lost stream, not a lost job (#60)", async () => {
    const onDone = vi.fn();
    render(h(JobProgress, { jobId: "j1", onDone }));
    await frame({ status: "running" });

    // What the route now emits at the 10-minute cap / on a vanished row.
    await frame({ status: "running", streamClosed: true });

    // Not a JOB outcome: nothing terminal is claimed and the pill stands.
    expect(onDone).not.toHaveBeenCalled();
    expect(screen.getByText("Üretiliyor")).toBeTruthy();
    // But it IS a lost STREAM, and only the disconnect notice distinguishes it
    // from an ordinary running snapshot. Without this line the whole
    // streamClosed branch can be deleted and this test still passes — which is
    // exactly what it did before, so assert the half that has teeth.
    expect(document.body.textContent).toContain("Bağlantı kesildi");
  });

  it("spends the drop budget on streamClosed frames, so a stream that is only ever capped stops waiting", async () => {
    const onDone = vi.fn();
    render(h(JobProgress, { jobId: "j1", onDone }));
    await frame({ status: "running" });

    // Caps with no healthy frame in between: reconnect is not delivering, so
    // the budget must actually run out rather than wait forever.
    for (let i = 0; i < 6; i += 1) {
      await frame({ status: "running", streamClosed: true });
    }

    expect(onDone).toHaveBeenCalledTimes(1);
    expect(onDone.mock.calls[0][0].status).toBe("running");
    expect(onDone.mock.calls[0][0].error).toContain("Bağlantı kesildi");
  });

  it("clears the disconnect banner once the reconnected stream reports a healthy run", async () => {
    render(h(JobProgress, { jobId: "j1" }));
    await frame({ status: "running" });
    await transientDrop();
    expect(document.body.textContent).toContain("Bağlantı kesildi");

    // The browser reconnected and the job is fine. Leaving "refresh the page"
    // on screen for the rest of a healthy 12-minute run is wrong advice, and
    // recovering to `succeeded` does not cover this: there the status predicate
    // hides the banner instead of anything actually clearing it.
    await frame({ status: "running" });

    expect(document.body.textContent).not.toContain("Bağlantı kesildi");
    expect(screen.getByText("Üretiliyor")).toBeTruthy();
  });

  it("counts drops consecutively, not for the lifetime of the stream", async () => {
    const onDone = vi.fn();
    render(h(JobProgress, { jobId: "j1", onDone }));
    await frame({ status: "running" });

    // The server caps EVERY stream at 10 minutes and each cap costs two drops,
    // so a lifetime budget gives up after ~30 minutes of healthy streaming —
    // on a branch that raised the job expiry to 4 hours because secondary_data
    // can legitimately run ~180 minutes.
    for (let i = 0; i < 5; i += 1) await transientDrop();
    await frame({ status: "running" });
    for (let i = 0; i < 5; i += 1) await transientDrop();

    expect(onDone).not.toHaveBeenCalled();
    expect(screen.getByText("Üretiliyor")).toBeTruthy();
  });

  it("gives up after repeated drops without claiming the generation failed", async () => {
    const onDone = vi.fn();
    render(h(JobProgress, { jobId: "j1", onDone }));
    await frame({ status: "running" });

    for (let i = 0; i < 8; i += 1) await transientDrop();

    expect(onDone).toHaveBeenCalledTimes(1);
    // The last thing we actually KNEW about the job was that it was running.
    expect(onDone.mock.calls[0][0].status).not.toBe("failed");
    expect(onDone.mock.calls[0][0].status).toBe("running");
    expect(onDone.mock.calls[0][0].error).toContain("Bağlantı kesildi");
  });

  it("ends the wait on a permanently closed stream, still without saying failed", async () => {
    const onDone = vi.fn();
    render(h(JobProgress, { jobId: "j1", onDone }));
    await frame({ status: "running" });

    await permanentDrop();

    expect(onDone).toHaveBeenCalledTimes(1);
    expect(onDone.mock.calls[0][0].status).not.toBe("failed");
    expect(onDone.mock.calls[0][0].error).toContain("Bağlantı kesildi");
  });

  it("still reports a genuine failure as failed", async () => {
    const onDone = vi.fn();
    render(h(JobProgress, { jobId: "j1", onDone }));

    await frame({ status: "failed", error: "OpenRouter 3 denemeden sonra düştü" });

    expect(onDone).toHaveBeenCalledTimes(1);
    expect(onDone.mock.calls[0][0].status).toBe("failed");
    expect(screen.getByText("Hata")).toBeTruthy();
    // A failure pill is red, so its explanation is red too.
    expect(
      screen.getByText("OpenRouter 3 denemeden sonra düştü").className,
    ).toContain("text-fg-error");
  });

  it("does not let the banner-clearing path swallow a real engine error", async () => {
    render(h(JobProgress, { jobId: "j1" }));
    await frame({ status: "running" });
    await transientDrop();

    await frame({
      status: "failed",
      error: "OpenRouter 3 denemeden sonra düştü",
    });

    // The engine's own reason replaces the stale transport copy, rather than
    // being cleared along with it.
    expect(document.body.textContent).toContain(
      "OpenRouter 3 denemeden sonra düştü",
    );
    expect(document.body.textContent).not.toContain("Bağlantı kesildi");
  });
});

describe("JobProgress cancelled job (#63)", () => {
  it("reports a cancelled job as superseded, not as a lost connection", async () => {
    const onDone = vi.fn();
    render(h(JobProgress, { jobId: "j1", onDone }));
    await frame({ status: "running" });

    // supersedeActiveJobs cancelled this run; the route emits it and closes.
    await frame({ status: "cancelled" });

    expect(onDone).toHaveBeenCalledTimes(1);
    expect(onDone.mock.calls[0][0].status).toBe("cancelled");
    // The honest reason, not the generic transport copy.
    expect(onDone.mock.calls[0][0].error).toContain("daha yeni bir üretim");
    expect(onDone.mock.calls[0][0].error).not.toContain("Bağlantı kesildi");
  });

  it("shows the cancelled pill and the superseded explanation", async () => {
    render(h(JobProgress, { jobId: "j1" }));
    await frame({ status: "cancelled" });

    expect(screen.getByText("İptal edildi")).toBeTruthy();
    expect(document.body.textContent).toContain("daha yeni bir üretim");
    expect(document.body.textContent).not.toContain("Bağlantı kesildi");
  });

  it("explains a superseded run in the pill's tone, not in error red", async () => {
    render(h(JobProgress, { jobId: "j1" }));
    await frame({ status: "cancelled" });

    // The pill is deliberately muted because a superseded run is a normal
    // outcome; an explanation in error red makes the two halves of the same
    // message disagree about whether anything broke.
    const explanation = screen.getByText(/daha yeni bir üretim/);
    expect(explanation.className).not.toContain("text-fg-error");
    expect(explanation.className).toContain("text-fg-muted");
  });

  it("closes the stream on cancelled so a later error cannot repaint it", async () => {
    const onDone = vi.fn();
    render(h(JobProgress, { jobId: "j1", onDone }));
    await frame({ status: "cancelled" });

    // The route closes right after the cancelled frame -> onerror fires.
    await permanentDrop();

    expect(onDone).toHaveBeenCalledTimes(1);
    expect(onDone.mock.calls[0][0].status).toBe("cancelled");
    // The cancelled FRAME is what finished us, so the reason is the superseded
    // copy. If the close-after-cancel error is what finished us instead, this
    // is the generic transport copy — which is exactly the bug in #63.
    expect(onDone.mock.calls[0][0].error).toContain("daha yeni bir üretim");
  });
});
