"use client";

import { useTranslations } from "next-intl";
import { useEffect, useRef, useState } from "react";

/**
 * Terminal job statuses: the stream closes and onDone fires on these.
 * 'cancelled' belongs here — the route treats it as terminal and closes right
 * after emitting it (#63). Without it the close arrived as a bare onerror and
 * a superseded job was reported to the user as a lost connection.
 */
const TERMINAL = new Set(["succeeded", "failed", "cancelled"]);

/**
 * How many CONSECUTIVE transport drops we absorb before we stop waiting.
 * EventSource reconnects on its own, so a drop is not news about the job; but a
 * stream that never delivers again must not keep a tab reconnecting forever.
 *
 * Consecutive is load-bearing, not a detail. The route caps every stream at
 * MAX_DURATION_MS (10 min), and each cap costs two drops: closeStream() emits
 * the streamClosed frame, then controller.close() surfaces as an EventSource
 * error. A lifetime budget would therefore expire after ~30 minutes of
 * perfectly healthy streaming — on the same branch that raised the pg-boss
 * expiry to 4 hours because secondary_data can legitimately occupy the handler
 * ~180 minutes, and that moved RESEARCH_MODEL to sonar-reasoning-pro, which
 * makes long runs more likely rather than less.
 */
const MAX_TRANSPORT_DROPS = 5;

/** EventSource.readyState — CLOSED means the browser will NOT retry. */
const ES_CLOSED = 2;

type JobResult = { status: string; output?: unknown; error?: string };

/** What the route sends over the wire; streamClosed is transport, not job. */
type StreamFrame = JobResult & { streamClosed?: boolean };

/**
 * UI mapping for each status: translation key + accent styling for the pill.
 * The label is looked up at render time (T25) so the pill follows the interface
 * language; only the tone is static.
 */
const STATUS_META: Record<
  string,
  {
    key: "queued" | "running" | "succeeded" | "failed" | "cancelled";
    tone: "active" | "success" | "error" | "idle";
  }
> = {
  queued: { key: "queued", tone: "idle" },
  running: { key: "running", tone: "active" },
  succeeded: { key: "succeeded", tone: "success" },
  failed: { key: "failed", tone: "error" },
  // Not an error tone: a superseded run is a normal outcome, not a breakage.
  cancelled: { key: "cancelled", tone: "idle" },
};

function pillClass(tone: "active" | "success" | "error" | "idle"): string {
  switch (tone) {
    case "active":
      return "bg-accent-subtle text-accent-fg";
    case "success":
      return "bg-bg-success text-fg-success";
    case "error":
      return "bg-bg-error text-fg-error";
    default:
      return "bg-bg-muted text-fg-muted";
  }
}

/**
 * Live progress for a single generation job. Opens an EventSource on the job's
 * SSE stream (/api/jobs/[id]/stream), renders a status pill + elapsed timer in
 * the HAVAI "Generating…" style, and fires onDone once on a terminal status.
 * Closes the EventSource on unmount and on terminal — no leaks.
 *
 * Transport state is NOT job state (#56, #60, #63). A dropped connection is not
 * a failed generation: the browser reconnects by itself and the reconnected
 * stream re-reports the job's real status. onDone therefore never carries a
 * status this component was not actually told — when the stream gives out for
 * good, it reports the last status seen plus the disconnect notice, so a caller
 * can never render a still-running (or already succeeded) job as a failure.
 *
 * Self-contained: T14–T21 mount this after POSTing a generate and receiving a
 * jobId.
 */
export function JobProgress({
  jobId,
  onDone,
}: {
  jobId: string;
  onDone?: (result: JobResult) => void;
}) {
  const t = useTranslations("jobProgress");
  const [status, setStatus] = useState<string>("queued");
  const [error, setError] = useState<string | null>(null);
  const [elapsed, setElapsed] = useState(0);

  // Keep the latest onDone without re-subscribing the EventSource.
  const onDoneRef = useRef(onDone);
  onDoneRef.current = onDone;

  // Read outside the effect so the effect does not depend on the translator
  // identity (which would re-subscribe the EventSource).
  const disconnected = t("disconnected");
  const cancelledReason = t("cancelledReason");

  useEffect(() => {
    const startedAt = Date.now();
    const es = new EventSource(`/api/jobs/${jobId}/stream`);
    let done = false;
    // The last status we actually observed. Handed to onDone when the stream
    // gives out, so we never invent a job state we were never told.
    let lastStatus = "queued";
    let drops = 0;
    const timer = setInterval(() => {
      setElapsed(Math.round((Date.now() - startedAt) / 1000));
    }, 1000);

    const finish = (result: JobResult) => {
      if (done) return;
      done = true;
      clearInterval(timer); // stop the per-second re-render once terminal
      es.close();
      onDoneRef.current?.(result);
    };

    /**
     * The connection went away while the job was still running. That is
     * TRANSPORT state and says nothing about the generation (#56, #60), so we
     * only surface a non-terminal notice and let EventSource reconnect — the
     * reconnected stream re-emits the job's real status, which is the recheck.
     * Only after MAX_TRANSPORT_DROPS do we stop waiting, and even then we hand
     * back the last status we actually saw rather than claiming "failed".
     */
    const onTransportDrop = () => {
      if (done) return;
      drops += 1;
      // The engine never produced this text — the browser lost the stream — so
      // it is UI copy and is translated here.
      setError((prev) => prev ?? disconnected);
      if (drops > MAX_TRANSPORT_DROPS) {
        finish({ status: lastStatus, error: disconnected });
      }
    };

    es.onmessage = (event) => {
      let data: StreamFrame;
      try {
        data = JSON.parse(event.data) as StreamFrame;
      } catch {
        return;
      }
      if (data.streamClosed) {
        // The route ended the stream without the job ending (duration cap,
        // vanished row, poll error). Keep the status it reported and wait.
        if (data.status) {
          lastStatus = data.status;
          setStatus(data.status);
        }
        onTransportDrop();
        return;
      }
      // This frame carries job data, which is proof the stream is delivering:
      // the budget above counts consecutive failures, so it starts over.
      drops = 0;
      lastStatus = data.status;
      setStatus(data.status);
      // A frame is a full snapshot of the job, so its error field is the whole
      // truth about the job right now. Adopting it — including when it is empty
      // — is what retires the disconnect notice once a reconnect succeeds,
      // instead of leaving "refresh the page" on screen for the rest of a
      // healthy run. A real engine error is not clobbered: the job row keeps
      // its error, so every later snapshot carries it too.
      setError(data.error ?? null);
      if (TERMINAL.has(data.status)) {
        if (data.status === "cancelled") {
          // A superseded run has no engine error to report, and the generic
          // transport copy would be a lie. Say what actually happened.
          const reason = data.error ?? cancelledReason;
          setError(reason);
          finish({ ...data, error: reason });
          return;
        }
        finish(data);
      }
    };

    es.onerror = () => {
      if (done) return;
      if (es.readyState === ES_CLOSED) {
        // The browser has given up on this stream and will not retry. Still
        // not evidence the generation failed — report what we last knew.
        setError((prev) => prev ?? disconnected);
        finish({ status: lastStatus, error: disconnected });
        return;
      }
      onTransportDrop();
    };

    return () => {
      clearInterval(timer);
      es.close();
    };
    // disconnected/cancelledReason are stable strings for a given locale;
    // re-subscribing the stream on a locale change is neither needed nor wanted.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [jobId]);

  const meta = STATUS_META[status] ?? STATUS_META.queued;
  const isTerminal = TERMINAL.has(status);

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-3">
        <span
          className={
            "inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-medium " +
            pillClass(meta.tone)
          }
        >
          {meta.tone === "active" && (
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-accent" />
          )}
          {t(meta.key)}
        </span>
        {!isTerminal && (
          <span className="text-xs text-fg-subtle">~{elapsed}s</span>
        )}
      </div>
      {/* Shown for a real failure, for a superseded run, and while the stream
          is down — anything but a success has something honest to say. The
          explanation takes the pill's tone: only a failure is red, so a
          superseded run and a dropped connection cannot be styled as breakage
          under a pill that says they are not. */}
      {error && status !== "succeeded" && (
        <p
          className={
            "text-sm " +
            (meta.tone === "error" ? "text-fg-error" : "text-fg-muted")
          }
        >
          {error}
        </p>
      )}
    </div>
  );
}
