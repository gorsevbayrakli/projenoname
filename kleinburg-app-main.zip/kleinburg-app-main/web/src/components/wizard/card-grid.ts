/**
 * Shared responsive grid geometry for the wizard's card lists (#44).
 *
 * The three list components (<SelectableItemList>, <SelectablePillarList>,
 * <PostCardList>) were each a single-column `flex flex-col`. With 21 pillars and
 * up to 30 posts per platform that is an unusable scroll and nothing can be
 * compared side by side, so they all became grids.
 *
 * The layout lives HERE rather than being copy-pasted per consumer: each list
 * takes a `columns` prop (its own documented default) and the class string is
 * produced in one place, so a future change to the breakpoints is one edit.
 *
 * `columns` is the MAXIMUM column count at the widest breakpoint. Every value
 * starts at ONE column and only widens upward — mobile (375px) is always a
 * single column, which is the hard requirement from the issue.
 *
 * The class strings are written out literally (no interpolation) because
 * Tailwind's scanner only sees complete class names in source.
 */

/** Max columns at the widest breakpoint. Always 1 column on phones. */
export type CardGridColumns = 1 | 2 | 3;

/**
 * Grid classes for a card list.
 *
 * - `1` — never widens. For content that only reads correctly in full width.
 * - `2` — for tall, long-form cards (pillars, posts): two columns is already the
 *   point where the whole set stops being a scroll, and a third would squeeze
 *   multi-line captions into a column too narrow to read.
 * - `3` — for short {title, description} cards (secondary data, sparks), which
 *   are the ones that benefit most from dense side-by-side comparison.
 *
 * `items-start` is deliberate: card heights vary (titles, descriptions and now
 * source links all differ in length) and stretching every card in a row to the
 * tallest one would leave large dead areas under short cards. Cards keep their
 * natural height; the grid rows stay aligned at the top.
 */
export function cardGridClass(columns: CardGridColumns): string {
  const base = "grid items-start gap-3 grid-cols-1";
  switch (columns) {
    case 1:
      return base;
    case 2:
      return base + " lg:grid-cols-2";
    case 3:
      return base + " md:grid-cols-2 xl:grid-cols-3";
    default:
      // CardGridColumns is a closed union, so TypeScript proves this is
      // unreachable through the typed API. It is here for the untyped
      // boundary: a value arriving through a cast or from stored data would
      // otherwise fall out of the switch as `undefined`, and `className=
      // {undefined}` renders an unstyled block list that LOOKS like a working
      // page with a lost layout. Hard rule 5 — a wrong column count is a bug
      // to report, not to render silently. The single column is the safe
      // fallback because it is the one layout that works at every width.
      console.warn(
        `[card-grid] unsupported column count ${String(columns)}; ` +
          "falling back to a single column. Expected 1, 2 or 3.",
      );
      return base;
  }
}

/**
 * Card chrome shared by the selectable lists.
 *
 * Selection has to read at a glance in a grid, where a card no longer sits in a
 * single scanned column — so it is carried by THREE signals at once (accent
 * border, tinted background, and an accent ring), not by the border alone as in
 * the old vertical list. The ring is used rather than a thicker border because
 * it draws outside the box and so cannot shift the grid on toggle.
 */
export function selectableCardClass(isSelected: boolean): string {
  return (
    "flex gap-3 " +
    CARD_CHROME +
    " transition-colors " +
    (isSelected
      ? "border-accent bg-accent-subtle ring-2 ring-accent"
      : "border-border bg-bg")
  );
}

/**
 * The card box itself: shape, edge, surface, padding — everything except how
 * the card lays out its own children and whether it can be selected.
 *
 * Shared by `selectableCardClass` and <PostCardList>, which cannot use that
 * helper (post cards are never selected, and stack their children in a column)
 * but must not drift away from it visually. Splitting the chrome out is what
 * keeps "the layout lives in one place" true for the one consumer that only
 * needs part of it — otherwise a change to the card edge silently applies to
 * two of the three lists.
 *
 * Note the border COLOR is not here: a selectable card carries it as state.
 * Every consumer supplies its own `border-*` alongside this.
 */
export const CARD_CHROME = "rounded-lg border p-4";
