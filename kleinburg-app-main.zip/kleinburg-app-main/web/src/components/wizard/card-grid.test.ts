// Unit test for the shared card-grid geometry (#44).
//
// The grid is a layout CONTRACT, not a cosmetic detail: "single column at
// 375px" is an explicit requirement, and the selection affordance had to survive
// the move out of a vertical list. Both are asserted here so a future tweak to
// the class strings cannot quietly drop them.

import { describe, expect, it, vi } from "vitest";

import {
  CARD_CHROME,
  cardGridClass,
  selectableCardClass,
} from "./card-grid";

const ALL = [1, 2, 3] as const;

describe("cardGridClass", () => {
  it("is a grid at every column count", () => {
    for (const n of ALL) {
      expect(cardGridClass(n).split(" ")).toContain("grid");
    }
  });

  it("falls back to a single column on mobile at every column count", () => {
    // The unprefixed grid-cols-1 IS the mobile layout; anything wider must be
    // behind a breakpoint prefix.
    for (const n of ALL) {
      const classes = cardGridClass(n).split(" ");
      expect(classes).toContain("grid-cols-1");
      const unprefixedWide = classes.filter(
        (c) => /^grid-cols-\d+$/.test(c) && c !== "grid-cols-1",
      );
      expect(unprefixedWide).toEqual([]);
    }
  });

  it("widens up to the requested maximum and no further", () => {
    expect(cardGridClass(1)).not.toMatch(/grid-cols-[23]/);
    expect(cardGridClass(2)).toContain("lg:grid-cols-2");
    expect(cardGridClass(2)).not.toMatch(/grid-cols-3/);
    expect(cardGridClass(3)).toContain("md:grid-cols-2");
    expect(cardGridClass(3)).toContain("xl:grid-cols-3");
  });

  it("keeps cards at their natural height so variable content cannot stretch a row", () => {
    for (const n of ALL) {
      expect(cardGridClass(n).split(" ")).toContain("items-start");
    }
  });
});

describe("selectableCardClass", () => {
  it("marks a selected card with border, background AND ring", () => {
    const selected = selectableCardClass(true).split(" ");
    expect(selected).toContain("border-accent");
    expect(selected).toContain("bg-accent-subtle");
    expect(selected).toContain("ring-2");
    expect(selected).toContain("ring-accent");
  });

  it("leaves an unselected card neutral", () => {
    const unselected = selectableCardClass(false).split(" ");
    expect(unselected).toContain("border-border");
    expect(unselected).toContain("bg-bg");
    expect(unselected).not.toContain("ring-2");
  });

  // <PostCardList> cannot use selectableCardClass (its cards are never selected
  // and stack in a column), so it composes CARD_CHROME instead. If the two ever
  // stop sharing the box, the post cards drift away from the other two lists
  // one edit at a time — which is exactly the copy-paste this module removed.
  it("builds its box out of the shared chrome", () => {
    for (const chrome of CARD_CHROME.split(" ")) {
      expect(selectableCardClass(false).split(" ")).toContain(chrome);
    }
  });
});

/**
 * The untyped boundary.
 *
 * `CardGridColumns` is a closed union, so the typed API cannot reach this. A
 * cast or a value read from stored data can. Before this guard the switch fell
 * through and returned `undefined`, and `className={undefined}` renders an
 * unstyled block list — a page that looks like it works but has lost its
 * layout, which is the silent failure hard rule 5 forbids.
 */
describe("cardGridClass with an unsupported column count", () => {
  const bad = (n: number) => cardGridClass(n as 1 | 2 | 3);

  it("says so instead of failing silently", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    bad(5);
    expect(warn).toHaveBeenCalledTimes(1);
    // Actionable without reading the source: the offending value and the range.
    expect(warn.mock.calls[0]![0]).toContain("5");
    warn.mockRestore();
  });

  it("still returns a usable single-column layout", () => {
    vi.spyOn(console, "warn").mockImplementation(() => {});
    const classes = bad(5).split(" ");
    expect(classes).toContain("grid");
    expect(classes).toContain("grid-cols-1");
    // Never a widening breakpoint: one column is the layout that works at every
    // width, so the fallback degrades rather than guessing.
    expect(classes.filter((c) => c.includes(":grid-cols-"))).toEqual([]);
    vi.restoreAllMocks();
  });
});
