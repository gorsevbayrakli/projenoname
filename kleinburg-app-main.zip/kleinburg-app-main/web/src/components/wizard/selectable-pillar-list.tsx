"use client";

import { useTranslations } from "next-intl";

import { cardGridClass, selectableCardClass, type CardGridColumns } from "./card-grid";

/**
 * Selectable card list for sm_pillars (T19).
 *
 * The pillar sibling of <SelectableItemList>: same structure, styling and bulk
 * controls, but a different item shape ({category, title, topicBlend,
 * creativeSpark, hook, contentBrief}) and GROUPED rendering — one section per
 * pillar category, in the fixed legacy order INSPIRATIONAL → ENTERTAINING →
 * INFORMATIONAL, with a heading and a per-section count. Sections with no
 * pillars are omitted.
 *
 * IMPORTANT: `selectedIndices` always refers to the ORIGINAL FLAT array order,
 * not the grouped rendering order. Grouping is a display concern only; every
 * callback (toggle, edit, select-all) maps back to the flat index carried
 * alongside each grouped entry. This is what keeps the persisted selection
 * compatible with gatherVars/serializePillars downstream, which read the flat
 * content.pillars array.
 *
 * Purely presentational: it owns NO persistence — it emits `onPillarsChange` on
 * an inline edit and `onSelectionChange` on a checkbox toggle / bulk action, and
 * the parent is responsible for saving.
 */

export interface PillarItem {
  category: string;
  title: string;
  topicBlend: string;
  creativeSpark: string;
  hook: string;
  contentBrief: string;
}

/** Fixed display order of the three legacy pillar categories. */
const CATEGORY_ORDER = [
  "INSPIRATIONAL",
  "ENTERTAINING",
  "INFORMATIONAL",
] as const;

/** Category -> translation key; the label follows the interface language (T25). */
const CATEGORY_KEY: Record<string, string> = {
  INSPIRATIONAL: "categoryInspirational",
  ENTERTAINING: "categoryEntertaining",
  INFORMATIONAL: "categoryInformational",
};

export function SelectablePillarList({
  pillars,
  selectedIndices,
  onPillarsChange,
  onSelectionChange,
  emptyHint,
  columns = 2,
}: {
  pillars: PillarItem[];
  selectedIndices: number[];
  onPillarsChange: (pillars: PillarItem[]) => void;
  onSelectionChange: (indices: number[]) => void;
  emptyHint?: string;
  /**
   * Max grid columns at the widest breakpoint (#44). DEFAULT 2, not 3: a pillar
   * card carries five labelled fields including a multi-line content brief, and
   * a third column would make those fields too narrow to edit. Two is already
   * enough to stop 21 pillars being a scroll. Grid applies WITHIN each category
   * section; the sections themselves stay stacked, since the whole point of the
   * grouping is that a category reads as one block.
   */
  columns?: CardGridColumns;
}) {
  const t = useTranslations("pillarList");
  const tCommon = useTranslations("common");
  const selected = new Set(selectedIndices);

  function toggle(index: number) {
    const next = new Set(selected);
    if (next.has(index)) {
      next.delete(index);
    } else {
      next.add(index);
    }
    onSelectionChange([...next].sort((a, b) => a - b));
  }

  function selectAll() {
    onSelectionChange(pillars.map((_, i) => i));
  }

  function clear() {
    onSelectionChange([]);
  }

  function editField(index: number, field: keyof PillarItem, value: string) {
    onPillarsChange(
      pillars.map((p, i) => (i === index ? { ...p, [field]: value } : p)),
    );
  }

  if (pillars.length === 0) {
    return (
      <p className="text-sm text-fg-muted">
        {emptyHint ?? t("empty")}
      </p>
    );
  }

  // Group by category while carrying each pillar's FLAT index along, so every
  // callback below addresses the original array position. Categories outside the
  // three known ones fall into a trailing "Diğer" group rather than vanishing.
  const known = new Set<string>(CATEGORY_ORDER);
  const groups: { category: string; entries: { pillar: PillarItem; index: number }[] }[] =
    [
      ...CATEGORY_ORDER.map((category) => ({
        category: category as string,
        entries: pillars
          .map((pillar, index) => ({ pillar, index }))
          .filter((e) => e.pillar.category === category),
      })),
      {
        category: "OTHER",
        entries: pillars
          .map((pillar, index) => ({ pillar, index }))
          .filter((e) => !known.has(e.pillar.category)),
      },
    ].filter((g) => g.entries.length > 0);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-2">
        <span className="text-sm text-fg-muted">
          {tCommon("selectedCount", {
            selected: selectedIndices.length,
            total: pillars.length,
          })}
        </span>
        <div className="ml-auto flex items-center gap-2">
          <button
            type="button"
            onClick={selectAll}
            className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
          >
            {tCommon("selectAll")}
          </button>
          <button
            type="button"
            onClick={clear}
            className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
          >
            {tCommon("clear")}
          </button>
        </div>
      </div>

      {groups.map((group) => (
        <section key={group.category} className="flex flex-col gap-3">
          <h2 className="text-sm font-semibold text-fg">
            {t("group", {
              label: t(CATEGORY_KEY[group.category] ?? "categoryOther"),
              count: group.entries.length,
            })}
          </h2>
          <ul className={cardGridClass(columns)}>
            {group.entries.map(({ pillar, index }) => {
              const isSelected = selected.has(index);
              const n = index + 1;
              return (
                <li key={index} className={selectableCardClass(isSelected)}>
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={() => toggle(index)}
                    aria-label={t("select", { n })}
                    className="mt-1 h-4 w-4 shrink-0 accent-accent"
                  />
                  {/* min-w-0 so the card can shrink into a narrow grid track. */}
                  <div className="flex min-w-0 flex-1 flex-col gap-2">
                    <input
                      type="text"
                      value={pillar.title}
                      onChange={(e) => editField(index, "title", e.target.value)}
                      aria-label={t("titleField", { n })}
                      className="w-full rounded-md border border-border bg-bg px-2 py-1 text-sm font-medium text-fg outline-none focus-visible:border-accent"
                    />
                    <label className="flex flex-col gap-1 text-xs text-fg-muted">
                      {t("topicBlend")}
                      <input
                        type="text"
                        value={pillar.topicBlend}
                        onChange={(e) =>
                          editField(index, "topicBlend", e.target.value)
                        }
                        aria-label={t("topicBlendField", { n })}
                        className="w-full rounded-md border border-border bg-bg px-2 py-1 text-sm text-fg outline-none focus-visible:border-accent"
                      />
                    </label>
                    <label className="flex flex-col gap-1 text-xs text-fg-muted">
                      {t("creativeSpark")}
                      <input
                        type="text"
                        value={pillar.creativeSpark}
                        readOnly
                        aria-label={t("creativeSparkField", { n })}
                        className="w-full rounded-md border border-border bg-bg-muted px-2 py-1 text-sm text-fg-muted outline-none"
                      />
                    </label>
                    <label className="flex flex-col gap-1 text-xs text-fg-muted">
                      {t("hook")}
                      <input
                        type="text"
                        value={pillar.hook}
                        onChange={(e) => editField(index, "hook", e.target.value)}
                        aria-label={t("hookField", { n })}
                        className="w-full rounded-md border border-border bg-bg px-2 py-1 text-sm text-fg outline-none focus-visible:border-accent"
                      />
                    </label>
                    <label className="flex flex-col gap-1 text-xs text-fg-muted">
                      {t("contentBrief")}
                      <textarea
                        value={pillar.contentBrief}
                        onChange={(e) =>
                          editField(index, "contentBrief", e.target.value)
                        }
                        aria-label={t("contentBriefField", { n })}
                        rows={3}
                        className="w-full resize-y rounded-md border border-border bg-bg px-2 py-1 text-sm leading-relaxed text-fg outline-none focus-visible:border-accent"
                      />
                    </label>
                  </div>
                </li>
              );
            })}
          </ul>
        </section>
      ))}
    </div>
  );
}
