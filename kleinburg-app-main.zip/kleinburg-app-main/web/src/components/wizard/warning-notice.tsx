import type { ReactNode } from "react";

/**
 * The wizard's non-blocking warning surface (T35).
 *
 * Deliberately NOT <ErrorNotice>: nothing failed, and nothing is stopped. This
 * is the shape for "we noticed something that will quietly degrade the output,
 * and you may want to fix it before continuing" — the step's navigation and its
 * generate button are untouched, because the condition is legitimate for some
 * brands and blocking on it would be wrong.
 *
 * `role="status"` (polite), not `role="alert"`: it is announced without
 * interrupting, matching the fact that the user may ignore it and proceed.
 * Purely presentational.
 *
 * ## Why `visible` instead of the caller rendering it conditionally
 *
 * Several screen-reader/browser combinations do not announce a live region
 * that is inserted into the DOM with its content already present — the region
 * has to exist and be mapped first, and only then change. So the container is
 * ALWAYS rendered and only its children toggle. While empty it is `sr-only`,
 * which keeps it in the accessibility tree (unlike `hidden`/`display:none`,
 * which would take it back out and reintroduce the bug) and out of the layout
 * flow, so it adds no stray gap between the caller's flex children.
 *
 * KNOWN, NOT FIXED HERE: `--color-border-warning` resolves to the same
 * `orange-50` as `--color-bg-warning`, so the border below renders invisibly.
 * That is not specific to this component — `border-error`, `border-success` and
 * `border-info` all collapse onto their own background the same way, so it is a
 * defect in the `design/tokens.json` export, and theme files are not hand
 * edited (hard rule 3). Swapping only this one call site to `border-fg-warning`
 * would give a non-blocking notice a heavier rule than <ErrorNotice> has and
 * would hide the systemic bug from whoever fixes the tokens. The notice still
 * reads: orange-50 fill against the white page, orange-600 title.
 */
export function WarningNotice({
  visible = true,
  message,
  detail,
  children,
}: {
  /** Whether the warning currently has anything to say. */
  visible?: boolean;
  /** What we noticed, in one line. */
  message: string;
  /** What the user can do about it, smaller and muted. */
  detail?: string;
  children?: ReactNode;
}) {
  return (
    <div role="status" aria-live="polite" className={visible ? undefined : "sr-only"}>
      {visible ? (
        <div className="flex flex-col items-start gap-2 rounded-lg border border-border-warning bg-bg-warning px-4 py-3">
          <p className="text-sm font-medium text-fg-warning">{message}</p>
          {detail ? <p className="text-xs text-fg-muted">{detail}</p> : null}
          {children}
        </div>
      ) : null}
    </div>
  );
}
