"use client";

import { useTranslations } from "next-intl";

import type { ItemSource } from "@/core/pipeline/schemas";

/**
 * The sources behind one researched item (#47).
 *
 * This is the durable half of the secondary_data fix. The prompt rules and the
 * retrieved-citation cross-check both reduce the chance of an unsupported claim
 * reaching the user; only this makes the difference VISIBLE. A reader can see
 * what stands behind a claim before selecting it into a post — and, just as
 * importantly, can see when nothing does.
 *
 * "No source" is therefore rendered, not hidden. An item with an empty list is
 * marked, so an unsourced claim looks different from a sourced one instead of
 * being silently indistinguishable — which is exactly how the 2026-07-20
 * "studies show…" item made it into a published post.
 *
 * ## What these links DO and DO NOT prove (#47 review)
 *
 * They prove RETRIEVAL, not SUPPORT. The cross-check in run-step.ts keeps only
 * URLs that appear in the call's real citations, so every link here is a
 * document the search actually fetched. But sonar retrieves a handful of
 * documents for the WHOLE call and the writing model then produces 15-20 items
 * and decides which document to hang on which item. That mapping is the model's
 * own claim and nothing verifies it. A fabricated finding carrying a genuinely
 * retrieved URL therefore passes every check in this system.
 *
 * #52 makes that slightly weaker, not stronger: the model that decides the
 * pairing is no longer the model that fetched the documents — it works from the
 * retrieval call's notes. So the label below stays exactly as cautious as it
 * is, and nothing here may be softened on the strength of the split.
 *
 * That makes the label load-bearing. It must not read "the sources for this
 * item" — the earlier wording did, and it made the pairing look established,
 * lending a real publication's authority to whatever sentence sat above it.
 * `sourcesLabel` now names the pairing as the model's, and asks the reviewer to
 * open it. This component's job is to keep the human in a position to catch
 * what the machine cannot.
 *
 * ## Link safety
 *
 * Every URL here originates from model-adjacent output, so:
 *  - the scheme is checked and anything that is not http(s) is dropped, which
 *    kills `javascript:` / `data:` hrefs (core/llm/openrouter.ts rejects them
 *    too; this is the render-site half of the same rule, so a URL that arrives
 *    by any other route — legacy stored content, a hand edit — is still caught);
 *  - `target="_blank"` with `rel="noopener noreferrer"`, so an opened page can
 *    neither reach back through `window.opener` nor be told where it came from.
 *
 * A source with no title falls back to its own URL as the link text; the label
 * is never left empty.
 */

/**
 * Re-exported, NOT re-declared (#47 review): the one definition lives in
 * core/pipeline/schemas.ts next to the schema it must stay compatible with.
 * `import type` keeps this a compile-time-only edge, so no core runtime is
 * pulled into the client bundle by this "use client" module.
 */
export type { ItemSource } from "@/core/pipeline/schemas";

/** True only for an absolute http(s) URL. Anything else is not linkable here. */
export function isSafeHttpUrl(value: string): boolean {
  try {
    const { protocol } = new URL(value);
    return protocol === "http:" || protocol === "https:";
  } catch {
    return false;
  }
}

export function SourceLinks({ sources }: { sources?: ItemSource[] }) {
  const t = useTranslations("steps.secondaryData");
  const safe = (sources ?? []).filter((s) => isSafeHttpUrl(s.url));

  if (safe.length === 0) {
    return (
      <p className="text-xs text-fg-warning" data-testid="no-source">
        {t("noSource")}
      </p>
    );
  }

  return (
    <div className="flex flex-col gap-1">
      <span className="text-xs font-medium text-fg-subtle">
        {t("sourcesLabel")}
      </span>
      <ul className="flex flex-col gap-1">
        {/*
          Keyed by INDEX, not by url. The list is render-only (never reordered,
          filtered or inserted into), so index is stable here — while `url` is
          not unique: legacy and hand-edited stored content can repeat a URL on
          one item, which React reports as a duplicate-key warning and then
          renders unpredictably.
        */}
        {/*
          `break-words` on the anchor is load-bearing, not cosmetic. When an
          entry has no title the link text IS the raw URL, and a retrieved
          research URL runs well past 100 characters without a space in it.
          Since T44 this list renders inside a grid track whose width is capped
          by `minmax(0,1fr)`, so an unbreakable token no longer has a wide
          single column to sit in: it spills out of the card and over its
          neighbour. Nothing else supplies a wrapping rule (the app has no
          global overflow-wrap), so it belongs here, on the one element whose
          content can be a bare URL.
        */}
        {safe.map((source, i) => (
          <li key={i} className="text-xs leading-snug">
            <a
              href={source.url}
              target="_blank"
              rel="noopener noreferrer"
              className="break-words text-accent underline underline-offset-2 hover:text-accent-emphasized"
            >
              {source.title?.trim() ? source.title : source.url}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
