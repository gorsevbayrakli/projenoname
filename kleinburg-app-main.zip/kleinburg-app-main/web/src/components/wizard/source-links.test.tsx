// @vitest-environment jsdom
//
// Rendering contract for <SourceLinks> (#47, hardened in #44 review).
//
// The link text is not always a title: `ItemSource.title` is optional, so an
// entry with no title falls back to the raw URL. That makes this the one place
// in the wizard whose visible content can be a single unbreakable 100+
// character token — and since #44 it renders inside a grid track capped by
// `minmax(0,1fr)`, where such a token spills out of the card and over its
// neighbour instead of finding a wide column to sit in.

import { cleanup, render, screen } from "@testing-library/react";
import { NextIntlClientProvider } from "next-intl";
import { afterEach, describe, expect, it } from "vitest";

import messages from "@/../messages/tr.json";

import { SourceLinks } from "./source-links";

function renderSources(sources: Array<{ url: string; title?: string }>) {
  return render(
    <NextIntlClientProvider locale="tr" messages={messages}>
      <SourceLinks sources={sources} />
    </NextIntlClientProvider>,
  );
}

const LONG_URL =
  "https://www.statista.com/statistics/1234567890/global-commensality-and-shared-meal-frequency-by-market-segment-2019-2026";

// The project has no global test setup file, so RTL's auto-cleanup is not
// wired up; without this, each render leaves its DOM behind and `getByRole`
// finds every earlier test's link too.
afterEach(cleanup);

describe("SourceLinks", () => {
  it("wraps a bare URL so it cannot overflow its grid track", () => {
    renderSources([{ url: LONG_URL }]);

    const link = screen.getByRole("link");
    // The link text IS the URL here — the case that produces the long token.
    expect(link.textContent).toBe(LONG_URL);
    // jsdom computes no layout, so the wrapping rule is asserted as the
    // contract it is: without this class the anchor inherits `overflow-wrap:
    // normal` and the app supplies no global rule to save it.
    expect(link.className.split(" ")).toContain("break-words");
  });

  it("prefers the retrieved title when there is one", () => {
    renderSources([{ url: LONG_URL, title: "Shared meals and trust" }]);

    const link = screen.getByRole("link");
    expect(link.textContent).toBe("Shared meals and trust");
    // Still wrapped: a retrieved title can be long too, and the class must not
    // be conditional on which branch produced the text.
    expect(link.className.split(" ")).toContain("break-words");
  });

  it("opens sources safely in a new tab", () => {
    renderSources([{ url: LONG_URL, title: "Shared meals and trust" }]);

    const link = screen.getByRole("link");
    expect(link.getAttribute("target")).toBe("_blank");
    expect(link.getAttribute("rel")).toBe("noopener noreferrer");
  });
});
