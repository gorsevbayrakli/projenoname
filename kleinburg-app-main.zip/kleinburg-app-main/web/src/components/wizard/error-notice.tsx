"use client";

import { useTranslations } from "next-intl";
import type { ReactNode } from "react";

/**
 * The wizard's single failure surface (T22): a failed generation job, or a save
 * that did not go through.
 *
 * Two lines, always in this order (hard rule 5 — the honest reason is never
 * hidden behind friendly copy):
 *  1. `message` — what happened, in plain language.
 *  2. `reason`  — the underlying raw error, smaller and muted, so support and
 *     debugging keep the truth. Omitted when `message` already IS the raw text.
 *
 * `role="alert"` so assistive tech announces the failure when it appears.
 * Purely presentational: retry behaviour is the caller's.
 */
export function ErrorNotice({
  message,
  reason,
  onRetry,
  retryLabel,
  children,
}: {
  message: string;
  reason?: string;
  /** When given, renders the retry button. */
  onRetry?: () => void;
  /** Overrides the default "try again" wording. */
  retryLabel?: string;
  /** Extra content (e.g. a link back to the step that must be completed). */
  children?: ReactNode;
}) {
  const t = useTranslations();
  return (
    <div
      role="alert"
      className="flex flex-col items-start gap-2 rounded-lg border border-border bg-bg-error px-4 py-3"
    >
      <p className="text-sm font-medium text-fg-error">{message}</p>
      {reason ? (
        <p className="text-xs break-words text-fg-muted">
          {t("errorNotice.reason", { reason })}
        </p>
      ) : null}
      {children}
      {onRetry ? (
        <button
          type="button"
          onClick={onRetry}
          className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
        >
          {retryLabel ?? t("common.retry")}
        </button>
      ) : null}
    </div>
  );
}
