// @vitest-environment jsdom
//
// Component test for the reusable SelectableItemList (T16). Mirrors the jsdom
// setup established by brand-context-step.test.tsx: per-file jsdom env, the test
// itself uses React.createElement (aliased `h`) so no JSX transform is needed
// for the test file, while the imported *.tsx component is handled by vitest's
// default transform.

import { cleanup, fireEvent, screen } from "@testing-library/react";

// T25: rendered through renderWithIntl, which wraps the component in
// NextIntlClientProvider with the REAL Turkish catalog — so every assertion
// below still checks the exact Turkish a user reads.
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { cardGridClass, selectableCardClass } from "./card-grid";
import {
  SelectableItemList,
  type TitledItem,
} from "./selectable-item-list";

const ITEMS: TitledItem[] = [
  { title: "Bir", description: "birinci" },
  { title: "İki", description: "ikinci" },
  { title: "Üç", description: "üçüncü" },
];

function list(
  props: Partial<Parameters<typeof SelectableItemList>[0]> = {},
) {
  return h(SelectableItemList, {
    items: ITEMS,
    selectedIndices: [],
    onItemsChange: vi.fn(),
    onSelectionChange: vi.fn(),
    ...props,
  });
}

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});

describe("SelectableItemList", () => {
  it("renders none-selected when selectedIndices=[]", () => {
    render(list());
    const boxes = screen.getAllByRole("checkbox") as HTMLInputElement[];
    expect(boxes).toHaveLength(3);
    expect(boxes.every((b) => !b.checked)).toBe(true);
    expect(screen.getByText("0 / 3 seçili")).toBeTruthy();
  });

  it("toggling a checkbox calls onSelectionChange with that index", () => {
    const onSelectionChange = vi.fn();
    render(list({ onSelectionChange }));
    const boxes = screen.getAllByRole("checkbox");
    fireEvent.click(boxes[1]);
    expect(onSelectionChange).toHaveBeenCalledWith([1]);
  });

  it("toggling an already-selected checkbox removes its index", () => {
    const onSelectionChange = vi.fn();
    render(list({ selectedIndices: [0, 1], onSelectionChange }));
    const boxes = screen.getAllByRole("checkbox");
    fireEvent.click(boxes[0]);
    expect(onSelectionChange).toHaveBeenCalledWith([1]);
  });

  it("Tümünü seç selects all indices", () => {
    const onSelectionChange = vi.fn();
    render(list({ onSelectionChange }));
    fireEvent.click(screen.getByText("Tümünü seç"));
    expect(onSelectionChange).toHaveBeenCalledWith([0, 1, 2]);
  });

  it("Temizle empties the selection", () => {
    const onSelectionChange = vi.fn();
    render(list({ selectedIndices: [0, 2], onSelectionChange }));
    fireEvent.click(screen.getByText("Temizle"));
    expect(onSelectionChange).toHaveBeenCalledWith([]);
  });

  it("editing a title calls onItemsChange with the updated text", () => {
    const onItemsChange = vi.fn();
    render(list({ onItemsChange }));
    const titleInput = screen.getByLabelText("Öğe 1 başlık");
    fireEvent.change(titleInput, { target: { value: "Değişti" } });
    expect(onItemsChange).toHaveBeenCalledWith([
      { title: "Değişti", description: "birinci" },
      ITEMS[1],
      ITEMS[2],
    ]);
  });

  it("editing a description calls onItemsChange with the updated text", () => {
    const onItemsChange = vi.fn();
    render(list({ onItemsChange }));
    const descInput = screen.getByLabelText("Öğe 2 açıklama");
    fireEvent.change(descInput, { target: { value: "yeni açıklama" } });
    expect(onItemsChange).toHaveBeenCalledWith([
      ITEMS[0],
      { title: "İki", description: "yeni açıklama" },
      ITEMS[2],
    ]);
  });

  /**
   * #47 review: editing an item must not keep its sources.
   *
   * `sources` asserts that specific retrieved documents sit behind THIS text.
   * Rewrite the text and that assertion is about nothing — but it used to
   * survive: the link, the retrieved publication title and the downstream
   * `[sources: …]` marker all carried over onto whatever the user typed, so
   * arbitrary text reached the post step licensed as a researched finding.
   */
  describe("editing an item drops its sources (#47)", () => {
    const SOURCED: TitledItem[] = [
      {
        title: "Bir",
        description: "birinci",
        sources: [{ url: "https://example.org/a", title: "A" }],
      },
    ];

    it("clears sources when the description is rewritten", () => {
      const onItemsChange = vi.fn();
      render(list({ items: SOURCED, onItemsChange, showSources: true }));
      fireEvent.change(screen.getByLabelText("Öğe 1 açıklama"), {
        target: { value: "tamamen başka bir iddia" },
      });
      expect(onItemsChange).toHaveBeenCalledWith([
        { title: "Bir", description: "tamamen başka bir iddia", sources: [] },
      ]);
    });

    it("clears sources when the title is rewritten", () => {
      // Title too: it is as much the claim as the description is, and it is the
      // field the pillar and post prompts read first.
      const onItemsChange = vi.fn();
      render(list({ items: SOURCED, onItemsChange, showSources: true }));
      fireEvent.change(screen.getByLabelText("Öğe 1 başlık"), {
        target: { value: "Başka" },
      });
      expect(onItemsChange).toHaveBeenCalledWith([
        { title: "Başka", description: "birinci", sources: [] },
      ]);
    });

    it("does not add a sources field to an item that never had one", () => {
      // creative_sparks reuses this list and its schema has no `sources`.
      // Writing an empty array onto those items would invent a field.
      const onItemsChange = vi.fn();
      render(list({ items: [{ title: "Bir", description: "birinci" }], onItemsChange }));
      fireEvent.change(screen.getByLabelText("Öğe 1 başlık"), {
        target: { value: "Başka" },
      });
      const [next] = onItemsChange.mock.calls[0] as [TitledItem[]];
      expect("sources" in next[0]).toBe(false);
    });
  });

  it("shows the empty hint when there are no items", () => {
    render(list({ items: [], emptyHint: "Hiç yok" }));
    expect(screen.getByText("Hiç yok")).toBeTruthy();
  });

  // #44: the cards render as a responsive grid instead of one long column. The
  // geometry itself is unit-tested in card-grid.test.ts; what matters here is
  // that the component actually puts it on the list and honours `columns`.
  describe("grid layout (#44)", () => {
    it("renders the cards in a grid, three across by default", () => {
      render(list());
      const ul = screen.getAllByRole("checkbox")[0].closest("ul")!;
      expect(ul.className).toBe(cardGridClass(3));
    });

    it("honours an explicit columns prop", () => {
      render(list({ columns: 2 }));
      const ul = screen.getAllByRole("checkbox")[0].closest("ul")!;
      expect(ul.className).toBe(cardGridClass(2));
    });

    it("marks the selected card with the shared selection chrome", () => {
      render(list({ selectedIndices: [1] }));
      const cards = screen
        .getAllByRole("checkbox")
        .map((b) => b.closest("li")!);
      expect(cards[1].className).toBe(selectableCardClass(true));
      expect(cards[0].className).toBe(selectableCardClass(false));
    });
  });
});
