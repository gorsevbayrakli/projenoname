"use client";

import { useTranslations } from "next-intl";
import { useCallback, useState } from "react";
import { apiErrorMessage, type ApiErrorTranslator } from "@/lib/api-error-copy";

/**
 * Reusable "kick off a generation job" hook for the generative wizard steps
 * (T15–T21). It POSTs to the step's generate route, reads the 202 { jobId },
 * and exposes the jobId so the caller can mount <JobProgress jobId onDone=…>.
 *
 * Division of labour:
 *  - this hook: POST + surface {jobId, isGenerating, error}. It does NOT watch
 *    the job — that is <JobProgress>'s SSE stream.
 *  - the caller: renders <JobProgress> while jobId is set; on the terminal
 *    callback it reloads (router.refresh()) on "succeeded" to pick up the saved
 *    step_contents (the worker upserts it), or shows the error on "failed".
 */
export function useGenerate(projectId: string, step: string) {
  const t = useTranslations();
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const [jobId, setJobId] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const generate = useCallback(
    async (input?: unknown) => {
      setError(null);
      setIsGenerating(true);
      setJobId(null);
      try {
        const res = await fetch(
          `/api/projects/${projectId}/steps/${step}/generate`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(input ?? {}),
          },
        );
        if (res.status === 202) {
          const data = (await res.json().catch(() => null)) as {
            jobId?: string;
          } | null;
          if (data?.jobId) {
            setJobId(data.jobId);
            return;
          }
          setError(t("generateHook.startFailed"));
          setIsGenerating(false);
          return;
        }
        const data = (await res.json().catch(() => null)) as {
          error?: string;
          code?: string;
        } | null;
        setError(apiErrorMessage(data, tApi, t("generateHook.startFailed")));
        setIsGenerating(false);
      } catch {
        setError(t("common.networkError"));
        setIsGenerating(false);
      }
    },
    [projectId, step, t, tApi],
  );

  const reset = useCallback(() => {
    setJobId(null);
    setIsGenerating(false);
    setError(null);
  }, []);

  return { generate, jobId, isGenerating, error, reset };
}
