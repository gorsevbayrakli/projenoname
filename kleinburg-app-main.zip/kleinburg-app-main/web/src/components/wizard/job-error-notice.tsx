"use client";

import { useTranslations } from "next-intl";
import Link from "next/link";

import { jobErrorCopy } from "@/lib/job-error-copy";
import { stepByNumber } from "@/lib/workflow-steps";
import { ErrorNotice } from "./error-notice";

/**
 * A failed generation, rendered the same way on every generative step (T22):
 * the humanized sentence from job-error-copy, the raw reason underneath, a
 * "Tekrar dene" that re-runs the step's generation, and — for the known
 * precondition failures — a link straight to the step that must be completed
 * first.
 *
 * This is the ONLY place the six generative steps handle a job failure, so the
 * copy and the placement cannot drift apart again.
 */
export function JobErrorNotice({
  error,
  projectId,
  onRetry,
  retryLabel,
}: {
  error: string;
  projectId: string;
  onRetry?: () => void;
  retryLabel?: string;
}) {
  const t = useTranslations();
  const stepLabel = useTranslations("stepLabels");
  // The mapper is locale-aware via this translator; the RAW reason it carries
  // stays the engine's own words (see lib/job-error-copy.ts).
  const copy = jobErrorCopy(error, (key) => t(`jobError.${key}`));
  const target =
    copy.stepNumber !== undefined ? stepByNumber(copy.stepNumber) : undefined;

  return (
    <ErrorNotice
      message={copy.message}
      reason={copy.reason}
      onRetry={onRetry}
      retryLabel={retryLabel}
    >
      {target ? (
        <Link
          href={`/projects/${projectId}/step/${target.n}`}
          className="text-sm font-medium text-fg-error underline underline-offset-2 hover:text-fg"
        >
          {t("wizard.stepLink", {
            n: target.n,
            label: stepLabel(target.key),
          })}
        </Link>
      ) : null}
    </ErrorNotice>
  );
}
