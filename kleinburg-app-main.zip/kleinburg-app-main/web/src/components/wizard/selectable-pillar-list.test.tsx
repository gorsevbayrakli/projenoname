// @vitest-environment jsdom
//
// Component test for SelectablePillarList (T19). Same jsdom setup as
// selectable-item-list.test.tsx: per-file jsdom env, React.createElement
// (aliased `h`) so the test file needs no JSX transform.
//
// The critical property under test is the GROUPED-render → FLAT-index mapping:
// pillars are displayed in three category sections but selection indices must
// keep addressing the original flat array (what gatherVars/serializePillars
// read downstream). The fixture is deliberately shuffled so grouped order and
// flat order differ.

import { cleanup, fireEvent, screen } from "@testing-library/react";

// T25: rendered through renderWithIntl, which wraps the component in
// NextIntlClientProvider with the REAL Turkish catalog — so every assertion
// below still checks the exact Turkish a user reads.
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { cardGridClass, selectableCardClass } from "./card-grid";
import {
  SelectablePillarList,
  type PillarItem,
} from "./selectable-pillar-list";

function p(category: string, title: string): PillarItem {
  return {
    category,
    title,
    topicBlend: `${title}-blend`,
    creativeSpark: `${title}-spark`,
    hook: `${title}-hook`,
    contentBrief: `${title}-brief`,
  };
}

// Flat order intentionally NOT grouped: index 0 is ENTERTAINING, so a naive
// grouped-index implementation would mis-map every callback.
const PILLARS: PillarItem[] = [
  p("ENTERTAINING", "E1"), // flat 0 -> group 2, first
  p("INFORMATIONAL", "N1"), // flat 1 -> group 3, first
  p("INSPIRATIONAL", "I1"), // flat 2 -> group 1, first
  p("ENTERTAINING", "E2"), // flat 3 -> group 2, second
  p("INSPIRATIONAL", "I2"), // flat 4 -> group 1, second
];

function list(
  props: Partial<Parameters<typeof SelectablePillarList>[0]> = {},
) {
  return h(SelectablePillarList, {
    pillars: PILLARS,
    selectedIndices: [],
    onPillarsChange: vi.fn(),
    onSelectionChange: vi.fn(),
    ...props,
  });
}

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});

describe("SelectablePillarList", () => {
  it("renders three category sections in INSPIRATIONAL → ENTERTAINING → INFORMATIONAL order with counts", () => {
    render(list());
    const headings = screen
      .getAllByRole("heading", { level: 2 })
      .map((el) => el.textContent);
    expect(headings).toEqual([
      "İlham veren (2)",
      "Eğlendiren (2)",
      "Bilgilendiren (1)",
    ]);
  });

  it("omits a category section that has no pillars", () => {
    render(list({ pillars: [p("ENTERTAINING", "only")] }));
    const headings = screen
      .getAllByRole("heading", { level: 2 })
      .map((el) => el.textContent);
    expect(headings).toEqual(["Eğlendiren (1)"]);
  });

  it("renders none-selected when selectedIndices=[]", () => {
    render(list());
    const boxes = screen.getAllByRole("checkbox") as HTMLInputElement[];
    expect(boxes).toHaveLength(5);
    expect(boxes.every((b) => !b.checked)).toBe(true);
    expect(screen.getByText("0 / 5 seçili")).toBeTruthy();
  });

  it("checking a pillar in the SECOND group emits its FLAT index", () => {
    const onSelectionChange = vi.fn();
    render(list({ onSelectionChange }));
    // "E2" sits in group 2 (Eğlendiren) but is flat index 3.
    fireEvent.click(screen.getByLabelText("Pillar 4 seç"));
    expect(onSelectionChange).toHaveBeenCalledWith([3]);
  });

  it("checking a pillar in the THIRD group emits its FLAT index", () => {
    const onSelectionChange = vi.fn();
    render(list({ onSelectionChange }));
    // "N1" is the only Bilgilendiren pillar, but flat index 1.
    fireEvent.click(screen.getByLabelText("Pillar 2 seç"));
    expect(onSelectionChange).toHaveBeenCalledWith([1]);
  });

  it("renders checked state from FLAT indices, not grouped positions", () => {
    render(list({ selectedIndices: [1, 4] }));
    // Flat 1 = N1 (3rd group), flat 4 = I2 (1st group).
    expect(
      (screen.getByLabelText("Pillar 2 seç") as HTMLInputElement).checked,
    ).toBe(true);
    expect(
      (screen.getByLabelText("Pillar 5 seç") as HTMLInputElement).checked,
    ).toBe(true);
    expect(
      (screen.getByLabelText("Pillar 1 seç") as HTMLInputElement).checked,
    ).toBe(false);
    expect(screen.getByText("2 / 5 seçili")).toBeTruthy();
  });

  it("unchecking an already-selected pillar removes its flat index", () => {
    const onSelectionChange = vi.fn();
    render(list({ selectedIndices: [1, 3], onSelectionChange }));
    fireEvent.click(screen.getByLabelText("Pillar 2 seç"));
    expect(onSelectionChange).toHaveBeenCalledWith([3]);
  });

  it("Tümünü seç selects every flat index", () => {
    const onSelectionChange = vi.fn();
    render(list({ onSelectionChange }));
    fireEvent.click(screen.getByText("Tümünü seç"));
    expect(onSelectionChange).toHaveBeenCalledWith([0, 1, 2, 3, 4]);
  });

  it("Temizle empties the selection", () => {
    const onSelectionChange = vi.fn();
    render(list({ selectedIndices: [0, 2], onSelectionChange }));
    fireEvent.click(screen.getByText("Temizle"));
    expect(onSelectionChange).toHaveBeenCalledWith([]);
  });

  it("editing a title emits onPillarsChange at the correct flat index", () => {
    const onPillarsChange = vi.fn();
    render(list({ onPillarsChange }));
    // "I1" is rendered first (group 1) but is flat index 2.
    fireEvent.change(screen.getByLabelText("Pillar 3 başlık"), {
      target: { value: "Değişti" },
    });
    const next = onPillarsChange.mock.calls[0][0] as PillarItem[];
    expect(next[2].title).toBe("Değişti");
    expect(next[0]).toEqual(PILLARS[0]);
    expect(next[2].category).toBe("INSPIRATIONAL");
  });

  it("editing hook / topicBlend / contentBrief emits the updated field", () => {
    const onPillarsChange = vi.fn();
    render(list({ onPillarsChange }));

    fireEvent.change(screen.getByLabelText("Pillar 1 kanca"), {
      target: { value: "yeni kanca" },
    });
    expect(
      (onPillarsChange.mock.calls[0][0] as PillarItem[])[0].hook,
    ).toBe("yeni kanca");

    fireEvent.change(screen.getByLabelText("Pillar 4 konu harmanı"), {
      target: { value: "yeni harman" },
    });
    expect(
      (onPillarsChange.mock.calls[1][0] as PillarItem[])[3].topicBlend,
    ).toBe("yeni harman");

    fireEvent.change(screen.getByLabelText("Pillar 2 içerik özeti"), {
      target: { value: "yeni özet" },
    });
    expect(
      (onPillarsChange.mock.calls[2][0] as PillarItem[])[1].contentBrief,
    ).toBe("yeni özet");
  });

  it("shows the empty hint when there are no pillars", () => {
    render(list({ pillars: [], emptyHint: "Hiç yok" }));
    expect(screen.getByText("Hiç yok")).toBeTruthy();
  });

  // #44: pillars render as a grid WITHIN each category section — the sections
  // themselves stay stacked, since the grouping is the point of T19.
  describe("grid layout (#44)", () => {
    it("gives every category section a two-column grid by default", () => {
      const { container } = render(list());
      const lists = [...container.querySelectorAll("ul")];
      expect(lists.length).toBeGreaterThan(1); // one per category section
      for (const ul of lists) {
        expect(ul.className).toBe(cardGridClass(2));
      }
    });

    it("honours an explicit columns prop", () => {
      const { container } = render(list({ columns: 3 }));
      for (const ul of container.querySelectorAll("ul")) {
        expect(ul.className).toBe(cardGridClass(3));
      }
    });

    it("marks the selected card with the shared selection chrome", () => {
      // Flat index 2 is I1, the first card of the INSPIRATIONAL section.
      render(list({ selectedIndices: [2] }));
      const card = screen.getByLabelText("Pillar 3 seç").closest("li")!;
      expect(card.className).toBe(selectableCardClass(true));
      const other = screen.getByLabelText("Pillar 1 seç").closest("li")!;
      expect(other.className).toBe(selectableCardClass(false));
    });
  });
});
