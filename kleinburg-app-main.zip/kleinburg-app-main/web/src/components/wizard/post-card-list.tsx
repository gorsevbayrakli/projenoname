"use client";

import { useTranslations } from "next-intl";

import { cardGridClass, CARD_CHROME, type CardGridColumns } from "./card-grid";

/**
 * Inline-editable card list for sm_posts (T20).
 *
 * The post sibling of <SelectableItemList>/<SelectablePillarList>: same card
 * styling and inline-edit shape, but NO selection — every post is used
 * downstream (the calendar is grounded in all of them), so there is nothing to
 * check.
 *
 * IMPORTANT: this list renders ONE PLATFORM's slice, but `onPostsChange` emits
 * the FULL posts array. Each rendered entry carries its index in the original
 * flat array, and every edit maps back to that flat index. Keeping the flat
 * array whole is what preserves the other platform's posts — see
 * core/pipeline/posts.ts for the slice model.
 *
 * Purely presentational: it owns no persistence; the parent saves.
 */

export interface PostItem {
  platform: string;
  theme: string;
  hook: string;
  caption: string;
  cta: string;
  hashtags: string[];
}

/** A post together with its position in the full (both-platform) posts array. */
export interface IndexedPost {
  post: PostItem;
  index: number;
}

export function PostCardList({
  entries,
  onEditField,
  emptyHint,
  columns = 2,
}: {
  entries: IndexedPost[];
  /** (flatIndex, field, value) — value is the raw string; hashtags are split by the parent. */
  onEditField: (index: number, field: keyof PostItem, value: string) => void;
  emptyHint?: string;
  /**
   * Max grid columns at the widest breakpoint (#44). DEFAULT 2: a post is
   * long-form copy — a four-row caption textarea the user actually writes in —
   * and it reads worse squeezed into a third of the width. Two columns halves
   * the 30-post scroll while keeping the caption a workable editing surface.
   */
  columns?: CardGridColumns;
}) {
  const t = useTranslations("postList");

  if (entries.length === 0) {
    return (
      <p className="text-sm text-fg-muted">
        {emptyHint ?? t("empty")}
      </p>
    );
  }

  return (
    <ul className={cardGridClass(columns)}>
      {entries.map(({ post, index }, position) => {
        // Cards are numbered within their platform tab (1..n), which is what the
        // user sees; the flat index is what the callbacks address.
        const n = position + 1;
        return (
          <li
            key={index}
            className={`flex min-w-0 flex-col gap-2 border-border bg-bg ${CARD_CHROME}`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-fg-subtle">
                {t("post", { n })}
              </span>
            </div>
            <label className="flex flex-col gap-1 text-xs text-fg-muted">
              {t("theme")}
              <input
                type="text"
                value={post.theme}
                onChange={(e) => onEditField(index, "theme", e.target.value)}
                aria-label={t("themeField", { n })}
                className="w-full rounded-md border border-border bg-bg px-2 py-1 text-sm font-medium text-fg outline-none focus-visible:border-accent"
              />
            </label>
            <label className="flex flex-col gap-1 text-xs text-fg-muted">
              {t("hook")}
              <input
                type="text"
                value={post.hook}
                onChange={(e) => onEditField(index, "hook", e.target.value)}
                aria-label={t("hookField", { n })}
                className="w-full rounded-md border border-border bg-bg px-2 py-1 text-sm text-fg outline-none focus-visible:border-accent"
              />
            </label>
            <label className="flex flex-col gap-1 text-xs text-fg-muted">
              {t("caption")}
              <textarea
                value={post.caption}
                onChange={(e) => onEditField(index, "caption", e.target.value)}
                aria-label={t("captionField", { n })}
                rows={4}
                className="w-full resize-y rounded-md border border-border bg-bg px-2 py-1 text-sm leading-relaxed text-fg outline-none focus-visible:border-accent"
              />
            </label>
            <label className="flex flex-col gap-1 text-xs text-fg-muted">
              {t("cta")}
              <input
                type="text"
                value={post.cta}
                onChange={(e) => onEditField(index, "cta", e.target.value)}
                aria-label={t("ctaField", { n })}
                className="w-full rounded-md border border-border bg-bg px-2 py-1 text-sm text-fg outline-none focus-visible:border-accent"
              />
            </label>
            <label className="flex flex-col gap-1 text-xs text-fg-muted">
              {t("hashtags")}
              <input
                type="text"
                value={post.hashtags.join(" ")}
                onChange={(e) => onEditField(index, "hashtags", e.target.value)}
                aria-label={t("hashtagsField", { n })}
                placeholder={t("hashtagsPlaceholder")}
                className="w-full rounded-md border border-border bg-bg px-2 py-1 text-sm text-fg outline-none focus-visible:border-accent"
              />
            </label>
          </li>
        );
      })}
    </ul>
  );
}
