import type { ReactNode } from "react";

/**
 * The wizard's single "there is nothing here yet" surface (T22).
 *
 * Purely presentational and theme-token styled: a title, one explanatory line
 * that says what WILL be here and what it is made from, and an optional action
 * slot (usually the step's "Üret" button, or nothing at all when the step has no
 * generation). Icon-free on purpose — the 8 steps differ in copy, not in
 * decoration, and identical framing is what makes them feel like one flow.
 *
 * Each step keeps its own wording; this component only fixes the shape.
 */
export function EmptyState({
  title,
  description,
  action,
  children,
}: {
  title: string;
  description?: ReactNode;
  /** Primary action, e.g. the step's "Üret" button. */
  action?: ReactNode;
  /** Extra content between the description and the action (hints, links). */
  children?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-start gap-4 rounded-lg border border-dashed border-border bg-bg p-6 sm:p-8">
      <div className="flex flex-col gap-1.5">
        <p className="text-sm font-medium text-fg">{title}</p>
        {description ? (
          <p className="text-sm text-fg-muted">{description}</p>
        ) : null}
      </div>
      {children}
      {action}
    </div>
  );
}
