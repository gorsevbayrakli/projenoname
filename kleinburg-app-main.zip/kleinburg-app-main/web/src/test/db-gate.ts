/**
 * The DB test gate — the half that every test worker loads.
 *
 * Suites that need a real Postgres are gated on `DATABASE_URL` via
 * `describe.skipIf(!hasDb)`. That gate is legal — a contributor without a local
 * database must still be able to run the rest of the suite. What is NOT legal is
 * doing it silently: a run that reports "32 passed | 13 skipped" reads as success
 * while tenancy, brand isolation and pipeline coverage never executed (CLAUDE.md
 * hard rule 5, no silent error swallowing).
 *
 * This module owns two things:
 *   - `hasDb`, the single source of truth for the `skipIf` gates;
 *   - `setup`, the `globalSetup` hook, which turns a missing `DATABASE_URL` into
 *     a hard failure on this repo's CI, where the variable is always present.
 *
 * The banner that reports what the closed gate cost lives in
 * `./db-gate-reporter.ts`, which only the main process loads. Keep this module
 * free of *value* imports from `vitest/node` and `vitest/reporters`: fourteen
 * test files import it, so anything non-type here is paid for in every worker.
 *
 * Deliberately NOT done here: loading `web/.env`. `npm run test:db` loads it in
 * `vitest.config.ts`, before any worker starts — which is the only place early
 * enough (see the note on `hasDb` below).
 */

/**
 * Whether the DB-backed suites can run.
 *
 * Evaluated ONCE, at import time. A `setupFiles` entry or a `beforeAll` that
 * assigned `process.env.DATABASE_URL` later would be silently ignored by every
 * gate, because the gates read this constant and not the environment. Anything
 * that needs to supply `DATABASE_URL` must do so before a worker imports this
 * module — i.e. in `vitest.config.ts`, or in the shell.
 */
export const hasDb = Boolean(process.env.DATABASE_URL);

/** The one-liner that runs the whole suite, DB tests included. */
export const FULL_SUITE_COMMAND = "npm run db:up && npm run test:db";

/**
 * The variable that actually means "this is this repo's CI".
 *
 * NOT `CI`. Docker builds, husky hooks, `netlify dev` and plenty of contributor
 * shells export `CI` — and `CI=false` is truthy — so gating on it would abort
 * whole local runs with advice about a GitHub workflow the person is not on.
 * `GITHUB_ACTIONS` is set by the Actions runner and by essentially nothing else.
 */
export const CI_ENV_VAR = "GITHUB_ACTIONS";

/** Escape hatch: run the non-DB suites on Actions on purpose. */
export const OPT_OUT_ENV_VAR = "ALLOW_MISSING_DATABASE_URL";

/**
 * `globalSetup`. On this repo's CI `DATABASE_URL` is always set, so its absence
 * means the workflow is misconfigured and every DB suite would silently vanish
 * from the only run anybody trusts. Fail the run instead. Locally this never
 * fires, whatever `CI` happens to be set to in the shell.
 */
export function setup(): void {
  const onCi = Boolean(process.env[CI_ENV_VAR]);
  const optedOut = Boolean(process.env[OPT_OUT_ENV_VAR]);
  if (onCi && !optedOut && !hasDb) {
    throw new Error(
      `DATABASE_URL is not set but ${CI_ENV_VAR} is. CI must run the DB-backed ` +
        "suites; check the `env:` block in .github/workflows/web-ci.yml. " +
        `To run without a database on purpose, set ${OPT_OUT_ENV_VAR}=1.`,
    );
  }
}
