import { readFileSync, readlinkSync, lstatSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";

import { describe, expect, it } from "vitest";

/**
 * The Node version is declared in FIVE places. This test is what stops them
 * drifting apart.
 *
 * (It was six while the app deployed to Render: `render.yaml` pinned a sixth
 * copy, and a test here caught it disagreeing with the other five — the exact
 * class of bug below. Render is gone and so is that file; when a new hosting
 * target is picked, its Node version pin needs the same test back.)
 *
 * ── WHY ──────────────────────────────────────────────────────────────────
 * `web/.nvmrc` said 22, CI ran 22, and there was no `.nvmrc` at
 * the REPO ROOT at all — so a shell opened at the root got whatever the machine
 * happened to default to (Node 24 on the development machine). That gap is what
 * hid this week's .pptx upload bug: it fails on 22 and passes on 24, so it could
 * not be reproduced locally and was found in production.
 *
 * The root `.nvmrc` is a SYMLINK to `web/.nvmrc`, so under normal conditions
 * there is only one copy of the number and nothing to keep in sync. This test
 * exists for the conditions that are not normal: a checkout that materialised
 * the symlink as a regular file, or somebody "simplifying" it into a real file
 * that then drifts. It asserts the AGREEMENT rather than the mechanism, because
 * agreement is the property that actually matters.
 *
 * The CI workflow is included deliberately. It is the one copy that cannot be a
 * symlink — `actions/setup-node` takes a literal string in YAML — and therefore
 * the one most able to drift unnoticed, since a wrong version there still goes
 * green on a machine that is running the right one. This repo has already
 * shipped this exact class of bug twice (the prompt/checkCounts pair, and the
 * models.ts maxOutput that disagreed with its own comment).
 */

const here = dirname(fileURLToPath(import.meta.url));
const webDir = resolve(here, "../..");
const repoRoot = resolve(webDir, "..");

/** The version string in an .nvmrc, normalised (`v22` and `22` are the same). */
function readNvmrc(path: string): string {
  return readFileSync(path, "utf8").trim().replace(/^v/, "");
}

describe("Node version pinning", () => {
  it("the repo root has an .nvmrc", () => {
    // Without this file, `nvm use` at the root silently does nothing and the
    // shell keeps whatever Node it had.
    expect(() => readNvmrc(resolve(repoRoot, ".nvmrc"))).not.toThrow();
  });

  it("the root and web/ .nvmrc name the same version", () => {
    expect(readNvmrc(resolve(repoRoot, ".nvmrc"))).toBe(
      readNvmrc(resolve(webDir, ".nvmrc")),
    );
  });

  it("the root .nvmrc is a symlink to web/.nvmrc, so there is only one copy", () => {
    // Softer than the agreement test above ON PURPOSE: this one documents the
    // mechanism and will fail loudly if someone replaces the link with a copy,
    // which is the moment to re-read this file rather than to paste a number.
    const rootNvmrc = resolve(repoRoot, ".nvmrc");
    expect(lstatSync(rootNvmrc).isSymbolicLink()).toBe(true);
    expect(readlinkSync(rootNvmrc)).toBe("web/.nvmrc");
  });

  it("CI runs the version the .nvmrc names", () => {
    // The copy that cannot be a symlink, and so the one that drifts.
    const workflow = readFileSync(
      resolve(repoRoot, ".github/workflows/web-ci.yml"),
      "utf8",
    );
    const declared = readNvmrc(resolve(webDir, ".nvmrc"));
    const matches = [...workflow.matchAll(/node-version:\s*'?"?([\d.]+)'?"?/g)];
    expect(matches.length, "no node-version found in web-ci.yml").toBeGreaterThan(
      0,
    );
    for (const [, version] of matches) {
      expect(version, "CI node-version disagrees with .nvmrc").toBe(declared);
    }
  });

  it("the dev container runs the version the .nvmrc names", () => {
    // The fifth copy. It drifts the same way the CI one does — a container on
    // the wrong major goes green on a developer machine that is on the right
    // one — and it is the copy whose whole reason for existing is to be the
    // pinned Node for people who do not have it installed. A `node:24` here
    // would hand them the exact environment the root .nvmrc was added to stop
    // (the .pptx bug passes on 24, fails on 22).
    const compose = readFileSync(
      resolve(webDir, "docker-compose.dev.yml"),
      "utf8",
    );
    const declaredMajor = readNvmrc(resolve(webDir, ".nvmrc")).split(".")[0];
    // Only the app service is on a node image; postgres:16 does not match.
    const matches = [...compose.matchAll(/image:\s*node:([\d.]+)/g)];
    expect(
      matches.length,
      "no node image found in docker-compose.dev.yml",
    ).toBeGreaterThan(0);
    for (const [, version] of matches) {
      expect(
        version.split(".")[0],
        "docker-compose.dev.yml node image disagrees with .nvmrc",
      ).toBe(declaredMajor);
    }
  });

  it("the .nvmrc version satisfies package.json engines", () => {
    const pkg = JSON.parse(
      readFileSync(resolve(webDir, "package.json"), "utf8"),
    ) as { engines?: { node?: string } };
    const engines = pkg.engines?.node;
    expect(engines, "package.json declares no engines.node").toBeTruthy();

    // `npm run test:db` uses `node --env-file-if-exists`, which needs >= 22.9;
    // that is what the engines range is protecting. A major below it would mean
    // the pinned version cannot run the repo's own test command.
    const requiredMajor = Number(/(\d+)/.exec(engines ?? "")?.[1]);
    const pinnedMajor = Number(readNvmrc(resolve(webDir, ".nvmrc")).split(".")[0]);
    expect(pinnedMajor).toBeGreaterThanOrEqual(requiredMajor);
  });
});
