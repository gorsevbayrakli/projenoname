/**
 * The DB test gate — the half that only the main process loads.
 *
 * `db-gate.ts` decides whether the DB-backed suites run. This module reports
 * what it cost when they did not: one banner, once per run, under the summary.
 *
 * Split out from `db-gate.ts` on purpose. Every test worker imports `hasDb`;
 * none of them needs the registry, the counting or the banner strings, and the
 * moment someone adds a non-type import from `vitest/node` to the shared module
 * it would be loaded fourteen times over. Reporters are a main-process concern.
 */
import type { TestCase, TestModule } from "vitest/node";
import type { Reporter } from "vitest/reporters";

import { FULL_SUITE_COMMAND, hasDb } from "./db-gate";

/**
 * One suite (or single test) held closed by the `DATABASE_URL` gate.
 *
 * An explicit registry, not a heuristic. `allTests("skipped")` cannot be used
 * to answer "what did the DB gate cost", because it counts every skip whatever
 * the cause — `worker.test.ts` also gates its pg-boss round trip on
 * `RUN_PGBOSS_TEST`, so those tests skip even with Postgres up, and any stray
 * `it.skip` in a pure-unit file would be attributed to the database too. A
 * banner that promises "146 tests will run" when 144 will is worse than no
 * banner at all.
 *
 * Vitest's own `meta`/tag mechanisms would be the tidier carrier, but they are
 * set at the test site; this registry is drift-checked instead, by
 * `db-gate-reporter.test.ts`, which reads every `skipIf(!hasDb)` out of the
 * source tree and fails if the two disagree.
 */
interface DbGatedSuite {
  /** Module path relative to `web/`. */
  readonly module: string;
  /**
   * Name path of the gated node, outermost first: the `describe.skipIf(!hasDb)`
   * chain down to and including the node that carries the gate. A skipped test
   * belongs to this gate when this is a prefix of its own name path.
   */
  readonly gate: readonly string[];
  /** What a reader loses when this gate is closed. Shown in the banner. */
  readonly label: string;
}

export const DB_GATED_SUITES: readonly DbGatedSuite[] = [
  {
    module: "src/app/api/admin/admin-routes.test.ts",
    gate: ["admin API routes"],
    label: "admin panel and brand isolation",
  },
  {
    module: "src/app/api/admin/admin-routes.test.ts",
    gate: ["first-login password change at the HTTP layer"],
    label: "first-login password change",
  },
  {
    module: "src/app/api/admin/admin-routes.test.ts",
    gate: ["admin password reset at the HTTP layer"],
    label: "admin password reset",
  },
  {
    module: "src/app/api/account/account-routes.test.ts",
    gate: ["api/account/profile"],
    label: "account area: self-scoped profile writes at the HTTP layer",
  },
  {
    module: "src/core/account/service.test.ts",
    gate: ["account/service"],
    label: "account area: profile, e-mail uniqueness and language preference",
  },
  {
    module: "src/core/admin/service.test.ts",
    gate: ["admin/service"],
    label: "admin panel and brand isolation",
  },
  {
    module: "src/app/api/auth/login-rate-limit.test.ts",
    gate: ["login route rate limit"],
    label: "login route: attempt ceiling and audit-flood containment",
  },
  {
    module: "src/core/admin/audit-rollback.test.ts",
    gate: ["directory actions roll back when the audit write fails"],
    label: "audit trail: directory actions are atomic with their audit row",
  },
  {
    module: "src/core/audit/service.test.ts",
    gate: ["audit trail"],
    label: "audit trail: append-only enforcement and log visibility",
  },
  {
    module: "src/core/auth/change-password.test.ts",
    gate: ["changePassword"],
    label: "first-login password change",
  },
  {
    module: "src/core/auth/session.test.ts",
    gate: ["session"],
    label: "auth sessions",
  },
  {
    module: "src/core/db/client.test.ts",
    gate: ["db client", "connects and runs select 1"],
    label: "database connectivity",
  },
  {
    module: "src/core/db/schema.test.ts",
    gate: ["schema constraints"],
    label: "schema constraints",
  },
  {
    module: "src/core/ingest/documents.test.ts",
    gate: ["ingest/documents"],
    label: "document ingest",
  },
  {
    module: "src/core/jobs/jobs.test.ts",
    gate: ["jobs repository"],
    label: "jobs",
  },
  {
    module: "src/core/jobs/worker.test.ts",
    gate: ["worker handler (direct)"],
    label: "jobs",
  },
  {
    module: "src/core/llm/usage.test.ts",
    gate: ["recordLlmCall"],
    label: "LLM usage accounting",
  },
  {
    module: "src/core/llm/spend.test.ts",
    gate: ["llm/spend"],
    label: "spend aggregation + brand isolation",
  },
  {
    module: "src/core/llm/admin-spend.test.ts",
    gate: ["llm/admin-spend"],
    label: "super admin cross-brand spend visibility + its audit trail",
  },
  {
    module: "src/core/llm/admin-spend-fail-closed.test.ts",
    gate: ["llm/admin-spend fails closed"],
    label: "super admin spend view refuses to render an unrecorded crossing",
  },
  {
    module: "src/core/llm/cap-enforcement.test.ts",
    gate: ["llm/cap enforcement"],
    label: "monthly spend cap: the month window, unpriced calls and its audit trail",
  },
  {
    module: "src/core/jobs/enqueue-cap.test.ts",
    gate: ["enqueueGeneration and the monthly cap"],
    label: "monthly spend cap refuses new work before anything is written",
  },
  {
    module: "src/core/pipeline/cadence.test.ts",
    gate: ["pipeline/cadence spend recording"],
    label: "spend aggregation + brand isolation",
  },
  {
    module: "src/core/pipeline/gather-vars.test.ts",
    gate: ["gatherVars honours each prompt's variable contract"],
    label: "pipeline steps",
  },
  {
    module: "src/core/pipeline/run-step.test.ts",
    gate: ["runStep"],
    label: "pipeline steps",
  },
  {
    module: "src/core/pipeline/run-step.test.ts",
    gate: ["runStep via worker"],
    label: "pipeline steps",
  },
  {
    module: "src/core/pipeline/save-step-content.test.ts",
    gate: ["saveStepContent"],
    label: "pipeline steps",
  },
  {
    module: "src/core/tenancy/access.test.ts",
    gate: ["tenancy/access"],
    label: "tenancy and brand isolation",
  },
  {
    module: "src/core/tenancy/recent-projects.test.ts",
    gate: ["tenancy/listRecentProjects"],
    label: "account area: brand isolation of the recent-work list",
  },
  {
    module: "src/core/tenancy/projects.test.ts",
    gate: ["tenancy/projects"],
    label: "tenancy and brand isolation",
  },
  {
    module: "src/lib/wizard-status.test.ts",
    gate: ["wizard-status"],
    label: "wizard status",
  },
];

/**
 * A skipped test, reduced to the two things attribution needs. Keeping the
 * counting free of Vitest's reporter classes is what makes it testable.
 */
export interface SkippedTest {
  /** Module path relative to `web/`. */
  readonly module: string;
  /** Suite names outermost first, ending with the test's own name. */
  readonly namePath: readonly string[];
}

export interface GateSkipSummary {
  /** Files holding at least one DB-gated skip. */
  readonly fileCount: number;
  /** DB-gated skipped tests — the number that `test:db` turns into runs. */
  readonly testCount: number;
  /** Labels of the gates actually closed in this run, deduped, in registry order. */
  readonly labels: readonly string[];
}

function normaliseModule(module: string): string {
  return module.replace(/^\.\//, "").replace(/\\/g, "/");
}

function isPrefix(gate: readonly string[], namePath: readonly string[]): boolean {
  if (gate.length > namePath.length) return false;
  return gate.every((segment, index) => segment === namePath[index]);
}

/**
 * Attributes skipped tests to the `DATABASE_URL` gate, ignoring skips that have
 * some other cause. Pure, so the numbers the banner prints can be tested.
 */
export function summariseGateSkips(
  skipped: readonly SkippedTest[],
): GateSkipSummary {
  const files = new Set<string>();
  const labels = new Set<string>();
  let testCount = 0;

  for (const test of skipped) {
    const modulePath = normaliseModule(test.module);
    const suite = DB_GATED_SUITES.find(
      (candidate) =>
        normaliseModule(candidate.module) === modulePath &&
        isPrefix(candidate.gate, test.namePath),
    );
    if (!suite) continue;
    files.add(modulePath);
    labels.add(suite.label);
    testCount += 1;
  }

  const ordered = DB_GATED_SUITES.map((suite) => suite.label).filter(
    (label, index, all) => labels.has(label) && all.indexOf(label) === index,
  );

  return { fileCount: files.size, testCount, labels: ordered };
}

const RULE = "=".repeat(78);

/** Wraps `items` into lines of at most `width` characters, each `indent`ed. */
function wrapList(items: readonly string[], indent: string, width: number): string[] {
  const lines: string[] = [];
  let current = "";
  items.forEach((item, index) => {
    const piece = index === items.length - 1 ? item : `${item}, `;
    if (current !== "" && (indent + current + piece).trimEnd().length > width) {
      lines.push(indent + current.trimEnd());
      current = "";
    }
    current += piece;
  });
  if (current !== "") lines.push(indent + current.trimEnd());
  return lines;
}

export function banner(summary: GateSkipSummary): string {
  const { fileCount, testCount, labels } = summary;
  const files = `${fileCount} test file${fileCount === 1 ? "" : "s"}`;
  const tests = `${testCount} test${testCount === 1 ? "" : "s"}`;
  return [
    "",
    RULE,
    "  DATABASE_URL IS NOT SET — THIS RUN WAS NOT THE FULL SUITE",
    RULE,
    `  Skipped by the DB gate: ${files} (${tests}).`,
    "",
    "  These did not execute:",
    ...wrapList(labels, "    ", 78),
    "",
    "  The summary above only covers the tests that ran. Running the full",
    `  suite turns exactly ${testCount === 1 ? "this" : "these"} ${tests} from skipped into run:`,
    "",
    `    ${FULL_SUITE_COMMAND}`,
    "",
    RULE,
    "",
  ].join("\n");
}

/** Suite names from the module down to (and including) the test itself. */
function namePathOf(test: TestCase): string[] {
  const path: string[] = [test.name];
  let node = test.parent;
  while (node.type === "suite") {
    path.unshift(node.name);
    node = node.parent;
  }
  return path;
}

/**
 * Counts what the gate cost and says so once per run, after the summary.
 *
 * Per-file reporting was rejected: fourteen identical copies is noise, not
 * signal. A `setupFiles` entry would give exactly that (it runs once per
 * worker), and a `globalSetup` message prints before the run, where it scrolls
 * away above the results.
 *
 * Placement caveat, stated honestly: this reporter is listed after `default` in
 * `test.reporters` and in practice its banner lands under the summary, but that
 * is not a contract. Vitest dispatches `onTestRunEnd` to all reporters via
 * `Promise.all`, so ordering holds only because the default reporter's hook is
 * synchronous. The banner is written to stdout — the same stream the summary
 * uses — so at minimum the two cannot be separated by a redirect.
 */
export class DbGateReporter implements Reporter {
  onTestRunEnd(
    testModules: ReadonlyArray<TestModule>,
    _unhandledErrors: unknown,
    reason?: "passed" | "interrupted" | "failed",
  ): void {
    if (hasDb) return;
    // A failed or Ctrl-C'd run has a louder problem than the DB gate; burying
    // the failures under 78 columns of notice would be the opposite of helpful.
    if (reason !== undefined && reason !== "passed") return;

    const skipped: SkippedTest[] = [];
    for (const testModule of testModules) {
      for (const test of testModule.children.allTests("skipped")) {
        skipped.push({
          module: testModule.relativeModuleId,
          namePath: namePathOf(test),
        });
      }
    }

    const summary = summariseGateSkips(skipped);
    if (summary.testCount === 0) return;

    process.stdout.write(banner(summary));
  }
}
