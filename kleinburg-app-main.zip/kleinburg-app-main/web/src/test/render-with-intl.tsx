import { render, type RenderOptions, type RenderResult } from "@testing-library/react";
import { NextIntlClientProvider } from "next-intl";
import type { ReactElement, ReactNode } from "react";

import messages from "../../messages/tr.json";

/**
 * Renders a component inside the TURKISH message catalog (T25).
 *
 * Why tr and not a stub: the component tests assert the real user-visible
 * Turkish sentences ("Devam etmek için en az bir içerik sütunu seçin", …). Those
 * assertions are the point — they describe what a user actually reads — so the
 * harness feeds the components the real tr.json rather than echoing keys back.
 * The assertions therefore keep their original meaning AND now also prove the
 * Turkish catalog is wired correctly.
 *
 * `rerender` from the returned result reuses this wrapper, so the prop-sync
 * tests (render(x) → rerender(y)) work unchanged.
 */
function IntlWrapper({ children }: { children: ReactNode }) {
  return (
    <NextIntlClientProvider locale="tr" messages={messages}>
      {children}
    </NextIntlClientProvider>
  );
}

export function renderWithIntl(
  ui: ReactElement,
  options?: Omit<RenderOptions, "wrapper">,
): RenderResult {
  return render(ui, { ...options, wrapper: IntlWrapper });
}
