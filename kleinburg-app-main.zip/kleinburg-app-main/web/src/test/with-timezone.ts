/**
 * Run a block with the PROCESS timezone pinned, then restore it.
 *
 * Why this exists: Render sets no `TZ`, so the app runs in UTC while every
 * user reads dates on an Istanbul calendar. A test that formats dates in
 * whatever zone the developer's laptop happens to be in proves nothing about
 * that — `relative-time.test.ts` anchored every case at noon UTC, which reads
 * as the same day in both zones and so passed under either implementation.
 *
 * Node re-reads `process.env.TZ` on the next date/`Intl` operation, so setting
 * it here really does move the runtime zone. `assertZone` is not decoration:
 * if a future runtime stops honouring the variable, the guard fails loudly
 * instead of letting the test quietly go back to proving nothing.
 */
export function withTimeZone<T>(timeZone: string, fn: () => T): T {
  const previous = process.env.TZ;
  process.env.TZ = timeZone;
  try {
    assertZone(timeZone);
    return fn();
  } finally {
    if (previous === undefined) {
      delete process.env.TZ;
    } else {
      process.env.TZ = previous;
    }
  }
}

function assertZone(expected: string): void {
  const actual = Intl.DateTimeFormat().resolvedOptions().timeZone;
  if (actual !== expected) {
    throw new Error(
      `Could not pin the process timezone: asked for ${expected}, runtime resolved ${actual}. ` +
        "This test cannot prove anything about timezone handling until that is fixed.",
    );
  }
}
