import { readdirSync, readFileSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

import {
  banner,
  DB_GATED_SUITES,
  summariseGateSkips,
  type SkippedTest,
} from "./db-gate-reporter";

const WEB_ROOT = fileURLToPath(new URL("../../", import.meta.url));

/** Every `*.test.ts(x)` under `src/`, as paths relative to `web/`. */
function testFiles(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...testFiles(full));
    else if (/\.test\.tsx?$/.test(entry.name)) out.push(full);
  }
  return out;
}

/**
 * Pulls `describe.skipIf(!hasDb)("name"` / `it.skipIf(!hasDb)("name"` out of the
 * source. Deliberately literal: the point is to notice when a gate is added,
 * removed or renamed without the registry following.
 */
const GATE_RE = /\b(?:describe|it|test)\.skipIf\(!hasDb\)\(\s*"((?:[^"\\]|\\.)*)"/g;

/** This file quotes the gate syntax it looks for, so it must not scan itself. */
const SELF = fileURLToPath(import.meta.url);

function gatesInSource(): Set<string> {
  const found = new Set<string>();
  for (const file of testFiles(join(WEB_ROOT, "src"))) {
    if (file === SELF) continue;
    const source = readFileSync(file, "utf8");
    const modulePath = relative(WEB_ROOT, file).replaceAll("\\", "/");
    for (const match of source.matchAll(GATE_RE)) {
      found.add(`${modulePath} :: ${match[1]}`);
    }
  }
  return found;
}

/** Builds a skipped test the way the reporter would report it. */
function skip(module: string, ...namePath: string[]): SkippedTest {
  return { module, namePath };
}

describe("DB gate registry", () => {
  it("matches every skipIf(!hasDb) gate in the source tree", () => {
    const registered = new Set(
      DB_GATED_SUITES.map(
        (suite) => `${suite.module} :: ${suite.gate[suite.gate.length - 1]}`,
      ),
    );
    // Sorted arrays rather than set equality so a mismatch names the culprit.
    expect([...gatesInSource()].sort()).toEqual([...registered].sort());
  });

  it("has no duplicate entries", () => {
    const keys = DB_GATED_SUITES.map(
      (suite) => `${suite.module} :: ${suite.gate.join(" > ")}`,
    );
    expect(new Set(keys).size).toBe(keys.length);
  });
});

describe("summariseGateSkips", () => {
  it("counts a skip inside a gated suite", () => {
    const summary = summariseGateSkips([
      skip("src/core/tenancy/access.test.ts", "tenancy/access", "denies"),
      skip("src/core/tenancy/access.test.ts", "tenancy/access", "allows"),
    ]);
    expect(summary).toEqual({
      fileCount: 1,
      testCount: 2,
      labels: ["tenancy and brand isolation"],
    });
  });

  it("counts a gated bare `it` nested under an ungated describe", () => {
    const summary = summariseGateSkips([
      skip("src/core/db/client.test.ts", "db client", "connects and runs select 1"),
    ]);
    expect(summary.testCount).toBe(1);
    expect(summary.labels).toEqual(["database connectivity"]);
  });

  it("counts skips nested arbitrarily deep inside a gated suite", () => {
    const summary = summariseGateSkips([
      skip("src/core/pipeline/run-step.test.ts", "runStep", "retries", "on 429"),
    ]);
    expect(summary.testCount).toBe(1);
  });

  // The defect this whole registry exists for: worker.test.ts skips its pg-boss
  // round trip on RUN_PGBOSS_TEST, which stays skipped even with Postgres up.
  it("ignores skips in a gated file that the DB gate does not cause", () => {
    const summary = summariseGateSkips([
      skip("src/core/jobs/worker.test.ts", "worker handler (direct)", "marks done"),
      skip("src/core/jobs/worker.test.ts", "pg-boss round trip", "supersedes"),
      skip("src/core/jobs/worker.test.ts", "pg-boss round trip", "cancels"),
    ]);
    expect(summary.testCount).toBe(1);
    expect(summary.fileCount).toBe(1);
  });

  it("ignores a stray it.skip in an ungated file", () => {
    const summary = summariseGateSkips([
      skip("src/lib/format.test.ts", "format", "handles nbsp"),
    ]);
    expect(summary).toEqual({ fileCount: 0, testCount: 0, labels: [] });
  });

  it("does not confuse a gate with a longer suite name sharing its prefix", () => {
    // "runStep" must not swallow "runStep via worker" or vice versa; both are
    // registered, but each skip may only be attributed once.
    const summary = summariseGateSkips([
      skip("src/core/pipeline/run-step.test.ts", "runStep via worker", "enqueues"),
    ]);
    expect(summary.testCount).toBe(1);
  });

  it("does not attribute a gated suite name found in the wrong module", () => {
    const summary = summariseGateSkips([
      skip("src/core/pipeline/gather-vars.test.ts", "tenancy/access", "denies"),
    ]);
    expect(summary.testCount).toBe(0);
  });

  it("dedupes labels shared by several gates and counts files once each", () => {
    const summary = summariseGateSkips([
      skip("src/core/tenancy/access.test.ts", "tenancy/access", "a"),
      skip("src/core/tenancy/projects.test.ts", "tenancy/projects", "b"),
      skip("src/core/pipeline/run-step.test.ts", "runStep", "c"),
      skip("src/core/pipeline/run-step.test.ts", "runStep via worker", "d"),
    ]);
    expect(summary.fileCount).toBe(3);
    expect(summary.testCount).toBe(4);
    expect(summary.labels).toEqual([
      "pipeline steps",
      "tenancy and brand isolation",
    ]);
  });

  it("tolerates ./-prefixed and backslashed module ids", () => {
    const summary = summariseGateSkips([
      skip("./src/core/tenancy/access.test.ts", "tenancy/access", "a"),
      skip("src\\core\\tenancy\\projects.test.ts", "tenancy/projects", "b"),
    ]);
    expect(summary.testCount).toBe(2);
    expect(summary.fileCount).toBe(2);
  });

  it("returns nothing for an empty run", () => {
    expect(summariseGateSkips([])).toEqual({
      fileCount: 0,
      testCount: 0,
      labels: [],
    });
  });
});

describe("banner", () => {
  it("names only the gates actually closed, not every gate that exists", () => {
    const text = banner(
      summariseGateSkips([
        skip("src/core/auth/session.test.ts", "session", "rotates"),
      ]),
    );
    expect(text).toContain("auth sessions");
    expect(text).not.toContain("tenancy and brand isolation");
    expect(text).not.toContain("pipeline steps");
  });

  it("uses singular wording for a single file and test", () => {
    const text = banner({ fileCount: 1, testCount: 1, labels: ["jobs"] });
    expect(text).toContain("1 test file (1 test)");
    expect(text).not.toContain("1 test files");
  });

  it("uses plural wording otherwise", () => {
    const text = banner({ fileCount: 3, testCount: 9, labels: ["jobs"] });
    expect(text).toContain("3 test files (9 tests)");
  });

  it("promises the same number it counted", () => {
    const text = banner({ fileCount: 2, testCount: 7, labels: ["jobs"] });
    expect(text).toContain("turns exactly these 7 tests from skipped into run");
  });

  it("keeps the promise grammatical for a single test", () => {
    const text = banner({ fileCount: 1, testCount: 1, labels: ["jobs"] });
    expect(text).toContain("turns exactly this 1 test from skipped into run");
  });

  it("stays inside 78 columns", () => {
    const text = banner(
      summariseGateSkips(
        DB_GATED_SUITES.map((suite) => skip(suite.module, ...suite.gate)),
      ),
    );
    for (const line of text.split("\n")) {
      expect(line.length).toBeLessThanOrEqual(78);
    }
  });
});
