import { LoginScreen } from "@/components/login-screen";

/**
 * `/login` — the same screen as `/` (T45).
 *
 * Kept as a route because every redirect in the app names it: the middleware,
 * the (app) auth layout, /change-password and the logout button. Rendering the
 * shared component rather than keeping a second copy is what stops the two
 * front doors from drifting apart.
 */
export default function LoginPage() {
  return <LoginScreen />;
}
