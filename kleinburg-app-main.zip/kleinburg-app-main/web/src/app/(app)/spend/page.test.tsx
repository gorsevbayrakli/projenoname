// @vitest-environment jsdom
/**
 * /spend — what the ADMIN IS TOLD about where they are (#50 review, M1/m3/m7).
 *
 * The data on this page is authorised: Elif decided the super admin may read
 * every brand's spend. What she decided it ON was that the crossing is VISIBLE
 * to the person making it. So the thing worth testing here is not access — the
 * core tests cover that — it is whether the page says the true thing on every
 * path that reaches it.
 *
 * The path that was silent (M1): an admin who IS a member of the selected
 * brand pastes `?brand=<theirs>&project=<id in a foreign brand>`. The audit row
 * is written, the brand banner is correctly absent (the SELECTED brand is
 * theirs), and before this fix the panel said only "this project belongs to X"
 * — true, but it did not say that X is not theirs or that looking was recorded.
 *
 * These are rendered against the real tr.json, so a test cannot pass against a
 * missing or renamed key.
 */
import { cleanup, screen } from "@testing-library/react";
import { cloneElement, isValidElement, type ReactNode } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { renderWithIntl } from "@/test/render-with-intl";
import messages from "../../../../messages/tr.json";

vi.mock("next-intl/server", () => ({
  getLocale: async () => "tr",
  getTranslations: async (namespace: keyof typeof messages) => {
    const table = messages[namespace] as Record<string, string>;
    return (key: string, values?: Record<string, string>) => {
      const template = table[key];
      if (template === undefined)
        throw new Error(`missing key ${namespace}.${key}`);
      return values
        ? template.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? ""))
        : template;
    };
  },
}));

const getCurrentUser = vi.fn();
vi.mock("@/lib/auth-server", () => ({ getCurrentUser: () => getCurrentUser() }));

vi.mock("@/core/auth/roles", () => ({
  isSuperAdmin: (u: { role: string }) => u.role === "admin",
}));

const listAllBrands = vi.fn();
const getBrandSpendAdmin = vi.fn();
const getProjectSpendAdmin = vi.fn();
vi.mock("@/core/llm/admin-spend", () => ({
  listAllBrandsForSpendAsSuperAdmin: (...a: unknown[]) => listAllBrands(...a),
  getBrandSpendAsSuperAdmin: (...a: unknown[]) => getBrandSpendAdmin(...a),
  getProjectSpendAsSuperAdmin: (...a: unknown[]) => getProjectSpendAdmin(...a),
}));

vi.mock("@/core/llm/spend", () => ({
  getBrandSpend: vi.fn(),
  getProjectSpend: vi.fn(),
}));

vi.mock("@/core/tenancy/access", () => ({
  listAccessibleBrands: async () => [],
}));

/**
 * T51's cap banner. Only the DATABASE read is stubbed — `warnsAboutSpend`,
 * `refusesGeneration` and `formatMonthReset` stay real, so a test asserting
 * that the banner appears is asserting against the actual thresholds and the
 * actual date formatting rather than against a second copy of them.
 */
const readCapStatus = vi.fn();
vi.mock("@/core/llm/cap", async (importOriginal) => ({
  ...(await importOriginal<typeof import("@/core/llm/cap")>()),
  readBrandCapStatusUnscoped: (...a: unknown[]) => readCapStatus(...a),
}));

vi.mock("next/navigation", () => ({
  redirect: (to: string) => {
    throw new Error(`redirected:${to}`);
  },
}));

// A plain anchor. `next/link` needs a router this environment does not have,
// and nothing asserted here depends on its behaviour.
vi.mock("next/link", () => ({
  default: ({ children, href }: { children: ReactNode; href: string }) => (
    <a href={href}>{children}</a>
  ),
}));

const SpendPage = (await import("./page")).default;
const { spendMonthOf } = await import("@/core/llm/cap");

/**
 * Render an async SERVER component tree.
 *
 * The page is not one async component, it is several nested ones (Shell,
 * TotalCard, Row all await `getTranslations`). React's client renderer refuses
 * async function components outright — "Only Server Components can be async" —
 * so `render(await SpendPage())` puts the outer element into the DOM and stops
 * at the first nested one, producing an empty body and a test that can only
 * ever fail. Awaiting each function component to its output first hands the
 * renderer a plain element tree, which is exactly what the server would have
 * streamed.
 */
async function resolveAsyncTree(node: ReactNode): Promise<ReactNode> {
  if (Array.isArray(node)) {
    const items = await Promise.all(node.map(resolveAsyncTree));
    // Static JSX children that pass back through `cloneElement` arrive as a
    // dynamic array, which React then wants keys for even though the source
    // never needed them. Positional keys are correct here: this tree is
    // rendered once and never reconciled.
    return items.map((item, i) =>
      isValidElement(item) && item.key === null
        ? cloneElement(item, { key: `resolved-${i}` })
        : item,
    );
  }
  if (node && typeof node === "object" && "then" in node) {
    return resolveAsyncTree((await node) as ReactNode);
  }
  if (!isValidElement(node)) return node;

  const element = node as React.ReactElement<{ children?: ReactNode }>;
  if (typeof element.type === "function") {
    const rendered = await (
      element.type as (props: unknown) => ReactNode | Promise<ReactNode>
    )(element.props);
    const resolved = await resolveAsyncTree(rendered);
    // The key lived on the component element, which has just been replaced by
    // its output. Carry it over or React warns about every mapped list.
    return element.key !== null && isValidElement(resolved)
      ? cloneElement(resolved, { key: element.key })
      : resolved;
  }
  if (element.props?.children !== undefined) {
    const children = await resolveAsyncTree(element.props.children);
    // Spread rather than pass the array: `cloneElement(el, undefined, [a, b])`
    // marks the children as a dynamic list and demands keys the original static
    // JSX never needed.
    return Array.isArray(children)
      ? cloneElement(element, undefined, ...children)
      : cloneElement(element, undefined, children);
  }
  return element;
}

async function renderPage(searchParams: { brand?: string; project?: string }) {
  renderWithIntl(
    (await resolveAsyncTree(
      await SpendPage({ searchParams: Promise.resolve(searchParams) }),
    )) as React.ReactElement,
  );
}

function summary(overrides: Record<string, unknown> = {}) {
  return {
    costUsd: 1.5,
    callCount: 3,
    pricedCallCount: 3,
    unpricedCallCount: 0,
    promptTokens: 100,
    completionTokens: 50,
    unpricedPromptTokens: 0,
    unpricedCompletionTokens: 0,
    complete: true,
    ...overrides,
  };
}

function brandSpend(brandId: string, brandName: string, viewerIsMember: boolean) {
  return {
    brandId,
    brandName,
    total: summary(),
    byProject: [],
    byModel: [],
    viewerIsMember,
  };
}

function projectSpend(
  brandId: string,
  brandName: string,
  viewerIsMember: boolean,
) {
  return {
    projectId: "p-1",
    projectName: "Yaz kampanyası",
    brandId,
    brandName,
    total: summary(),
    byStep: [],
    byModel: [],
    viewerIsMember,
  };
}

/** The Turkish sentences a reader would actually see, out of the catalog. */
const copy = messages.spend;

beforeEach(() => {
  vi.clearAllMocks();
  getCurrentUser.mockResolvedValue({
    id: "admin-1",
    role: "admin",
    username: "elif",
  });
  // Default: no cap set, which is what every brand ships as. The cap tests
  // below override it; every other test on this page must render as if T51
  // had not happened, which is the behaviour a null cap is supposed to give.
  readCapStatus.mockResolvedValue(capStatus({ capUsd: null, state: "unlimited" }));
});

/** A `BrandCapStatus`, defaulted to a brand sitting at 85% of a $100 cap. */
function capStatus(overrides: Record<string, unknown> = {}) {
  return {
    brandId: "b-1",
    brandName: "Kendi markam",
    capUsd: 100,
    month: spendMonthOf(new Date("2026-08-15T12:00:00.000Z")),
    measuredUsd: 85,
    estimatedUnpricedUsd: 0,
    chargeableUsd: 85,
    unpricedCallCount: 0,
    ratio: 0.85,
    state: "warning",
    ...overrides,
  };
}

afterEach(cleanup);

describe("SpendPage — telling the admin where they are", () => {
  it("marks a drill-down into a FOREIGN brand even when the selected brand is the admin's own", async () => {
    // M1. Selected brand is one the admin belongs to, so no page banner is due.
    // The project id, pasted, belongs to a brand that is not theirs.
    listAllBrands.mockResolvedValue([
      { id: "b-mine", name: "Benim Markam", viewerIsMember: true },
      { id: "b-other", name: "Yabancı Marka", viewerIsMember: false },
    ]);
    getBrandSpendAdmin.mockResolvedValue(
      brandSpend("b-mine", "Benim Markam", true),
    );
    getProjectSpendAdmin.mockResolvedValue(
      projectSpend("b-other", "Yabancı Marka", false),
    );

    await renderPage({ brand: "b-mine", project: "p-1" });

    // The page-level banner is correctly absent: the SELECTED brand is theirs.
    expect(screen.queryByText(copy.nonMemberBannerAudited)).toBeNull();

    // ...but the panel must not read as a neutral "belongs to another brand".
    // It has to say both things: not yours, and this was recorded.
    const expected = copy.projectOtherBrandNonMember.replace(
      "{brand}",
      "Yabancı Marka",
    );
    expect(screen.getByText(expected)).toBeTruthy();
  });

  it("keeps the neutral wording when the other brand IS one the admin belongs to", async () => {
    // The control. Crossing brands is not by itself a crossing of the boundary;
    // over-marking would make the real marker furniture.
    listAllBrands.mockResolvedValue([
      { id: "b-mine", name: "Benim Markam", viewerIsMember: true },
      { id: "b-second", name: "İkinci Markam", viewerIsMember: true },
    ]);
    getBrandSpendAdmin.mockResolvedValue(
      brandSpend("b-mine", "Benim Markam", true),
    );
    getProjectSpendAdmin.mockResolvedValue(
      projectSpend("b-second", "İkinci Markam", true),
    );

    await renderPage({ brand: "b-mine", project: "p-1" });

    expect(
      screen.getByText(
        copy.projectOtherBrand.replace("{brand}", "İkinci Markam"),
      ),
    ).toBeTruthy();
    expect(
      screen.queryByText(
        copy.projectOtherBrandNonMember.replace("{brand}", "İkinci Markam"),
      ),
    ).toBeNull();
  });

  it("drives the banner off the flag the AUDIT decision was made on, not the list's", async () => {
    // m3. The chips come from listAllBrandsForSpendAsSuperAdmin; the audit row
    // is decided inside getBrandSpendAsSuperAdmin, which does its OWN
    // membership query and returns the answer. Two queries can disagree
    // (membership revoked between them, at minimum). The banner is the claim
    // "this was recorded", so it must follow the flag that decided the record.
    listAllBrands.mockResolvedValue([
      { id: "b-1", name: "Marka Bir", viewerIsMember: true },
    ]);
    getBrandSpendAdmin.mockResolvedValue(brandSpend("b-1", "Marka Bir", false));

    await renderPage({ brand: "b-1" });

    expect(screen.getByText(copy.nonMemberBannerAudited)).toBeTruthy();
    expect(
      screen.getByText(copy.nonMemberBanner.replace("{brand}", "Marka Bir")),
    ).toBeTruthy();
  });

  it("gives a non-member chip a marker a non-technical reader can read", async () => {
    // m7. The dashed border and the screen-reader text do the real work, but
    // the visible mark has to mean something to Elif at a glance rather than
    // looking like a rendering artefact.
    listAllBrands.mockResolvedValue([
      { id: "b-1", name: "Marka Bir", viewerIsMember: true },
      { id: "b-2", name: "Marka İki", viewerIsMember: false },
    ]);
    getBrandSpendAdmin.mockResolvedValue(brandSpend("b-1", "Marka Bir", true));

    await renderPage({ brand: "b-1" });

    expect(screen.getByText(copy.nonMemberChipMark)).toBeTruthy();
    // ...and it is a word, not a glyph a reader has to decode.
    expect(copy.nonMemberChipMark).toMatch(/\p{L}/u);
  });
});

/**
 * The cap banner (T51). What is asserted here is the WARNING BEHAVIOUR, not
 * the arithmetic: whether the page speaks up at all, whether it says the right
 * thing when it does, and — the one most likely to regress — whether it stays
 * quiet for the brands that ship with no cap.
 */
describe("SpendPage — the monthly cap banner", () => {
  beforeEach(() => {
    listAllBrands.mockResolvedValue([
      { id: "b-1", name: "Marka Bir", viewerIsMember: true },
    ]);
    getBrandSpendAdmin.mockResolvedValue(brandSpend("b-1", "Marka Bir", true));
  });

  it("says NOTHING for a brand with no cap", async () => {
    // The default state of every brand in the product. If this ever fails, the
    // feature has started shouting at people who never opted into it.
    readCapStatus.mockResolvedValue(
      capStatus({ capUsd: null, state: "unlimited", ratio: null }),
    );
    await renderPage({ brand: "b-1" });
    expect(screen.queryByRole("note")).toBeNull();
  });

  it("shows the monthly figure as soon as a cap is set, well below 80%", async () => {
    // #51 review, finding 8. The tables on this page are LIFETIME, and the
    // monthly figure used to exist only inside the banner, which was gated on
    // the warning. So an operator could not answer "how much of my cap have I
    // used" until they were already at 80% — and the refusal message sends
    // them to this page precisely to find that out.
    readCapStatus.mockResolvedValue(
      capStatus({
        brandName: "Marka Bir",
        state: "ok",
        measuredUsd: 40,
        chargeableUsd: 40,
        ratio: 0.4,
      }),
    );
    await renderPage({ brand: "b-1" });

    const note = screen.getByRole("note");
    expect(note.textContent).toContain("40");
    expect(note.textContent).toContain("100");
    expect(note.textContent).toContain("1 Eylül 2026");

    // And it is the CALM sentence, not the warning one. A page that shouted
    // from $0 would be the failure the 80% threshold exists to avoid.
    const spend = messages.spend as Record<string, string>;
    expect(note.textContent).toContain(
      spend.capStatusTitle.replace("{brand}", "Marka Bir"),
    );
    expect(note.textContent).not.toContain(
      spend.capWarningTitle.replace("{brand}", "Marka Bir"),
    );
  });

  it("warns at 80% and names the brand, the numbers and the reset date", async () => {
    readCapStatus.mockResolvedValue(capStatus({ brandName: "Marka Bir" }));
    await renderPage({ brand: "b-1" });

    const note = screen.getByRole("note");
    expect(note.textContent).toContain("Marka Bir");
    expect(note.textContent).toContain("85");
    // `formatMonthReset` is NOT mocked, so this is the real boundary date on
    // the operator's calendar: August's window ends at 1 September local.
    expect(note.textContent).toContain("1 Eylül 2026");
  });

  it("says which part of the figure is an estimate over unpriced calls", async () => {
    // The honesty requirement (#51 item 2) surviving all the way to the
    // screen. A banner that showed only the combined total would present
    // arithmetic with the authority of a measurement.
    readCapStatus.mockResolvedValue(
      capStatus({
        measuredUsd: 60,
        estimatedUnpricedUsd: 25,
        chargeableUsd: 85,
        unpricedCallCount: 4,
      }),
    );
    await renderPage({ brand: "b-1" });

    const note = screen.getByRole("note");
    expect(note.textContent).toContain("60");
    expect(note.textContent).toContain("25");
    expect(note.textContent).toContain("4");
  });

  it("does not mention an estimate when every call was priced", async () => {
    readCapStatus.mockResolvedValue(capStatus());
    await renderPage({ brand: "b-1" });
    expect(screen.getByRole("note").textContent).not.toContain(
      copy_estimateFragment(),
    );
  });

  it("distinguishes 'reached the cap' from 'cannot be established'", async () => {
    // A brand refused because its spend could not be bounded did NOT overspend,
    // and telling the operator it hit its cap would be a lie.
    readCapStatus.mockResolvedValue(
      capStatus({ state: "unmeasurable", brandName: "Marka Bir" }),
    );
    await renderPage({ brand: "b-1" });

    const spend = messages.spend as Record<string, string>;
    expect(screen.getByRole("note").textContent).toContain(
      spend.capUnmeasurableTitle.replace("{brand}", "Marka Bir"),
    );
  });
});

/** The first few words of the estimate sentence, for a negative assertion. */
function copy_estimateFragment(): string {
  const spend = messages.spend as Record<string, string>;
  return spend.capEstimatePart.slice(0, 20);
}
