import { getLocale, getTranslations } from "next-intl/server";
import Link from "next/link";
import { redirect } from "next/navigation";

import {
  getBrandSpendAsSuperAdmin,
  getProjectSpendAsSuperAdmin,
  listAllBrandsForSpendAsSuperAdmin,
  type AdminBrandSpend,
  type AdminProjectSpend,
  type AdminSpendBrand,
} from "@/core/llm/admin-spend";
import {
  formatMonthReset,
  readBrandCapStatusUnscoped,
  refusesGeneration,
  warnsAboutSpend,
} from "@/core/llm/cap";
import { getBrandSpend, getProjectSpend } from "@/core/llm/spend";
import type { SpendSummary } from "@/core/llm/spend";
import { isSuperAdmin } from "@/core/auth/roles";
import { listAccessibleBrands } from "@/core/tenancy/access";
import { AccessError, NotFoundError } from "@/core/tenancy/errors";
import { getCurrentUser } from "@/lib/auth-server";

/**
 * /spend — per-brand / per-project / per-step cost visibility (T42).
 *
 * ── WHAT THIS PAGE IS FOR ────────────────────────────────────────────────
 * Elif's ask: after a test run, see roughly what a brand / project / step
 * cost, in order to decide whether an API-level cap is warranted. So the job
 * of this page is to be TRUSTWORTHY rather than precise: a number that might
 * be wrong in an unknown direction is worse than useless for that decision,
 * because it would be acted on.
 *
 * Enforcing a cap is explicitly NOT built here — issue #42 item 4 calls it a
 * separate piece of work and it is left as one.
 *
 * ── SCOPE: TWO PATHS, AND WHY THE BRANCH IS WRITTEN OUT IN FULL ──────────
 * This page has an ADMIN VARIANT as of T50, and it is the only place in the
 * product where a role rather than a `user_brands` row opens a brand.
 *
 *   ORDINARY USER — `listAccessibleBrands` + `getBrandSpend`/`getProjectSpend`,
 *   which go through requireBrandAccess/requireProjectAccess. Unchanged by
 *   T50 in every respect, and asserted so in core/llm/admin-spend.test.ts.
 *
 *   SUPER ADMIN — `listAllBrandsForSpendAsSuperAdmin` +
 *   `getBrandSpendAsSuperAdmin`/`getProjectSpendAsSuperAdmin`, which see every
 *   active brand with its project names, and which write an audit row whenever
 *   the brand is one the admin does not belong to.
 *
 * The `isSuperAdmin(user)` branch below is deliberately explicit rather than
 * hidden behind one polymorphic helper. A reader of this file should be able
 * to see that admin scope is in play without following an import; a helper
 * that silently did the right thing for both roles would be exactly the kind
 * of quiet super-view T50 was careful not to build.
 *
 * As on /activity, the UI is still not the authorization: both paths decide
 * their scope in the query, server-side. What the UI is responsible for here
 * is HONESTY — see below.
 *
 * ── TELLING THE ADMIN WHERE THEY ARE ─────────────────────────────────────
 * An admin looking at a brand they are not a member of must be able to see
 * that, at a glance and without reading a URL. Three signals, all of them
 * server-computed and none behind a hover, because a silent super-view is how
 * accidental disclosure happens:
 *
 *   - every non-member brand chip carries a marker. This one comes from
 *     `listAllBrandsForSpendAsSuperAdmin`, which is a SEPARATE query from the
 *     one that decides the audit row — it has to be, it is a list. So the chip
 *     is an advance warning about a brand not yet opened, not a claim about a
 *     record;
 *   - selecting a brand raises a banner saying so and saying the view was
 *     recorded. This is gated on `brandSpend.viewerIsMember` — the flag
 *     returned BY the call that decided whether to write the row, not the
 *     list's copy of it. The banner asserts "this was recorded", so it must
 *     follow the thing that recorded it; two queries can disagree, and if they
 *     ever do it is the banner that must be right;
 *   - drilling into a project in a brand that is not the admin's says so in
 *     the panel, off `projectSpend.viewerIsMember` — again the flag the audit
 *     decision was made on. The selected brand's banner cannot cover this
 *     case: the project may live in a different brand entirely.
 *
 * ── HONESTY ──────────────────────────────────────────────────────────────
 * `llm_calls.cost_usd` is nullable, so a plain sum silently reads unknown
 * costs as zero. Every figure rendered here is therefore labelled: exact when
 * every call was priced, and an explicit lower bound ("≥") when it was not,
 * with the count of unpriced calls and the tokens they burned shown alongside.
 * No figure on this page is ever presented as a total it is not.
 */
export default async function SpendPage({
  searchParams,
}: {
  // Next 15: searchParams is a Promise.
  searchParams: Promise<{ brand?: string; project?: string }>;
}) {
  const t = await getTranslations("spend");
  const user = await getCurrentUser();
  // The (app) layout already guards auth; this narrows the type.
  if (!user) redirect("/login");

  // THE BRANCH. Everything downstream is shared; the scope is decided here.
  const isAdmin = isSuperAdmin(user);
  const adminActor = { id: user.id, role: user.role, username: user.username };

  const brands: AdminSpendBrand[] = isAdmin
    ? await listAllBrandsForSpendAsSuperAdmin(adminActor)
    : (await listAccessibleBrands(user.id)).map((b) => ({
        id: b.id,
        name: b.name,
        // An ordinary user only ever reaches brands they are a member of, so
        // the flag is constant here and no marker is ever drawn for them.
        viewerIsMember: true,
      }));

  if (brands.length === 0) {
    return (
      <Shell title={t("title")} back={t("backToProjects")}>
        <p className="rounded-lg border border-border bg-bg p-8 text-center text-sm text-fg-muted">
          {isAdmin ? t("noBrandsAdmin") : t("noBrands")}
        </p>
      </Shell>
    );
  }

  const { brand: brandParam, project: projectParam } = await searchParams;
  // An unknown brand id falls back to the first accessible brand rather than
  // erroring — but it is never trusted: the id handed to getBrandSpend always
  // comes from the accessible list, and getBrandSpend re-checks it anyway.
  const selectedBrand = brands.find((b) => b.id === brandParam) ?? brands[0];

  // The admin call is where the audit row is written, so it happens on the way
  // to rendering rather than lazily — the crossing is the page load.
  //
  // The ordinary branch is widened to the admin shape with a CONSTANT flag
  // rather than the reads being typed separately, so that everything below can
  // ask one question. An ordinary user reaches this line only through
  // requireBrandAccess, so `true` is not an assumption, it is what that gate
  // has already established.
  const brandSpend: AdminBrandSpend = isAdmin
    ? await getBrandSpendAsSuperAdmin(adminActor, selectedBrand.id)
    : { ...(await getBrandSpend(user.id, selectedBrand.id)), viewerIsMember: true };

  // Drill-down. Both paths re-gate independently of the brand selector: for a
  // user requireProjectAccess refuses a hand-typed id from another brand, and
  // for an admin the project's OWN brand is what gets audited, so a project id
  // pasted from a third brand still leaves an accurate record.
  //
  // Typed to the ADMIN shape deliberately. Narrowing this to `ProjectSpend`
  // threw away the `viewerIsMember` the call had already computed and returned,
  // which is what left the one path this page used to be silent on: an admin
  // who IS a member of the selected brand, opening a project in a brand they
  // are NOT a member of. The row was written; the page said nothing about it.
  let projectSpend: AdminProjectSpend | null = null;
  if (projectParam) {
    try {
      projectSpend = isAdmin
        ? await getProjectSpendAsSuperAdmin(adminActor, projectParam)
        : {
            ...(await getProjectSpend(user.id, projectParam)),
            viewerIsMember: true,
          };
    } catch (e) {
      if (!(e instanceof AccessError) && !(e instanceof NotFoundError)) throw e;
      // Silently dropping the drill-down would look like the project had no
      // spend. Bounce to the brand view instead.
      redirect(`/spend?brand=${selectedBrand.id}`);
    }
  }

  // T51. Read AFTER the gate above, so the cap of a brand the viewer may not
  // see is never computed, let alone rendered. Uses the same aggregation as
  // everything else on this page, narrowed to the current month.
  const capStatus = await readBrandCapStatusUnscoped(
    selectedBrand.id,
    new Date(),
  );
  // The page's own currency formatter, not the cap module's, so the banner and
  // the tables below it show money the same way in the same locale.
  const pageLocale = await getLocale();

  return (
    <Shell
      title={t("title")}
      back={t("backToProjects")}
      subtitle={isAdmin ? t("scopeAdmin") : t("scope")}
    >
      {/* THE CAP BLOCK (T51).

          Drawn whenever a cap EXISTS, not only from 80% upwards (#51 review,
          finding 8). Everything else on this page is lifetime, and the monthly
          figure the cap is actually compared against lived only in the warning
          — so an operator could not answer "how much of my cap have I used"
          until they were already at 80%, which is exactly when it stops being
          a useful question. The refusal message points people here.

          What the threshold still decides is the TONE. Below 80% this is a
          quiet line of information; from 80% it turns into a warning. Elif's
          decision was that the warning is what makes someone look before a
          refusal does it for them, and drawing the figure earlier does not
          weaken that as long as the shouting still starts where she put it.

          The two figures stay APART — measured and estimated — because part of
          the number can be arithmetic over calls OpenRouter did not price, and
          presenting that with the authority of a measurement is the dishonesty
          this whole feature was careful to avoid. */}
      {capStatus && capStatus.state !== "unlimited" && (
        <div
          role="note"
          className={
            warnsAboutSpend(capStatus.state)
              ? "flex flex-col gap-1 rounded-lg border border-border-warning bg-bg-warning p-4 text-sm text-fg-warning"
              : "flex flex-col gap-1 rounded-lg border border-border bg-bg p-4 text-sm text-fg-muted"
          }
        >
          <p className="font-semibold">
            {capStatus.state === "unmeasurable"
              ? t("capUnmeasurableTitle", { brand: capStatus.brandName })
              : refusesGeneration(capStatus.state)
                ? t("capBlockedTitle", { brand: capStatus.brandName })
                : warnsAboutSpend(capStatus.state)
                  ? t("capWarningTitle", { brand: capStatus.brandName })
                  : t("capStatusTitle", { brand: capStatus.brandName })}
          </p>
          <p>
            {t("capSpent", {
              spent: formatUsd(capStatus.chargeableUsd, pageLocale),
              cap: formatUsd(capStatus.capUsd ?? 0, pageLocale),
              percent: Math.round((capStatus.ratio ?? 0) * 100),
            })}
          </p>
          {capStatus.estimatedUnpricedUsd > 0 && (
            <p>
              {t("capEstimatePart", {
                measured: formatUsd(capStatus.measuredUsd, pageLocale),
                estimated: formatUsd(capStatus.estimatedUnpricedUsd, pageLocale),
                calls: capStatus.unpricedCallCount,
              })}
            </p>
          )}
          {/* The unpriceable tail: calls nothing in this brand can price, and
              the absurd upper bound they are held to. Shown whenever it is not
              zero — including when the brand is comfortably under its cap,
              because "some of your calls have no price at all" is worth
              knowing BEFORE it is the reason work stops. */}
          {capStatus.unpriceableTokens > 0 && (
            <p>
              {t("capWorstCase", {
                worstCase: formatUsd(capStatus.worstCaseUsd, pageLocale),
                calls: capStatus.unpricedCallCount,
              })}
            </p>
          )}
          <p>
            {warnsAboutSpend(capStatus.state)
              ? t("capResets", { date: formatMonthReset(capStatus.month.until) })
              : t("capResetsPlain", {
                  date: formatMonthReset(capStatus.month.until),
                })}
          </p>
        </div>
      )}
      {/* SIGNAL 2: the loud one. Drawn only when the admin is actually inside
          a brand they do not belong to, so it stays meaningful instead of
          becoming furniture an admin learns to skip past. It says both things
          a reader needs: whose data this is, and that looking was recorded. */}
      {!brandSpend.viewerIsMember && (
        <div
          role="note"
          className="flex flex-col gap-1 rounded-lg border border-border-warning bg-bg-warning p-4 text-sm text-fg-warning"
        >
          <p className="font-semibold">
            {t("nonMemberBanner", { brand: brandSpend.brandName })}
          </p>
          <p>{t("nonMemberBannerAudited")}</p>
        </div>
      )}
      {/* The standing caveat this page cannot derive from the data. Calls that
          failed on a truncation / JSON / schema path used to leave no row at
          all (fixed in #39/#46), and an absent row is indistinguishable from a
          call that never happened — so older runs under-report by an amount
          no query can recover. Stated plainly rather than guessed at. */}
      <div className="flex flex-col gap-2 rounded-lg border border-border bg-bg p-4 text-sm text-fg-muted">
        <p>{t("sourceNote")}</p>
        {/* The second standing caveat, and the one a reader would never guess:
            deleting a project cascades through generation_jobs to llm_calls
            (core/tenancy/projects.ts), so money that was genuinely spent leaves
            the brand total with no tombstone. Not something this commit
            introduced, but it is a load-bearing property of the number this
            page shows, so it is stated rather than left to be discovered. */}
        <p>{t("deletionNote")}</p>
      </div>

      <nav className="flex flex-wrap gap-2" aria-label={t("brandsLabel")}>
        {/* SIGNAL 1: the ambient one. A marker on every chip the admin does
            not belong to, so the shape of "mine vs everyone's" is visible
            BEFORE clicking rather than only after. */}
        {brands.map((b) => (
          <Chip
            key={b.id}
            href={`/spend?brand=${b.id}`}
            active={b.id === selectedBrand.id}
            nonMember={!b.viewerIsMember}
            nonMemberLabel={t("nonMemberChip")}
            nonMemberMark={t("nonMemberChipMark")}
          >
            {b.name}
          </Chip>
        ))}
      </nav>

      <TotalCard
        label={t("brandTotal", { brand: selectedBrand.name })}
        summary={brandSpend.total}
      />

      <Section title={t("byProject")}>
        {/* A granted brand with no projects rendered a bare header row over an
            empty table body, which reads as a rendering fault rather than as
            "nothing here yet". The other zero cases already say so in words. */}
        {brandSpend.byProject.length === 0 ? (
          <p className="rounded-lg border border-border bg-bg p-6 text-center text-sm text-fg-muted">
            {t("emptyBrand")}
          </p>
        ) : (
          <Table
            head={[t("colProject"), t("colCalls"), t("colTokens"), t("colCost")]}
          >
            {brandSpend.byProject.map((p) => (
              <Row
                key={p.projectId}
                label={p.projectName}
                href={`/spend?brand=${selectedBrand.id}&project=${p.projectId}`}
                summary={p}
              />
            ))}
          </Table>
        )}
      </Section>

      {brandSpend.byModel.length > 0 && (
        <Section title={t("byModel")} note={t("byModelNote")}>
          <Table
            head={[t("colModel"), t("colCalls"), t("colTokens"), t("colCost")]}
          >
            {brandSpend.byModel.map((m) => (
              <Row key={m.model} label={m.model} mono summary={m} />
            ))}
          </Table>
        </Section>
      )}

      {projectSpend && (
        <div className="flex flex-col gap-6 rounded-lg border border-accent bg-bg p-6">
          <header className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="text-lg font-semibold tracking-tight text-fg">
                {projectSpend.projectName}
              </h2>
              {/* SIGNAL 3. An admin can reach a project by id without its brand
                  being the one selected in the chips above, in which case the
                  banner at the top of the page is about a DIFFERENT brand and
                  would read as reassurance. Name the project's real owner here
                  so the panel can never be misattributed.

                  And say WHICH KIND of crossing it is. Landing in another brand
                  the admin belongs to is ordinary navigation; landing in one
                  they do not belong to is the boundary crossing that was
                  audited, and the person who made it is owed both halves of
                  that fact — whose data, and that it was recorded. The
                  member/non-member split is read off the same flag the audit
                  decision was made on, so this line cannot say "yours" about a
                  read that wrote a row. */}
              {projectSpend.brandId !== selectedBrand.id && (
                <p className="mt-1 text-sm text-fg-warning">
                  {projectSpend.viewerIsMember
                    ? t("projectOtherBrand", { brand: projectSpend.brandName })
                    : t("projectOtherBrandNonMember", {
                        brand: projectSpend.brandName,
                      })}
                </p>
              )}
            </div>
            <Link
              href={`/spend?brand=${selectedBrand.id}`}
              className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
            >
              {t("closeProject")}
            </Link>
          </header>

          <TotalCard
            label={t("projectTotal")}
            summary={projectSpend.total}
          />

          {projectSpend.byStep.length === 0 ? (
            <p className="text-sm text-fg-muted">{t("emptyProject")}</p>
          ) : (
            <Section title={t("byStep")}>
              <Table
                head={[
                  t("colStep"),
                  t("colCalls"),
                  t("colTokens"),
                  t("colCost"),
                ]}
              >
                {await Promise.all(
                  projectSpend.byStep.map(async (s) => {
                    const tStep = await getTranslations("stepLabels");
                    return (
                      <Row key={s.step} label={tStep(s.step)} summary={s} />
                    );
                  }),
                )}
              </Table>
            </Section>
          )}

          {/* Issue #42's "platform başına" ask, at the level you would actually
              drill in for it. getProjectSpend was already paying for this query
              and the result was being thrown away — a scan for nothing, and the
              per-model split missing from the one view where it is the point.
              Only secondary_data routes elsewhere today (#47), so a one-model
              project would render a table that just restates the total; the
              length check keeps it out of the way until it says something. */}
          {projectSpend.byModel.length > 1 && (
            <Section title={t("byModel")} note={t("byModelNote")}>
              <Table
                head={[
                  t("colModel"),
                  t("colCalls"),
                  t("colTokens"),
                  t("colCost"),
                ]}
              >
                {projectSpend.byModel.map((m) => (
                  <Row key={m.model} label={m.model} mono summary={m} />
                ))}
              </Table>
            </Section>
          )}
        </div>
      )}
    </Shell>
  );
}

/* ── presentation ──────────────────────────────────────────────────────── */

async function Shell({
  title,
  subtitle,
  back,
  children,
}: {
  title: string;
  subtitle?: string;
  back: string;
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-bg-subtle">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-6 py-10 sm:px-8">
        <header className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-fg">
              {title}
            </h1>
            {subtitle && (
              <p className="mt-1 text-sm text-fg-muted">{subtitle}</p>
            )}
          </div>
          <Link
            href="/projects"
            className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
          >
            {back}
          </Link>
        </header>
        {children}
      </div>
    </div>
  );
}

/**
 * The headline figure. When the summary is incomplete the amount is prefixed
 * with "≥" and the shortfall is spelled out underneath — the number is never
 * shown bare in a way that would read as a settled total.
 */
async function TotalCard({
  label,
  summary,
}: {
  label: string;
  summary: SpendSummary;
}) {
  const t = await getTranslations("spend");
  const locale = await getLocale();

  return (
    <div className="flex flex-col gap-2 rounded-lg border border-border bg-bg p-6">
      <div className="text-xs font-medium tracking-wide text-fg-subtle uppercase">
        {label}
      </div>
      <div className="flex items-baseline gap-2">
        {!summary.complete && (
          <span
            className="text-2xl font-semibold text-fg-muted"
            title={t("lowerBoundHint")}
            aria-label={t("atLeast")}
          >
            ≥
          </span>
        )}
        <span className="text-3xl font-semibold tabular-nums text-fg">
          {formatUsd(summary.costUsd, locale)}
        </span>
      </div>
      <div className="text-sm text-fg-muted">
        {t("callsAndTokens", {
          calls: formatNumber(summary.callCount, locale),
          tokens: formatNumber(
            summary.promptTokens + summary.completionTokens,
            locale,
          ),
        })}
      </div>
      {summary.complete ? (
        summary.callCount > 0 && (
          <p className="text-sm text-fg-subtle">{t("completeNote")}</p>
        )
      ) : (
        // The whole point of the feature: say exactly how much is unknown.
        <p className="rounded-lg border border-border-warning bg-bg-warning p-3 text-sm text-fg-warning">
          {t("partialNote", {
            calls: formatNumber(summary.unpricedCallCount, locale),
            total: formatNumber(summary.callCount, locale),
            tokens: formatNumber(
              summary.unpricedPromptTokens + summary.unpricedCompletionTokens,
              locale,
            ),
          })}
        </p>
      )}
    </div>
  );
}

async function Section({
  title,
  note,
  children,
}: {
  title: string;
  note?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="flex flex-col gap-2">
      <h2 className="text-sm font-semibold tracking-tight text-fg">{title}</h2>
      {note && <p className="text-xs text-fg-subtle">{note}</p>}
      {children}
    </section>
  );
}

function Table({
  head,
  children,
}: {
  head: string[];
  children: React.ReactNode;
}) {
  return (
    <div className="overflow-x-auto rounded-lg border border-border bg-bg">
      <table className="w-full min-w-[40rem] text-left text-sm">
        <thead className="border-b border-border text-xs tracking-wide text-fg-subtle uppercase">
          <tr>
            {head.map((h, i) => (
              <th
                key={h}
                className={
                  "px-4 py-3 font-medium" + (i === 0 ? "" : " text-right")
                }
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

/**
 * One breakdown line. Carries the same "≥" treatment as the headline: a row
 * must not look settled while the total it rolls into is hedged.
 */
async function Row({
  label,
  href,
  mono,
  summary,
}: {
  label: string;
  href?: string;
  mono?: boolean;
  summary: SpendSummary;
}) {
  const t = await getTranslations("spend");
  const locale = await getLocale();

  return (
    <tr className="border-b border-border last:border-0">
      <td className={"px-4 py-3 text-fg" + (mono ? " font-mono text-xs" : "")}>
        {href ? (
          <Link href={href} className="hover:text-accent hover:underline">
            {label}
          </Link>
        ) : (
          label
        )}
      </td>
      <td className="px-4 py-3 text-right tabular-nums text-fg-muted">
        {formatNumber(summary.callCount, locale)}
      </td>
      <td className="px-4 py-3 text-right tabular-nums text-fg-muted">
        {formatNumber(
          summary.promptTokens + summary.completionTokens,
          locale,
        )}
      </td>
      <td className="px-4 py-3 text-right tabular-nums text-fg">
        {!summary.complete && (
          <span className="text-fg-muted" title={t("lowerBoundHint")}>
            ≥{" "}
          </span>
        )}
        {formatUsd(summary.costUsd, locale)}
        {!summary.complete && (
          <div className="text-xs font-normal text-fg-subtle">
            {/* Raw number, not preformatted: the catalog entry is an ICU
                plural and needs to select on it. */}
            {t("unpricedShort", { calls: summary.unpricedCallCount })}
          </div>
        )}
      </td>
    </tr>
  );
}

/**
 * A brand chip. `nonMember` marks a brand the viewer does not belong to —
 * only ever true for the super admin (T50).
 *
 * The marker is a dashed border AND a short WORD, not a colour alone: an admin
 * with a colour-vision deficiency, or reading a screenshot, must still be able
 * to tell whose data they are about to open. It was a "°" glyph, which at this
 * size carries meaning only to a reader who already knows the convention and
 * otherwise reads as a rendering fault — so it says "üye değil" / "not a
 * member" instead. The person this page is for runs an agency; a marker she has
 * to decode is not a marker.
 *
 * The longer label still goes in `title` and in visually-hidden text so a
 * screen reader announces "brand X — not a member" rather than just the name.
 */
function Chip({
  href,
  active,
  nonMember,
  nonMemberLabel,
  nonMemberMark,
  children,
}: {
  href: string;
  active: boolean;
  nonMember?: boolean;
  nonMemberLabel?: string;
  nonMemberMark?: string;
  children: React.ReactNode;
}) {
  const base = "rounded-full px-3 py-1 text-xs transition-colors";
  const tone = active
    ? "bg-accent font-medium text-white"
    : "bg-bg text-fg-muted hover:bg-bg-muted hover:text-fg";
  const edge = nonMember
    ? active
      ? " border border-dashed border-white/70"
      : " border border-dashed border-border-warning"
    : active
      ? " border border-accent"
      : " border border-border";

  return (
    <Link
      href={href}
      aria-current={active ? "page" : undefined}
      title={nonMember ? nonMemberLabel : undefined}
      className={`${base} ${tone}${edge}`}
    >
      {children}
      {nonMember && (
        <>
          {/* The separator is its own node so the mark stays a clean piece of
              text — readable, and assertable by a test that does not have to
              know about punctuation. */}
          <span aria-hidden="true" className="mx-1 opacity-50">
            ·
          </span>
          <span aria-hidden="true" className="font-medium opacity-80">
            {nonMemberMark}
          </span>
          <span className="sr-only"> — {nonMemberLabel}</span>
        </>
      )}
    </Link>
  );
}

/**
 * Costs here run from ~$0.01 to a few dollars, so 2 decimals would round a
 * real per-step cost to "$0.02" and 6 would be noise.
 *
 * ALWAYS exactly 4 decimals, deliberately. In tr-TR the decimal separator is a
 * comma, so a variable-width "$1,049" is a factor-of-1000 misread away from
 * "$1,049.00" to anyone reading it as a thousands group. A group is always
 * exactly 3 digits, so pinning the fraction to 4 makes the separator
 * unambiguous in either locale — which matters more here than tidiness,
 * because this number gets used to decide a spending cap.
 */
function formatUsd(value: number, locale: string): string {
  const fmt = (v: number) =>
    new Intl.NumberFormat(locale, {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 4,
      maximumFractionDigits: 4,
    }).format(v);

  // A real but tiny cost must not round down to a figure that reads as free.
  if (value > 0 && value < 0.00005) return `< ${fmt(0.0001)}`;
  return fmt(value);
}

function formatNumber(value: number, locale: string): string {
  return new Intl.NumberFormat(locale).format(value);
}
