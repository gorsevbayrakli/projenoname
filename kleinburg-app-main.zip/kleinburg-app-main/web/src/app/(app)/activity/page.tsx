import { getTranslations } from "next-intl/server";
import Link from "next/link";
import { redirect } from "next/navigation";

import { isSuperAdmin } from "@/core/auth/roles";
import {
  DEFAULT_AUDIT_PAGE_SIZE,
  listAuditEvents,
} from "@/core/audit/service";
import { AUDIT_ACTIONS } from "@/core/db/schema";
import type { AuditAction } from "@/core/db/schema";
import { getCurrentUser } from "@/lib/auth-server";

/**
 * /activity — the audit trail viewer (T41).
 *
 * ── ONE ROUTE, TWO AUDIENCES ─────────────────────────────────────────────
 * There is deliberately no separate /admin/activity. The scope is decided by
 * `listAuditEvents` from the caller's role — a super admin gets everything, an
 * ordinary user gets their own rows and nothing else — so a single page serves
 * both and there is exactly one query to review. Two pages would mean two
 * queries and a second place for the scope to be got wrong.
 *
 * ── THE UI IS NOT THE AUTHORIZATION ──────────────────────────────────────
 * Nothing on this page filters anything for security. The rows that arrive
 * here have already been scoped by the query, server-side. If this file were
 * replaced with one that rendered every field of every row it received, an
 * ordinary user would still see only their own — which is the property
 * `core/audit/service.test.ts` asserts, and the reason it asserts it there
 * rather than here.
 *
 * There is no `admin` check on this route AT ALL, on purpose: every
 * authenticated user is allowed to see their own history. It is the query,
 * not the door, that decides how much history that is.
 */
export default async function ActivityPage({
  searchParams,
}: {
  searchParams: Promise<{ action?: string; page?: string }>;
}) {
  const t = await getTranslations("activity");
  const tAction = await getTranslations("auditActions");
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const { action: actionParam, page: pageParam } = await searchParams;

  // An unknown `action` is dropped rather than passed through: the service
  // would reject it anyway, and a silently-empty list would read as "you have
  // done nothing" instead of "that filter is not a thing".
  const action = (AUDIT_ACTIONS as readonly string[]).includes(
    actionParam ?? "",
  )
    ? (actionParam as AuditAction)
    : undefined;

  const page = Math.max(1, Number.parseInt(pageParam ?? "1", 10) || 1);
  const offset = (page - 1) * DEFAULT_AUDIT_PAGE_SIZE;

  const { events, hasMore } = await listAuditEvents(user, {
    limit: DEFAULT_AUDIT_PAGE_SIZE,
    offset,
    action,
  });

  const admin = isSuperAdmin(user);

  function href(next: { action?: string; page?: number }) {
    const params = new URLSearchParams();
    const a = next.action ?? action;
    if (a) params.set("action", a);
    if (next.page && next.page > 1) params.set("page", String(next.page));
    const qs = params.toString();
    return qs ? `/activity?${qs}` : "/activity";
  }

  return (
    <div className="min-h-screen bg-bg-subtle">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-6 py-10 sm:px-8">
        <header className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-fg">
              {t("title")}
            </h1>
            {/* Says WHOSE records these are. A user who assumes they are
                looking at everything would draw wrong conclusions from an
                empty page. */}
            <p className="mt-1 text-sm text-fg-muted">
              {admin ? t("scopeAdmin") : t("scopeSelf")}
            </p>
          </div>
          <Link
            href="/projects"
            className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
          >
            {t("backToProjects")}
          </Link>
        </header>

        <p className="rounded-lg border border-border bg-bg p-4 text-sm text-fg-muted">
          {t("retentionNote")}
        </p>

        <nav className="flex flex-wrap gap-2" aria-label={t("filterLabel")}>
          <FilterChip href={href({ action: "", page: 1 })} active={!action}>
            {t("filterAll")}
          </FilterChip>
          {AUDIT_ACTIONS.map((a) => (
            <FilterChip
              key={a}
              href={href({ action: a, page: 1 })}
              active={action === a}
            >
              {tAction(a)}
            </FilterChip>
          ))}
        </nav>

        {events.length === 0 ? (
          <p className="rounded-lg border border-border bg-bg p-8 text-center text-sm text-fg-muted">
            {t("empty")}
          </p>
        ) : (
          <div className="overflow-x-auto rounded-lg border border-border bg-bg">
            <table className="w-full min-w-[56rem] text-left text-sm">
              <thead className="border-b border-border text-xs uppercase tracking-wide text-fg-subtle">
                <tr>
                  <th className="px-4 py-3 font-medium">{t("colWhen")}</th>
                  <th className="px-4 py-3 font-medium">{t("colAction")}</th>
                  {/* An ordinary user's rows are all their own, so an "actor"
                      column would repeat their name on every line. */}
                  {admin && (
                    <th className="px-4 py-3 font-medium">{t("colActor")}</th>
                  )}
                  <th className="px-4 py-3 font-medium">{t("colTarget")}</th>
                  <th className="px-4 py-3 font-medium">{t("colContext")}</th>
                </tr>
              </thead>
              <tbody>
                {events.map((e) => (
                  <tr key={e.id} className="border-b border-border last:border-0">
                    <td className="whitespace-nowrap px-4 py-3 text-fg-muted tabular-nums">
                      {/* Absolute and unambiguous. A relative stamp ("3 gün
                          önce") is friendly on a project card and useless in an
                          audit trail, where the exact instant is the point. */}
                      {e.occurredAt.toISOString().replace("T", " ").slice(0, 19)}
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-fg">
                      {tAction(e.action)}
                    </td>
                    {admin && (
                      <td className="px-4 py-3 text-fg">{e.actorUsername}</td>
                    )}
                    <td className="px-4 py-3 text-fg-muted">
                      {e.targetUsername ?? "—"}
                    </td>
                    <td className="px-4 py-3 text-fg-muted">
                      <ContextCell
                        brandName={e.brandName}
                        projectName={e.projectName}
                        step={e.step}
                        metadata={e.metadata as Record<string, unknown>}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {(page > 1 || hasMore) && (
          <div className="flex items-center justify-between">
            {page > 1 ? (
              <Link
                href={href({ page: page - 1 })}
                className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
              >
                {t("previous")}
              </Link>
            ) : (
              <span />
            )}
            {hasMore && (
              <Link
                href={href({ page: page + 1 })}
                className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
              >
                {t("next")}
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function FilterChip({
  href,
  active,
  children,
}: {
  href: string;
  active: boolean;
  children: React.ReactNode;
}) {
  return (
    <Link
      href={href}
      aria-current={active ? "page" : undefined}
      className={
        active
          ? "rounded-full border border-accent bg-accent px-3 py-1 text-xs font-medium text-white"
          : "rounded-full border border-border bg-bg px-3 py-1 text-xs text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
      }
    >
      {children}
    </Link>
  );
}

/**
 * The brand / project / step / metadata column.
 *
 * Metadata is rendered as `key: value` pairs and nothing more. It is already
 * scalars-only and sanitised by `sanitizeAuditMetadata` before storage, so
 * there is no shape here that needs unwrapping — and deliberately no attempt
 * to prettify it, because an audit reader wants what was recorded rather than
 * an interpretation of it.
 */
function ContextCell({
  brandName,
  projectName,
  step,
  metadata,
}: {
  brandName: string | null;
  projectName: string | null;
  step: string | null;
  metadata: Record<string, unknown>;
}) {
  const parts: string[] = [];
  if (brandName) parts.push(brandName);
  if (projectName) parts.push(projectName);
  if (step) parts.push(step);

  const meta = Object.entries(metadata ?? {})
    .map(([k, v]) => `${k}: ${String(v)}`)
    .join(", ");

  if (parts.length === 0 && !meta) return <>—</>;

  return (
    <span className="break-words">
      {parts.join(" / ")}
      {parts.length > 0 && meta ? " · " : ""}
      {meta && <span className="text-fg-subtle">{meta}</span>}
    </span>
  );
}
