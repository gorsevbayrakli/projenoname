import Link from "next/link";
import { getTranslations } from "next-intl/server";
import { notFound, redirect } from "next/navigation";

import type { Brand } from "@/core/db/schema";
import {
  formatUsd,
  getBrandCapStatus,
  refusesGeneration,
  warnsAboutSpend,
} from "@/core/llm/cap";
import { requireProjectAccess } from "@/core/tenancy/access";
import { AccessError, NotFoundError } from "@/core/tenancy/errors";
import { getCurrentUser } from "@/lib/auth-server";
import { getWizardStatus } from "@/lib/wizard-status";
import { WizardRail } from "./wizard-rail";

/**
 * Wizard shell for a single project: the two-pane layout wrapping every step
 * page. This layout is the isolation gate for the whole /projects/[id] subtree
 * (requireProjectAccess). The left rail shows the 8 steps with completed/active
 * state and forward-lock; `children` is the active step page.
 */
export default async function ProjectWizardLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  // Next 15: params is a Promise.
  params: Promise<{ id: string }>;
}) {
  const user = await getCurrentUser();
  // The (app) layout already guards auth; this narrows the type.
  if (!user) redirect("/login");

  const { id } = await params;
  const tCap = await getTranslations("spend");

  let project;
  let brand;
  try {
    ({ project, brand } = await requireProjectAccess(user.id, id));
  } catch (e) {
    // A user reaching another brand's project (or a stale link) is bounced to
    // their own project list rather than shown an error.
    if (e instanceof AccessError) redirect("/projects");
    if (e instanceof NotFoundError) notFound();
    throw e;
  }

  const { completed, current } = await getWizardStatus(id);

  // THE CAP, WHERE THE WORK HAPPENS (#51 review, finding 9).
  //
  // The cap refuses at JOB granularity, which is what #51 item 6 asked for:
  // nothing in flight is ever interrupted. But a project is eight steps, and
  // job-granularity non-interruption at step 6 still leaves a half-finished
  // project — the same loss the non-interruption rule exists to prevent, one
  // level up. A user could start an eight-step build at 95% of the cap and be
  // refused partway with no warning anywhere on the way in.
  //
  // So the warning is drawn HERE, in the layout that wraps every step, rather
  // than in each step component: one place, no step able to forget it, and it
  // is on screen before the first generate button is pressed. It is a warning
  // and not a lock, because deciding whether 40% of a cap is enough for the
  // rest of a build is the operator's judgement and not this layout's.
  //
  // `brand` is already loaded by the access check above, so this costs one
  // query for a capped brand and nothing at all for an uncapped one — see
  // `getBrandCapStatus`, which returns without touching the database when
  // `monthlyCapUsd` is null.
  const capStatus = await readWizardCapStatus(brand);

  return (
    // Column on phones (compact step bar on top), two-pane rail + content from
    // `md` up. See wizard-rail.tsx for why the rail collapses (T22).
    <div className="flex min-h-screen flex-col bg-bg md:flex-row">
      <WizardRail
        projectId={id}
        projectName={project.name}
        brandName={brand.name}
        completed={[...completed]}
        current={current}
      />
      <main className="flex-1 overflow-x-hidden bg-bg-subtle">
        {capStatus && (
          <div className="px-4 pt-4 md:px-8 md:pt-8">
            <div
              role="note"
              className="flex flex-col gap-1 rounded-lg border border-border-warning bg-bg-warning p-4 text-sm text-fg-warning"
            >
              <p className="font-semibold">
                {capStatus.refuses
                  ? tCap("wizardCapBlocked", { brand: capStatus.brandName })
                  : tCap("wizardCapWarning", { brand: capStatus.brandName })}
              </p>
              <p>{tCap("wizardCapDetail", capStatus.values)}</p>
              <p>
                <Link className="underline" href="/spend">
                  {tCap("wizardCapLink")}
                </Link>
              </p>
            </div>
          </div>
        )}
        {children}
      </main>
    </div>
  );
}

/**
 * What the wizard needs to know about the brand's cap, or null when there is
 * nothing to say — no cap, or comfortably under the warning threshold.
 *
 * It returns a flat bag rather than the `BrandCapStatus` so the JSX above
 * stays a template. `refusesGeneration` is asked rather than re-derived,
 * because there must be exactly one definition of which states stop work.
 *
 * A cap that cannot be read must not take the wizard down: `parseCap` throws on
 * a corrupt row and this is a layout wrapping every step of every project, so
 * the same reasoning as `readBrandCapStatusUnscoped` applies — the brand cannot
 * generate either way, and it should not also lose the ability to look at what
 * it has. The refusal at `enqueueGeneration` is the fail-closed half.
 */
async function readWizardCapStatus(brand: Brand) {
  let status;
  try {
    status = await getBrandCapStatus(brand, new Date());
  } catch {
    return null;
  }
  if (!warnsAboutSpend(status.state)) return null;

  return {
    brandName: status.brandName,
    refuses: refusesGeneration(status.state),
    values: {
      spent: formatUsd(status.chargeableUsd),
      cap: formatUsd(status.capUsd ?? 0),
      percent: Math.round((status.ratio ?? 0) * 100),
    },
  };
}
