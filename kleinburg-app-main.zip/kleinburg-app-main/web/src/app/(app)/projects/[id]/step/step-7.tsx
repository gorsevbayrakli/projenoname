import { redirect } from "next/navigation";

import { getStepContent } from "@/core/pipeline/inputs";
import type { PillarItem } from "@/components/wizard/selectable-pillar-list";
import { requireProjectAccess } from "@/core/tenancy/access";
import { getCurrentUser } from "@/lib/auth-server";
import { extractSelectedIndices } from "@/lib/selected-indices";
import { SmPillarsStep } from "./sm-pillars-step";

/**
 * Wizard step 7 — SM Pillars (sm_pillars).
 *
 * Server wrapper: repeats requireProjectAccess (defense-in-depth per the T13
 * note) and loads the sm_pillars step_contents row, extracting its pillars
 * (null when no content yet).
 *
 * THE STORED SELECTION IS PASSED AND IT *IS* THE INITIAL SELECTION.
 * The prop was `previousSelectedIndices` until 2026-07-21, when the product
 * owner removed the legacy conscious-re-pick rule: the client used to show
 * this value without applying it, and now it seeds the checkboxes from it, so
 * a returning user opens step 7 on the selection they already made. The
 * reasoning lives in sm-pillars-step.tsx's docblock — read it before
 * "restoring" the old behaviour.
 *
 * Read through the shared `extractSelectedIndices`, the same reader
 * wizard-status's `sm_pillars` predicate is built on, so what the rail counts
 * as complete and what this page shows can never disagree. Clamped to the
 * current pillar count: a stale index would otherwise mark a card that no
 * longer exists.
 */
export async function Step7({ projectId }: { projectId: string }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  try {
    await requireProjectAccess(user.id, projectId);
  } catch {
    redirect("/projects");
  }

  const row = await getStepContent(projectId, "sm_pillars");
  const pillars = row ? extractPillars(row.content) : null;
  const initialSelectedIndices = extractSelectedIndices(
    row?.selections,
    pillars?.length ?? 0,
  );

  return (
    <SmPillarsStep
      projectId={projectId}
      initialPillars={pillars}
      initialSelectedIndices={initialSelectedIndices}
    />
  );
}

/** content.pillars as PillarItem[], defaulting to [] on a malformed row. */
function extractPillars(content: unknown): PillarItem[] {
  if (
    content &&
    typeof content === "object" &&
    "pillars" in content &&
    Array.isArray((content as { pillars: unknown }).pillars)
  ) {
    return (content as { pillars: unknown[] }).pillars.map((p) => ({
      category: field(p, "category"),
      title: field(p, "title"),
      topicBlend: field(p, "topicBlend"),
      creativeSpark: field(p, "creativeSpark"),
      hook: field(p, "hook"),
      contentBrief: field(p, "contentBrief"),
    }));
  }
  return [];
}

/** A string field off an unknown object, "" when absent/nullish. */
function field(value: unknown, key: string): string {
  if (value && typeof value === "object" && key in value) {
    const v = (value as Record<string, unknown>)[key];
    return v === null || v === undefined ? "" : String(v);
  }
  return "";
}
