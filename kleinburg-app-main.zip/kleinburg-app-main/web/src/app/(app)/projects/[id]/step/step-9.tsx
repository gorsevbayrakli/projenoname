import { redirect } from "next/navigation";

import { DEFAULT_PLATFORM } from "@/core/platforms";
import { parseCalendarTable } from "@/core/pipeline/calendar";
import type { CalendarRow } from "@/core/pipeline/schemas";

import { getBrandName, getProject, getStepContent } from "@/core/pipeline/inputs";
import { requireProjectAccess } from "@/core/tenancy/access";
import { getCurrentUser } from "@/lib/auth-server";
import { ContentCalendarStep } from "./content-calendar-step";

/**
 * Wizard step 9 — İçerik Takvimi (content_calendar), the last content step.
 *
 * Server wrapper: repeats requireProjectAccess (defense-in-depth per the T13
 * note) and loads the content_calendar row's `calendar` string, null when there
 * is no row yet so the client can tell "never generated" from "generated
 * empty".
 *
 * It also loads the project and its brand name — not for the generation (the
 * pipeline builds its own inputs) but for the DOWNLOAD FILENAME, which is
 * `marka-proje-dil.csv|xlsx`.
 */
export async function Step9({ projectId }: { projectId: string }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  try {
    await requireProjectAccess(user.id, projectId);
  } catch {
    redirect("/projects");
  }

  const [row, project, brandName] = await Promise.all([
    getStepContent(projectId, "content_calendar"),
    getProject(projectId),
    getBrandName(projectId),
  ]);

  return (
    <ContentCalendarStep
      projectId={projectId}
      initialCalendars={row ? calendarEntries(row.content) : []}
      shortfalls={row ? calendarShortfalls(row.content) : []}
      brandName={brandName}
      projectName={project.name}
      language={project.language}
    />
  );
}

/**
 * The shortfall list stored alongside the calendar, or [] when there is none.
 *
 * Read TOLERANTLY, like calendarEntries below and for the same reason: every
 * calendar written before the step became deterministic has no such field, and
 * a hand-edited row could carry anything. An entry that is not a complete
 * {platform, requested, scheduled} triple is dropped rather than rendered as a
 * half-formed warning.
 */
function calendarShortfalls(
  content: unknown,
): Array<{ platform: string; requested: number; scheduled: number }> {
  if (!content || typeof content !== "object") return [];
  const list = (content as { shortfalls?: unknown }).shortfalls;
  if (!Array.isArray(list)) return [];
  return list.flatMap((entry) => {
    if (!entry || typeof entry !== "object") return [];
    const { platform, requested, scheduled } = entry as Record<string, unknown>;
    if (
      typeof platform !== "string" ||
      typeof requested !== "number" ||
      typeof scheduled !== "number"
    ) {
      return [];
    }
    return [{ platform, requested, scheduled }];
  });
}

/**
 * The stored calendars as [{ platform, rows }], safe on junk content.
 *
 * Converts both older shapes so an existing project still renders: a
 * per-platform markdown table (T29) and a single merged table (pre-T29) are
 * parsed into rows, with the caption landing in the caption column and the
 * separate hook/CTA/hashtag columns left empty — that is genuinely all the
 * information those rows ever held.
 */
function calendarEntries(
  content: unknown,
): Array<{ platform: string; rows: CalendarRow[] }> {
  if (!content || typeof content !== "object") return [];

  const list = (content as { calendars?: unknown }).calendars;
  if (Array.isArray(list)) {
    return list.flatMap((entry) => {
      if (!entry || typeof entry !== "object") return [];
      const { platform, rows, calendar } = entry as {
        platform?: unknown;
        rows?: unknown;
        calendar?: unknown;
      };
      if (typeof platform !== "string") return [];
      if (Array.isArray(rows)) {
        return [{ platform, rows: rows as CalendarRow[] }];
      }
      if (typeof calendar === "string" && calendar.trim() !== "") {
        return [{ platform, rows: rowsFromTable(calendar) }];
      }
      return [];
    });
  }

  const legacy = (content as { calendar?: unknown }).calendar;
  return typeof legacy === "string" && legacy.trim() !== ""
    ? [{ platform: DEFAULT_PLATFORM, rows: rowsFromTable(legacy) }]
    : [];
}

/** A pre-T33 markdown table as rows: Day / Format / Pillar / Post. */
function rowsFromTable(markdown: string): CalendarRow[] {
  const { rows } = parseCalendarTable(markdown);
  return rows.map((cells) => ({
    day: cells[0] ?? "",
    format: cells[1] ?? "",
    pillar: cells[2] ?? "",
    hook: "",
    caption: cells[3] ?? "",
    cta: "",
    hashtags: [],
  }));
}
