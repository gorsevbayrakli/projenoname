import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";

import { getDb } from "@/core/db/client";
import { projects } from "@/core/db/schema";
import { sortPlatforms } from "@/core/platforms";
import { requireProjectAccess } from "@/core/tenancy/access";
import { getCurrentUser } from "@/lib/auth-server";
import { PlatformsStep } from "./platforms-step";

/**
 * Wizard step 6 — Platform Seçimi (T29).
 *
 * Sits before the pillars step on purpose: the pillars are generated FOR the
 * chosen platforms (a TikTok pillar and a LinkedIn pillar are different
 * things), so the choice has to exist before step 7 runs.
 *
 * The selection lives on projects.platforms, not in step_contents — it is a
 * property of the project rather than the output of a generation, and steps 7,
 * 8 and 9 all read it.
 */
export async function Step6({ projectId }: { projectId: string }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  try {
    await requireProjectAccess(user.id, projectId);
  } catch {
    redirect("/projects");
  }

  const db = getDb();
  const [row] = await db
    .select({ platforms: projects.platforms, postCounts: projects.postCounts })
    .from(projects)
    .where(eq(projects.id, projectId))
    .limit(1);

  // Normalise on read as well as on write: a platform retired from the
  // registry must not render as a checkbox with no label.
  const selected = sortPlatforms(row?.platforms ?? []);

  return (
    <PlatformsStep
      projectId={projectId}
      initialSelected={selected}
      initialCounts={(row?.postCounts ?? {}) as Record<string, number>}
    />
  );
}
