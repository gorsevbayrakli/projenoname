// @vitest-environment jsdom
//
// Component test for wizard step 4 (Ek Girdi / user_input), mirroring the T15
// brand-context-step.test.tsx pattern: per-file jsdom env, next/navigation
// mocked, fetch mocked, React.createElement (aliased `h`) so no JSX transform is
// needed for the test file itself.
//
// Locks the three behaviours this step depends on: debounced auto-save with the
// `{ content: { text } }` shape gatherVars reads for {User_input}, prop-sync
// re-seeding on a server-side change, and Devam saving BEFORE navigating (the
// row write is what completes this optional step).

import { cleanup, fireEvent, screen } from "@testing-library/react";

// T25: rendered through renderWithIntl, which wraps the component in
// NextIntlClientProvider with the REAL Turkish catalog — so every assertion
// below still checks the exact Turkish a user reads.
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const refreshMock = vi.fn();
const pushMock = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    refresh: refreshMock,
    push: pushMock,
    replace: vi.fn(),
    back: vi.fn(),
    forward: vi.fn(),
    prefetch: vi.fn(),
  }),
}));

import { UserInputStep } from "./user-input-step";

function step(initialText: string | null) {
  return h(UserInputStep, { projectId: "p1", initialText });
}

function okFetch() {
  return vi.fn(() =>
    Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve({}) }),
  );
}

beforeEach(() => {
  refreshMock.mockClear();
  pushMock.mockClear();
  vi.stubGlobal("fetch", okFetch());
});

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.useRealTimers();
});

describe("UserInputStep", () => {
  // T27 + T28. This step's copy has to agree with what the prompt actually
  // does, and that changed: sparks are now always about the brand's audience
  // and this field only sets the angle. Copy that still said "what you write
  // is the subject" would send the user back into the failure it replaced.
  it("says the sparks are about the audience, not about what you type", () => {
    render(step(null));
    expect(
      screen.getByText(/markanın hedef kitlesi hakkında üretilir/),
    ).toBeDefined();
  });

  it("asks for a direction rather than a subject, and shows an example", () => {
    render(step(null));
    expect(screen.getByText(/yön yazılır, konu değil/)).toBeDefined();
    expect(
      screen.getByText(/Farkındalık ve değerlendirme aşaması/),
    ).toBeDefined();
  });

  it("does not save on mount when there is no row yet", async () => {
    vi.useFakeTimers();
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);

    render(step(null));
    await vi.advanceTimersByTimeAsync(900);

    // Merely opening the step must not write a row (which would silently mark
    // step 4 complete without the user acting).
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("debounced-saves typing via PUT with { content: { text } }", async () => {
    vi.useFakeTimers();
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);

    render(step(null));

    const textarea = screen.getByLabelText("Ek girdi") as HTMLTextAreaElement;
    fireEvent.change(textarea, { target: { value: "yaz kampanyası" } });

    // Before the debounce elapses, no save.
    expect(fetchMock).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(900);

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ];
    expect(url).toBe("/api/projects/p1/steps/user_input/content");
    expect(init.method).toBe("PUT");
    expect(JSON.parse(String(init.body))).toEqual({
      content: { text: "yaz kampanyası" },
    });
    expect(screen.getByText("Kaydedildi")).toBeTruthy();
  });

  it("re-seeds the textarea when the server prop changes", () => {
    const { rerender } = render(step(null));

    const textarea = screen.getByLabelText("Ek girdi") as HTMLTextAreaElement;
    expect(textarea.value).toBe("");

    // Simulate a server-side change landing via router.refresh().
    rerender(step("sunucudan gelen metin"));

    expect(
      (screen.getByLabelText("Ek girdi") as HTMLTextAreaElement).value,
    ).toBe("sunucudan gelen metin");
  });

  it("Devam saves the current text (even empty) BEFORE navigating to step 5", async () => {
    const calls: string[] = [];
    const fetchMock = vi.fn((_url: string, init: RequestInit) => {
      calls.push("fetch");
      void init;
      return Promise.resolve({
        ok: true,
        status: 200,
        json: () => Promise.resolve({}),
      });
    });
    vi.stubGlobal("fetch", fetchMock);
    pushMock.mockImplementation(() => {
      calls.push("push");
    });

    render(step(null));

    // Empty textarea, untouched: Devam is still enabled and must write the row.
    fireEvent.click(screen.getByRole("button", { name: /Devam/ }));

    // Let the awaited save + navigation settle.
    await vi.waitFor(() => expect(pushMock).toHaveBeenCalled());

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ];
    expect(url).toBe("/api/projects/p1/steps/user_input/content");
    expect(init.method).toBe("PUT");
    expect(JSON.parse(String(init.body))).toEqual({ content: { text: "" } });
    expect(pushMock).toHaveBeenCalledWith("/projects/p1/step/5");
    // The PUT must be fully awaited before navigating, or step 5 can still be
    // locked when it renders.
    expect(calls).toEqual(["fetch", "push"]);
  });

  it("Devam saves the typed text and does not navigate when the save fails", async () => {
    const fetchMock = vi.fn(() =>
      Promise.resolve({
        ok: false,
        status: 500,
        json: () => Promise.resolve({}),
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    render(step(null));
    fireEvent.change(screen.getByLabelText("Ek girdi"), {
      target: { value: "kısa not" },
    });
    fireEvent.click(screen.getByRole("button", { name: /Devam/ }));

    await vi.waitFor(() => expect(screen.getByText("Kaydedilemedi")).toBeTruthy());
    expect(pushMock).not.toHaveBeenCalled();
  });
});
