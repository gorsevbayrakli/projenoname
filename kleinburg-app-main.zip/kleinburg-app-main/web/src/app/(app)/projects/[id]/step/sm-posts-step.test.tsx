// @vitest-environment jsdom
//
// Component test for wizard step 7 (SM Posts / sm_posts), mirroring the
// T15/T17/T18/T19 step-test pattern: per-file jsdom env, next/navigation mocked,
// fetch mocked, React.createElement (aliased `h`).
//
// The two headline cases are the T20 rules: Facebook is OPT-IN, and only ONE
// platform may generate at a time (the queue supersedes a project's active job,
// so a second enqueue would cancel the first). Both are locked below.

import { cleanup, fireEvent, screen } from "@testing-library/react";

// T25: rendered through renderWithIntl, which wraps the component in
// NextIntlClientProvider with the REAL Turkish catalog — so every assertion
// below still checks the exact Turkish a user reads.
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const refreshMock = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    refresh: refreshMock,
    push: vi.fn(),
    replace: vi.fn(),
    back: vi.fn(),
    forward: vi.fn(),
    prefetch: vi.fn(),
  }),
}));

// <JobProgress> opens an EventSource; stub it so the tests don't need a stream.
class FakeEventSource {
  close = vi.fn();
  addEventListener = vi.fn();
  removeEventListener = vi.fn();
  onmessage: unknown = null;
  onerror: unknown = null;
}

import type { PostItem } from "@/components/wizard/post-card-list";
import { SmPostsStep } from "./sm-posts-step";
import type { Platform } from "@/core/platforms";

function post(platform: string, theme: string): PostItem {
  return {
    platform,
    theme,
    hook: `${theme}-hook`,
    caption: `${theme}-caption`,
    cta: `${theme}-cta`,
    hashtags: [`#${theme}`],
  };
}

function step(
  opts: { posts?: PostItem[] | null; platforms?: Platform[] } = {},
) {
  return h(SmPostsStep, {
    projectId: "p1",
    initialPosts: opts.posts === undefined ? null : opts.posts,
    // T29: the set comes from step 6 now, so tests state it explicitly.
    platforms: opts.platforms ?? ["instagram", "facebook"],
  });
}

function okFetch(body: unknown = {}) {
  return vi.fn(() =>
    Promise.resolve({
      ok: true,
      status: 200,
      json: () => Promise.resolve(body),
    }),
  );
}

/** A fetch whose generate POST returns 202 { jobId }, and PUTs return 200. */
function generateFetch(jobId = "job-1") {
  return vi.fn((url: string, init?: RequestInit) => {
    void init;
    return Promise.resolve(
      String(url).endsWith("/generate")
        ? { ok: true, status: 202, json: () => Promise.resolve({ jobId }) }
        : { ok: true, status: 200, json: () => Promise.resolve({}) },
    );
  });
}

function putBodies(fetchMock: ReturnType<typeof vi.fn>) {
  return fetchMock.mock.calls
    .filter((c) => (c[1] as { method?: string } | undefined)?.method === "PUT")
    .map((c) => JSON.parse((c[1] as { body: string }).body));
}

beforeEach(() => {
  refreshMock.mockClear();
  vi.stubGlobal("fetch", okFetch());
  vi.stubGlobal("EventSource", FakeEventSource);
});

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.useRealTimers();
});

describe("SmPostsStep — tabs follow the project's platforms (T29)", () => {
  it("shows a tab per chosen platform, and only those", () => {
    render(step({ platforms: ["instagram"], posts: [post("instagram", "i1")] }));

    // The opt-in checkbox this step used to own is gone: step 6 decides.
    const tabs = screen.getAllByRole("tab");
    expect(tabs.map((t) => t.textContent)).toEqual(["Instagram (1)"]);
    expect(screen.queryByLabelText("Facebook platformu")).toBeNull();
    expect(screen.queryByText(/Facebook için üret/)).toBeNull();
  });

  it("shows a generate button for every chosen platform", () => {
    render(step({ platforms: ["instagram", "facebook"] }));

    const tabs = screen.getAllByRole("tab");
    expect(tabs.map((t) => t.textContent)).toEqual([
      "Instagram (1)".replace("1", "0"),
      "Facebook (0)",
    ]);
    expect(screen.getByText("Facebook için üret")).toBeTruthy();
  });

  it("still shows posts from a platform the project no longer includes", () => {
    // Narrowing the project at step 6 must not look like data loss: the posts
    // are still in the database, so they keep a tab.
    render(
      step({
        platforms: ["instagram"],
        posts: [post("instagram", "i1"), post("facebook", "f1")],
      }),
    );

    const tabs = screen.getAllByRole("tab");
    expect(tabs.map((t) => t.textContent)).toEqual([
      "Instagram (1)",
      "Facebook (1)",
    ]);
  });

  it("opens on the project's first platform, not a hardcoded Instagram", () => {
    render(step({ platforms: ["facebook"], posts: [post("facebook", "f1")] }));

    expect(
      (screen.getByLabelText("Gönderi 1 tema") as HTMLInputElement).value,
    ).toBe("f1");
  });

  it("each tab lists only its own platform's posts", () => {
    render(
      step({
        posts: [
          post("instagram", "i1"),
          post("facebook", "f1"),
          post("instagram", "i2"),
        ],
      }),
    );

    expect(
      (screen.getByLabelText("Gönderi 1 tema") as HTMLInputElement).value,
    ).toBe("i1");
    expect(
      (screen.getByLabelText("Gönderi 2 tema") as HTMLInputElement).value,
    ).toBe("i2");

    fireEvent.click(screen.getByRole("tab", { name: "Facebook (1)" }));

    expect(
      (screen.getByLabelText("Gönderi 1 tema") as HTMLInputElement).value,
    ).toBe("f1");
    expect(screen.queryByLabelText("Gönderi 2 tema")).toBeNull();
  });

  // #54: the tab filter used to collapse every non-facebook tag into
  // "instagram", so a LinkedIn-only project saw a LinkedIn tab reading (0) and
  // an EmptyState while its generated posts sat in the array, invisible.
  it("shows a registered platform's own posts in its own tab", () => {
    render(
      step({ platforms: ["linkedin"], posts: [post("linkedin", "l1")] }),
    );

    const tabs = screen.getAllByRole("tab");
    expect(tabs.map((t) => t.textContent)).toEqual(["LinkedIn (1)"]);
    expect(
      (screen.getByLabelText("Gönderi 1 tema") as HTMLInputElement).value,
    ).toBe("l1");
  });

  it("does not leak linkedin/tiktok posts into the Instagram tab", () => {
    render(
      step({
        platforms: ["instagram", "linkedin", "tiktok"],
        posts: [
          post("instagram", "i1"),
          post("linkedin", "l1"),
          post("tiktok", "t1"),
        ],
      }),
    );

    const tabs = screen.getAllByRole("tab");
    expect(tabs.map((t) => t.textContent)).toEqual([
      "Instagram (1)",
      "LinkedIn (1)",
      "TikTok (1)",
    ]);

    // Instagram tab shows only the Instagram post...
    expect(
      (screen.getByLabelText("Gönderi 1 tema") as HTMLInputElement).value,
    ).toBe("i1");
    expect(screen.queryByLabelText("Gönderi 2 tema")).toBeNull();

    // ...and TikTok copy is not presented as Instagram copy for editing.
    fireEvent.click(screen.getByRole("tab", { name: "TikTok (1)" }));
    expect(
      (screen.getByLabelText("Gönderi 1 tema") as HTMLInputElement).value,
    ).toBe("t1");
  });

  it("still parks an unknown platform tag in the default tab", () => {
    // The fallback guarantee: a hand-edited or legacy post can never vanish
    // from every tab.
    render(
      step({
        platforms: ["instagram", "linkedin"],
        posts: [post("myspace", "x1"), post("linkedin", "l1")],
      }),
    );

    const tabs = screen.getAllByRole("tab");
    expect(tabs.map((t) => t.textContent)).toEqual([
      "Instagram (1)",
      "LinkedIn (1)",
    ]);
    expect(
      (screen.getByLabelText("Gönderi 1 tema") as HTMLInputElement).value,
    ).toBe("x1");
  });
});

describe("SmPostsStep — one platform at a time", () => {
  it("generating Instagram disables the Facebook button (and vice versa)", async () => {
    const fetchMock = generateFetch();
    vi.stubGlobal("fetch", fetchMock);
    render(step({ posts: [post("instagram", "i1"), post("facebook", "f1")] }));

    const fbButton = screen.getByText("Facebook için yeniden üret");
    expect((fbButton as HTMLButtonElement).disabled).toBe(false);

    fireEvent.click(screen.getByText("Instagram için yeniden üret"));
    await Promise.resolve();
    await Promise.resolve();

    // BOTH buttons are locked while a job is in flight: the queue supersedes a
    // project's active job, so a second enqueue would cancel the first.
    expect(
      (screen.getByText("Facebook için yeniden üret") as HTMLButtonElement)
        .disabled,
    ).toBe(true);
    expect(
      (screen.getByText("Üretiliyor...") as HTMLButtonElement).disabled,
    ).toBe(true);
  });

  it("sends the requested platform as the job input", async () => {
    const fetchMock = generateFetch();
    vi.stubGlobal("fetch", fetchMock);
    render(step({ posts: [post("instagram", "i1")] }));

    // Facebook is available because the project includes it; no opt-in step.
    fireEvent.click(screen.getByText("Facebook için üret"));
    await Promise.resolve();

    const generateCall = fetchMock.mock.calls.find((c) =>
      String(c[0]).endsWith("/generate"),
    );
    expect(String(generateCall?.[0])).toContain("/steps/sm_posts/generate");
    expect(JSON.parse((generateCall?.[1] as { body: string }).body)).toEqual({
      platform: "facebook",
    });
  });

  it("only ONE generate request is issued per click", async () => {
    const fetchMock = generateFetch();
    vi.stubGlobal("fetch", fetchMock);
    render(step({ posts: [post("instagram", "i1"), post("facebook", "f1")] }));

    fireEvent.click(screen.getByText("Instagram için yeniden üret"));
    await Promise.resolve();
    await Promise.resolve();
    // A second click on the (now disabled) other button must do nothing.
    fireEvent.click(screen.getByText("Facebook için yeniden üret"));
    await Promise.resolve();

    const generates = fetchMock.mock.calls.filter((c) =>
      String(c[0]).endsWith("/generate"),
    );
    expect(generates).toHaveLength(1);
  });
});

describe("SmPostsStep — editing and saving", () => {
  it("fires NO PUT on mount", async () => {
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);
    render(step({ posts: [post("instagram", "i1")] }));
    await Promise.resolve();

    expect(putBodies(fetchMock)).toEqual([]);
  });

  it("debounce-PUTs the FULL posts array — both platforms — on an edit", async () => {
    vi.useFakeTimers();
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);
    render(step({ posts: [post("instagram", "i1"), post("facebook", "f1")] }));

    fireEvent.change(screen.getByLabelText("Gönderi 1 tema"), {
      target: { value: "edited-ig" },
    });
    vi.advanceTimersByTime(1000);
    await vi.runAllTimersAsync();

    const bodies = putBodies(fetchMock);
    expect(bodies).toHaveLength(1);
    const posts = bodies[0].content.posts as PostItem[];
    // The facebook post is still there — sending only the visible tab would
    // delete it (the slice model, see core/pipeline/posts.ts).
    expect(posts.map((p) => p.platform)).toEqual(["instagram", "facebook"]);
    expect(posts[0].theme).toBe("edited-ig");
    expect(posts[1].theme).toBe("f1");
  });

  it("edits made on the Facebook tab address the right post in the flat array", async () => {
    vi.useFakeTimers();
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);
    render(step({ posts: [post("instagram", "i1"), post("facebook", "f1")] }));

    fireEvent.click(screen.getByRole("tab", { name: "Facebook (1)" }));
    fireEvent.change(screen.getByLabelText("Gönderi 1 kanca"), {
      target: { value: "edited-fb-hook" },
    });
    await vi.runAllTimersAsync();

    const posts = putBodies(fetchMock)[0].content.posts as PostItem[];
    expect(posts[0].hook).toBe("i1-hook");
    expect(posts[1].hook).toBe("edited-fb-hook");
  });

  it("hashtags are edited as text and stored as an array", async () => {
    vi.useFakeTimers();
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);
    render(step({ posts: [post("instagram", "i1")] }));

    fireEvent.change(screen.getByLabelText("Gönderi 1 etiketler"), {
      target: { value: "#bir  #iki" },
    });
    await vi.runAllTimersAsync();

    const posts = putBodies(fetchMock)[0].content.posts as PostItem[];
    expect(posts[0].hashtags).toEqual(["#bir", "#iki"]);
  });
});

describe("SmPostsStep — navigation", () => {
  it("Devam is disabled when there are no posts at all", () => {
    render(step({ posts: null }));

    const devam = screen.getByTitle("Devam etmek için en az bir gönderi üretin");
    expect(devam.getAttribute("aria-disabled")).toBe("true");
    expect(devam.tagName).toBe("SPAN");
  });

  it("Devam is enabled with ≥1 post (either platform) and links to step 9", () => {
    render(step({ posts: [post("facebook", "f1")] }));

    const devam = screen.getByText("Devam →");
    expect(devam.getAttribute("href")).toBe("/projects/p1/step/9");
  });

  it("Geri links back to step 7", () => {
    render(step({ posts: null }));
    expect(screen.getByText("← Geri").getAttribute("href")).toBe(
      "/projects/p1/step/7",
    );
  });

  it("hints when no posts exist yet", () => {
    render(step({ posts: null }));
    expect(
      screen.getByText(/Henüz Instagram gönderisi yok/),
    ).toBeTruthy();
  });
});
