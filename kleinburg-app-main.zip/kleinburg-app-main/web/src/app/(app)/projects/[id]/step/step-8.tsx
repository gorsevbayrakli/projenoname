import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";

import type { PostItem } from "@/components/wizard/post-card-list";
import { getDb } from "@/core/db/client";
import { projects } from "@/core/db/schema";
import { sortPlatforms } from "@/core/platforms";
import { getStepContent, postsContentToArray } from "@/core/pipeline/inputs";
import { requireProjectAccess } from "@/core/tenancy/access";
import { getCurrentUser } from "@/lib/auth-server";
import { SmPostsStep } from "./sm-posts-step";

/**
 * Wizard step 8 — SM Posts (sm_posts).
 *
 * Server wrapper: repeats requireProjectAccess (defense-in-depth per the T13
 * note) and loads the sm_posts step_contents row's posts (null when no content
 * yet, so the client can tell "never generated" from "generated, then emptied").
 *
 * The row holds ONE flat posts array containing BOTH platforms' slices; the
 * client filters it per tab. We deliberately do NOT split it here — every save
 * writes the whole array back, which is what keeps the other platform's posts
 * alive (see core/pipeline/posts.ts).
 */
export async function Step8({ projectId }: { projectId: string }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  try {
    await requireProjectAccess(user.id, projectId);
  } catch {
    redirect("/projects");
  }

  const db = getDb();
  const [projectRow] = await db
    .select({ platforms: projects.platforms })
    .from(projects)
    .where(eq(projects.id, projectId))
    .limit(1);
  const platforms = sortPlatforms(projectRow?.platforms ?? []);

  const row = await getStepContent(projectId, "sm_posts");
  const posts = row ? normalizePosts(row.content) : null;

  return <SmPostsStep projectId={projectId} initialPosts={posts} platforms={platforms} />;
}

/** content.posts as fully-populated PostItem[] (missing fields become ""/[]). */
function normalizePosts(content: unknown): PostItem[] {
  return postsContentToArray(content).map((p) => ({
    platform: field(p, "platform"),
    theme: field(p, "theme"),
    hook: field(p, "hook"),
    caption: field(p, "caption"),
    cta: field(p, "cta"),
    hashtags: Array.isArray(p.hashtags) ? p.hashtags.map((t) => String(t)) : [],
  }));
}

/** A string field off an unknown object, "" when absent/nullish. */
function field(value: unknown, key: string): string {
  if (value && typeof value === "object" && key in value) {
    const v = (value as Record<string, unknown>)[key];
    return v === null || v === undefined ? "" : String(v);
  }
  return "";
}
