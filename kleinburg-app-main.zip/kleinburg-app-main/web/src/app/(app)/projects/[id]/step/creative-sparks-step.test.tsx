// @vitest-environment jsdom
//
// Component test for wizard step 5 (Creative Sparks / creative_sparks),
// mirroring the T15/T17 step-test pattern: per-file jsdom env, next/navigation
// mocked, fetch mocked, React.createElement (aliased `h`) so no JSX transform is
// needed for the test file itself.
//
// Locks the behaviours specific to this step: the empty-user_input generate gate
// (the T17-review decision — {User_input} is the SUBJECT of the prompt and
// gatherVars throws on an empty one), the immediate selection PUT, and prop-sync
// re-seeding with NONE selected after a regenerate.

import { cleanup, fireEvent, screen } from "@testing-library/react";

// T25: rendered through renderWithIntl, which wraps the component in
// NextIntlClientProvider with the REAL Turkish catalog — so every assertion
// below still checks the exact Turkish a user reads.
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const refreshMock = vi.fn();
const pushMock = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    refresh: refreshMock,
    push: pushMock,
    replace: vi.fn(),
    back: vi.fn(),
    forward: vi.fn(),
    prefetch: vi.fn(),
  }),
}));

import type { TitledItem } from "@/components/wizard/selectable-item-list";
import { CreativeSparksStep } from "./creative-sparks-step";

function step(opts: {
  items?: TitledItem[] | null;
  selected?: number[];
  hasUserInput?: boolean;
}) {
  return h(CreativeSparksStep, {
    projectId: "p1",
    initialItems: opts.items ?? null,
    initialSelectedIndices: opts.selected ?? [],
    hasUserInput: opts.hasUserInput ?? true,
  });
}

function okFetch() {
  return vi.fn(() =>
    Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve({}) }),
  );
}

beforeEach(() => {
  refreshMock.mockClear();
  pushMock.mockClear();
  vi.stubGlobal("fetch", okFetch());
});

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.useRealTimers();
});

describe("CreativeSparksStep", () => {
  it("disables Üret and links back to step 4 when there is no user input", () => {
    render(step({ items: null, hasUserInput: false }));

    const button = screen.getByRole("button", { name: "Üret" });
    expect((button as HTMLButtonElement).disabled).toBe(true);

    expect(
      screen.getByText(/önce Adım 4'te bir girdi yazın/),
    ).toBeTruthy();
    const link = screen.getByRole("link", { name: /Adım 4'e git/ });
    expect(link.getAttribute("href")).toBe("/projects/p1/step/4");
  });

  it("disables Yeniden üret too when there is no user input", () => {
    render(step({ items: [{ title: "t", description: "d" }], hasUserInput: false }));

    const button = screen.getByRole("button", { name: "Yeniden üret" });
    expect((button as HTMLButtonElement).disabled).toBe(true);
    expect(screen.getByText(/önce Adım 4'te bir girdi yazın/)).toBeTruthy();
  });

  it("enables Üret and hides the hint when a user input exists", () => {
    render(step({ items: null, hasUserInput: true }));

    const button = screen.getByRole("button", { name: "Üret" });
    expect((button as HTMLButtonElement).disabled).toBe(false);
    expect(screen.queryByText(/önce Adım 4'te bir girdi yazın/)).toBeNull();
  });

  it("saves a selection change immediately via PUT { selections }", async () => {
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);

    render(
      step({
        items: [
          { title: "a", description: "d1" },
          { title: "b", description: "d2" },
        ],
      }),
    );

    // Devam is gated until something is selected.
    expect(screen.queryByRole("link", { name: /Devam/ })).toBeNull();

    fireEvent.click(screen.getByLabelText("Öğe 2 seç"));

    await vi.waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    const [url, init] = fetchMock.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ];
    expect(url).toBe("/api/projects/p1/steps/creative_sparks/content");
    expect(init.method).toBe("PUT");
    expect(JSON.parse(String(init.body))).toEqual({
      selections: { selectedIndices: [1] },
    });

    // With ≥1 selected, Devam becomes a real link to step 6.
    const devam = screen.getByRole("link", { name: /Devam/ });
    expect(devam.getAttribute("href")).toBe("/projects/p1/step/6");
  });

  it("re-seeds with NONE selected when a regenerate delivers new items", () => {
    const { rerender } = render(
      step({ items: [{ title: "eski", description: "d" }], selected: [0] }),
    );

    expect(
      (screen.getByLabelText("Öğe 1 başlık") as HTMLInputElement).value,
    ).toBe("eski");
    expect(
      (screen.getByLabelText("Öğe 1 seç") as HTMLInputElement).checked,
    ).toBe(true);

    // A fresh generation: new items, selections reset to [] on the server.
    rerender(
      step({
        items: [
          { title: "yeni", description: "d" },
          { title: "yeni2", description: "d" },
        ],
        selected: [],
      }),
    );

    expect(
      (screen.getByLabelText("Öğe 1 başlık") as HTMLInputElement).value,
    ).toBe("yeni");
    expect(
      (screen.getByLabelText("Öğe 1 seç") as HTMLInputElement).checked,
    ).toBe(false);
    expect(
      (screen.getByLabelText("Öğe 2 seç") as HTMLInputElement).checked,
    ).toBe(false);
    expect(screen.getByText("0 / 2 seçili")).toBeTruthy();
  });

  it("debounced-saves an item edit via PUT { content: { items } }", async () => {
    vi.useFakeTimers();
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);

    render(step({ items: [{ title: "a", description: "d1" }] }));

    fireEvent.change(screen.getByLabelText("Öğe 1 başlık"), {
      target: { value: "düzenlendi" },
    });
    expect(fetchMock).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(900);

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ];
    expect(url).toBe("/api/projects/p1/steps/creative_sparks/content");
    expect(JSON.parse(String(init.body))).toEqual({
      content: { items: [{ title: "düzenlendi", description: "d1" }] },
    });
  });
});
