"use client";

import { useTranslations } from "next-intl";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";

import { EmptyState } from "@/components/wizard/empty-state";
import { JobErrorNotice } from "@/components/wizard/job-error-notice";
import { JobProgress } from "@/components/wizard/job-progress";
import { useGenerate } from "@/components/wizard/use-generate";
import { WarningNotice } from "@/components/wizard/warning-notice";
import { assessToneStrength } from "@/core/pipeline/tone-strength";
import { TOTAL_STEPS } from "@/lib/workflow-steps";

// Kept in sync with MIN_BRAND_CONTEXT_CHARS in lib/wizard-status.ts (that module
// is server-only — it imports the DB client — so the value is duplicated here
// rather than imported into the client bundle).
const MIN_CHARS = 200;
const AUTOSAVE_DELAY_MS = 800;
// The tone read is debounced on the same beat as the autosave: re-assessing on
// every keystroke made the warning appear and disappear under the cursor while
// the user was mid-way through typing an example line.
const TONE_ASSESS_DELAY_MS = AUTOSAVE_DELAY_MS;

type SaveState = "idle" | "saving" | "saved" | "error";

/**
 * Client body for wizard step 2 — Marka Bağlamı.
 *
 * Two modes:
 *  - no content yet: intro + "Üret" (useGenerate('brand_context')). While a job
 *    runs, <JobProgress> streams status; on succeeded → router.refresh() picks
 *    up the worker-saved brandContext, on failed → error + retry.
 *  - content exists: an editable textarea, auto-saved (debounced) via PUT
 *    .../steps/brand_context/content, a live char counter + <200 hint, a
 *    "Yeniden üret" button, and "Devam →" enabled only at ≥ MIN_CHARS.
 */
export function BrandContextStep({
  projectId,
  initialBrandContext,
}: {
  projectId: string;
  initialBrandContext: string | null;
}) {
  const t = useTranslations("steps.brandContext");
  const tCommon = useTranslations("common");
  const tWizard = useTranslations("wizard");
  const router = useRouter();
  const { generate, jobId, isGenerating, error, reset } = useGenerate(
    projectId,
    "brand_context",
  );

  const [text, setText] = useState(initialBrandContext ?? "");
  const [saveState, setSaveState] = useState<SaveState>("idle");
  // Error from a failed generation job (surfaced via JobProgress's terminal
  // callback). Kept in local state so it stays visible after we unmount
  // <JobProgress> on failure. Cleared when a new generation starts.
  const [jobError, setJobError] = useState<string | null>(null);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // The last value we successfully persisted, to skip redundant saves.
  const savedValueRef = useRef(initialBrandContext ?? "");
  // Latest text in a ref, so the unmount-only flush effect (empty deps, stale
  // closure) can read the current value rather than the mount-time one.
  const textRef = useRef(text);
  textRef.current = text;
  // The last server-provided value, to detect real prop changes (from a
  // router.refresh() after generation) vs. re-renders where it's unchanged.
  const lastServerValue = useRef(initialBrandContext);

  const hasContent = initialBrandContext !== null;
  const charCount = text.length;
  const longEnough = charCount >= MIN_CHARS;
  // T35: the tone section is what every post prompt takes the brand's voice
  // from, and when it is thin the posts silently fall back to a generic
  // platform voice — fluent, well-formed, and not this brand. The engine's
  // heuristic (core/pipeline/tone-strength.ts) is deterministic and cheap, so
  // it re-runs on the live editor text: fix the section by hand and the
  // warning clears without a regeneration. It NEVER gates Devam or Yeniden
  // üret — some brands genuinely have no tone document.
  //
  // Debounced AND memoized: the assessment walks the whole context with an
  // Intl.Segmenter, and running it inline on every render put milliseconds of
  // work on the typing path of a textarea that can hold tens of KB.
  const [assessedText, setAssessedText] = useState(text);
  useEffect(() => {
    const timer = setTimeout(() => setAssessedText(text), TONE_ASSESS_DELAY_MS);
    return () => clearTimeout(timer);
  }, [text]);
  const toneWeak = useMemo(
    () => hasContent && assessToneStrength(assessedText).weak,
    [hasContent, assessedText],
  );
  // A POST-time hook error (generate never started) OR a failed-job error.
  const displayError = error ?? jobError;

  // Kick off a generation, clearing any stale failed-job error first.
  function startGenerate() {
    setJobError(null);
    reset();
    void generate();
  }

  // CRITICAL: Next.js App Router preserves this client component's state across
  // router.refresh(), so when generation completes and the server re-renders
  // with the new brandContext, useState would otherwise keep the stale "".
  // Sync local text from the server prop ONLY when the prop actually changes —
  // auto-save never calls router.refresh(), so the prop only moves on
  // generation / Yeniden üret, and this won't clobber in-progress edits.
  useEffect(() => {
    if (initialBrandContext !== lastServerValue.current) {
      lastServerValue.current = initialBrandContext;
      setText(initialBrandContext ?? "");
      savedValueRef.current = initialBrandContext ?? "";
      // The re-seed is not an edit: drop any indicator left over from the
      // previous content (a regenerate must not look like a pending save).
      setSaveState("idle");
    }
  }, [initialBrandContext]);

  // Debounced auto-save of the textarea. Only runs when content already exists.
  useEffect(() => {
    if (!hasContent) return;
    // Nothing to save. If a previous pass showed "Kaydediliyor…" and its timer
    // was cleared by this re-render (prop-sync re-seed), the indicator would
    // stick forever — so clear it here. Only "saving" is reset; a "saved" or
    // "error" result must stay visible.
    if (text === savedValueRef.current) {
      setSaveState((s) => (s === "saving" ? "idle" : s));
      return;
    }

    if (saveTimer.current) clearTimeout(saveTimer.current);
    setSaveState("saving");
    saveTimer.current = setTimeout(() => {
      void saveContent(text);
    }, AUTOSAVE_DELAY_MS);

    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
    // saveContent is stable enough for this effect's purpose; keying on text.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, hasContent]);

  // Flush a pending edit on unmount. "Geri"/"Devam" are <Link> client
  // navigations that unmount this component before the 800ms debounce fires,
  // which would silently drop the last keystrokes. This empty-deps cleanup runs
  // only on unmount: if the latest text differs from what we last saved, fire
  // the PUT immediately with keepalive so it survives teardown (best-effort;
  // a failed flush is swallowed and must not crash navigation).
  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      const pending = textRef.current;
      if (pending === savedValueRef.current) return;
      try {
        void fetch(`/api/projects/${projectId}/steps/brand_context/content`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: { brandContext: pending } }),
          keepalive: true,
        }).catch(() => {});
      } catch {
        // best-effort; never block navigation on a flush failure
      }
    };
    // Mount/unmount only — projectId is stable for this component's lifetime.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function saveContent(value: string) {
    try {
      const res = await fetch(
        `/api/projects/${projectId}/steps/brand_context/content`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: { brandContext: value } }),
        },
      );
      if (res.ok) {
        savedValueRef.current = value;
        setSaveState("saved");
        return;
      }
      setSaveState("error");
    } catch {
      setSaveState("error");
    }
  }

  function handleJobDone(result: { status: string; error?: string }) {
    if (result.status === "succeeded") {
      // The worker upserted step_contents; reload to render the new text. Then
      // reset() clears jobId so the already-terminal <JobProgress> unmounts and
      // can't re-fire onDone → router.refresh() in a loop. The prop-sync effect
      // above applies the refreshed content once router.refresh() lands.
      router.refresh();
      reset();
      return;
    }
    // On failed: capture the honest error in local state so it survives the
    // <JobProgress> unmount, then clear jobId so the terminal progress stream
    // tears down and stops re-firing. The user retries via Üret / Yeniden üret.
    setJobError(result.error ?? tCommon("generationFailed"));
    reset();
  }

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-8 px-4 py-8 sm:px-8 sm:py-10">
      <header className="flex flex-col gap-1">
        <div className="text-sm font-medium text-fg-subtle">
          {tWizard("stepIndicator", { n: 2, total: TOTAL_STEPS })}
        </div>
        <h1 className="text-2xl font-semibold tracking-tight text-fg">
          {t("title")}
        </h1>
        <p className="mt-1 text-sm text-fg-muted">{t("description")}</p>
      </header>

      {!hasContent ? (
        jobId ? (
          <div className="flex flex-col gap-3 rounded-lg border border-border bg-bg p-4">
            <JobProgress jobId={jobId} onDone={handleJobDone} />
          </div>
        ) : displayError ? (
          <JobErrorNotice
            error={displayError}
            projectId={projectId}
            onRetry={startGenerate}
          />
        ) : (
          <EmptyState
            title={t("emptyTitle")}
            description={t("emptyDescription")}
            action={
              <button
                type="button"
                disabled={isGenerating}
                onClick={startGenerate}
                className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isGenerating ? tCommon("starting") : tCommon("generate")}
              </button>
            }
          />
        )
      ) : (
        <div className="flex flex-col gap-3">
          {jobId ? (
            <div className="flex flex-col gap-3 rounded-lg border border-border bg-bg p-4">
              <JobProgress jobId={jobId} onDone={handleJobDone} />
            </div>
          ) : displayError ? (
            <JobErrorNotice
              error={displayError}
              projectId={projectId}
              onRetry={startGenerate}
            />
          ) : null}

          {/* Always rendered, content toggled: see WarningNotice on why the
              live region must pre-exist its own announcement. */}
          <WarningNotice
            visible={toneWeak}
            message={t("toneWeakTitle")}
            detail={t("toneWeakHint")}
          />


          <div className="flex items-center justify-between">
            <label
              htmlFor="brand-context-textarea"
              className="text-sm font-medium text-fg"
            >
              {t("label")}
            </label>
            <SaveIndicator state={saveState} />
          </div>

          <textarea
            id="brand-context-textarea"
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={16}
            className="w-full resize-y rounded-lg border border-border bg-bg px-3 py-2 text-sm leading-relaxed text-fg outline-none placeholder:text-fg-subtle focus-visible:border-accent"
          />

          <div className="flex items-center justify-between gap-3">
            <span
              className={
                "text-xs " + (longEnough ? "text-fg-subtle" : "text-fg-error")
              }
            >
              {t("charCount", { count: String(charCount) })}
            </span>
            <button
              type="button"
              disabled={isGenerating}
              onClick={startGenerate}
              className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isGenerating ? tCommon("starting") : tCommon("regenerate")}
            </button>
          </div>

          {!longEnough ? (
            <p className="text-sm text-fg-error">
              {t("tooShort", { min: MIN_CHARS })}
            </p>
          ) : null}
        </div>
      )}

      {/* Navigation */}
      <nav className="flex items-center justify-between border-t border-border pt-4">
        <Link
          href={`/projects/${projectId}/step/1`}
          className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
        >
          {tCommon("back")}
        </Link>
        {longEnough ? (
          <Link
            href={`/projects/${projectId}/step/3`}
            className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized"
          >
            {tCommon("continue")}
          </Link>
        ) : (
          <span
            aria-disabled="true"
            title={t("continueLocked", { min: MIN_CHARS })}
            className="cursor-not-allowed rounded-lg bg-bg-muted px-4 py-2 text-sm font-medium text-fg-subtle opacity-60"
          >
            {tCommon("continue")}
          </span>
        )}
      </nav>
    </div>
  );
}

function SaveIndicator({ state }: { state: SaveState }) {
  const t = useTranslations("save");
  if (state === "saving") {
    return <span className="text-xs text-fg-subtle">{t("saving")}</span>;
  }
  if (state === "saved") {
    return <span className="text-xs text-fg-success">{t("saved")}</span>;
  }
  if (state === "error") {
    return <span className="text-xs text-fg-error">{t("failed")}</span>;
  }
  return null;
}
