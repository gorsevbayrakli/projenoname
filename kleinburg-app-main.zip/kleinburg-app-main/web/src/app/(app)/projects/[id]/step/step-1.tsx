import { redirect } from "next/navigation";

import { listDocuments } from "@/core/ingest/documents";
import { requireProjectAccess } from "@/core/tenancy/access";
import { getCurrentUser } from "@/lib/auth-server";
import { DocumentsStep } from "./documents-step";

/**
 * Wizard step 1 — Belge Yükleme (document upload).
 *
 * Server wrapper: repeats requireProjectAccess (defense-in-depth per the T13
 * note — the layout already gated it, but every step loader re-checks) and
 * loads the current documents, handing both to the client component.
 */
export async function Step1({ projectId }: { projectId: string }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  // The layout already enforced access; re-assert here so the loader is safe on
  // its own. An access failure at this point means a stale session — bounce.
  try {
    await requireProjectAccess(user.id, projectId);
  } catch {
    redirect("/projects");
  }

  const documents = await listDocuments(projectId);

  return (
    <DocumentsStep
      projectId={projectId}
      initialDocuments={documents.map((d) => ({
        id: d.id,
        filename: d.filename,
        kind: d.kind,
      }))}
    />
  );
}
