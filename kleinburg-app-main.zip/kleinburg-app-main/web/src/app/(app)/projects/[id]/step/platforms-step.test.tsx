// @vitest-environment jsdom
//
// Component test for wizard step 6 — Platform Seçimi (T29).
//
// Two of these exist because the browser found what the suite did not: the
// button's saving label read a key that does not exist (`common.saving`; it
// lives under `save`), and nothing re-rendered the rail after the save, so
// step 6 stayed unticked. Rendering through the REAL Turkish catalog is what
// makes the first one catchable here.

import { cleanup, fireEvent, screen, waitFor } from "@testing-library/react";
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const refreshMock = vi.fn();
const pushMock = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    refresh: refreshMock,
    push: pushMock,
    replace: vi.fn(),
    back: vi.fn(),
  }),
}));

import { PlatformsStep } from "./platforms-step";
import { PLATFORMS } from "@/core/platforms";

const PROJECT = "p-1";

function step(
  initialSelected: string[] = [],
  initialCounts: Record<string, number> = {},
) {
  return h(PlatformsStep, { projectId: PROJECT, initialSelected, initialCounts });
}

function okFetch() {
  return vi.fn(async () => new Response(JSON.stringify({ project: {} }), { status: 200 }));
}

describe("PlatformsStep", () => {
  beforeEach(() => {
    refreshMock.mockClear();
    pushMock.mockClear();
  });

  afterEach(cleanup);

  it("lists every registered platform", () => {
    render(step());
    // Registry-driven: LinkedIn and TikTok appear here by being registered.
    expect(screen.getAllByRole("checkbox")).toHaveLength(PLATFORMS.length);
  });

  it("cannot continue with nothing selected", () => {
    vi.stubGlobal("fetch", okFetch());
    render(step());

    // Rendered as a non-button span while locked, so there is nothing to click.
    expect(screen.queryByRole("button", { name: "Devam →" })).toBeNull();
    expect(fetch).not.toHaveBeenCalled();
  });

  it("saves the selection and moves to the pillars step", async () => {
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);
    render(step());

    fireEvent.click(screen.getAllByRole("checkbox")[0]);
    fireEvent.click(screen.getByRole("button", { name: "Devam →" }));

    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    const [url, init] = fetchMock.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ];
    expect(url).toBe(`/api/projects/${PROJECT}/platforms`);
    expect(init.method).toBe("PUT");
    expect(JSON.parse(init.body as string)).toEqual({
      platforms: [PLATFORMS[0].code],
      postCounts: { [PLATFORMS[0].code]: PLATFORMS[0].defaultPostCount },
    });
    await waitFor(() =>
      expect(pushMock).toHaveBeenCalledWith(`/projects/${PROJECT}/step/7`),
    );
  });

  it("refreshes so the rail ticks step 6 as it navigates", async () => {
    vi.stubGlobal("fetch", okFetch());
    render(step());

    fireEvent.click(screen.getAllByRole("checkbox")[0]);
    fireEvent.click(screen.getByRole("button", { name: "Devam →" }));

    // The rail is a server component in the layout; without this it keeps
    // rendering step 6 as incomplete until the next full page load.
    await waitFor(() => expect(refreshMock).toHaveBeenCalled());
  });

  it("shows a real message while saving, not a missing-key fallback", async () => {
    let release: (() => void) | undefined;
    vi.stubGlobal(
      "fetch",
      vi.fn(
        () =>
          new Promise<Response>((resolve) => {
            release = () => resolve(new Response("{}", { status: 200 }));
          }),
      ),
    );
    render(step());

    fireEvent.click(screen.getAllByRole("checkbox")[0]);
    fireEvent.click(screen.getByRole("button", { name: "Devam →" }));

    // "Kaydediliyor…" comes from the real catalog; a missing key would render
    // the key path instead, which is exactly the bug this locks.
    await waitFor(() => expect(screen.getByText("Kaydediliyor…")).toBeDefined());
    release?.();
  });

  it("offers the registry default count for a chosen platform", () => {
    render(step());
    fireEvent.click(screen.getAllByRole("checkbox")[0]);

    // Defaults differ per platform on purpose: TikTok tolerates a cadence
    // LinkedIn would punish.
    const input = screen.getByLabelText("gönderi") as HTMLInputElement;
    expect(input.value).toBe(String(PLATFORMS[0].defaultPostCount));
  });

  it("keeps a stored count over the default", () => {
    render(step([PLATFORMS[0].code], { [PLATFORMS[0].code]: 7 }));
    expect((screen.getByLabelText("gönderi") as HTMLInputElement).value).toBe("7");
  });

  it("saves the edited count, not the default", async () => {
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);
    render(step([PLATFORMS[0].code]));

    fireEvent.change(screen.getByLabelText("gönderi"), { target: { value: "9" } });
    fireEvent.click(screen.getByRole("button", { name: "Devam →" }));

    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    const [, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(JSON.parse(init.body as string).postCounts).toEqual({
      [PLATFORMS[0].code]: 9,
    });
  });

  it("does not ask for a cadence suggestion until a platform is chosen", () => {
    // The suggestion costs an LLM call; offering it with nothing selected
    // would bill the user for a question with no subject.
    render(step());
    expect(screen.queryByRole("button", { name: "Sıklık önerisi al" })).toBeNull();
  });

  it("surfaces a failed save instead of navigating", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(
        async () =>
          new Response(JSON.stringify({ code: "PROJECT_PLATFORMS_EMPTY" }), {
            status: 400,
          }),
      ),
    );
    render(step());

    fireEvent.click(screen.getAllByRole("checkbox")[0]);
    fireEvent.click(screen.getByRole("button", { name: "Devam →" }));

    await waitFor(() =>
      expect(screen.getByText("En az bir platform seçilmeli.")).toBeDefined(),
    );
    expect(pushMock).not.toHaveBeenCalled();
  });
});
