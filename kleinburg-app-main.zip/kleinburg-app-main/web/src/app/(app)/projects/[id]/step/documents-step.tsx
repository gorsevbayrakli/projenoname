"use client";

import { useTranslations } from "next-intl";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useRef, useState } from "react";

import { EmptyState } from "@/components/wizard/empty-state";
import { ErrorNotice } from "@/components/wizard/error-notice";
import type { DocumentKind } from "@/core/db/schema";
import { TOTAL_STEPS } from "@/lib/workflow-steps";
import { apiErrorMessage, type ApiErrorTranslator } from "@/lib/api-error-copy";

type DocItem = { id: string; filename: string; kind: DocumentKind };

const KIND_LABELS: Record<DocumentKind, string> = {
  pdf: "PDF",
  docx: "DOCX",
  pptx: "PPTX",
  url: "URL",
};

const ACCEPT = ".pdf,.docx,.pptx";

/**
 * Client body for wizard step 1. Uploads (file dropzone/button + URL input)
 * POST to /api/projects/[id]/documents; the list reflects what is persisted and
 * refreshes via router.refresh() after each mutation. "Devam" is enabled only
 * when ≥1 document exists (step 1 completion).
 */
export function DocumentsStep({
  projectId,
  initialDocuments,
}: {
  projectId: string;
  initialDocuments: DocItem[];
}) {
  const t = useTranslations("steps.documents");
  const tCommon = useTranslations("common");
  const tWizard = useTranslations("wizard");
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [uploading, setUploading] = useState(false);
  const [urlValue, setUrlValue] = useState("");
  const [addingUrl, setAddingUrl] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const hasDocuments = initialDocuments.length > 0;
  const nextEnabled = hasDocuments && TOTAL_STEPS > 1;

  async function postFile(file: File) {
    setError(null);
    setUploading(true);
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await fetch(`/api/projects/${projectId}/documents`, {
        method: "POST",
        body: form,
      });
      if (res.status === 201) {
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => null)) as {
        error?: string;
        code?: string;
      } | null;
      setError(apiErrorMessage(data, tApi, t("uploadFailed")));
    } catch {
      setError(tCommon("networkError"));
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  async function addUrl(event: React.FormEvent) {
    event.preventDefault();
    const url = urlValue.trim();
    if (url.length === 0) return;
    setError(null);
    setAddingUrl(true);
    try {
      const res = await fetch(`/api/projects/${projectId}/documents`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      if (res.status === 201) {
        setUrlValue("");
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => null)) as {
        error?: string;
        code?: string;
      } | null;
      setError(apiErrorMessage(data, tApi, t("urlFailed")));
    } catch {
      setError(tCommon("networkError"));
    } finally {
      setAddingUrl(false);
    }
  }

  async function remove(documentId: string) {
    setError(null);
    setDeletingId(documentId);
    try {
      const res = await fetch(
        `/api/projects/${projectId}/documents/${documentId}`,
        { method: "DELETE" },
      );
      if (res.ok) {
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => null)) as {
        error?: string;
        code?: string;
      } | null;
      setError(apiErrorMessage(data, tApi, t("deleteFailed")));
    } catch {
      setError(tCommon("networkError"));
    } finally {
      setDeletingId(null);
    }
  }

  const busy = uploading || addingUrl;

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-8 px-4 py-8 sm:px-8 sm:py-10">
      <header className="flex flex-col gap-1">
        <div className="text-sm font-medium text-fg-subtle">
          {tWizard("stepIndicator", { n: 1, total: TOTAL_STEPS })}
        </div>
        <h1 className="text-2xl font-semibold tracking-tight text-fg">
          {t("title")}
        </h1>
        <p className="mt-1 text-sm text-fg-muted">{t("description")}</p>
        {/* T27: what this step DOES vs what YOU write here are different
            questions. The first live run failed because only the first was
            answered, so the guidance gets its own block rather than another
            sentence in the description nobody finishes reading. */}
        <p className="mt-3 rounded-lg border border-border bg-bg-muted px-3 py-2 text-sm text-fg-muted">
          {t("inputHint")}
        </p>
      </header>

      {/* File dropzone */}
      <label
        htmlFor="documents-file-input"
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          const file = e.dataTransfer.files?.[0];
          if (file && !busy) void postFile(file);
        }}
        className={
          // #57: the file input inside is visually hidden but still focusable,
          // and a <label> never takes focus itself — so the ONLY way keyboard
          // focus on the picker can be seen is this container reacting to it.
          "flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed px-6 py-10 text-center transition-colors focus-within:border-accent focus-within:ring-3 focus-within:ring-ring/50 " +
          (dragOver
            ? "border-accent bg-accent-subtle"
            : "border-border bg-bg hover:border-border-emphasized hover:bg-bg-muted") +
          (busy ? " pointer-events-none opacity-60" : "")
        }
      >
        <input
          id="documents-file-input"
          ref={fileInputRef}
          type="file"
          accept={ACCEPT}
          // #57: `hidden` (display:none) took this out of the tab order AND the
          // accessibility tree, and since the wrapping <label> is not focusable
          // there was no keyboard path to the file picker at all — a keyboard or
          // screen-reader user could only add URLs, and step 1's "Devam" gate
          // wants a document. `sr-only` keeps the input focusable and announced
          // (with the dropzone's own wording) while looking exactly the same.
          className="sr-only"
          disabled={busy}
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void postFile(file);
          }}
        />
        <span className="text-sm font-medium text-fg">
          {uploading ? t("uploading") : t("dropzone")}
        </span>
        <span className="text-xs text-fg-subtle">
          {t("limits")}
        </span>
      </label>

      {/* URL input */}
      <form onSubmit={addUrl} className="flex items-end gap-2">
        <div className="flex flex-1 flex-col gap-1.5">
          <label
            htmlFor="documents-url-input"
            className="text-sm font-medium text-fg"
          >
            {t("urlLabel")}
          </label>
          <input
            id="documents-url-input"
            type="url"
            inputMode="url"
            placeholder={t("urlPlaceholder")}
            value={urlValue}
            onChange={(e) => setUrlValue(e.target.value)}
            disabled={busy}
            className="h-9 rounded-lg border border-border bg-bg px-3 text-sm text-fg outline-none placeholder:text-fg-subtle focus-visible:border-accent"
          />
        </div>
        <button
          type="submit"
          disabled={busy || urlValue.trim().length === 0}
          className="h-9 rounded-lg bg-accent px-4 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized disabled:cursor-not-allowed disabled:opacity-50"
        >
          {addingUrl ? t("adding") : t("add")}
        </button>
      </form>

      {/* Upload / URL / delete failures — the honest server reason, never a
          generic "bir şeyler ters gitti". */}
      {error ? <ErrorNotice message={error} /> : null}

      {/* Document list */}
      <div className="flex flex-col gap-2">
        <div className="text-xs font-medium tracking-wide text-fg-subtle uppercase">
          {t("listTitle", { count: initialDocuments.length })}
        </div>
        {hasDocuments ? (
          <ul className="flex flex-col gap-2">
            {initialDocuments.map((doc) => (
              <li
                key={doc.id}
                className="flex items-center justify-between gap-3 rounded-lg border border-border bg-bg px-4 py-3"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <span className="shrink-0 rounded-md bg-bg-muted px-2 py-0.5 text-xs font-medium text-fg-muted">
                    {KIND_LABELS[doc.kind]}
                  </span>
                  <span className="truncate text-sm text-fg" title={doc.filename}>
                    {doc.filename}
                  </span>
                </div>
                <button
                  type="button"
                  aria-label={t("delete")}
                  title={t("delete")}
                  disabled={deletingId === doc.id}
                  onClick={() => void remove(doc.id)}
                  className="shrink-0 rounded-md px-2 py-1 text-sm text-fg-subtle transition-colors hover:bg-bg-muted hover:text-fg-error disabled:opacity-50"
                >
                  ✕
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <EmptyState
            title={t("emptyTitle")}
            description={t("emptyDescription")}
          />
        )}
      </div>

      {/* Navigation (step 1 has no Back) */}
      <nav className="flex items-center justify-end border-t border-border pt-4">
        {nextEnabled ? (
          <Link
            href={`/projects/${projectId}/step/2`}
            className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized"
          >
            {tCommon("continue")}
          </Link>
        ) : (
          <span
            aria-disabled="true"
            title={t("continueLocked")}
            className="cursor-not-allowed rounded-lg bg-bg-muted px-4 py-2 text-sm font-medium text-fg-subtle opacity-60"
          >
            {tCommon("continue")}
          </span>
        )}
      </nav>
    </div>
  );
}
