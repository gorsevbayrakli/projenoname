// @vitest-environment jsdom
//
// Component test for wizard step 1 (Belge Yükleme / documents), following the
// sibling-step pattern: per-file jsdom env, next/navigation mocked,
// React.createElement (aliased `h`) so no JSX transform is needed here.
//
// Locks the ONE thing this file exists for (#57): the file picker is reachable
// without a mouse. The dropzone is a <label> wrapping the file input, and a
// <label> is not focusable — so the input itself has to stay in the tab order
// and in the accessibility tree. If it is display:none there is no
// keyboard-reachable path to the picker at all, and step 1's "Devam" gate
// (initialDocuments.length > 0) then cannot be satisfied by anyone whose
// sources are files rather than URLs.

import { cleanup, screen } from "@testing-library/react";
import { createElement as h } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { renderWithIntl as render } from "@/test/render-with-intl";

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    refresh: vi.fn(),
    push: vi.fn(),
    replace: vi.fn(),
    back: vi.fn(),
    forward: vi.fn(),
    prefetch: vi.fn(),
  }),
}));

import { DocumentsStep } from "./documents-step";

/**
 * jsdom has no compiled Tailwind, so class names carry no meaning until we give
 * them one. These two declarations are Tailwind's own published semantics for
 * the utilities in play, and they are what the assertion below actually turns
 * on: `hidden` takes the input out of the box tree (and with it the tab order
 * and the accessibility tree), `sr-only` keeps it in both while hiding it from
 * sight. Anything else the component might use resolves to its default display
 * and therefore reads as visible — this stylesheet is the discriminator for
 * exactly the bug in #57, not a general "is it visible" oracle.
 *
 * (jsdom's own focus() ignores display entirely — a display:none input still
 * accepts focus there — so computed display, not activeElement, is the only
 * honest signal available in this environment.)
 */
function installDisplaySemantics() {
  const style = document.createElement("style");
  style.textContent =
    ".hidden{display:none}" +
    ".sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip-path:inset(50%)}";
  document.head.appendChild(style);
}

function step() {
  return h(DocumentsStep, { projectId: "p1", initialDocuments: [] });
}

const DROPZONE = /Dosya seçin ya da sürükleyip bırakın/;

afterEach(() => {
  cleanup();
  document.head.innerHTML = "";
});

describe("DocumentsStep file input accessibility (#57)", () => {
  it("keeps the file input in the tab order and the accessibility tree", () => {
    installDisplaySemantics();
    render(step());

    // Resolving the input by its label text is itself half the contract: a
    // screen reader announces the picker with the dropzone's wording.
    const input = screen.getByLabelText(DROPZONE);
    expect(input).toBeInstanceOf(HTMLInputElement);
    expect((input as HTMLInputElement).type).toBe("file");

    // The failing half: display:none removes the input from the tab order, and
    // the wrapping <label> is not focusable, so nothing on this step opens the
    // picker from the keyboard.
    expect(getComputedStyle(input).display).not.toBe("none");
  });

  it("shows keyboard focus on the dropzone the input is buried in", () => {
    render(step());

    const input = screen.getByLabelText(DROPZONE);
    const dropzone = input.closest("label");
    expect(dropzone).not.toBeNull();

    // The input is visually hidden by design, so the only way its focus can be
    // seen is the dropzone reacting to focus landing inside it.
    expect(dropzone?.className).toMatch(/focus-within:/);
  });
});
