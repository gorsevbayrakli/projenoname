"use client";

import { useTranslations } from "next-intl";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

import { EmptyState } from "@/components/wizard/empty-state";
import { JobErrorNotice } from "@/components/wizard/job-error-notice";
import { JobProgress } from "@/components/wizard/job-progress";
import {
  SelectableItemList,
  type TitledItem,
} from "@/components/wizard/selectable-item-list";
import { useGenerate } from "@/components/wizard/use-generate";
import { TOTAL_STEPS } from "@/lib/workflow-steps";

const AUTOSAVE_DELAY_MS = 800;

type SaveState = "idle" | "saving" | "saved" | "error";

/**
 * Client body for wizard step 5 — Creative Sparks (creative_sparks).
 *
 * Mirrors the T16 (secondary_data) generate → edit → auto-save shape verbatim —
 * same {title, description} item shape, same <SelectableItemList>, same
 * debounced content auto-save + immediate selection save + prop-sync + unmount
 * flush — with ONE addition: the empty-input gate.
 *
 * {User_input} (step 4, Ek Girdi) is the SUBJECT of the creative_spark prompt.
 * Generating from an empty input yields confident nonsense, and gatherVars
 * throws on it. So when `hasUserInput` is false the Üret / Yeniden üret button
 * is disabled and an inline hint links back to step 4. The gatherVars throw
 * stays as the backend guard; this is only the UI gate that stops a user from
 * hitting it blindly.
 *
 * "Devam →" is enabled only when ≥1 spark is selected — the selected sparks are
 * what feed the sm_pillars prompt (T19).
 */
export function CreativeSparksStep({
  projectId,
  initialItems,
  initialSelectedIndices,
  hasUserInput,
}: {
  projectId: string;
  initialItems: TitledItem[] | null;
  initialSelectedIndices: number[];
  hasUserInput: boolean;
}) {
  const t = useTranslations("steps.creativeSparks");
  const tCommon = useTranslations("common");
  const tWizard = useTranslations("wizard");
  const router = useRouter();
  const { generate, jobId, isGenerating, error, reset } = useGenerate(
    projectId,
    "creative_sparks",
  );

  const [items, setItems] = useState<TitledItem[]>(initialItems ?? []);
  const [selectedIndices, setSelectedIndices] = useState<number[]>(
    initialSelectedIndices,
  );
  const [saveState, setSaveState] = useState<SaveState>("idle");
  // Error from a failed generation job (kept in local state so it survives the
  // <JobProgress> unmount on failure). Cleared when a new generation starts.
  const [jobError, setJobError] = useState<string | null>(null);

  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // The last items array we successfully persisted, to skip redundant saves.
  const savedItemsRef = useRef(JSON.stringify(initialItems ?? []));
  // Latest items in a ref, so the unmount-only flush effect can read the current
  // value rather than the mount-time one.
  const itemsRef = useRef(items);
  itemsRef.current = items;
  // The last server-provided signature, to detect real prop changes (from a
  // router.refresh() after generation) vs. re-renders where it is unchanged.
  const lastServerSig = useRef(sig(initialItems, initialSelectedIndices));

  const hasContent = initialItems !== null;
  const selectedCount = selectedIndices.length;
  const canContinue = selectedCount >= 1;
  const canGenerate = hasUserInput && !isGenerating;
  const displayError = error ?? jobError;

  function startGenerate() {
    if (!hasUserInput) return;
    setJobError(null);
    reset();
    void generate();
  }

  // Sync local state from the server props ONLY when they actually change (a
  // fresh generation / Yeniden üret → new items and selections reset to null).
  // Auto-save never calls router.refresh(), so this won't clobber in-progress
  // edits. A regenerate re-seeds the list with NONE selected.
  useEffect(() => {
    const next = sig(initialItems, initialSelectedIndices);
    if (next !== lastServerSig.current) {
      lastServerSig.current = next;
      setItems(initialItems ?? []);
      setSelectedIndices(initialSelectedIndices);
      savedItemsRef.current = JSON.stringify(initialItems ?? []);
      // The re-seed is not an edit: drop any indicator left over from the
      // previous content (a regenerate must not look like a pending save).
      setSaveState("idle");
    }
  }, [initialItems, initialSelectedIndices]);

  // Debounced auto-save of item edits. Only runs when content already exists.
  useEffect(() => {
    if (!hasContent) return;
    const serialized = JSON.stringify(items);
    // Nothing to save. If a previous pass showed "Kaydediliyor…" and its timer
    // was cleared by this re-render (prop-sync re-seed), the indicator would
    // stick forever — so clear it here. Only "saving" is reset; a "saved" or
    // "error" result must stay visible.
    if (serialized === savedItemsRef.current) {
      setSaveState((s) => (s === "saving" ? "idle" : s));
      return;
    }

    if (saveTimer.current) clearTimeout(saveTimer.current);
    setSaveState("saving");
    saveTimer.current = setTimeout(() => {
      void saveItems(items);
    }, AUTOSAVE_DELAY_MS);

    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items, hasContent]);

  // Flush a pending item edit on unmount (Geri/Devam are client navigations that
  // unmount before the debounce fires). Best-effort keepalive; a failed flush is
  // swallowed and must never crash navigation.
  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      const pending = JSON.stringify(itemsRef.current);
      if (pending === savedItemsRef.current) return;
      try {
        void fetch(`/api/projects/${projectId}/steps/creative_sparks/content`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: { items: itemsRef.current } }),
          keepalive: true,
        }).catch(() => {});
      } catch {
        // best-effort; never block navigation on a flush failure
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function saveItems(value: TitledItem[]) {
    try {
      const res = await fetch(
        `/api/projects/${projectId}/steps/creative_sparks/content`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: { items: value } }),
        },
      );
      if (res.ok) {
        savedItemsRef.current = JSON.stringify(value);
        setSaveState("saved");
        return;
      }
      setSaveState("error");
    } catch {
      setSaveState("error");
    }
  }

  // Selection is a discrete action — save it immediately (no debounce).
  async function saveSelection(indices: number[]) {
    try {
      const res = await fetch(
        `/api/projects/${projectId}/steps/creative_sparks/content`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ selections: { selectedIndices: indices } }),
        },
      );
      setSaveState(res.ok ? "saved" : "error");
    } catch {
      setSaveState("error");
    }
  }

  function handleSelectionChange(indices: number[]) {
    setSelectedIndices(indices);
    setSaveState("saving");
    void saveSelection(indices);
  }

  function handleJobDone(result: { status: string; error?: string }) {
    if (result.status === "succeeded") {
      // The worker upserted step_contents (items, selections reset to null);
      // reload to render the new list, then reset() so the terminal
      // <JobProgress> unmounts and can't re-fire onDone in a loop.
      router.refresh();
      reset();
      return;
    }
    setJobError(result.error ?? tCommon("generationFailed"));
    reset();
  }

  // max-w-6xl, wider than the 3xl of the non-listing steps: this step renders a
  // card GRID (#44) and a 3xl column has no room for a second track. The other
  // steps stay narrow because a form column reads better short.
  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8 sm:px-8 sm:py-10">
      <header className="flex flex-col gap-1">
        <div className="text-sm font-medium text-fg-subtle">
          {tWizard("stepIndicator", { n: 5, total: TOTAL_STEPS })}
        </div>
        <h1 className="text-2xl font-semibold tracking-tight text-fg">
          {t("title")}
        </h1>
        <p className="mt-1 text-sm text-fg-muted">{t("description")}</p>
        {/* T27: what this step DOES vs what YOU write here are different
            questions. The first live run failed because only the first was
            answered, so the guidance gets its own block rather than another
            sentence in the description nobody finishes reading. */}
        <p className="mt-3 rounded-lg border border-border bg-bg-muted px-3 py-2 text-sm text-fg-muted">
          {t("inputHint")}
        </p>
      </header>

      {!hasContent ? (
        jobId ? (
          <div className="flex flex-col gap-3 rounded-lg border border-border bg-bg p-4">
            <JobProgress jobId={jobId} onDone={handleJobDone} />
          </div>
        ) : displayError ? (
          <div className="flex flex-col gap-3">
            <JobErrorNotice
              error={displayError}
              projectId={projectId}
              onRetry={hasUserInput ? startGenerate : undefined}
            />
            <MissingInputHint
              hasUserInput={hasUserInput}
              projectId={projectId}
            />
          </div>
        ) : (
          <EmptyState
            title={t("emptyTitle")}
            description={t("emptyDescription")}
            action={
              <button
                type="button"
                disabled={!canGenerate}
                onClick={startGenerate}
                className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isGenerating ? tCommon("starting") : tCommon("generate")}
              </button>
            }
          >
            <MissingInputHint
              hasUserInput={hasUserInput}
              projectId={projectId}
            />
          </EmptyState>
        )
      ) : (
        <div className="flex flex-col gap-4">
          {jobId ? (
            <div className="flex flex-col gap-3 rounded-lg border border-border bg-bg p-4">
              <JobProgress jobId={jobId} onDone={handleJobDone} />
            </div>
          ) : displayError ? (
            <JobErrorNotice
              error={displayError}
              projectId={projectId}
              onRetry={hasUserInput ? startGenerate : undefined}
            />
          ) : null}

          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-fg">
              {t("listLabel")}
            </span>
            <SaveIndicator state={saveState} />
          </div>

          <SelectableItemList
            items={items}
            selectedIndices={selectedIndices}
            onItemsChange={setItems}
            onSelectionChange={handleSelectionChange}
          />

          <MissingInputHint hasUserInput={hasUserInput} projectId={projectId} />

          <div className="flex items-center justify-between gap-3">
            {!canContinue ? (
              <p className="text-sm text-fg-error">{t("selectHint")}</p>
            ) : (
              <span />
            )}
            <button
              type="button"
              disabled={!canGenerate}
              onClick={startGenerate}
              className="shrink-0 rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isGenerating ? tCommon("starting") : tCommon("regenerate")}
            </button>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex items-center justify-between border-t border-border pt-4">
        <Link
          href={`/projects/${projectId}/step/4`}
          className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
        >
          {tCommon("back")}
        </Link>
        {canContinue ? (
          <Link
            href={`/projects/${projectId}/step/6`}
            className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized"
          >
            {tCommon("continue")}
          </Link>
        ) : (
          <span
            aria-disabled="true"
            title={t("continueLocked")}
            className="cursor-not-allowed rounded-lg bg-bg-muted px-4 py-2 text-sm font-medium text-fg-subtle opacity-60"
          >
            {tCommon("continue")}
          </span>
        )}
      </nav>
    </div>
  );
}

/**
 * Explains why generation is unavailable and links back to step 4. Renders
 * nothing once an input exists.
 */
function MissingInputHint({
  hasUserInput,
  projectId,
}: {
  hasUserInput: boolean;
  projectId: string;
}) {
  const t = useTranslations("steps.creativeSparks");
  if (hasUserInput) return null;
  return (
    <p className="text-sm text-fg-error">
      {t("missingInput")}{" "}
      <Link
        href={`/projects/${projectId}/step/4`}
        className="font-medium underline underline-offset-2 hover:text-fg"
      >
        {t("missingInputLink")}
      </Link>
    </p>
  );
}

/** A stable signature of the server props, to detect real prop changes. */
function sig(items: TitledItem[] | null, selectedIndices: number[]): string {
  return JSON.stringify({ items, selectedIndices });
}

function SaveIndicator({ state }: { state: SaveState }) {
  const t = useTranslations("save");
  if (state === "saving") {
    return <span className="text-xs text-fg-subtle">{t("saving")}</span>;
  }
  if (state === "saved") {
    return <span className="text-xs text-fg-success">{t("saved")}</span>;
  }
  if (state === "error") {
    return <span className="text-xs text-fg-error">{t("failed")}</span>;
  }
  return null;
}
