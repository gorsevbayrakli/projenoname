import { getTranslations } from "next-intl/server";
import Link from "next/link";

import { TOTAL_STEPS } from "@/lib/workflow-steps";

/**
 * Temporary body for every wizard step in T13. It renders the step heading, a
 * "coming later" note, a disabled Üret button, and Back/Next navigation so the
 * shell (rail highlight + forward-lock + nav) can be verified now.
 *
 * T14–T21 replace each registry entry with the real step body (upload,
 * generate + results, selection). See step-registry.tsx.
 */
export async function StepPlaceholder({
  n,
  label,
  projectId,
  isCompleted,
}: {
  n: number;
  label: string;
  projectId: string;
  isCompleted: boolean;
}) {
  const t = await getTranslations();
  const prevN = n > 1 ? n - 1 : null;
  // Next is only reachable once this step is completed (forward-lock).
  const nextN = n < TOTAL_STEPS && isCompleted ? n + 1 : null;

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-8 px-4 py-8 sm:px-8 sm:py-10">
      <header className="flex flex-col gap-1">
        <div className="text-sm font-medium text-fg-subtle">
          {t("wizard.stepIndicator", { n, total: TOTAL_STEPS })}
        </div>
        <h1 className="text-2xl font-semibold tracking-tight text-fg">
          {label}
        </h1>
      </header>

      <div className="flex flex-col items-start gap-4 rounded-lg border border-border bg-bg p-8">
        <p className="text-fg-muted">{t("placeholder.comingSoon")}</p>
        <button
          type="button"
          disabled
          className="cursor-not-allowed rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast opacity-50"
        >
          {t("common.generate")}
        </button>
      </div>

      <nav className="flex items-center justify-between border-t border-border pt-4">
        {prevN ? (
          <Link
            href={`/projects/${projectId}/step/${prevN}`}
            className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
          >
            {t("common.back")}
          </Link>
        ) : (
          <span />
        )}
        {nextN ? (
          <Link
            href={`/projects/${projectId}/step/${nextN}`}
            className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized"
          >
            {t("common.next")}
          </Link>
        ) : (
          <span
            aria-disabled="true"
            title={t("placeholder.nextLocked")}
            className="cursor-not-allowed rounded-lg bg-bg-muted px-4 py-2 text-sm font-medium text-fg-subtle opacity-60"
          >
            {t("common.next")}
          </span>
        )}
      </nav>
    </div>
  );
}
