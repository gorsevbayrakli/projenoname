"use client";

import { useTranslations } from "next-intl";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

import { ErrorNotice } from "@/components/wizard/error-notice";
import { TOTAL_STEPS } from "@/lib/workflow-steps";

const AUTOSAVE_DELAY_MS = 800;

type SaveState = "idle" | "saving" | "saved" | "error";

/**
 * Client body for wizard step 4 — Ek Girdi (user_input).
 *
 * The simplest step: NOT generative (user_input has no schema in STEP_SCHEMAS
 * and runStep rejects it), so there is no "Üret" button and no <JobProgress>.
 * It is purely the user's typed text, persisted as content `{ text }` — the
 * shape gatherVars reads for the creative_sparks prompt's {User_input} variable.
 *
 * The text auto-saves (debounced) via PUT .../steps/user_input/content and
 * flushes any pending edit on unmount, which closes the legacy "advanced without
 * saving" bug class. The input is OPTIONAL, so "Devam →" is always enabled and
 * explicitly saves (awaited, even when empty) before navigating — writing the
 * row is what marks step 4 complete, and awaiting it avoids a race where step 5
 * would still be locked on arrival.
 */
export function UserInputStep({
  projectId,
  initialText,
}: {
  projectId: string;
  initialText: string | null;
}) {
  const t = useTranslations("steps.userInput");
  const tCommon = useTranslations("common");
  const tWizard = useTranslations("wizard");
  const tSave = useTranslations("save");
  const router = useRouter();

  const [text, setText] = useState(initialText ?? "");
  const [saveState, setSaveState] = useState<SaveState>("idle");
  const [isContinuing, setIsContinuing] = useState(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // The last value we successfully persisted, to skip redundant auto-saves. When
  // no row exists yet this seeds to "" so merely OPENING the step does not write
  // a row (and silently mark it complete); Devam saves unconditionally instead.
  const savedValueRef = useRef(initialText ?? "");
  // Latest text in a ref, so the unmount-only flush effect (empty deps, stale
  // closure) reads the current value rather than the mount-time one.
  const textRef = useRef(text);
  textRef.current = text;
  // The last server-provided value, to detect real prop changes vs. re-renders
  // where it is unchanged.
  const lastServerValue = useRef(initialText);

  // Sync local text from the server prop ONLY when the prop actually changes
  // (Next.js preserves client state across router.refresh()). Auto-save never
  // calls router.refresh(), so this cannot clobber in-progress edits.
  useEffect(() => {
    if (initialText !== lastServerValue.current) {
      lastServerValue.current = initialText;
      setText(initialText ?? "");
      savedValueRef.current = initialText ?? "";
      // The re-seed is not an edit: never leave a stale save indicator behind.
      setSaveState("idle");
    }
  }, [initialText]);

  // Debounced auto-save of the textarea.
  useEffect(() => {
    // Nothing to save. If a previous pass showed "Kaydediliyor…" and its timer
    // was cleared by this re-render (prop-sync re-seed), the indicator would
    // stick forever — so clear it here. Only "saving" is reset; a "saved" or
    // "error" result must stay visible.
    if (text === savedValueRef.current) {
      setSaveState((s) => (s === "saving" ? "idle" : s));
      return;
    }

    if (saveTimer.current) clearTimeout(saveTimer.current);
    setSaveState("saving");
    saveTimer.current = setTimeout(() => {
      void saveText(text);
    }, AUTOSAVE_DELAY_MS);

    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
    // saveText is stable enough for this effect's purpose; keying on text.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text]);

  // Flush a pending edit on unmount. "Geri" is a <Link> client navigation that
  // unmounts this component before the 800ms debounce fires, which would
  // silently drop the last keystrokes. Best-effort: keepalive PUT, failures
  // swallowed so they can never block navigation.
  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      const pending = textRef.current;
      if (pending === savedValueRef.current) return;
      try {
        void fetch(`/api/projects/${projectId}/steps/user_input/content`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: { text: pending } }),
          keepalive: true,
        }).catch(() => {});
      } catch {
        // best-effort; never block navigation on a flush failure
      }
    };
    // Mount/unmount only — projectId is stable for this component's lifetime.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function saveText(value: string): Promise<boolean> {
    try {
      const res = await fetch(
        `/api/projects/${projectId}/steps/user_input/content`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: { text: value } }),
        },
      );
      if (res.ok) {
        savedValueRef.current = value;
        setSaveState("saved");
        return true;
      }
      setSaveState("error");
      return false;
    } catch {
      setSaveState("error");
      return false;
    }
  }

  // Devam: cancel any pending debounce, save the CURRENT text (even empty —
  // that row is what completes the step), and only then navigate to step 5.
  async function handleContinue() {
    if (isContinuing) return;
    setIsContinuing(true);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    setSaveState("saving");
    const ok = await saveText(textRef.current);
    if (!ok) {
      setIsContinuing(false);
      return;
    }
    // refresh() so the wizard status (and the step-5 lock) reflects the new row.
    router.refresh();
    router.push(`/projects/${projectId}/step/5`);
  }

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-8 px-4 py-8 sm:px-8 sm:py-10">
      <header className="flex flex-col gap-1">
        <div className="text-sm font-medium text-fg-subtle">
          {tWizard("stepIndicator", { n: 4, total: TOTAL_STEPS })}
        </div>
        <h1 className="text-2xl font-semibold tracking-tight text-fg">
          {t("title")}
        </h1>
        <p className="mt-1 text-sm text-fg-muted">{t("description")}</p>

        {/* T27: the step that broke the first live run. Its old description
            invited "yön, tema veya kısıtlar", so a campaign GOAL read as a
            valid answer — and the prompt then treated that goal as the subject
            to write observations about. The rule, the read-it-back test and a
            worked example replace that ambiguity; the example is doing most of
            the work, so it is shown rather than described. */}
        <div className="mt-3 flex flex-col gap-2 rounded-lg border border-border bg-bg-muted px-3 py-2">
          <p className="text-sm text-fg-muted">{t("inputHint")}</p>
          <p className="text-sm text-fg-muted">
            <span className="font-medium text-fg">{t("exampleLabel")}: </span>
            <span className="italic">{t("example")}</span>
          </p>
        </div>
      </header>

      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <label
            htmlFor="user-input-textarea"
            className="text-sm font-medium text-fg"
          >
            {t("label")}
          </label>
          <SaveIndicator state={saveState} />
        </div>

        <textarea
          id="user-input-textarea"
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={14}
          placeholder={t("placeholder")}
          className="w-full resize-y rounded-lg border border-border bg-bg px-3 py-2 text-sm leading-relaxed text-fg outline-none placeholder:text-fg-subtle focus-visible:border-accent"
        />

        <span className="text-xs text-fg-subtle">{t("autosaveHint")}</span>

        {/* A failed save is more than a two-word indicator: it means the text on
            screen is NOT what step 5 will read, so it gets the full notice and a
            retry. */}
        {saveState === "error" ? (
          <ErrorNotice
            message={t("saveFailed")}
            onRetry={() => void saveText(textRef.current)}
          />
        ) : null}
      </div>

      {/* Navigation */}
      <nav className="flex items-center justify-between border-t border-border pt-4">
        <Link
          href={`/projects/${projectId}/step/3`}
          className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
        >
          {tCommon("back")}
        </Link>
        <button
          type="button"
          onClick={() => void handleContinue()}
          disabled={isContinuing}
          className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized disabled:cursor-not-allowed disabled:opacity-50"
        >
          {isContinuing ? tSave("saving") : tCommon("continue")}
        </button>
      </nav>
    </div>
  );
}

function SaveIndicator({ state }: { state: SaveState }) {
  const t = useTranslations("save");
  if (state === "saving") {
    return <span className="text-xs text-fg-subtle">{t("saving")}</span>;
  }
  if (state === "saved") {
    return <span className="text-xs text-fg-success">{t("saved")}</span>;
  }
  if (state === "error") {
    return <span className="text-xs text-fg-error">{t("failed")}</span>;
  }
  return null;
}
