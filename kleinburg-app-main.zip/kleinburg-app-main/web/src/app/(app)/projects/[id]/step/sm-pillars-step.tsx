"use client";

import { useTranslations } from "next-intl";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

import { EmptyState } from "@/components/wizard/empty-state";
import { JobErrorNotice } from "@/components/wizard/job-error-notice";
import { JobProgress } from "@/components/wizard/job-progress";
import {
  SelectablePillarList,
  type PillarItem,
} from "@/components/wizard/selectable-pillar-list";
import { useGenerate } from "@/components/wizard/use-generate";
import { TOTAL_STEPS } from "@/lib/workflow-steps";

const AUTOSAVE_DELAY_MS = 800;

type SaveState = "idle" | "saving" | "saved" | "error";

/**
 * Client body for wizard step 7 — SM Pillars (sm_pillars).
 *
 * Same generate → edit → auto-save shape as T16/T18 (debounced content save,
 * immediate selection save, prop-sync on regenerate, unmount flush), with the
 * pillar item shape and grouped <SelectablePillarList> rendering.
 *
 * ── THE LEGACY "CONSCIOUS RE-PICK" RULE WAS REMOVED (2026-07-21) ──────────
 * The pillar selection decides which pillars become posts (T20) and calendar
 * entries (T21). Legacy therefore forced a conscious re-pick on EVERY visit:
 * the step opened with nothing checked, and "Devam →" stayed locked until the
 * user picked again in that session. THE PRODUCT OWNER OVERTURNED THAT RULE.
 *
 * Elif returned to step 7 three times in a live run just to LOOK at what she
 * had selected. She found an empty page and was then blocked by "Devam etmek
 * için en az bir içerik sütunu seçin" — locked out of a step she had already
 * completed, by a rule meant to protect a decision she had already made.
 * #82 tried to fix this WITHOUT touching the rule: a "Geçen sefer seçildi"
 * badge, a count, and a one-click restore button. The badge rendered exactly
 * as designed and it still did not solve the problem, which is what settled
 * it — the information was never the missing piece, the checkboxes were.
 *
 * So the boxes are now SEEDED from the persisted selection, "Devam →" is
 * enabled whenever something is selected (which can be true straight from
 * persistence), and the whole #82 display is gone — a "restore previous
 * selection" button next to boxes already showing that selection is worse
 * than nothing.
 *
 * DO NOT RE-ADD THE RE-PICK GATE AS A FIX. Finding that this component seeds
 * itself from storage is not a regression you have discovered; it is the
 * decision above. Re-adding it re-breaks a returning user.
 *
 * ── WHAT STILL HOLDS (these ARE deliberate; do NOT "fix" them) ────────────
 *  1. NO WRITE ON MOUNT. Merely visiting the step must NOT persist anything.
 *     The selection PUT lives ONLY inside handleSelectionChange (a user-driven
 *     checkbox/bulk action), never in an effect, so the stored selection
 *     survives untouched until the user actively changes it. SEEDING STATE IS
 *     NOT WRITING — the seed reads the value the server already sent and puts
 *     it in useState; nothing goes back over the wire. Guarded by a test that
 *     predates the reversal and is unchanged by it.
 *  2. THE LOCK USES THE PERSISTED SELECTION. The rail ✓ and step 8's
 *     forward-lock read wizard-status's sm_pillars predicate (persisted
 *     selections.selectedIndices >= 1), NOT this component's state. That was
 *     already true and is now simply consistent with what the page shows,
 *     instead of contradicting it.
 *  3. A REGENERATE CLEARS THE SELECTION (see the prop-sync effect). Those
 *     indices addressed the OLD pillars and describe nothing about the new
 *     ones, so seeding them against fresh content would tick arbitrary cards.
 * ─────────────────────────────────────────────────────────────────────────
 */
export function SmPillarsStep({
  projectId,
  initialPillars,
  initialSelectedIndices,
}: {
  projectId: string;
  initialPillars: PillarItem[] | null;
  /**
   * The PERSISTED selection, already clamped to the pillar count by
   * step-7.tsx. APPLIED as the initial checkbox state — hence the name; it was
   * `previousSelectedIndices` while the re-pick rule stood and it was display
   * data then. [] when nothing is stored.
   */
  initialSelectedIndices: number[];
}) {
  const t = useTranslations("steps.smPillars");
  const tCommon = useTranslations("common");
  const tWizard = useTranslations("wizard");
  const router = useRouter();
  const { generate, jobId, isGenerating, error, reset } = useGenerate(
    projectId,
    "sm_pillars",
  );

  const [pillars, setPillars] = useState<PillarItem[]>(initialPillars ?? []);
  // SEEDED FROM PERSISTENCE (2026-07-21 reversal — see the docblock). A
  // useState initial value, so it is read once at mount and never written back;
  // rule 1 above (no write on mount) is untouched by this.
  const [selectedIndices, setSelectedIndices] =
    useState<number[]>(initialSelectedIndices);
  const [saveState, setSaveState] = useState<SaveState>("idle");
  // Error from a failed generation job (kept in local state so it survives the
  // <JobProgress> unmount on failure). Cleared when a new generation starts.
  const [jobError, setJobError] = useState<string | null>(null);

  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // The last pillars array we successfully persisted, to skip redundant saves.
  // Seeded from the server value so the mount render never triggers a content
  // PUT either.
  const savedPillarsRef = useRef(JSON.stringify(initialPillars ?? []));
  // Latest pillars in a ref, so the unmount-only flush effect can read the
  // current value rather than the mount-time one.
  const pillarsRef = useRef(pillars);
  pillarsRef.current = pillars;
  // The last server-provided signature, to detect real prop changes (from a
  // router.refresh() after generation) vs. re-renders where it is unchanged.
  const lastServerSig = useRef(JSON.stringify(initialPillars));

  const hasContent = initialPillars !== null;
  const selectedCount = selectedIndices.length;
  // Anything selected unlocks Devam — including a selection that arrived from
  // persistence via the seed. The "must have picked in THIS session" gate was
  // removed on 2026-07-21; see the docblock.
  const canContinue = selectedCount >= 1;
  const displayError = error ?? jobError;

  function startGenerate() {
    setJobError(null);
    reset();
    void generate();
  }

  // Sync local state from the server props ONLY when they actually change (a
  // fresh generation / Yeniden üret → new pillars). Auto-save never calls
  // router.refresh(), so this won't clobber in-progress edits.
  // NOTE: this effect never issues a selection PUT (rule 1).
  useEffect(() => {
    const next = JSON.stringify(initialPillars);
    if (next !== lastServerSig.current) {
      lastServerSig.current = next;
      setPillars(initialPillars ?? []);
      // NONE selected after a regenerate, even though mount seeds from
      // persistence (rule 3). The stored indices addressed the pillars that
      // were just replaced, so carrying them over would tick arbitrary cards —
      // claiming the user picked a pillar they have never seen.
      setSelectedIndices([]);
      savedPillarsRef.current = JSON.stringify(initialPillars ?? []);
      // The re-seed is not an edit: drop any indicator left over from the
      // previous content (a regenerate must not look like a pending save).
      setSaveState("idle");
    }
  }, [initialPillars]);

  // Debounced auto-save of pillar edits. Only runs when content already exists,
  // and only when the serialized value actually differs from what we persisted
  // (so the initial seed is a no-op).
  useEffect(() => {
    if (!hasContent) return;
    const serialized = JSON.stringify(pillars);
    // Nothing to save. If a previous pass showed "Kaydediliyor…" and its timer
    // was cleared by this re-render (prop-sync re-seed), the indicator would
    // stick forever — so clear it here. Only "saving" is reset; a "saved" or
    // "error" result must stay visible.
    if (serialized === savedPillarsRef.current) {
      setSaveState((s) => (s === "saving" ? "idle" : s));
      return;
    }

    if (saveTimer.current) clearTimeout(saveTimer.current);
    setSaveState("saving");
    saveTimer.current = setTimeout(() => {
      void savePillars(pillars);
    }, AUTOSAVE_DELAY_MS);

    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pillars, hasContent]);

  // Flush a pending pillar edit on unmount (Geri/Devam are client navigations
  // that unmount before the debounce fires). Best-effort keepalive; a failed
  // flush is swallowed and must never crash navigation. Content only — the
  // selection is never flushed here (rule 1: no write on mount/unmount).
  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      const pending = JSON.stringify(pillarsRef.current);
      if (pending === savedPillarsRef.current) return;
      try {
        void fetch(`/api/projects/${projectId}/steps/sm_pillars/content`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: { pillars: pillarsRef.current } }),
          keepalive: true,
        }).catch(() => {});
      } catch {
        // best-effort; never block navigation on a flush failure
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function savePillars(value: PillarItem[]) {
    try {
      const res = await fetch(
        `/api/projects/${projectId}/steps/sm_pillars/content`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: { pillars: value } }),
        },
      );
      if (res.ok) {
        savedPillarsRef.current = JSON.stringify(value);
        setSaveState("saved");
        return;
      }
      setSaveState("error");
    } catch {
      setSaveState("error");
    }
  }

  // Selection is a discrete action — save it immediately (no debounce).
  async function saveSelection(indices: number[]) {
    try {
      const res = await fetch(
        `/api/projects/${projectId}/steps/sm_pillars/content`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ selections: { selectedIndices: indices } }),
        },
      );
      setSaveState(res.ok ? "saved" : "error");
    } catch {
      setSaveState("error");
    }
  }

  // The ONLY caller of saveSelection. Reached exclusively from a user action in
  // <SelectablePillarList> (checkbox toggle, Tümünü seç, Temizle) — never from
  // an effect, so mounting the step cannot overwrite the persisted selection.
  function handleSelectionChange(indices: number[]) {
    setSelectedIndices(indices);
    setSaveState("saving");
    void saveSelection(indices);
  }

  function handleJobDone(result: { status: string; error?: string }) {
    if (result.status === "succeeded") {
      // The worker upserted step_contents; reload to render the new list, then
      // reset() so the terminal <JobProgress> unmounts and can't re-fire onDone.
      router.refresh();
      reset();
      return;
    }
    setJobError(result.error ?? tCommon("generationFailed"));
    reset();
  }

  // max-w-6xl, wider than the 3xl of the non-listing steps: this step renders a
  // card GRID (#44) and a 3xl column has no room for a second track. The other
  // steps stay narrow because a form column reads better short.
  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8 sm:px-8 sm:py-10">
      <header className="flex flex-col gap-1">
        <div className="text-sm font-medium text-fg-subtle">
          {tWizard("stepIndicator", { n: 7, total: TOTAL_STEPS })}
        </div>
        <h1 className="text-2xl font-semibold tracking-tight text-fg">
          {t("title")}
        </h1>
        <p className="mt-1 text-sm text-fg-muted">{t("description")}</p>
        {/* T27: what this step DOES vs what YOU write here are different
            questions. The first live run failed because only the first was
            answered, so the guidance gets its own block rather than another
            sentence in the description nobody finishes reading. */}
        <p className="mt-3 rounded-lg border border-border bg-bg-muted px-3 py-2 text-sm text-fg-muted">
          {t("inputHint")}
        </p>
      </header>

      {!hasContent ? (
        jobId ? (
          <div className="flex flex-col gap-3 rounded-lg border border-border bg-bg p-4">
            <JobProgress jobId={jobId} onDone={handleJobDone} />
          </div>
        ) : displayError ? (
          <JobErrorNotice
            error={displayError}
            projectId={projectId}
            onRetry={startGenerate}
          />
        ) : (
          <EmptyState
            title={t("emptyTitle")}
            description={t("emptyDescription")}
            action={
              <button
                type="button"
                disabled={isGenerating}
                onClick={startGenerate}
                className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isGenerating ? tCommon("starting") : tCommon("generate")}
              </button>
            }
          />
        )
      ) : (
        <div className="flex flex-col gap-4">
          {jobId ? (
            <div className="flex flex-col gap-3 rounded-lg border border-border bg-bg p-4">
              <JobProgress jobId={jobId} onDone={handleJobDone} />
            </div>
          ) : displayError ? (
            <JobErrorNotice
              error={displayError}
              projectId={projectId}
              onRetry={startGenerate}
            />
          ) : null}

          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-fg">{t("listLabel")}</span>
            <SaveIndicator state={saveState} />
          </div>

          {/* The #82 summary line and "Önceki seçimi geri yükle" button stood
              here until 2026-07-21. They existed only because the boxes opened
              empty; now that the boxes carry the stored selection, offering to
              restore it next to itself just raises a question the page has
              already answered. Removed with the re-pick rule, not separately. */}

          <SelectablePillarList
            pillars={pillars}
            selectedIndices={selectedIndices}
            onPillarsChange={setPillars}
            onSelectionChange={handleSelectionChange}
          />

          <div className="flex items-center justify-between gap-3">
            {!canContinue ? (
              <p className="text-sm text-fg-error">{t("selectHint")}</p>
            ) : (
              <span />
            )}
            <button
              type="button"
              disabled={isGenerating}
              onClick={startGenerate}
              className="shrink-0 rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isGenerating ? tCommon("starting") : tCommon("regenerate")}
            </button>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex items-center justify-between border-t border-border pt-4">
        <Link
          href={`/projects/${projectId}/step/6`}
          className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
        >
          {tCommon("back")}
        </Link>
        {canContinue ? (
          <Link
            href={`/projects/${projectId}/step/8`}
            className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized"
          >
            {tCommon("continue")}
          </Link>
        ) : (
          <span
            aria-disabled="true"
            title={t("continueLocked")}
            className="cursor-not-allowed rounded-lg bg-bg-muted px-4 py-2 text-sm font-medium text-fg-subtle opacity-60"
          >
            {tCommon("continue")}
          </span>
        )}
      </nav>
    </div>
  );
}

function SaveIndicator({ state }: { state: SaveState }) {
  const t = useTranslations("save");
  if (state === "saving") {
    return <span className="text-xs text-fg-subtle">{t("saving")}</span>;
  }
  if (state === "saved") {
    return <span className="text-xs text-fg-success">{t("saved")}</span>;
  }
  if (state === "error") {
    return <span className="text-xs text-fg-error">{t("failed")}</span>;
  }
  return null;
}
