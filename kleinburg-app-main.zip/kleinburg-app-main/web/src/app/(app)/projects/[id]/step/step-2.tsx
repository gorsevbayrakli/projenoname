import { redirect } from "next/navigation";

import { getStepContent } from "@/core/pipeline/inputs";
import { requireProjectAccess } from "@/core/tenancy/access";
import { getCurrentUser } from "@/lib/auth-server";
import { BrandContextStep } from "./brand-context-step";

/**
 * Wizard step 2 — Marka Bağlamı (brand context).
 *
 * Server wrapper: repeats requireProjectAccess (defense-in-depth per the T13
 * note) and loads the brand_context step_contents row, extracting the current
 * brandContext text (if any) for the client editor.
 */
export async function Step2({ projectId }: { projectId: string }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  try {
    await requireProjectAccess(user.id, projectId);
  } catch {
    redirect("/projects");
  }

  const row = await getStepContent(projectId, "brand_context");
  const brandContext = extractBrandContext(row?.content);

  return (
    <BrandContextStep projectId={projectId} initialBrandContext={brandContext} />
  );
}

/** content.brandContext when the row holds a string, else null (no content yet). */
function extractBrandContext(content: unknown): string | null {
  if (
    content &&
    typeof content === "object" &&
    "brandContext" in content &&
    typeof (content as { brandContext: unknown }).brandContext === "string"
  ) {
    return (content as { brandContext: string }).brandContext;
  }
  return null;
}
