import { redirect } from "next/navigation";

import { getWizardStatus } from "@/lib/wizard-status";

/**
 * /projects/[id] — the wizard entry point. Access is already gated by the
 * layout; this just sends the user to their current (first-incomplete) step.
 */
export default async function ProjectWizardIndex({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const { current } = await getWizardStatus(id);
  redirect(`/projects/${id}/step/${current}`);
}
