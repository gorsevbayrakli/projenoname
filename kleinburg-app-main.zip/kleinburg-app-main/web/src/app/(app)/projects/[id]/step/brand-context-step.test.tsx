// @vitest-environment jsdom
//
// Component test for wizard step 2 (Marka Bağlamı). This is the FIRST component
// test in the repo and establishes the pattern reused by T16–T21: per-file
// jsdom env (the global vitest env stays `node` so DB tests keep running),
// next/navigation mocked, and fetch mocked. It locks the Critical regression:
// after generation completes, router.refresh() re-renders the server component
// with the new brandContext prop, and the client must sync its local textarea
// state to that prop instead of keeping the stale empty string.
//
// The component is authored in JSX; the test itself uses React.createElement
// (aliased `h`) so this file needs no JSX transform — vitest's default (oxc)
// transform handles the imported *.tsx component, and we avoid adding a
// Babel-based React plugin that conflicts with shadcn's pinned @babel/core.

import { act, cleanup, fireEvent, screen } from "@testing-library/react";

// T25: rendered through renderWithIntl, which wraps the component in
// NextIntlClientProvider with the REAL Turkish catalog — so every assertion
// below still checks the exact Turkish a user reads.
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const refreshMock = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    refresh: refreshMock,
    push: vi.fn(),
    replace: vi.fn(),
    back: vi.fn(),
    forward: vi.fn(),
    prefetch: vi.fn(),
  }),
}));

// EventSource isn't in jsdom; JobProgress opens one. Stub it so mounting the
// component never throws. These tests stay on the no-job path.
// The failed-generation test drives this stub directly: it pushes a terminal
// SSE payload into the live instance, which is what a real failing job does.
const sources: FakeEventSource[] = [];
class FakeEventSource {
  constructor() {
    sources.push(this);
  }
  close() {}
  onmessage: ((e: MessageEvent) => void) | null = null;
  onerror: (() => void) | null = null;
}
vi.stubGlobal("EventSource", FakeEventSource);

import { BrandContextStep } from "./brand-context-step";

const GENERATED = "x".repeat(240); // ≥ MIN_CHARS (200)

/** The URL of the nth fetch call (the mock's tuple type is not indexable). */
function generateUrlAt(mock: { mock: { calls: unknown[] } }, n: number): string {
  return (mock.mock.calls[n] as [string, ...unknown[]])[0];
}

function step(initialBrandContext: string | null) {
  return h(BrandContextStep, { projectId: "p1", initialBrandContext });
}

beforeEach(() => {
  refreshMock.mockClear();
  sources.length = 0;
  vi.stubGlobal(
    "fetch",
    vi.fn(() =>
      Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve({}) }),
    ),
  );
});

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.useRealTimers();
});

describe("BrandContextStep", () => {
  it("syncs the textarea when the server prop changes null → generated string (Critical regression)", () => {
    const { rerender } = render(step(null));

    // No content yet: the editable textarea is not rendered.
    expect(screen.queryByLabelText("Marka bağlamı")).toBeNull();

    // Simulate router.refresh() re-fetching the server component: the prop
    // flips from null to the worker-saved generated text.
    rerender(step(GENERATED));

    const textarea = screen.getByLabelText(
      "Marka bağlamı",
    ) as HTMLTextAreaElement;
    // Without the prop-sync fix this stays "" (stale useState) and the test fails.
    expect(textarea.value).toBe(GENERATED);
  });

  it("reflects the synced text in the char counter and enables Devam", () => {
    const { rerender } = render(step(null));
    rerender(step(GENERATED));

    expect(screen.getByText(`${GENERATED.length} karakter`)).toBeTruthy();
    // Devam is a real <Link> (enabled) only at ≥ MIN_CHARS.
    const devam = screen.getByRole("link", { name: /Devam/ });
    expect(devam.getAttribute("href")).toBe("/projects/p1/step/3");
  });

  it("debounced-saves an edit via PUT to the content route", async () => {
    vi.useFakeTimers();
    const fetchMock = vi.fn(() =>
      Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve({}) }),
    );
    vi.stubGlobal("fetch", fetchMock);

    render(step("seed content ".repeat(20)));

    const textarea = screen.getByLabelText(
      "Marka bağlamı",
    ) as HTMLTextAreaElement;
    fireEvent.change(textarea, { target: { value: "edited " + GENERATED } });

    // Before the debounce elapses, no save.
    expect(fetchMock).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(900);

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ];
    expect(url).toBe("/api/projects/p1/steps/brand_context/content");
    expect(init.method).toBe("PUT");
    expect(String(init.body)).toContain("edited ");
  });

  // T22: a failed generation must read as a sentence a non-engineer can act on,
  // must still carry the raw reason, and must offer a retry that actually
  // re-POSTs the generation.
  it("renders the humanized failure + raw reason + a working Tekrar dene", async () => {
    const fetchMock = vi.fn(() =>
      Promise.resolve({
        ok: true,
        status: 202,
        json: () => Promise.resolve({ jobId: "job-1" }),
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    render(step(null));

    // Empty state first: title + the step's Üret action.
    expect(screen.getByText("Henüz marka bağlamı yok")).toBeTruthy();

    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: "Üret" }));
    });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(generateUrlAt(fetchMock, 0)).toBe(
      "/api/projects/p1/steps/brand_context/generate",
    );

    // The job fails with a schema violation (LlmPermanentError).
    const raw = "Model çıktısı beklenen şemaya uymadı";
    await act(async () => {
      sources[0].onmessage?.({
        data: JSON.stringify({ status: "failed", error: raw }),
      } as MessageEvent);
    });

    const alert = screen.getByRole("alert");
    expect(alert.textContent).toContain("Model beklenen yapıda içerik üretmedi");
    // The truth is still on screen (hard rule 5).
    expect(alert.textContent).toContain(raw);

    // Retry re-runs the generation.
    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: "Tekrar dene" }));
    });
    expect(fetchMock).toHaveBeenCalledTimes(2);
    expect(generateUrlAt(fetchMock, 1)).toBe(
      "/api/projects/p1/steps/brand_context/generate",
    );
  });
});

/**
 * T35. A thin tone section is the input the post prompts silently fall back
 * from, so step 2 says so — and only says so. The tests below are the contract:
 * shown when weak, absent when rich, and never in the way.
 *
 * Silence is asserted on the warning's own TEXT, not on the absence of any
 * `role="status"` node. The live region is deliberately always mounted (an
 * inserted-with-content region is not reliably announced), and any other polite
 * region on the step — a save indicator, a progress line — would otherwise make
 * these tests lie in either direction.
 */
describe("BrandContextStep tone warning", () => {
  const TONE_WARNING = /Ton bölümü zayıf görünüyor/;

  /** The warning's text node, or null when the region is empty. */
  function toneWarning(): HTMLElement | null {
    return screen.queryByText(TONE_WARNING);
  }

  /** A brand context whose last bullet is the tone section under test. */
  function contextWith(tone: string): string {
    return [
      "## CONTEXT for Brand Key: Örnek Marka",
      "",
      "- **Genel bilgi:** Bölgesel bir kahve kavurmacısı, tek kökenli çekirdek satıyor.",
      "- **Değerler:** Meraklı, titiz, zanaat konusunda gösterişsiz.",
      "- **Öz:** Yavaşlamaya değer kahve.",
      "- **Hedef kitle:** Evde pişiren, 25-45 yaş şehirli profesyoneller.",
      tone,
    ].join("\n");
  }

  const WEAK = contextWith(
    [
      "- **Ses tonu:**",
      "  - Ses: —",
      "  - Örnek cümleler: —",
      "  - Asla: —",
    ].join("\n"),
  );

  const RICH = contextWith(
    [
      "- **Ses tonu:**",
      "  - Ses: sıcak ve net; tezgâhın arkasından konuşan bir kavurmacı gibi.",
      "    Kısa cümleler, somut isimler, ölçünün yeteceği yerde asla abartı yok.",
      '  - Örnek cümleler: 1) "Bu, yazın son haftası gibi kokuyor." 2) "Üç derece',
      '    daha açık kavurduk, her şey değişti." 3) "Bugün ne içiyoruz, sorun."',
      "  - Asla: abartı kelimeler yok, ünlem yok, yolculuk edebiyatı yok.",
    ].join("\n"),
  );

  it("warns when the generated tone section is weak", () => {
    render(step(WEAK));

    const warning = toneWarning();
    expect(warning).toBeTruthy();
    // The fix is named, not just the problem.
    expect(warning!.closest("[role='status']")!.textContent).toContain(
      "ton rehberi",
    );
  });

  it("announces from a live region that existed before the warning did", () => {
    // Several screen-reader/browser pairs never announce a live region that is
    // inserted into the DOM with its content already in place, so the region
    // must be mounted while silent and only its children may toggle.
    const { container } = render(step(RICH));

    const region = container.querySelector("[role='status']");
    expect(region).toBeTruthy();
    expect(region!.getAttribute("aria-live")).toBe("polite");
    expect(region!.textContent).toBe("");
  });

  it("stays silent when the tone section is rich", () => {
    render(step(RICH));

    expect(toneWarning()).toBeNull();
  });

  it("does not warn before any content exists", () => {
    render(step(null));

    expect(toneWarning()).toBeNull();
  });

  it("blocks neither navigation nor regeneration while warning", () => {
    // The whole point of warn-rather-than-block: some brands genuinely have no
    // tone document and must still be able to finish the wizard.
    render(step(WEAK));

    expect(toneWarning()).toBeTruthy();

    // Devam is a real enabled <Link> to step 3, exactly as without the warning.
    const devam = screen.getByRole("link", { name: /Devam/ });
    expect(devam.getAttribute("href")).toBe("/projects/p1/step/3");
    expect(devam.getAttribute("aria-disabled")).toBeNull();

    // Yeniden üret is still clickable, and the textarea is still editable.
    const regenerate = screen.getByRole("button", {
      name: "Yeniden üret",
    }) as HTMLButtonElement;
    expect(regenerate.disabled).toBe(false);

    const textarea = screen.getByLabelText(
      "Marka bağlamı",
    ) as HTMLTextAreaElement;
    expect(textarea.readOnly).toBe(false);
    expect(textarea.disabled).toBe(false);
  });

  it("clears the warning once the user enriches the tone section by hand", async () => {
    vi.useFakeTimers();
    render(step(WEAK));
    expect(toneWarning()).toBeTruthy();

    const textarea = screen.getByLabelText(
      "Marka bağlamı",
    ) as HTMLTextAreaElement;
    fireEvent.change(textarea, { target: { value: RICH } });

    // The verdict is debounced on the autosave's beat, so it does not flicker
    // under the cursor while an example line is half-typed.
    expect(toneWarning()).toBeTruthy();
    await vi.advanceTimersByTimeAsync(900);

    expect(toneWarning()).toBeNull();
  });

  it("does not re-judge the text on every keystroke", async () => {
    // The assessment walks the whole context; running it inline on each render
    // put milliseconds of work on the typing path of a very large textarea.
    vi.useFakeTimers();
    render(step(RICH));

    const textarea = screen.getByLabelText(
      "Marka bağlamı",
    ) as HTMLTextAreaElement;
    // Mid-word through deleting the examples: still no warning, because the
    // verdict has not been recomputed yet.
    fireEvent.change(textarea, { target: { value: WEAK } });
    expect(toneWarning()).toBeNull();

    await vi.advanceTimersByTimeAsync(900);
    expect(toneWarning()).toBeTruthy();
  });
});
