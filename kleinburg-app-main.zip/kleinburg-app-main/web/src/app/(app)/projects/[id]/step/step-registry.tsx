import { getTranslations } from "next-intl/server";

import { stepByNumber } from "@/lib/workflow-steps";
import { StepPlaceholder } from "./step-placeholder";
import { Step1 } from "./step-1";
import { Step2 } from "./step-2";
import { Step3 } from "./step-3";
import { Step4 } from "./step-4";
import { Step5 } from "./step-5";
import { Step6 } from "./step-6";
import { Step7 } from "./step-7";
import { Step8 } from "./step-8";
import { Step9 } from "./step-9";

/**
 * Maps a step number (1..9) to its body component. The step page looks the
 * active step up here after computing status + lock, so real step bodies drop
 * in without touching routing/lock logic.
 *
 * T14–T21 replaced every entry with its real step body, so <StepPlaceholder />
 * now only serves the `default` arm — an out-of-range step number, which the
 * step page's own bounds check should already have rejected.
 */
export type StepBodyProps = {
  n: number;
  projectId: string;
  isCompleted: boolean;
};

export async function renderStep(props: StepBodyProps) {
  const meta = stepByNumber(props.n);
  const t = await getTranslations();
  const label = meta
    ? t(`stepLabels.${meta.key}`)
    : t("wizard.fallbackLabel", { n: props.n });

  switch (props.n) {
    // T14: Belge Yükleme (documents upload).
    case 1:
      return <Step1 projectId={props.projectId} />;
    // T15: Marka Bağlamı.
    case 2:
      return <Step2 projectId={props.projectId} />;
    // T16: Bakış Açıları (storage key secondary_data; renamed in T47).
    case 3:
      return <Step3 projectId={props.projectId} />;
    // T17: Ek Girdi.
    case 4:
      return <Step4 projectId={props.projectId} />;
    // T18: Creative Sparks.
    case 5:
      return <Step5 projectId={props.projectId} />;
    // T29: Platform Seçimi — before the pillars, which are generated for it.
    case 6:
      return <Step6 projectId={props.projectId} />;
    // T19: SM Pillars.
    case 7:
      return <Step7 projectId={props.projectId} />;
    // T20: SM Posts.
    case 8:
      return <Step8 projectId={props.projectId} />;
    // T21: İçerik Takvimi.
    case 9:
      return <Step9 projectId={props.projectId} />;
    default:
      return (
        <StepPlaceholder
          n={props.n}
          label={label}
          projectId={props.projectId}
          isCompleted={props.isCompleted}
        />
      );
  }
}
