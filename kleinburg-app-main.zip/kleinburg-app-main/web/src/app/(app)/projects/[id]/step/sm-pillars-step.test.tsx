// @vitest-environment jsdom
//
// Component test for wizard step 7 (SM Pillars / sm_pillars), mirroring the
// T15/T17/T18 step-test pattern: per-file jsdom env, next/navigation mocked,
// fetch mocked, React.createElement (aliased `h`).
//
// THE LEGACY "CONSCIOUS RE-PICK" RULE WAS REMOVED ON 2026-07-21 by the product
// owner. Until then the step opened with NOTHING checked and "Devam →" needed a
// pick made in THIS session; the cases below asserted exactly that, and they
// have been INVERTED rather than deleted so the record of the reversal survives
// where a future reader will trip over it.
//
// Why it went: Elif returned to step 7 three times only to LOOK at her stored
// selection, found an empty page, and was blocked by "Devam etmek için en az bir
// içerik sütunu seçin" — from continuing past a step she had already completed.
// #82 tried to solve it with a "Geçen sefer seçildi" badge and a restore button;
// the badge rendered correctly and it still did not solve it. So the boxes are
// now pre-checked from persistence, and the badge/summary/restore went with it.
//
// WHAT STILL HOLDS, and is still locked below:
//   - NO WRITE ON MOUNT. Visiting the step must never PUT. Seeding state is not
//     writing, and that test is unchanged from before the reversal.
//   - A regenerate still clears the selection: those indices addressed the old
//     pillars.
//   - With nothing stored, "Devam →" is still locked. The gate did not go away;
//     it just reads persistence now instead of session-only state.

import { cleanup, fireEvent, screen } from "@testing-library/react";

// T25: rendered through renderWithIntl, which wraps the component in
// NextIntlClientProvider with the REAL Turkish catalog — so every assertion
// below still checks the exact Turkish a user reads.
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const refreshMock = vi.fn();
const pushMock = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    refresh: refreshMock,
    push: pushMock,
    replace: vi.fn(),
    back: vi.fn(),
    forward: vi.fn(),
    prefetch: vi.fn(),
  }),
}));

import type { PillarItem } from "@/components/wizard/selectable-pillar-list";
import en from "../../../../../../messages/en.json";
import tr from "../../../../../../messages/tr.json";
import { SmPillarsStep } from "./sm-pillars-step";

function p(category: string, title: string): PillarItem {
  return {
    category,
    title,
    topicBlend: `${title}-blend`,
    creativeSpark: `${title}-spark`,
    hook: `${title}-hook`,
    contentBrief: `${title}-brief`,
  };
}

const PILLARS: PillarItem[] = [
  p("ENTERTAINING", "E1"),
  p("INSPIRATIONAL", "I1"),
  p("INFORMATIONAL", "N1"),
];

function step(
  opts: {
    pillars?: PillarItem[] | null;
    initialSelectedIndices?: number[];
  } = {},
) {
  return h(SmPillarsStep, {
    projectId: "p1",
    initialPillars: opts.pillars === undefined ? null : opts.pillars,
    initialSelectedIndices: opts.initialSelectedIndices ?? [],
  });
}

function okFetch() {
  return vi.fn(() =>
    Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve({}) }),
  );
}

beforeEach(() => {
  refreshMock.mockClear();
  pushMock.mockClear();
  vi.stubGlobal("fetch", okFetch());
});

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  vi.useRealTimers();
});

describe("SmPillarsStep", () => {
  // ── THE REVERSAL (2026-07-21) ────────────────────────────────────────────
  // INVERTED. This case used to read "opens with NOTHING checked even though a
  // selection is persisted" and asserted `boxes.every((b) => !b.checked)`. The
  // product owner overturned that rule after being blocked three times on a
  // return visit; see the file header. Same fixture, opposite expectation.
  it("opens with the STORED selection already checked", () => {
    render(step({ pillars: PILLARS, initialSelectedIndices: [0, 2] }));

    // Addressed by LABEL, not by DOM order: the list renders grouped by
    // category (INSPIRATIONAL → ENTERTAINING → INFORMATIONAL) while the stored
    // indices are flat array positions, so reading getAllByRole order here
    // would quietly assert the wrong pillars.
    const checked = (n: number) =>
      (screen.getByLabelText(`Pillar ${n} seç`) as HTMLInputElement).checked;
    // Exactly the stored indices (flat 0 and 2 -> labels 1 and 3), not all and
    // not none.
    expect([checked(1), checked(2), checked(3)]).toEqual([true, false, true]);
    expect(screen.getAllByRole("checkbox")).toHaveLength(3);
    expect(screen.getByText("2 / 3 seçili")).toBeTruthy();
  });

  it("still opens with nothing checked when nothing is stored", () => {
    // The seed is the STORED value, not a blanket "select everything".
    render(step({ pillars: PILLARS, initialSelectedIndices: [] }));

    const boxes = screen.getAllByRole("checkbox") as HTMLInputElement[];
    expect(boxes.every((b) => !b.checked)).toBe(true);
    expect(screen.getByText("0 / 3 seçili")).toBeTruthy();
  });

  // UNCHANGED BY THE REVERSAL, deliberately. Seeding state is not writing:
  // merely visiting the step must still never issue a selection PUT, or a
  // returning user's stored selection could be overwritten by a page view.
  it("fires NO selection PUT on mount (the persisted selection must survive)", async () => {
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);
    vi.useFakeTimers({ shouldAdvanceTime: true });

    try {
      // With a stored selection present: seeding it must not write it back.
      render(step({ pillars: PILLARS, initialSelectedIndices: [0, 2] }));

      // Past the 800ms auto-save debounce too: a regression that routed the
      // selection through the debounce (instead of firing it directly) must
      // also fail here, not just an effect that PUTs synchronously.
      await vi.advanceTimersByTimeAsync(900);
      expect(fetchMock).not.toHaveBeenCalled();
    } finally {
      vi.useRealTimers();
    }
  });

  it("fires no PUT on mount for an empty-content step either", async () => {
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);

    render(step({ pillars: null }));
    await Promise.resolve();
    expect(fetchMock).not.toHaveBeenCalled();
  });

  // INVERTED. This case used to read "Devam is disabled until a pick is made in
  // this session" and asserted the link was ABSENT with a stored selection of
  // [0, 1, 2]. That assertion IS the bug Elif hit: it locked a user out of a
  // step she had already completed. Same fixture, opposite expectation.
  it("Devam is enabled by the stored selection alone, with no pick this session", () => {
    render(step({ pillars: PILLARS, initialSelectedIndices: [0, 1, 2] }));

    expect(
      screen.getByRole("link", { name: /Devam/ }).getAttribute("href"),
    ).toBe("/projects/p1/step/8");
    expect(
      screen.queryByText(/Devam etmek için en az bir içerik sütunu seçin/),
    ).toBeNull();
  });

  it("Devam is still locked when nothing is stored and nothing is picked", () => {
    // The gate did not disappear with the reversal — it reads persistence now.
    render(step({ pillars: PILLARS, initialSelectedIndices: [] }));

    expect(screen.queryByRole("link", { name: /Devam/ })).toBeNull();
    expect(
      screen.getByText(/Devam etmek için en az bir içerik sütunu seçin/),
    ).toBeTruthy();
  });

  it("unchecking the last seeded box locks Devam again and PUTs the empty selection", async () => {
    // The seed is real editable state, not a cosmetic tick: clearing it has to
    // behave exactly like clearing a selection made by hand.
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);

    render(step({ pillars: PILLARS, initialSelectedIndices: [0] }));
    expect(screen.getByRole("link", { name: /Devam/ })).toBeTruthy();

    fireEvent.click(screen.getByLabelText("Pillar 1 seç"));

    await vi.waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    const [, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(JSON.parse(String(init.body))).toEqual({
      selections: { selectedIndices: [] },
    });
    expect(screen.queryByRole("link", { name: /Devam/ })).toBeNull();
  });

  // ── THE #82 DISPLAY IS GONE ──────────────────────────────────────────────
  // The badge, the summary line and the one-click restore button existed only
  // because the boxes opened empty. With the boxes pre-checked they are
  // redundant, and a "restore previous selection" button sitting next to boxes
  // that are ALREADY showing that selection is actively misleading. These cases
  // replace the four that used to assert the display renders.
  describe("the #82 previous-selection display", () => {
    it("renders no badge, summary or restore button", () => {
      render(step({ pillars: PILLARS, initialSelectedIndices: [0, 2] }));

      expect(screen.queryByText(/Geçen sefer/)).toBeNull();
      expect(screen.queryByRole("button", { name: /Önceki seçimi/ })).toBeNull();
    });

    it("left no orphaned message keys behind in either catalog", () => {
      // A removed UI whose keys survive is how a catalog rots. Key parity
      // between tr and en is checked in i18n/messages.test.ts; what is checked
      // here is that these three are gone from BOTH.
      for (const catalog of [tr, en] as Record<string, unknown>[]) {
        const pillarList = catalog.pillarList as Record<string, unknown>;
        const smPillars = (
          (catalog.steps as Record<string, unknown>).smPillars
        ) as Record<string, unknown>;
        expect(pillarList.previouslySelected).toBeUndefined();
        expect(smPillars.previousSelectionSummary).toBeUndefined();
        expect(smPillars.restorePreviousSelection).toBeUndefined();
      }
    });
  });

  it("a regenerate clears the seeded selection", () => {
    // The stored indices addressed the OLD pillars; against new content they
    // describe nothing, so the seed must not survive a regenerate.
    const { rerender } = render(
      step({ pillars: PILLARS, initialSelectedIndices: [0, 2] }),
    );
    expect(screen.getByText("2 / 3 seçili")).toBeTruthy();

    rerender(
      step({
        pillars: [p("INSPIRATIONAL", "yeni")],
        initialSelectedIndices: [0, 2],
      }),
    );

    expect(screen.getByText("0 / 1 seçili")).toBeTruthy();
    expect(
      (screen.getByLabelText("Pillar 1 seç") as HTMLInputElement).checked,
    ).toBe(false);
  });
  // ─────────────────────────────────────────────────────────────────────────

  it("picking a pillar PUTs the selection immediately and enables Devam", async () => {
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);

    render(step({ pillars: PILLARS }));

    // "N1" is flat index 2 but renders last (3rd group).
    fireEvent.click(screen.getByLabelText("Pillar 3 seç"));

    await vi.waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    const [url, init] = fetchMock.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ];
    expect(url).toBe("/api/projects/p1/steps/sm_pillars/content");
    expect(init.method).toBe("PUT");
    expect(JSON.parse(String(init.body))).toEqual({
      selections: { selectedIndices: [2] },
    });

    const devam = screen.getByRole("link", { name: /Devam/ });
    expect(devam.getAttribute("href")).toBe("/projects/p1/step/8");
  });

  it("Geri links back to step 6", () => {
    render(step({ pillars: PILLARS }));
    const geri = screen.getByRole("link", { name: /Geri/ });
    expect(geri.getAttribute("href")).toBe("/projects/p1/step/6");
  });

  it("re-seeds with NONE selected when a regenerate delivers new pillars", () => {
    const { rerender } = render(step({ pillars: PILLARS }));

    fireEvent.click(screen.getByLabelText("Pillar 1 seç"));
    expect(screen.getByText("1 / 3 seçili")).toBeTruthy();

    rerender(step({ pillars: [p("INSPIRATIONAL", "yeni")] }));

    expect(
      (screen.getByLabelText("Pillar 1 başlık") as HTMLInputElement).value,
    ).toBe("yeni");
    expect(
      (screen.getByLabelText("Pillar 1 seç") as HTMLInputElement).checked,
    ).toBe(false);
    expect(screen.getByText("0 / 1 seçili")).toBeTruthy();
  });

  it("debounced-saves a pillar edit via PUT { content: { pillars } }", async () => {
    vi.useFakeTimers();
    const fetchMock = okFetch();
    vi.stubGlobal("fetch", fetchMock);

    render(step({ pillars: [p("INSPIRATIONAL", "a")] }));

    fireEvent.change(screen.getByLabelText("Pillar 1 kanca"), {
      target: { value: "yeni kanca" },
    });
    expect(fetchMock).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(900);

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0] as unknown as [
      string,
      RequestInit,
    ];
    expect(url).toBe("/api/projects/p1/steps/sm_pillars/content");
    const body = JSON.parse(String(init.body)) as {
      content: { pillars: PillarItem[] };
    };
    expect(body.content.pillars[0].hook).toBe("yeni kanca");
    expect(body.content.pillars[0].title).toBe("a");
  });

  it("renders the generate prompt when there is no content yet", () => {
    render(step({ pillars: null }));
    const button = screen.getByRole("button", { name: "Üret" });
    expect((button as HTMLButtonElement).disabled).toBe(false);
  });
});
