import { notFound, redirect } from "next/navigation";

import { TOTAL_STEPS } from "@/lib/workflow-steps";
import { getWizardStatus } from "@/lib/wizard-status";
import { renderStep } from "../step-registry";

/**
 * /projects/[id]/step/[n] — a single wizard step. Access is gated by the
 * layout. This parses n (1..9; invalid -> 404), and forward-locks: if n is past
 * `current` (a prior step is incomplete) it redirects to the current step.
 */
export default async function WizardStepPage({
  params,
}: {
  params: Promise<{ id: string; n: string }>;
}) {
  const { id, n: nRaw } = await params;

  const n = Number(nRaw);
  if (!Number.isInteger(n) || n < 1 || n > TOTAL_STEPS) notFound();

  const { completed, current } = await getWizardStatus(id);

  // Forward-lock: cannot jump ahead of the first-incomplete step.
  if (n > current) redirect(`/projects/${id}/step/${current}`);

  return renderStep({ n, projectId: id, isCompleted: completed.has(n) });
}
