import { redirect } from "next/navigation";

import { getStepContent } from "@/core/pipeline/inputs";
import { extractSelectedIndices } from "@/lib/selected-indices";
import type { TitledItem } from "@/components/wizard/selectable-item-list";
import { requireProjectAccess } from "@/core/tenancy/access";
import { getCurrentUser } from "@/lib/auth-server";
import { CreativeSparksStep } from "./creative-sparks-step";

/**
 * Wizard step 5 — Creative Sparks (creative_sparks).
 *
 * Server wrapper: repeats requireProjectAccess (defense-in-depth per the T13
 * note) and loads the creative_sparks step_contents row, extracting its items
 * (null when no content yet) and selected indices for the client editor.
 *
 * Also loads step 4's user_input row: {User_input} is the SUBJECT of the
 * creative_spark prompt and gatherVars THROWS on an empty one, so the client
 * gates its "Üret" button on `hasUserInput` rather than letting the user fire a
 * job that can only fail (or, worse, produce confident nonsense).
 */
export async function Step5({ projectId }: { projectId: string }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  try {
    await requireProjectAccess(user.id, projectId);
  } catch {
    redirect("/projects");
  }

  const [row, userInputRow] = await Promise.all([
    getStepContent(projectId, "creative_sparks"),
    getStepContent(projectId, "user_input"),
  ]);

  const items = row ? extractItems(row.content) : null;
  // Clamp to the current item count: a stale index (from content that shrank)
  // would otherwise inflate the "N seçili" counter and enable Devam with no
  // visibly checked card.
  const selectedIndices = extractSelectedIndices(row?.selections, items?.length ?? 0);
  const hasUserInput = extractText(userInputRow?.content).trim().length > 0;

  return (
    <CreativeSparksStep
      projectId={projectId}
      initialItems={items}
      initialSelectedIndices={selectedIndices}
      hasUserInput={hasUserInput}
    />
  );
}

/** content.items as {title, description}[], defaulting to [] on a malformed row. */
function extractItems(content: unknown): TitledItem[] {
  if (
    content &&
    typeof content === "object" &&
    "items" in content &&
    Array.isArray((content as { items: unknown }).items)
  ) {
    return (content as { items: unknown[] }).items.map((it) => ({
      title:
        it && typeof it === "object" && "title" in it
          ? String((it as { title: unknown }).title ?? "")
          : "",
      description:
        it && typeof it === "object" && "description" in it
          ? String((it as { description: unknown }).description ?? "")
          : "",
    }));
  }
  return [];
}

/** content.text when the row holds a string, else "" (nothing saved yet). */
function extractText(content: unknown): string {
  if (
    content &&
    typeof content === "object" &&
    "text" in content &&
    typeof (content as { text: unknown }).text === "string"
  ) {
    return (content as { text: string }).text;
  }
  return "";
}
