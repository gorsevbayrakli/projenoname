"use client";

import { useTranslations } from "next-intl";
import Link from "next/link";
import { usePathname } from "next/navigation";

import { LocaleSwitcher } from "@/components/locale-switcher";
import { Wordmark } from "@/components/wordmark";
import { TOTAL_STEPS, WIZARD_STEPS } from "@/lib/workflow-steps";

/**
 * Navigation of the wizard shell (client): lists the 8 steps, marks completed
 * ones with a check, highlights the active step (derived from the URL), and
 * forward-locks any step past `current` (a prior step is still incomplete).
 * Back navigation is always free, so every step n <= current is a link.
 *
 * TWO PRESENTATIONS, ONE STATE (T22). A fixed 288px rail leaves a 375px phone
 * ~87px of content, which is unusable. So below `md` the rail is replaced by a
 * compact sticky bar: "Adım N / 8", the active step's label, a link back to the
 * project list, and a horizontally SCROLLABLE step strip. The strip owns its own
 * overflow, so the page itself never scrolls sideways at 375px.
 */
export function WizardRail({
  projectId,
  projectName,
  brandName,
  completed,
  current,
}: {
  projectId: string;
  projectName: string;
  brandName: string;
  completed: number[];
  current: number;
}) {
  const t = useTranslations("wizard");
  // Step labels are keyed by the step's storage key (see lib/workflow-steps.ts).
  const stepLabel = useTranslations("stepLabels");
  const pathname = usePathname();
  const activeMatch = pathname.match(/\/step\/(\d+)/);
  const activeN = activeMatch ? Number(activeMatch[1]) : current;
  const completedSet = new Set(completed);
  const activeStep = WIZARD_STEPS.find((s) => s.n === activeN);

  return (
    <>
      {/* Mobile (< md): compact indicator + scrollable step strip. */}
      <div className="sticky top-0 z-20 flex flex-col gap-2 border-b border-border bg-bg px-4 py-3 md:hidden">
        <div className="flex items-center justify-between gap-3">
          <div className="flex shrink-0 items-center gap-2">
            <Link
              href="/projects"
              className="text-sm text-fg-muted transition-colors hover:text-fg"
            >
              {t("backToProjects")}
            </Link>
            <LocaleSwitcher />
          </div>
          <div className="min-w-0 text-right">
            <div className="truncate text-sm font-medium text-fg">
              {t("stepIndicator", { n: activeN, total: TOTAL_STEPS })}
              {activeStep ? ` · ${stepLabel(activeStep.key)}` : ""}
            </div>
            <div className="truncate text-xs text-fg-muted">
              {projectName} · {brandName}
            </div>
          </div>
        </div>

        {/* The strip owns the horizontal overflow so the PAGE never scrolls
            sideways at 375px. */}
        <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
          {WIZARD_STEPS.map((step) => {
            const isCompleted = completedSet.has(step.n);
            const isActive = step.n === activeN;
            const isLocked = step.n > current;
            const marker = isCompleted ? "✓" : String(step.n);
            const chip =
              "flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-medium ";

            if (isLocked) {
              return (
                <span
                  key={step.n}
                  aria-disabled="true"
                  title={t("lockedChip", { label: stepLabel(step.key) })}
                  className={chip + "bg-bg-muted text-fg-subtle opacity-60"}
                >
                  {marker}
                </span>
              );
            }
            return (
              <Link
                key={step.n}
                href={`/projects/${projectId}/step/${step.n}`}
                aria-current={isActive ? "step" : undefined}
                title={stepLabel(step.key)}
                className={
                  chip +
                  (isActive
                    ? "bg-accent text-accent-contrast"
                    : isCompleted
                      ? "bg-accent-subtle text-accent-fg"
                      : "bg-bg-muted text-fg-muted")
                }
              >
                {marker}
              </Link>
            );
          })}
        </div>
      </div>

      {/* Desktop (>= md): the full rail. */}
      <aside className="hidden w-72 shrink-0 flex-col gap-6 border-r border-border bg-bg px-4 py-6 md:flex">
      <div className="flex flex-col gap-3">
        {/* T45: the typographic logo, top left of the app chrome. Desktop
            only — the sub-`md` bar above is already carrying the step
            indicator, the project name and two controls at 375px (T22), and
            the logo there would push one of them off. */}
        <Wordmark href="/projects" />
        <div className="flex items-center justify-between gap-2">
          <Link
            href="/projects"
            className="text-sm text-fg-muted transition-colors hover:text-fg"
          >
            {t("backToProjects")}
          </Link>
          <LocaleSwitcher />
        </div>
        <div className="px-1">
          <div className="truncate text-lg font-semibold tracking-tight text-fg">
            {projectName}
          </div>
          <div className="truncate text-sm text-fg-muted">{brandName}</div>
        </div>
      </div>

      <nav className="flex flex-1 flex-col gap-1">
        {WIZARD_STEPS.map((step) => {
          const isCompleted = completedSet.has(step.n);
          const isActive = step.n === activeN;
          // Forward-lock: any step past the current (first-incomplete) one.
          const isLocked = step.n > current;

          const marker = isCompleted ? "✓" : String(step.n);

          const inner = (
            <>
              <span
                className={
                  "flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-medium " +
                  (isActive
                    ? "bg-accent text-accent-contrast"
                    : isCompleted
                      ? "bg-accent-subtle text-accent-fg"
                      : "bg-bg-muted text-fg-subtle")
                }
              >
                {marker}
              </span>
              <span className="truncate">{stepLabel(step.key)}</span>
            </>
          );

          const base =
            "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors";

          if (isLocked) {
            return (
              <div
                key={step.n}
                aria-disabled="true"
                title={t("lockedHint")}
                className={base + " cursor-not-allowed text-fg-subtle opacity-60"}
              >
                {inner}
              </div>
            );
          }

          return (
            <Link
              key={step.n}
              href={`/projects/${projectId}/step/${step.n}`}
              aria-current={isActive ? "step" : undefined}
              className={
                base +
                " " +
                (isActive
                  ? "bg-accent-subtle font-medium text-accent-fg"
                  : "text-fg-muted hover:bg-bg-muted hover:text-fg")
              }
            >
              {inner}
            </Link>
          );
        })}
      </nav>
      </aside>
    </>
  );
}
