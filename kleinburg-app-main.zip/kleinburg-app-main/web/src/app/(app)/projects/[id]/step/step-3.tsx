import { redirect } from "next/navigation";

import { getStepContent } from "@/core/pipeline/inputs";
import { extractSelectedIndices } from "@/lib/selected-indices";
import type { TitledItem } from "@/components/wizard/selectable-item-list";
import type { ItemSource } from "@/core/pipeline/schemas";
import { requireProjectAccess } from "@/core/tenancy/access";
import { getCurrentUser } from "@/lib/auth-server";
import { SecondaryDataStep } from "./secondary-data-step";

/**
 * Wizard step 3 — İkincil Veri / Secondary Data.
 *
 * #47 restored both the capability and the name: a search-backed model runs
 * behind the step again, so calling it research is accurate once more (an
 * earlier fix had renamed it "Bakış Açıları"/"Angles" while it had no search).
 * #52 moved the search into its own call without changing that. The
 * `secondary_data` enum value and step_contents key never changed through any
 * of these moves.
 *
 * Server wrapper: repeats requireProjectAccess (defense-in-depth per the T13
 * note) and loads the secondary_data step_contents row, extracting its items
 * (null when no content yet) and selected indices for the client editor.
 */
export async function Step3({ projectId }: { projectId: string }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  try {
    await requireProjectAccess(user.id, projectId);
  } catch {
    redirect("/projects");
  }

  const row = await getStepContent(projectId, "secondary_data");
  const items = row ? extractItems(row.content) : null;
  // Clamp to the current item count: a stale index (from content that shrank)
  // would otherwise inflate the "N seçili" counter and enable Devam with no
  // visibly checked card.
  const selectedIndices = extractSelectedIndices(row?.selections, items?.length ?? 0);

  return (
    <SecondaryDataStep
      projectId={projectId}
      initialItems={items}
      initialSelectedIndices={selectedIndices}
    />
  );
}

/**
 * content.items as {title, description, sources}[], defaulting to [] on a
 * malformed row.
 *
 * LEGACY SHAPE TOLERANCE (#47), following step-9.tsx's calendar precedent.
 * Every project generated before this change stored items with NO `sources`
 * field at all. Those rows must keep rendering, so a missing/malformed
 * `sources` reads as an EMPTY list rather than throwing or being dropped — and
 * empty is the honest value, not a placeholder: those items really were written
 * by a model with no search behind it, so "no source" is exactly what they had.
 * They therefore render marked as unsourced, which is the correct history.
 *
 * The row is not re-validated against secondaryDataSchema here on purpose. That
 * schema is the MODEL's output contract (where `sources` is required); stored
 * content is a different, older population, and running new-contract validation
 * over it is what would break the old projects.
 */
function extractItems(content: unknown): TitledItem[] {
  if (
    content &&
    typeof content === "object" &&
    "items" in content &&
    Array.isArray((content as { items: unknown }).items)
  ) {
    return (content as { items: unknown[] }).items.map((it) => ({
      title:
        it && typeof it === "object" && "title" in it
          ? String((it as { title: unknown }).title ?? "")
          : "",
      description:
        it && typeof it === "object" && "description" in it
          ? String((it as { description: unknown }).description ?? "")
          : "",
      sources: extractSources(it),
    }));
  }
  return [];
}

/**
 * One item's sources as {url, title}[], defaulting to [] on anything else.
 *
 * Entries with no usable `url` are dropped rather than rendered as an empty
 * link. The scheme is NOT checked here — <SourceLinks> does that at the render
 * site, where the href actually is.
 */
function extractSources(item: unknown): ItemSource[] {
  if (!item || typeof item !== "object") return [];
  const raw = (item as { sources?: unknown }).sources;
  if (!Array.isArray(raw)) return [];
  return raw.flatMap((s) => {
    if (!s || typeof s !== "object") return [];
    const url = (s as { url?: unknown }).url;
    if (typeof url !== "string" || url.trim() === "") return [];
    const title = (s as { title?: unknown }).title;
    return [{ url, title: typeof title === "string" ? title : "" }];
  });
}
