import { redirect } from "next/navigation";

import { getStepContent } from "@/core/pipeline/inputs";
import { requireProjectAccess } from "@/core/tenancy/access";
import { getCurrentUser } from "@/lib/auth-server";
import { UserInputStep } from "./user-input-step";

/**
 * Wizard step 4 — Ek Girdi (user_input).
 *
 * Server wrapper: repeats requireProjectAccess (defense-in-depth per the T13
 * note) and loads the user_input step_contents row, extracting content.text
 * (null when no row / no text yet) for the client editor.
 */
export async function Step4({ projectId }: { projectId: string }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  try {
    await requireProjectAccess(user.id, projectId);
  } catch {
    redirect("/projects");
  }

  const row = await getStepContent(projectId, "user_input");
  const text = extractText(row?.content);

  return <UserInputStep projectId={projectId} initialText={text} />;
}

/** content.text when the row holds a string, else null (nothing saved yet). */
function extractText(content: unknown): string | null {
  if (
    content &&
    typeof content === "object" &&
    "text" in content &&
    typeof (content as { text: unknown }).text === "string"
  ) {
    return (content as { text: string }).text;
  }
  return null;
}
