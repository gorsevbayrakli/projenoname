"use client";

import {
  DEFAULT_PLATFORM,
  normalizePlatform,
  sortPlatforms,
  type Platform,
} from "@/core/platforms";

import { useTranslations } from "next-intl";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

import { EmptyState } from "@/components/wizard/empty-state";
import { JobErrorNotice } from "@/components/wizard/job-error-notice";
import { JobProgress } from "@/components/wizard/job-progress";
import {
  PostCardList,
  type IndexedPost,
  type PostItem,
} from "@/components/wizard/post-card-list";
import { useGenerate } from "@/components/wizard/use-generate";
import { TOTAL_STEPS } from "@/lib/workflow-steps";

const AUTOSAVE_DELAY_MS = 800;

type SaveState = "idle" | "saving" | "saved" | "error";

/**
 * Client body for wizard step 7 — SM Posts (sm_posts).
 *
 * Same generate → edit → auto-save shape as T16/T18/T19, with two extra rules
 * that are load-bearing and must not be "simplified" away:
 *
 * ── 1. ONE FLAT ARRAY, ONE SLICE PER PLATFORM ────────────────────────────
 * Every platform's posts live in ONE `posts` array, each tagged with its
 * platform. The tabs merely FILTER that array for display; every edit maps back
 * to the post's index in the flat array, and every save PUTs the FULL array.
 * Sending only the visible tab's posts would delete every other platform's —
 * the same slice model runStep's merge enforces on the generate path (see
 * core/pipeline/posts.ts). The filter compares against the platform REGISTRY
 * (core/platforms.ts), so registering a platform is all it takes for its tab to
 * show its own posts; there is no hardcoded platform set here.
 *
 * ── 2. ONE PLATFORM GENERATES AT A TIME ──────────────────────────────────
 * The job queue enforces one active job per project (enqueueGeneration →
 * supersedeActiveJobs), so kicking off a second platform while the first is
 * running would CANCEL the first. There is therefore no "generate all" action,
 * and while any job is in flight EVERY platform button is disabled.
 *
 * ── 3. THE PLATFORM SET COMES FROM THE PROJECT (T29) ─────────────────────
 * Step 6 decides it. This step used to own that choice with a Facebook opt-in
 * checkbox and a hardcoded always-on Instagram; both are gone. Posts for a
 * platform the project no longer includes still get a tab, because they exist
 * and hiding them would look like data loss.
 */
export function SmPostsStep({
  projectId,
  initialPosts,
  platforms,
}: {
  projectId: string;
  initialPosts: PostItem[] | null;
  /** The project's chosen platforms (step 6), in registry order. */
  platforms: Platform[];
}) {
  const t = useTranslations("steps.smPosts");
  const tPlatform = useTranslations("platforms");
  const tCommon = useTranslations("common");
  const tWizard = useTranslations("wizard");
  const router = useRouter();
  const { generate, jobId, isGenerating, error, reset } = useGenerate(
    projectId,
    "sm_posts",
  );

  const [posts, setPosts] = useState<PostItem[]>(initialPosts ?? []);
  const [saveState, setSaveState] = useState<SaveState>("idle");
  const [jobError, setJobError] = useState<string | null>(null);
  // Which platform the in-flight job is for (null when nothing is running) —
  // drives the per-tab "Üretiliyor" placement.
  const [generatingPlatform, setGeneratingPlatform] =
    useState<Platform | null>(null);

  // The project's platforms, plus any platform that already has posts. A
  // project narrowed after generating (Facebook dropped at step 6) must still
  // show what it produced; hiding those posts would read as data loss.
  const tabs: Platform[] = sortPlatforms([
    ...platforms,
    ...posts.map((p) => normalizePlatform(p.platform)),
  ]);

  const [activeTab, setActiveTab] = useState<Platform>(
    platforms[0] ?? DEFAULT_PLATFORM,
  );
  const effectiveTab: Platform = tabs.includes(activeTab)
    ? activeTab
    : (tabs[0] ?? DEFAULT_PLATFORM);

  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const savedPostsRef = useRef(JSON.stringify(initialPosts ?? []));
  const postsRef = useRef(posts);
  postsRef.current = posts;
  const lastServerSig = useRef(JSON.stringify(initialPosts));

  const hasAnyPost = posts.length > 0;
  // Any generation in flight (POST pending OR job running) locks BOTH buttons.
  const busy = isGenerating || jobId !== null;
  const canContinue = hasAnyPost;
  const displayError = error ?? jobError;

  function startGenerate(platform: Platform) {
    if (busy) return;
    setJobError(null);
    setGeneratingPlatform(platform);
    setActiveTab(platform);
    reset();
    void generate({ platform });
  }

  // Sync from server props ONLY when they actually change (a fresh generation
  // followed by router.refresh()). Auto-save never refreshes, so this cannot
  // clobber in-progress edits.
  useEffect(() => {
    const next = JSON.stringify(initialPosts);
    if (next !== lastServerSig.current) {
      lastServerSig.current = next;
      setPosts(initialPosts ?? []);
      savedPostsRef.current = JSON.stringify(initialPosts ?? []);
      // The re-seed is not an edit: drop any indicator left over from the
      // previous content (a regenerate must not look like a pending save).
      setSaveState("idle");
    }
  }, [initialPosts]);

  // Debounced auto-save of post edits. Skipped while the serialized value still
  // matches what we persisted, so mounting never fires a PUT.
  useEffect(() => {
    const serialized = JSON.stringify(posts);
    // Nothing to save. If a previous pass showed "Kaydediliyor…" and its timer
    // was cleared by this re-render (prop-sync re-seed), the indicator would
    // stick forever — so clear it here. Only "saving" is reset; a "saved" or
    // "error" result must stay visible.
    if (serialized === savedPostsRef.current) {
      setSaveState((s) => (s === "saving" ? "idle" : s));
      return;
    }

    if (saveTimer.current) clearTimeout(saveTimer.current);
    setSaveState("saving");
    saveTimer.current = setTimeout(() => {
      void savePosts(posts);
    }, AUTOSAVE_DELAY_MS);

    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [posts]);

  // Flush a pending edit on unmount (Geri/Devam unmount before the debounce
  // fires). Best-effort keepalive; a failed flush must never block navigation.
  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      const pending = JSON.stringify(postsRef.current);
      if (pending === savedPostsRef.current) return;
      try {
        void fetch(`/api/projects/${projectId}/steps/sm_posts/content`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: { posts: postsRef.current } }),
          keepalive: true,
        }).catch(() => {});
      } catch {
        // best-effort
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /** PUT the FULL posts array — both platform slices, always. */
  async function savePosts(value: PostItem[]) {
    try {
      const res = await fetch(
        `/api/projects/${projectId}/steps/sm_posts/content`,
        {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content: { posts: value } }),
        },
      );
      if (res.ok) {
        savedPostsRef.current = JSON.stringify(value);
        setSaveState("saved");
        return;
      }
      setSaveState("error");
    } catch {
      setSaveState("error");
    }
  }

  // Edits address the post's index in the FLAT array (see rule 1 above).
  function handleEditField(
    index: number,
    field: keyof PostItem,
    value: string,
  ) {
    setPosts((prev) =>
      prev.map((p, i) => {
        if (i !== index) return p;
        if (field === "hashtags") {
          return { ...p, hashtags: splitHashtags(value) };
        }
        return { ...p, [field]: value };
      }),
    );
  }

  function handleJobDone(result: { status: string; error?: string }) {
    setGeneratingPlatform(null);
    if (result.status === "succeeded") {
      // The worker upserted the MERGED posts (runStep merged the new platform's
      // slice into the stored array), so a refresh brings back both platforms.
      router.refresh();
      reset();
      return;
    }
    setJobError(result.error ?? tCommon("generationFailed"));
    reset();
  }

  const visibleEntries = entriesFor(posts, effectiveTab);

  // max-w-6xl, wider than the 3xl of the non-listing steps: this step renders a
  // card GRID (#44) and a 3xl column has no room for a second track. The other
  // steps stay narrow because a form column reads better short.
  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-8 sm:px-8 sm:py-10">
      <header className="flex flex-col gap-1">
        <div className="text-sm font-medium text-fg-subtle">
          {tWizard("stepIndicator", { n: 8, total: TOTAL_STEPS })}
        </div>
        <h1 className="text-2xl font-semibold tracking-tight text-fg">
          {t("title")}
        </h1>
        <p className="mt-1 text-sm text-fg-muted">{t("description")}</p>
      </header>

      {displayError && !jobId ? (
        <JobErrorNotice
          error={displayError}
          projectId={projectId}
          onRetry={
            busy
              ? undefined
              : () => startGenerate(generatingPlatform ?? effectiveTab)
          }
        />
      ) : null}

      {/* Tabs */}
      <div className="flex flex-col gap-4">
        <div role="tablist" className="flex items-center gap-2 border-b border-border">
          {tabs.map((platform) => {
            const isActive = platform === effectiveTab;
            const count = entriesFor(posts, platform).length;
            return (
              <button
                key={platform}
                type="button"
                role="tab"
                aria-selected={isActive}
                onClick={() => setActiveTab(platform)}
                className={
                  "-mb-px border-b-2 px-3 py-2 text-sm font-medium transition-colors " +
                  (isActive
                    ? "border-accent text-fg"
                    : "border-transparent text-fg-muted hover:text-fg")
                }
              >
                {t("tab", { platform: tPlatform(platform), count })}
              </button>
            );
          })}
        </div>

        {/* One generate action PER PLATFORM. Both are disabled while ANY job is
            in flight — the queue supersedes a project's active job, so starting
            the second platform would cancel the first (rule 2 above). */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            {tabs.map((platform) => {
              const platformHasPosts =
                entriesFor(posts, platform).length > 0;
              const label = platformHasPosts
                ? t("regenerateFor", { platform: tPlatform(platform) })
                : t("generateFor", { platform: tPlatform(platform) });
              return (
                <button
                  key={platform}
                  type="button"
                  disabled={busy}
                  onClick={() => startGenerate(platform)}
                  className={
                    platformHasPosts
                      ? "shrink-0 rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg disabled:cursor-not-allowed disabled:opacity-50"
                      : "shrink-0 rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized disabled:cursor-not-allowed disabled:opacity-50"
                  }
                >
                  {busy && generatingPlatform === platform
                    ? tCommon("generating")
                    : label}
                </button>
              );
            })}
          </div>
          <SaveIndicator state={saveState} />
        </div>

        {jobId ? (
          <div className="flex flex-col gap-3 rounded-lg border border-border bg-bg p-4">
            <p className="text-xs text-fg-subtle">
              {t("generatingFor", {
                platform: tPlatform(generatingPlatform ?? effectiveTab),
              })}
            </p>
            <JobProgress jobId={jobId} onDone={handleJobDone} />
          </div>
        ) : null}

        {visibleEntries.length === 0 ? (
          <EmptyState
            title={t("emptyTitle", {
              platform: tPlatform(effectiveTab),
            })}
            description={t("emptyDescription", {
              platform: tPlatform(effectiveTab),
            })}
            action={
              <button
                type="button"
                disabled={busy}
                onClick={() => startGenerate(effectiveTab)}
                className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized disabled:cursor-not-allowed disabled:opacity-50"
              >
                {busy && generatingPlatform === effectiveTab
                  ? tCommon("generating")
                  : t("generateFor", {
                      platform: tPlatform(effectiveTab),
                    })}
              </button>
            }
          />
        ) : (
          <PostCardList
            entries={visibleEntries}
            onEditField={handleEditField}
          />
        )}
      </div>

      {/* Navigation */}
      <nav className="flex items-center justify-between border-t border-border pt-4">
        <Link
          href={`/projects/${projectId}/step/7`}
          className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
        >
          {tCommon("back")}
        </Link>
        {canContinue ? (
          <Link
            href={`/projects/${projectId}/step/9`}
            className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized"
          >
            {tCommon("continue")}
          </Link>
        ) : (
          <span
            aria-disabled="true"
            title={t("continueLocked")}
            className="cursor-not-allowed rounded-lg bg-bg-muted px-4 py-2 text-sm font-medium text-fg-subtle opacity-60"
          >
            {tCommon("continue")}
          </span>
        )}
      </nav>
    </div>
  );
}

/**
 * The posts belonging to one platform, each carrying its FLAT index so edits
 * address the full array.
 *
 * The comparison runs on the REGISTERED code, whatever it is — never on a
 * hardcoded platform pair. normalizePlatform whitelists against PLATFORM_CODES
 * and falls back to DEFAULT_PLATFORM, so an untagged/unknown platform lands in
 * the default tab and a hand-edited or legacy post can never vanish from every
 * tab (the UI mirror of core/pipeline/posts.ts).
 */
function entriesFor(posts: PostItem[], platform: Platform): IndexedPost[] {
  return posts
    .map((post, index) => ({ post, index }))
    .filter(({ post }) => normalizePlatform(post.platform) === platform);
}

/** "#a #b" (or newline/comma separated) -> ["#a", "#b"]. */
function splitHashtags(value: string): string[] {
  return value
    .split(/[\s,]+/)
    .map((t) => t.trim())
    .filter((t) => t.length > 0);
}

function SaveIndicator({ state }: { state: SaveState }) {
  const t = useTranslations("save");
  if (state === "saving") {
    return <span className="text-xs text-fg-subtle">{t("saving")}</span>;
  }
  if (state === "saved") {
    return <span className="text-xs text-fg-success">{t("saved")}</span>;
  }
  if (state === "error") {
    return <span className="text-xs text-fg-error">{t("failed")}</span>;
  }
  return null;
}
