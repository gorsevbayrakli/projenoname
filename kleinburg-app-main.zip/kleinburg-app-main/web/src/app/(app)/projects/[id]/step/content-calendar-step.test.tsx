// @vitest-environment jsdom
//
// Component test for wizard step 9 (İçerik Takvimi / content_calendar),
// mirroring the T15–T20 step-test pattern: per-file jsdom env, next/navigation
// mocked, fetch mocked, React.createElement (aliased `h`).
//
// The rules locked here: structured rows render as a real table (T33), a
// platform with no rows is dropped rather than shown as a blank tab, and the
// downloads produce a Blob whose anchor carries the slugified marka-proje-dil
// filename — with the XLSX covering EVERY platform in one workbook.

import {
  cleanup,
  fireEvent,
  screen,
  waitFor,
} from "@testing-library/react";

// T25: rendered through renderWithIntl, which wraps the component in
// NextIntlClientProvider with the REAL Turkish catalog — so every assertion
// below still checks the exact Turkish a user reads.
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const refreshMock = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    refresh: refreshMock,
    push: vi.fn(),
    replace: vi.fn(),
    back: vi.fn(),
    forward: vi.fn(),
    prefetch: vi.fn(),
  }),
}));

// <JobProgress> opens an EventSource; stub it so the tests don't need a stream.
class FakeEventSource {
  close = vi.fn();
  addEventListener = vi.fn();
  removeEventListener = vi.fn();
  onmessage: unknown = null;
  onerror: unknown = null;
}

import { ContentCalendarStep } from "./content-calendar-step";

const CALENDAR = [
  "| Gün | Format | İçerik Sütunu | Gönderi |",
  "| --- | --- | --- | --- |",
  "| Day 1 | Reel | İlham | Kanca<br>Gövde<br>#etiket |",
  "| Day 3 | Carousel | Eğitim | Şişli'de güzel bir gün |",
].join("\n");

function row(over: Partial<Record<string, unknown>> = {}) {
  return {
    day: "Day 1",
    format: "Reel",
    pillar: "İlham",
    hook: "Kanca",
    caption: "Şişli'de güzel bir gün",
    cta: "Kaydet",
    hashtags: ["#etiket"],
    ...over,
  };
}

function step(
  calendar: string | null,
  extra: Array<{ platform: string; rows: ReturnType<typeof row>[] }> = [],
  shortfalls: Array<{ platform: string; requested: number; scheduled: number }> = [],
) {
  return h(ContentCalendarStep, {
    projectId: "p1",
    shortfalls,
    initialCalendars: [
      ...(calendar === null
        ? []
        : [{ platform: "instagram", rows: [row(), row({ day: "Day 3", pillar: "Eğitim" })] }]),
      ...extra,
    ],
    brandName: "Kleinburg",
    projectName: "Yaz Kampanyası",
    language: "tr",
  });
}

function okFetch(body: unknown = {}) {
  return vi.fn((url?: unknown, init?: unknown) => {
    void url;
    void init;
    return Promise.resolve({
      ok: true,
      status: 200,
      json: () => Promise.resolve(body),
    });
  });
}

/**
 * Blob bytes. jsdom's Blob has neither .text() nor .arrayBuffer(), so we go
 * through FileReader (which jsdom does implement).
 */
function blobBytes(blob: Blob): Promise<Uint8Array> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error);
    reader.onload = () => resolve(new Uint8Array(reader.result as ArrayBuffer));
    reader.readAsArrayBuffer(blob);
  });
}

/**
 * The produced workbook, parsed back. Deliberately NOT the lib test's
 * `readBack`: this file runs under jsdom, whose Blob has no .arrayBuffer(), so
 * the bytes have to come through FileReader above.
 */
async function readWorkbook(blob: Blob) {
  const XLSX = await import("xlsx");
  return XLSX.read(await blobBytes(blob), { type: "array" });
}

/** Captures every <a> that download() clicks, so we can assert on it. */
function captureAnchors() {
  const anchors: HTMLAnchorElement[] = [];
  const original = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function click(this: HTMLAnchorElement) {
    anchors.push(this);
  };
  return {
    anchors,
    restore: () => {
      HTMLAnchorElement.prototype.click = original;
    },
  };
}

beforeEach(() => {
  refreshMock.mockClear();
  vi.stubGlobal("fetch", okFetch());
  vi.stubGlobal("EventSource", FakeEventSource);
});

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});

describe("ContentCalendarStep — empty state", () => {
  it("shows the intro and an Üret button when there is no content", () => {
    render(step(null));

    expect(screen.getByText("Üret")).toBeTruthy();
    expect(screen.queryByRole("table")).toBeNull();
    expect(screen.queryByText("CSV indir")).toBeNull();
  });

  it("treats a platform with no rows as 'not generated yet'", () => {
    render(step(null, [{ platform: "instagram", rows: [] }]));

    expect(screen.getByText("Üret")).toBeTruthy();
  });

  it("POSTs to the content_calendar generate route on Üret", () => {
    const fetchMock = okFetch({ jobId: "job-1" });
    vi.stubGlobal("fetch", fetchMock);
    render(step(null));

    fireEvent.click(screen.getByText("Üret"));

    expect(fetchMock.mock.calls[0][0]).toBe(
      "/api/projects/p1/steps/content_calendar/generate",
    );
  });
});

describe("ContentCalendarStep — parsed table", () => {
  it("gives the caption parts their own columns (T33)", () => {
    render(step(CALENDAR));

    // The whole point: hook, caption, CTA and hashtags are no longer one
    // <br>-joined blob in a single Gönderi cell.
    const headers = screen.getAllByRole("columnheader").map((h) => h.textContent);
    expect(headers).toEqual([
      "Gün",
      "Format",
      "Sütun",
      "Kanca",
      "Metin",
      "Harekete çağrı",
      "Etiketler",
    ]);

    expect(screen.getAllByRole("row")).toHaveLength(3);
    expect(screen.getAllByText("Kanca").length).toBeGreaterThan(0);
    expect(screen.getAllByText("Şişli'de güzel bir gün")).toHaveLength(2);
  });

  it("joins a row's hashtags into one cell", () => {
    render(step(null, [{ platform: "instagram", rows: [row({ hashtags: ["#a", "#b"] })] }]));

    expect(screen.getByText("#a #b")).toBeTruthy();
  });

  it("offers the downloads and a regenerate action, but no inline editing", () => {
    render(step(CALENDAR));

    expect(screen.getByText("CSV indir")).toBeTruthy();
    expect(screen.getByText("XLSX indir")).toBeTruthy();
    expect(screen.getByText("Yeniden üret")).toBeTruthy();
    expect(screen.queryAllByRole("textbox")).toHaveLength(0);
  });
});

;

describe("ContentCalendarStep — one calendar per platform (T29)", () => {
  const OTHER = [
    { platform: "facebook", rows: [row({ pillar: "Facebook Sütunu" })] },
  ];

  it("shows no tabs for a single platform", () => {
    render(step(CALENDAR));
    expect(screen.queryAllByRole("tab")).toHaveLength(0);
  });

  it("shows a tab per platform and switches the rendered table", () => {
    render(step(CALENDAR, OTHER));

    expect(screen.getAllByRole("tab").map((t) => t.textContent)).toEqual([
      "Instagram",
      "Facebook",
    ]);
    expect(screen.getByText("İlham")).toBeTruthy();

    fireEvent.click(screen.getByRole("tab", { name: "Facebook" }));

    expect(screen.getByText("Facebook Sütunu")).toBeTruthy();
    expect(screen.queryByText("İlham")).toBeNull();
  });

  it("ignores a platform whose table came back empty", () => {
    // An empty string is a job that produced nothing for that platform; a blank
    // tab would read as a real calendar.
    render(step(CALENDAR, [{ platform: "facebook", rows: [] }]));

    expect(screen.queryAllByRole("tab")).toHaveLength(0);
  });
});

describe("ContentCalendarStep — downloads", () => {
  /** Stub URL.createObjectURL and capture the anchors download() clicks. */
  function setupDownload(objectUrl: string) {
    const createObjectURL = vi.fn((blob: Blob) => {
      void blob;
      return objectUrl;
    });
    const revokeObjectURL = vi.fn();
    vi.stubGlobal("URL", { ...URL, createObjectURL, revokeObjectURL });
    return { createObjectURL, revokeObjectURL, ...captureAnchors() };
  }

  it("CSV indir creates an object URL and names the file with the platform", async () => {
    const dl = setupDownload("blob:csv");

    try {
      render(step(CALENDAR));
      fireEvent.click(screen.getByText("CSV indir"));
      await waitFor(() => expect(dl.createObjectURL).toHaveBeenCalledTimes(1));
    } finally {
      dl.restore();
    }

    const blob = dl.createObjectURL.mock.calls[0][0];
    expect(blob.type).toContain("text/csv");
    // The exported bytes carry the BOM + the parsed rows (not the raw string).
    const bytes = await blobBytes(blob);
    // The first three bytes are the UTF-8 BOM — this is what makes Excel read
    // ş/ğ/ı correctly instead of as cp1252 mojibake.
    expect([bytes[0], bytes[1], bytes[2]]).toEqual([0xef, 0xbb, 0xbf]);
    // TextDecoder eats the BOM, so decode for the content assertions.
    const text = new TextDecoder().decode(bytes);
    expect(text).toContain("Şişli'de güzel bir gün");
    // The PARSED rows are exported, with <br> already newlines — not the raw
    // markdown string.
    // T33: the parts are their own columns now, so the export has no
    // multi-line "everything" cell to unpack.
    expect(text).toContain("Gün,Format,Sütun,Kanca,Metin");
    expect(text).toContain("#etiket");
    expect(text).not.toContain("<br>");

    expect(dl.anchors).toHaveLength(1);
    expect(dl.anchors[0].download).toBe("kleinburg-yaz-kampanyasi-tr-instagram.csv");
    expect(dl.anchors[0].getAttribute("href")).toBe("blob:csv");
  });

  it("XLSX indir names the xlsx file with the platform", async () => {
    const dl = setupDownload("blob:xlsx");

    try {
      render(step(CALENDAR));
      fireEvent.click(screen.getByText("XLSX indir"));
      await waitFor(() => expect(dl.createObjectURL).toHaveBeenCalledTimes(1));
    } finally {
      dl.restore();
    }

    expect(dl.anchors[0].download).toBe("kleinburg-yaz-kampanyasi-tr-instagram.xlsx");
    // A real workbook: the zip container's local file header magic.
    const head = await blobBytes(dl.createObjectURL.mock.calls[0][0]);
    expect([head[0], head[1]]).toEqual([0x50, 0x4b]);
  });

  // T33 (3/3): the XLSX is ONE workbook covering every platform, so with more
  // than one platform it must not be named after the active tab.
  it("XLSX exports every platform as one file with no platform suffix", async () => {
    const dl = setupDownload("blob:xlsx");

    try {
      render(
        step(CALENDAR, [
          { platform: "facebook", rows: [row({ pillar: "Facebook Sütunu" })] },
        ]),
      );
      // With several platforms the button says so rather than "XLSX indir".
      fireEvent.click(screen.getByText("Tüm platformlar (XLSX)"));
      await waitFor(() => expect(dl.createObjectURL).toHaveBeenCalledTimes(1));
    } finally {
      dl.restore();
    }

    // Exactly one download, not one per platform.
    expect(dl.anchors).toHaveLength(1);
    expect(dl.anchors[0].download).toBe("kleinburg-yaz-kampanyasi-tr.xlsx");

    // Opened, not just sniffed for the zip magic: the point of the feature is
    // WHAT is inside, and a "PK" check would stay green if the workbook fell
    // back to the active tab alone.
    const book = await readWorkbook(dl.createObjectURL.mock.calls[0][0]);
    // Tabs are named from the registry's untranslated `promptName`, not the
    // platform CODE ("instagram") the entries carry.
    expect(book.SheetNames).toEqual(["Instagram", "Facebook"]);
    // Facebook's own rows really are in there, not a copy of Instagram's.
    expect(book.Sheets["Facebook"]["C2"].v).toBe("Facebook Sütunu");
    expect(book.Sheets["Instagram"]["C2"].v).toBe("İlham");
  });

  it("names an unregistered platform's tab after its code rather than dropping it", async () => {
    // The `?? entry.platform` fallback in download(): a code with no registry
    // entry still has to produce a usable, correctly-ordered tab.
    const dl = setupDownload("blob:xlsx");

    try {
      render(step(CALENDAR, [{ platform: "threads", rows: [row()] }]));
      fireEvent.click(screen.getByText("Tüm platformlar (XLSX)"));
      await waitFor(() => expect(dl.createObjectURL).toHaveBeenCalledTimes(1));
    } finally {
      dl.restore();
    }

    const book = await readWorkbook(dl.createObjectURL.mock.calls[0][0]);
    expect(book.SheetNames).toEqual(["Instagram", "threads"]);
  });

  it("CSV stays per-platform even when several platforms exist", async () => {
    const dl = setupDownload("blob:csv");

    try {
      render(
        step(CALENDAR, [
          { platform: "facebook", rows: [row({ pillar: "Facebook Sütunu" })] },
        ]),
      );
      fireEvent.click(screen.getByText("CSV indir"));
      await waitFor(() => expect(dl.createObjectURL).toHaveBeenCalledTimes(1));
    } finally {
      dl.restore();
    }

    expect(dl.anchors).toHaveLength(1);
    expect(dl.anchors[0].download).toBe("kleinburg-yaz-kampanyasi-tr-instagram.csv");
    const text = new TextDecoder().decode(
      await blobBytes(dl.createObjectURL.mock.calls[0][0]),
    );
    // Only the active tab's rows: Facebook's pillar is not in this file.
    expect(text).not.toContain("Facebook Sütunu");
  });

  it("leaves no stray anchor in the document after downloading", async () => {
    const dl = setupDownload("blob:csv");

    try {
      render(step(CALENDAR));
      fireEvent.click(screen.getByText("CSV indir"));
      await waitFor(() => expect(dl.createObjectURL).toHaveBeenCalledTimes(1));
    } finally {
      dl.restore();
    }

    expect(document.querySelectorAll("a[download]")).toHaveLength(0);
  });

  /**
   * The calendar is built from approved posts now, so it can be SHORT: a
   * platform asked for 10 posts with 6 approved gets 6 rows and no invented
   * copy. Six real rows look exactly like a finished calendar, which is the
   * failure hard rule 5 exists to forbid — the gap has to be on the screen,
   * naming the platform and both numbers, not buried in a job record.
   */
  it("says which platform is short and by how much", () => {
    render(step(CALENDAR, [], [{ platform: "linkedin", requested: 10, scheduled: 6 }]));

    const notice = screen.getByRole("status");
    expect(notice.textContent).toContain("LinkedIn");
    expect(notice.textContent).toContain("10");
    expect(notice.textContent).toContain("6");
  });

  it("shows no shortfall notice when every platform is complete", () => {
    render(step(CALENDAR, [], []));

    expect(screen.queryByRole("status")).toBeNull();
  });
});
