"use client";

import { useTranslations } from "next-intl";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

import { ErrorNotice } from "@/components/wizard/error-notice";
import { apiErrorMessage, type ApiErrorTranslator } from "@/lib/api-error-copy";
import { MAX_POST_COUNT, PLATFORMS } from "@/core/platforms";
import { TOTAL_STEPS } from "@/lib/workflow-steps";

/**
 * Client body for wizard step 6 — Platform Seçimi (T29).
 *
 * Not a generative step: no "Üret" button and no job progress. It writes
 * projects.platforms and moves on.
 *
 * Unlike the auto-saving text steps, this saves on "Devam →" only. The choice
 * decides what steps 7-9 generate, so a half-made selection auto-persisting
 * mid-click would be a worse failure than an explicit save: the user would
 * discover it as pillars for the wrong platform set.
 *
 * The list is rendered from the registry, so LinkedIn and TikTok appear here
 * the moment they are registered — no edit to this file.
 */
export function PlatformsStep({
  projectId,
  initialSelected,
  initialCounts,
}: {
  projectId: string;
  initialSelected: string[];
  /** Stored posts-per-platform (T34); missing entries use registry defaults. */
  initialCounts: Record<string, number>;
}) {
  const t = useTranslations("steps.platforms");
  const tCommon = useTranslations("common");
  const tSave = useTranslations("save");
  const tWizard = useTranslations("wizard");
  const tPlatform = useTranslations("platforms");
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const router = useRouter();

  const [selected, setSelected] = useState<string[]>(initialSelected);
  const [counts, setCounts] = useState<Record<string, number>>(() =>
    Object.fromEntries(
      PLATFORMS.map((p) => [
        p.code,
        initialCounts[p.code] ?? p.defaultPostCount,
      ]),
    ),
  );
  const [advising, setAdvising] = useState(false);
  const [advice, setAdvice] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canContinue = selected.length > 0;

  function toggle(code: string) {
    setSelected((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code],
    );
  }

  async function saveAndContinue() {
    if (!canContinue || saving) return;
    setSaving(true);
    setError(null);
    try {
      const res = await fetch(`/api/projects/${projectId}/platforms`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          platforms: selected,
          postCounts: Object.fromEntries(
            selected.map((code) => [code, counts[code]]),
          ),
        }),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => null)) as {
          error?: string;
          code?: string;
        } | null;
        setError(apiErrorMessage(data, tApi, t("saveFailed")));
        return;
      }
      router.refresh();
      router.push(`/projects/${projectId}/step/7`);
    } catch {
      setError(tCommon("networkError"));
    } finally {
      setSaving(false);
    }
  }

  async function fetchAdvice() {
    if (!canContinue || advising) return;
    setAdvising(true);
    setError(null);
    try {
      const res = await fetch(`/api/projects/${projectId}/platforms/advice`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ platforms: selected }),
      });
      const data = (await res.json().catch(() => null)) as {
        counts?: Record<string, number>;
        rationale?: string;
        error?: string;
        code?: string;
      } | null;
      if (!res.ok || !data?.counts) {
        setError(apiErrorMessage(data, tApi, t("adviceFailed")));
        return;
      }
      // Pre-fills, never overrides silently: the user still owns the number.
      setCounts((prev) => ({ ...prev, ...data.counts }));
      setAdvice(data.rationale ?? null);
    } catch {
      setError(tCommon("networkError"));
    } finally {
      setAdvising(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-8 px-4 py-8 sm:px-8 sm:py-10">
      <header className="flex flex-col gap-1">
        <div className="text-sm font-medium text-fg-subtle">
          {tWizard("stepIndicator", { n: 6, total: TOTAL_STEPS })}
        </div>
        <h1 className="text-2xl font-semibold tracking-tight text-fg">
          {t("title")}
        </h1>
        <p className="mt-1 text-sm text-fg-muted">{t("description")}</p>
        <p className="mt-3 rounded-lg border border-border bg-bg-muted px-3 py-2 text-sm text-fg-muted">
          {t("inputHint")}
        </p>
      </header>

      <fieldset className="flex flex-col gap-2">
        <legend className="sr-only">{t("title")}</legend>
        {PLATFORMS.map((p) => {
          const checked = selected.includes(p.code);
          return (
            <label
              key={p.code}
              className="flex cursor-pointer items-center gap-3 rounded-lg border border-border px-3 py-2.5 text-sm text-fg transition-colors hover:bg-bg-muted"
            >
              <input
                type="checkbox"
                checked={checked}
                onChange={() => toggle(p.code)}
                className="size-4 accent-accent"
              />
              <span className="flex-1">{tPlatform(p.labelKey)}</span>
              {checked ? (
                <span className="flex items-center gap-2 text-sm text-fg-muted">
                  <label htmlFor={`count-${p.code}`}>{t("postCount")}</label>
                  <input
                    id={`count-${p.code}`}
                    type="number"
                    min={1}
                    max={MAX_POST_COUNT}
                    value={counts[p.code]}
                    onChange={(e) =>
                      setCounts((prev) => ({
                        ...prev,
                        [p.code]: Number(e.target.value),
                      }))
                    }
                    onClick={(e) => e.stopPropagation()}
                    className="w-16 rounded-md border border-border bg-bg px-2 py-1 text-sm text-fg outline-none focus-visible:border-accent"
                  />
                </span>
              ) : null}
            </label>
          );
        })}
      </fieldset>

      {canContinue ? (
        <div className="flex flex-col gap-2">
          <button
            type="button"
            disabled={advising}
            onClick={() => void fetchAdvice()}
            className="self-start rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg disabled:cursor-not-allowed disabled:opacity-50"
          >
            {advising ? tCommon("starting") : t("getAdvice")}
          </button>
          {advice ? (
            <p className="rounded-lg border border-border bg-bg-muted px-3 py-2 text-sm text-fg-muted">
              {advice}
            </p>
          ) : null}
        </div>
      ) : null}

      {error ? (
        <ErrorNotice message={error} onRetry={() => void saveAndContinue()} />
      ) : null}

      {/* Navigation */}
      <nav className="flex items-center justify-between border-t border-border pt-4">
        <Link
          href={`/projects/${projectId}/step/5`}
          className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
        >
          {tCommon("back")}
        </Link>
        {canContinue ? (
          <button
            type="button"
            disabled={saving}
            onClick={() => void saveAndContinue()}
            className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized disabled:cursor-not-allowed disabled:opacity-50"
          >
            {saving ? tSave("saving") : tCommon("continue")}
          </button>
        ) : (
          <span
            aria-disabled="true"
            title={t("continueLocked")}
            className="cursor-not-allowed rounded-lg bg-bg-muted px-4 py-2 text-sm font-medium text-fg-subtle"
          >
            {tCommon("continue")}
          </span>
        )}
      </nav>
    </div>
  );
}
