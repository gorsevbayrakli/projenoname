// @vitest-environment jsdom
//
// Component test for wizard step 3 (İkincil Veri / secondary_data), following
// the T15/T17 step-test pattern: per-file jsdom env, next/navigation mocked,
// fetch mocked, React.createElement (aliased `h`) so the test file needs no JSX
// transform of its own.
//
// Scope is #47: per-item sources. The step has a search-backed model behind it
// again (a dedicated retrieval call since #52),
// so the T47-era blanket "none of this is verified" warning is gone — it would
// now be false about a sourced item and, worse, say the same thing about a
// sourced and an unsourced one. What replaces it is per-item honesty: each
// item shows the documents that back it, and an item nothing backs is marked
// as such instead of looking identical to a sourced one. The step's
// generate/edit/select behaviour is exercised through the shared
// <SelectableItemList> tests.

import { cleanup, fireEvent, screen } from "@testing-library/react";

// Rendered through renderWithIntl (T25), i.e. against the REAL Turkish catalog,
// so the assertions below check the exact sentences a user reads.
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const refreshMock = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    refresh: refreshMock,
    push: vi.fn(),
    replace: vi.fn(),
    back: vi.fn(),
    forward: vi.fn(),
    prefetch: vi.fn(),
  }),
}));

import type { TitledItem } from "@/components/wizard/selectable-item-list";
import { SecondaryDataStep } from "./secondary-data-step";

const NO_SOURCE = /Kaynak yok — bu madde hiçbir belgeye dayanmıyor/;

function step(opts: { items?: TitledItem[] | null; selected?: number[] }) {
  return h(SecondaryDataStep, {
    projectId: "p1",
    initialItems: opts.items ?? null,
    initialSelectedIndices: opts.selected ?? [],
  });
}

const SOURCED: TitledItem = {
  title: "Paylaşılan atıştırmalık",
  description: "Birlikte yemek yemenin sessiz sözleşmesi.",
  sources: [
    {
      url: "https://example.org/commensality",
      title: "What Is Commensality?",
    },
  ],
};

/** An item with an empty sources list — the model found nothing for it. */
const UNSOURCED: TitledItem = {
  title: "Mutfaktaki sıra",
  description: "Kimin ilk uzandığı bir hiyerarşi anlatır.",
  sources: [],
};

/** A pre-#47 stored item: generated before sources existed at all. */
const LEGACY: TitledItem = {
  title: "Eski proje maddesi",
  description: "Kaynak alanı olmadan üretilmiş içerik.",
};

beforeEach(() => {
  refreshMock.mockClear();
  vi.stubGlobal(
    "fetch",
    vi.fn(() =>
      Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve({}) }),
    ),
  );
});

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
});

describe("SecondaryDataStep — per-item sources (#47)", () => {
  it("links each sourced item to the documents behind it, safely", () => {
    render(step({ items: [SOURCED] }));

    const link = screen.getByRole("link", { name: "What Is Commensality?" });
    expect(link.getAttribute("href")).toBe("https://example.org/commensality");
    // Model-adjacent URL in an href: new tab, no opener, no referrer.
    expect(link.getAttribute("target")).toBe("_blank");
    expect(link.getAttribute("rel")).toBe("noopener noreferrer");
    // The label must NOT read as "the sources for this item" (#47 review). The
    // cross-check proves these documents were retrieved for the CALL; which
    // item each belongs to is the model's own unverified claim, and a label
    // that hides that lends a real publication's authority to whatever sentence
    // sits above it. It has to send the reviewer to the link.
    expect(
      screen.getByText(
        "Modelin bu maddeyle eşleştirdiği belgeler — eşleştirme doğrulanmadı, açıp kontrol edin",
      ),
    ).toBeTruthy();
  });

  it("marks an item that nothing backs, instead of hiding the difference", () => {
    render(step({ items: [SOURCED, UNSOURCED] }));

    // Exactly one of the two items is marked unsourced.
    expect(screen.getAllByText(NO_SOURCE)).toHaveLength(1);
  });

  it("treats a legacy item (no sources field) as unsourced — the honest history", () => {
    render(step({ items: [LEGACY] }));

    expect(screen.getByText(NO_SOURCE)).toBeTruthy();
    expect(screen.queryByText("Kaynaklar")).toBeNull();
  });

  it("never renders a non-http(s) URL as a link", () => {
    render(
      step({
        items: [
          {
            ...SOURCED,
            sources: [{ url: "javascript:alert(1)", title: "tıkla" }],
          },
        ],
      }),
    );

    expect(screen.queryByRole("link", { name: "tıkla" })).toBeNull();
    // With its only source dropped, the item is honestly marked unsourced.
    expect(screen.getByText(NO_SOURCE)).toBeTruthy();
  });

  it("falls back to the URL as link text when the source has no title", () => {
    render(
      step({
        items: [
          { ...SOURCED, sources: [{ url: "https://example.org/untitled" }] },
        ],
      }),
    );

    expect(
      screen
        .getByRole("link", { name: "https://example.org/untitled" })
        .getAttribute("href"),
    ).toBe("https://example.org/untitled");
  });

  it("dropped the blanket unverified warning — sources carry the honesty now", () => {
    render(step({ items: [SOURCED, UNSOURCED] }));

    expect(
      screen.queryByText(/doğrulanmamış bakış açılarıdır/),
    ).toBeNull();
    expect(screen.queryByRole("status")).toBeNull();
  });
});

describe("SecondaryDataStep — flow unchanged (#47)", () => {
  it("does not block generation", () => {
    render(step({ items: null }));

    const uret = screen.getByRole("button", { name: "Üret" });
    expect((uret as HTMLButtonElement).disabled).toBe(false);
    fireEvent.click(uret);
    expect(
      (global.fetch as ReturnType<typeof vi.fn>).mock.calls.length,
    ).toBeGreaterThan(0);
  });

  it("keeps the select-at-least-one gate as the ONLY thing that locks Devam", () => {
    render(step({ items: [SOURCED, UNSOURCED], selected: [] }));

    expect(screen.queryByRole("link", { name: /Devam/ })).toBeNull();
    expect(screen.getByText("Devam etmek için en az bir öğe seçin.")).toBeTruthy();
  });

  it("navigates on with any selection — an unsourced item may still be chosen", () => {
    render(step({ items: [SOURCED, UNSOURCED], selected: [1] }));

    const devam = screen.getByRole("link", { name: /Devam/ });
    expect(devam.getAttribute("href")).toBe("/projects/p1/step/4");
    expect(devam.getAttribute("aria-disabled")).toBeNull();
    expect(screen.getByRole("link", { name: /Geri/ }).getAttribute("href")).toBe(
      "/projects/p1/step/2",
    );
  });

  it("presents the step as research again — sourced this time", () => {
    render(step({ items: [SOURCED] }));

    expect(screen.getByRole("heading", { name: "İkincil Veri" })).toBeTruthy();
    expect(screen.getByText("Araştırma öğeleri")).toBeTruthy();
  });
});
