"use client";

import { DEFAULT_PLATFORM, platformDef } from "@/core/platforms";
import type { CalendarRow } from "@/core/pipeline/schemas";

import { useTranslations } from "next-intl";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";

import { EmptyState } from "@/components/wizard/empty-state";
import { ErrorNotice } from "@/components/wizard/error-notice";
import { JobErrorNotice } from "@/components/wizard/job-error-notice";
import { JobProgress } from "@/components/wizard/job-progress";
import { useGenerate } from "@/components/wizard/use-generate";
import {
  CAPTION_COLUMN,
  calendarFilename,
  toCsv,
  toXlsxWorkbookBlob,
} from "@/lib/calendar-export";
import { TOTAL_STEPS } from "@/lib/workflow-steps";

/**
 * Client body for wizard step 9 — İçerik Takvimi (content_calendar). The last
 * content step, so there is no "Devam →".
 *
 * ── WHY THIS STEP HAS NO EDITING ─────────────────────────────────────────
 * Every other generative step stores structured rows and offers inline editing
 * with a debounced auto-save. content_calendar deliberately keeps its table
 * READ-ONLY (T21 scope). Hence: no auto-save, no SaveIndicator, no unmount
 * flush — the only mutations are "Yeniden üret" and the downloads.
 *
 * ── WHAT IT RECEIVES ─────────────────────────────────────────────────────
 * Since T33 the step no longer parses a freeform markdown string: it is handed
 * already-structured `CalendarRow`s, one set per platform. A platform whose set
 * is empty produced nothing and is dropped entirely (a blank tab would read as
 * a real but broken calendar), so a platform that reaches the table always has
 * rows. Whether ANY platform has rows is the only distinction left, and that is
 * the empty state.
 */
export function ContentCalendarStep({
  projectId,
  initialCalendars,
  shortfalls = [],
  brandName,
  projectName,
  language,
}: {
  projectId: string;
  /** One set of rows per platform (T29 + T33). Empty until generated. */
  initialCalendars: Array<{ platform: string; rows: CalendarRow[] }>;
  /**
   * Platforms the builder could not fill to their requested count.
   *
   * The calendar is assembled from approved posts and never invents copy, so a
   * platform with 6 approved posts against a cadence of 10 gets 6 real rows —
   * which on screen is indistinguishable from a finished calendar. Showing the
   * gap is what keeps a short calendar from reading as a complete one (hard
   * rule 5). Defaults to [] so a calendar stored before this existed, which has
   * no shortfall field at all, renders exactly as it did.
   */
  shortfalls?: Array<{ platform: string; requested: number; scheduled: number }>;
  brandName: string;
  projectName: string;
  language: string;
}) {
  const t = useTranslations("steps.contentCalendar");
  const tCommon = useTranslations("common");
  const tPlatform = useTranslations("platforms");
  const tWizard = useTranslations("wizard");
  const router = useRouter();
  const { generate, jobId, isGenerating, error, reset } = useGenerate(
    projectId,
    "content_calendar",
  );

  const [jobError, setJobError] = useState<string | null>(null);
  const [downloadError, setDownloadError] = useState<string | null>(null);
  // The underlying cause, kept so the notice never hides the truth (hard rule 5).
  const [downloadReason, setDownloadReason] = useState<string | undefined>(
    undefined,
  );

  // Only platforms whose table actually has content get a tab: an empty string
  // is a job that produced nothing for that platform, and a blank tab would
  // read as a real (but broken) calendar.
  const entries = useMemo(
    () => initialCalendars.filter((e) => e.rows.length > 0),
    [initialCalendars],
  );
  const [activeTab, setActiveTab] = useState<string>(
    entries[0]?.platform ?? DEFAULT_PLATFORM,
  );
  const activeEntry =
    entries.find((e) => e.platform === activeTab) ?? entries[0];

  const hasContent = entries.length > 0;
  // T33: the caption used to arrive as one <br>-joined blob in a single cell.
  // It arrives as separate fields now, so the table simply shows them.
  const headers = useMemo(
    () => [
      t("colDay"),
      t("colFormat"),
      t("colPillar"),
      t("colHook"),
      t("colCaption"),
      t("colCta"),
      t("colHashtags"),
    ],
    [t],
  );
  const rows = useMemo(() => toCells(activeEntry?.rows ?? []), [activeEntry]);
  const displayError = error ?? jobError;

  // A download failure names the format AND the platform it was for, so it must
  // not outlive the tab it belongs to: leaving it up while the user reads a
  // different platform points the error at the wrong calendar.
  function selectTab(platform: string) {
    setActiveTab(platform);
    setDownloadError(null);
    setDownloadReason(undefined);
  }

  function startGenerate() {
    if (isGenerating || jobId) return;
    setJobError(null);
    reset();
    void generate({});
  }

  function handleJobDone(result: { status: string; error?: string }) {
    if (result.status === "succeeded") {
      // The worker upserted the row; refresh to pick it up, then reset() so the
      // terminal <JobProgress> unmounts and cannot re-fire onDone.
      router.refresh();
      reset();
      return;
    }
    setJobError(result.error ?? tCommon("generationFailed"));
    reset();
  }

  // Async because the XLSX writer is dynamically imported (see calendar-export).
  // A failed chunk load must say so rather than look like a dead button.
  //
  // The two formats deliberately differ in scope (T33 item 3):
  //   CSV  — the ACTIVE platform only. A CSV file cannot hold several sheets,
  //          so multiple platforms would mean multiple files.
  //   XLSX — EVERY platform that has rows, one worksheet each, in ONE workbook.
  async function download(ext: "csv" | "xlsx") {
    // Whether the file is named after the tab the user is looking at. True for
    // every CSV (a CSV only ever holds the active platform, however many exist)
    // and for a single-platform XLSX. A multi-sheet workbook is not "the
    // Instagram file", so it drops the suffix.
    const nameAfterActivePlatform = ext === "csv" || entries.length === 1;
    const name = calendarFilename(
      brandName,
      projectName,
      language,
      ext,
      nameAfterActivePlatform ? activeEntry?.platform : undefined,
    );
    let blob: Blob;
    try {
      blob =
        ext === "csv"
          ? new Blob([toCsv(headers, rows)], {
              type: "text/csv;charset=utf-8",
            })
          : await toXlsxWorkbookBlob(
              entries.map((entry) => ({
                // Untranslated on purpose: the registry's promptName is the
                // production shorthand used across the calendar (see
                // core/platforms). Unregistered codes fall back to the code.
                name: platformDef(entry.platform)?.promptName ?? entry.platform,
                headers,
                rows: toCells(entry.rows),
              })),
            );
    } catch (e) {
      setDownloadError(t("downloadFailed", { format: ext.toUpperCase() }));
      setDownloadReason(e instanceof Error ? e.message : String(e));
      return;
    }
    setDownloadError(null);
    setDownloadReason(undefined);

    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    // Revoke on the next tick: revoking synchronously can race the download in
    // some browsers.
    setTimeout(() => URL.revokeObjectURL(url), 0);

    // T41: tell the server the content left the building. The file is built
    // here, so this beacon is the ONLY way a download can be audited — see the
    // route for how much that record is and is not worth.
    //
    // Fired after the download is under way and deliberately not awaited: the
    // user has their file, and a beacon that could delay or fail the download
    // it reports would be a worse trade than a missing row. A rejection is
    // swallowed HERE and only here, because the server-side write is what
    // hard rule 5 governs and it does its own loud reporting; a red console
    // error on a successful download would just teach users to ignore it.
    void fetch(
      `/api/projects/${projectId}/steps/content_calendar/download`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          format: ext,
          ...(nameAfterActivePlatform && activeEntry
            ? { platform: activeEntry.platform }
            : {}),
        }),
      },
    ).catch(() => {});
  }

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-8 px-4 py-8 sm:px-8 sm:py-10">
      <header className="flex flex-col gap-1">
        <div className="text-sm font-medium text-fg-subtle">
          {tWizard("stepIndicator", { n: 9, total: TOTAL_STEPS })}
        </div>
        <h1 className="text-2xl font-semibold tracking-tight text-fg">
          {t("title")}
        </h1>
        <p className="mt-1 text-sm text-fg-muted">{t("description")}</p>
      </header>

      {shortfalls.length > 0 && (
        <div
          role="status"
          className="flex flex-col gap-2 rounded-lg border border-border-warning bg-bg-warning px-4 py-3"
        >
          <p className="text-sm font-medium text-fg">{t("shortfallTitle")}</p>
          {shortfalls.map((s) => (
            <p key={s.platform} className="text-sm text-fg-muted">
              {t("shortfallBody", {
                platform: tPlatform(platformDef(s.platform)?.labelKey ?? s.platform),
                requested: s.requested,
                scheduled: s.scheduled,
                missing: s.requested - s.scheduled,
              })}
            </p>
          ))}
        </div>
      )}

      {!hasContent ? (
        jobId ? (
          <div className="flex flex-col gap-3 rounded-lg border border-border bg-bg p-4">
            <JobProgress jobId={jobId} onDone={handleJobDone} />
          </div>
        ) : displayError ? (
          <JobErrorNotice
            error={displayError}
            projectId={projectId}
            onRetry={startGenerate}
          />
        ) : (
          <EmptyState
            title={t("emptyTitle")}
            description={t("emptyDescription")}
            action={
              <button
                type="button"
                disabled={isGenerating}
                onClick={startGenerate}
                className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-accent-contrast transition-colors hover:bg-accent-emphasized disabled:cursor-not-allowed disabled:opacity-50"
              >
                {isGenerating ? tCommon("starting") : tCommon("generate")}
              </button>
            }
          />
        )
      ) : (
        <div className="flex flex-col gap-4">
          {jobId ? (
            <div className="flex flex-col gap-3 rounded-lg border border-border bg-bg p-4">
              <JobProgress jobId={jobId} onDone={handleJobDone} />
            </div>
          ) : displayError ? (
            <JobErrorNotice
              error={displayError}
              projectId={projectId}
              onRetry={startGenerate}
            />
          ) : null}

          {entries.length > 1 ? (
            <div role="tablist" className="flex items-center gap-2 border-b border-border">
              {entries.map((entry) => {
                const selected = entry.platform === activeEntry?.platform;
                return (
                  <button
                    key={entry.platform}
                    type="button"
                    role="tab"
                    aria-selected={selected}
                    onClick={() => selectTab(entry.platform)}
                    className={`-mb-px border-b-2 px-3 py-2 text-sm font-medium transition-colors ${
                      selected
                        ? "border-accent text-fg"
                        : "border-transparent text-fg-muted hover:text-fg"
                    }`}
                  >
                    {tPlatform(entry.platform)}
                  </button>
                );
              })}
            </div>
          ) : null}

          {/* Actions stay ABOVE the table so they remain visible however long
              the calendar is (the table scrolls inside its own box). */}
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => void download("csv")}
                className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
              >
                {t("downloadCsv")}
              </button>
              <button
                type="button"
                onClick={() => void download("xlsx")}
                className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
              >
                {/* With several platforms the XLSX is one workbook covering
                    all of them, which the label has to say — otherwise it
                    reads as "the tab I am looking at", like the CSV. */}
                {entries.length > 1 ? t("downloadXlsxAll") : t("downloadXlsx")}
              </button>
            </div>
            <button
              type="button"
              disabled={isGenerating || jobId !== null}
              onClick={startGenerate}
              className="shrink-0 rounded-lg border border-border bg-bg px-3 py-1.5 text-sm font-medium text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isGenerating ? tCommon("starting") : tCommon("regenerate")}
            </button>
          </div>

          {downloadError ? (
            <ErrorNotice message={downloadError} reason={downloadReason} />
          ) : null}

          {/* No "rows might be empty" fallback: `entries` is filtered to
              platforms that HAVE rows, so reaching this point means there is a
              table to show. */}
          <p className="text-xs text-fg-subtle">
            {t("rowCount", { count: String(rows.length) })}
          </p>
          <CalendarTable headers={headers} rows={rows} />
        </div>
      )}

      <nav className="flex items-center justify-between border-t border-border pt-4">
        <Link
          href={`/projects/${projectId}/step/8`}
          className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
        >
          {tCommon("back")}
        </Link>
      </nav>
    </div>
  );
}

/**
 * A platform's rows as flat cells, in the T33 column order (day, format,
 * pillar, hook, caption, cta, hashtags). Shared by the on-screen table and both
 * exports so a column can never drift between what is shown and what is
 * downloaded — and so the widths in calendar-export keep matching.
 */
function toCells(rows: readonly CalendarRow[]): string[][] {
  return rows.map((r) => [
    r.day,
    r.format,
    r.pillar,
    r.hook,
    r.caption,
    r.cta,
    (r.hashtags ?? []).join(" "),
  ]);
}

/**
 * The parsed calendar as a real table.
 *
 * The container owns BOTH scroll axes (`overflow-auto` + a max height) so a
 * 30-row calendar with a wide Caption column never makes the PAGE scroll
 * sideways, and the header row stays pinned while the body scrolls.
 */
function CalendarTable({
  headers,
  rows,
}: {
  headers: string[];
  rows: string[][];
}) {
  return (
    <div className="max-h-[36rem] w-full overflow-auto rounded-lg border border-border">
      <table className="w-full min-w-max border-collapse text-left text-sm">
        <thead className="sticky top-0 z-10 bg-bg-muted">
          <tr>
            {headers.map((header, i) => (
              <th
                key={i}
                scope="col"
                className="border-b border-border px-3 py-2 text-xs font-semibold whitespace-nowrap text-fg"
              >
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, r) => (
            <tr key={r} className="align-top even:bg-bg-muted/40">
              {row.map((cell, c) => (
                <td
                  key={c}
                  className={
                    "border-b border-border px-3 py-2 text-fg-muted " +
                    // Only the long freeform column (Caption) wraps and gets a
                    // width; the short columns stay on one line. Driven by the
                    // same constant as the exported sheet widths so the two
                    // cannot disagree about WHICH column is the long one — the
                    // rule used to be "the last column", which T33 turned into
                    // Hashtags while Caption ran off the side of the screen.
                    (c === CAPTION_COLUMN
                      ? "min-w-[28rem] whitespace-pre-wrap"
                      : "whitespace-nowrap")
                  }
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
