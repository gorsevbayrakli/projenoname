// @vitest-environment jsdom
//
// Locks the #11 review decision that a project's language must be an explicit
// choice. The dialog used to pre-select English; a user who skipped the field
// generated an entire campaign in the wrong language, and the language cannot
// be changed once content exists. Nothing else in the suite covers this dialog.

import { cleanup, fireEvent, screen } from "@testing-library/react";
import { renderWithIntl as render } from "@/test/render-with-intl";
import { createElement as h } from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const refreshMock = vi.fn();

vi.mock("next/navigation", () => ({
  useRouter: () => ({
    refresh: refreshMock,
    push: vi.fn(),
    replace: vi.fn(),
    back: vi.fn(),
  }),
}));

import { NewProjectDialog } from "./new-project-dialog";

function openDialog() {
  render(h(NewProjectDialog, { brandId: "b-1", brandName: "Demo Marka" }));
  // The trigger is the only button before the dialog opens.
  fireEvent.click(screen.getByRole("button"));
}

function submitButton(): HTMLButtonElement {
  return screen.getByRole("button", { name: "Oluştur" }) as HTMLButtonElement;
}

describe("NewProjectDialog language choice", () => {
  beforeEach(() => {
    vi.restoreAllMocks();
    refreshMock.mockClear();
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => new Response(null, { status: 201 })),
    );
  });

  afterEach(cleanup);

  it("starts with no language chosen and says so", () => {
    openDialog();
    expect(screen.getByText("Dil seçin")).toBeDefined();
  });

  it("keeps submit disabled until a language is chosen", () => {
    openDialog();
    fireEvent.change(screen.getByLabelText("Proje adı"), {
      target: { value: "Yaz kampanyası" },
    });
    // Name filled, language still empty: not submittable.
    expect(submitButton().disabled).toBe(true);
  });

  it("never sends a language the user did not pick", async () => {
    openDialog();
    fireEvent.change(screen.getByLabelText("Proje adı"), {
      target: { value: "Yaz kampanyası" },
    });
    fireEvent.click(submitButton());
    expect(fetch).not.toHaveBeenCalled();
  });
});
