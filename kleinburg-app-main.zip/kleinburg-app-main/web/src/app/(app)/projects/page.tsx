import { getTranslations } from "next-intl/server";
import Link from "next/link";

import { LocaleSwitcher } from "@/components/locale-switcher";
import { isSuperAdmin } from "@/core/auth/roles";
import { AccessError } from "@/core/tenancy/errors";
import { listAccessibleBrands } from "@/core/tenancy/access";
import { listProjects } from "@/core/tenancy/projects";
import type { Brand, Project } from "@/core/db/schema";
import { getCurrentUser } from "@/lib/auth-server";
import { relativeTime } from "@/lib/relative-time";
import { LogoutButton } from "@/components/logout-button";
import { Wordmark } from "@/components/wordmark";
import { NewProjectDialog } from "./new-project-dialog";

/**
 * /projects — brand + project selector.
 *
 * The (app) layout already guards auth; we re-read the user here for the
 * greeting. Brand isolation is enforced entirely by listAccessibleBrands /
 * listProjects (T7) — this page never queries brands or projects directly.
 */
export default async function ProjectsPage({
  searchParams,
}: {
  // Next 15: searchParams is a Promise.
  searchParams: Promise<{ brand?: string }>;
}) {
  const t = await getTranslations("projects");
  const tAccount = await getTranslations("account");
  const user = await getCurrentUser();
  // Layout guarantees a user; this narrows the type for the greeting.
  if (!user) return null;

  const brands = await listAccessibleBrands(user.id);

  if (brands.length === 0) {
    return (
      <main className="mx-auto flex min-h-screen max-w-2xl flex-col items-center justify-center gap-4 px-6 py-16 text-center">
        <h1 className="text-2xl font-semibold tracking-tight text-fg">
          {t("greeting", { username: user.username })}
        </h1>
        <p className="text-fg-muted">{t("noBrands")}</p>
        {/* The account area has to be reachable from HERE too: a user with no
            brand grants never renders the sidebar, and without this link the
            only screen they can reach has no way into their own profile. */}
        <Link
          href="/account"
          className="text-sm text-fg-muted transition-colors hover:text-fg"
        >
          {tAccount("title")}
        </Link>
        <LocaleSwitcher />
        <LogoutButton />
      </main>
    );
  }

  const { brand: brandParam } = await searchParams;
  let selectedBrand = brands.find((b) => b.id === brandParam) ?? brands[0];

  // Defensive: membership is already validated (selectedBrand comes from the
  // accessible list), so an AccessError here should not happen — fall back to
  // the first brand if it somehow does, keeping the highlighted brand and the
  // listed projects consistent.
  let projects: Project[] = [];
  try {
    projects = await listProjects(user.id, selectedBrand.id);
  } catch (e) {
    if (e instanceof AccessError) {
      selectedBrand = brands[0];
      projects = await listProjects(user.id, selectedBrand.id);
    } else {
      throw e;
    }
  }

  return (
    // Column on phones, two-pane from `md` up — a fixed 256px sidebar leaves a
    // 375px screen unusable (T22).
    <div className="flex min-h-screen flex-col bg-bg md:flex-row">
      <Sidebar
        username={user.username}
        brands={brands}
        selectedBrandId={selectedBrand.id}
        isAdmin={isSuperAdmin(user)}
      />

      <main className="flex-1 overflow-x-hidden bg-bg-subtle">
        <div className="mx-auto flex max-w-5xl flex-col gap-8 px-8 py-10">
          <header className="flex items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-semibold tracking-tight text-fg">
                {t("greeting", { username: user.username })}
              </h1>
              <p className="mt-1 text-sm text-fg-muted">
                {selectedBrand.name}
              </p>
            </div>
          </header>

          {projects.length === 0 ? (
            <div className="flex flex-col items-start gap-4 rounded-lg border border-border bg-bg p-8">
              <p className="text-fg-muted">{t("empty")}</p>
              <div className="w-56">
                <NewProjectDialog
                  key={selectedBrand.id}
                  brandId={selectedBrand.id}
                  brandName={selectedBrand.name}
                />
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {projects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

async function Sidebar({
  username,
  brands,
  selectedBrandId,
  isAdmin,
}: {
  username: string;
  brands: Brand[];
  selectedBrandId: string;
  /**
   * Shows the admin link. Convenience ONLY — /admin re-checks the role
   * server-side and so does every endpoint it calls. Hiding this link is not
   * what keeps a non-admin out (T40).
   */
  isAdmin: boolean;
}) {
  const t = await getTranslations("projects");
  const tActivity = await getTranslations("activity");
  const tAccount = await getTranslations("account");
  const tSpend = await getTranslations("spend");
  const selectedBrand = brands.find((b) => b.id === selectedBrandId)!;

  return (
    <>
      {/* Mobile (< md): a compact bar with a horizontally scrollable brand
          strip. The strip owns its overflow, so the page never scrolls
          sideways at 375px. */}
      <div className="flex flex-col gap-3 border-b border-border bg-bg px-4 py-3 md:hidden">
        <div className="flex items-center justify-between gap-3">
          {/* T45: the same typographic logo as the login page, top left. */}
          <Wordmark href="/projects" className="shrink-0" />
          <div className="flex min-w-0 items-center gap-3">
            {/* The username IS the entry point to the account area — the
                convention every user already expects, and it costs no width
                in a row that is already tight at 375px. */}
            <Link
              href="/account"
              className="truncate text-sm text-fg-muted transition-colors hover:text-fg"
            >
              {username}
            </Link>
            {isAdmin ? (
              <Link
                href="/admin"
                className="shrink-0 text-sm text-fg-muted transition-colors hover:text-fg"
              >
                {t("adminPanel")}
              </Link>
            ) : null}
            {/* NOT admin-gated: every user may read their OWN audit records.
                How much they see is decided by listAuditEvents, server-side. */}
            <Link
              href="/activity"
              className="shrink-0 text-sm text-fg-muted transition-colors hover:text-fg"
            >
              {tActivity("link")}
            </Link>
            {/* Same reasoning as /activity: not admin-gated. Every user may
                see spend for the brands they are granted, and getBrandSpend
                decides how much that is, server-side. */}
            <Link
              href="/spend"
              className="shrink-0 text-sm text-fg-muted transition-colors hover:text-fg"
            >
              {tSpend("link")}
            </Link>
            <LocaleSwitcher />
            {/* w-auto, not the component's default w-full: inside this flex
                row a full-width button claims ~250px and cannot shrink, which
                pushed itself and the username off the right edge at 375px
                (the page measured 453px wide). Pre-existing, found while
                placing the logo in this same row (T45/T22). */}
            <LogoutButton className="w-auto" />
          </div>
        </div>

        <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
          {brands.map((brand) => {
            const active = brand.id === selectedBrandId;
            return (
              <Link
                key={brand.id}
                href={`/projects?brand=${brand.id}`}
                className={
                  "shrink-0 rounded-lg px-3 py-1.5 text-sm whitespace-nowrap transition-colors " +
                  (active
                    ? "bg-accent-subtle font-medium text-accent-fg"
                    : "text-fg-muted hover:bg-bg-muted hover:text-fg")
                }
              >
                {brand.name}
              </Link>
            );
          })}
        </div>

        <NewProjectDialog
          key={selectedBrand.id}
          brandId={selectedBrand.id}
          brandName={selectedBrand.name}
        />
      </div>

      {/* Desktop (>= md): the full sidebar. */}
      <aside className="hidden w-64 shrink-0 flex-col gap-6 border-r border-border bg-bg px-4 py-6 md:flex">
        {/* T45: the same typographic logo as the login page, top left. */}
        <div className="px-2">
          <Wordmark href="/projects" />
        </div>

        <NewProjectDialog
          key={selectedBrand.id}
          brandId={selectedBrand.id}
          brandName={selectedBrand.name}
        />

        <nav className="flex flex-1 flex-col gap-1">
          <div className="px-2 pb-1 text-xs font-medium tracking-wide text-fg-subtle uppercase">
            {t("brands")}
          </div>
          {brands.map((brand) => {
            const active = brand.id === selectedBrandId;
            return (
              <Link
                key={brand.id}
                href={`/projects?brand=${brand.id}`}
                className={
                  "truncate rounded-lg px-3 py-2 text-sm transition-colors " +
                  (active
                    ? "bg-accent-subtle font-medium text-accent-fg"
                    : "text-fg-muted hover:bg-bg-muted hover:text-fg")
                }
              >
                {brand.name}
              </Link>
            );
          })}
        </nav>

        <div className="flex flex-col gap-3 border-t border-border pt-4">
          {isAdmin ? (
            <Link
              href="/admin"
              className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
            >
              {t("adminPanel")}
            </Link>
          ) : null}
          <Link
            href="/activity"
            className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
          >
            {tActivity("link")}
          </Link>
          {/* Neither link is admin-gated, and neither could be: /account only
              ever shows the caller their own row, and /spend is scoped to the
              brands the caller can already reach. Scope is decided by the
              query, not by hiding the door. */}
          <Link
            href="/account"
            className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
          >
            {tAccount("title")}
          </Link>
          <Link
            href="/spend"
            className="rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
          >
            {tSpend("link")}
          </Link>
          <div className="flex items-center justify-between gap-2 px-2">
            <Link
              href="/account"
              className="truncate text-sm text-fg-muted transition-colors hover:text-fg"
            >
              {username}
            </Link>
            <LocaleSwitcher />
          </div>
          <LogoutButton />
        </div>
      </aside>
    </>
  );
}

async function ProjectCard({ project }: { project: Project }) {
  // The CONTENT language badge — its display name follows the interface
  // locale (T25), while the stored code is untouched.
  const languageName = await getTranslations("contentLanguages");
  const tRelative = await getTranslations("relativeTime");
  return (
    // Links to the wizard route (/projects/[id]) built in T13; navigating there
    // may 404 until then — that is expected.
    // NOTE: "aktif adım" (current step) is deferred — step_contents does not
    // exist until T9.
    <Link
      href={`/projects/${project.id}`}
      className="flex flex-col gap-3 rounded-lg border border-border bg-bg p-4 transition-colors hover:border-border-emphasized hover:bg-bg-muted"
    >
      <div className="font-medium text-fg">{project.name}</div>
      <div className="flex items-center justify-between gap-2">
        <span className="rounded-md bg-bg-muted px-2 py-0.5 text-xs font-medium text-fg-muted">
          {languageName(project.language)}
        </span>
        <span className="text-xs text-fg-subtle">
          {relativeTime(new Date(project.updatedAt), tRelative)}
        </span>
      </div>
    </Link>
  );
}
