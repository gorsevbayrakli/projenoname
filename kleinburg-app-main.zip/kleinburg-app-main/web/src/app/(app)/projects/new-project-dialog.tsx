"use client";

import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { ProjectLanguage } from "@/core/tenancy/projects";
import { LANGUAGE_OPTIONS } from "@/lib/languages";
import { apiErrorMessage, type ApiErrorTranslator } from "@/lib/api-error-copy";

type NewProjectDialogProps = {
  brandId: string;
  brandName: string;
};

/**
 * "＋ Yeni proje" dialog. The brand is fixed to the currently-selected brand
 * (shown read-only). On a successful create we refresh the route so the new
 * card appears; we intentionally do NOT push to /projects/[id] because the
 * wizard route is not built until T13 and would 404.
 */
export function NewProjectDialog({ brandId, brandName }: NewProjectDialogProps) {
  const t = useTranslations("newProject");
  // The 7 CONTENT languages the engine generates in — unrelated to the
  // interface locale, but their display names follow it (T25).
  const languageName = useTranslations("contentLanguages");
  const tCommon = useTranslations("common");
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  // No pre-selected language. Every generation step writes in the project's
  // language, and it cannot be changed once content exists, so a pre-selected
  // value is a trap: whoever misses the field ships a whole campaign in the
  // wrong language. Empty string = nothing chosen yet; submit stays disabled.
  const [language, setLanguage] = useState<ProjectLanguage | "">("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function reset() {
    setName("");
    setLanguage("");
    setError(null);
    setPending(false);
  }

  async function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    setError(null);
    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ brandId, name, language }),
      });
      if (res.status === 201) {
        setOpen(false);
        reset();
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => null)) as {
        error?: string;
        code?: string;
      } | null;
      setError(apiErrorMessage(data, tApi, t("failed")));
    } catch {
      setError(tCommon("networkError"));
    } finally {
      setPending(false);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) reset();
      }}
    >
      <DialogTrigger
        render={
          <Button className="w-full bg-accent text-accent-contrast hover:bg-accent/90">
            {t("trigger")}
          </Button>
        }
      />
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{t("title")}</DialogTitle>
          <DialogDescription>
            {t("description", { brandName })}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={onSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="new-project-brand">{t("brandLabel")}</Label>
            <Input
              id="new-project-brand"
              value={brandName}
              readOnly
              disabled
              className="cursor-not-allowed"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="new-project-name">{t("nameLabel")}</Label>
            <Input
              id="new-project-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={t("namePlaceholder")}
              autoFocus
              required
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <Label htmlFor="new-project-language">{t("languageLabel")}</Label>
            <Select
              value={language}
              onValueChange={(value) => setLanguage(value as ProjectLanguage)}
            >
              <SelectTrigger id="new-project-language" className="w-full">
                <SelectValue>
                  {language ? languageName(language) : t("languagePlaceholder")}
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                {LANGUAGE_OPTIONS.map((code) => (
                  <SelectItem key={code} value={code}>
                    {languageName(code)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {error ? (
            <p className="text-sm text-fg-error" role="alert">
              {error}
            </p>
          ) : null}

          <DialogFooter>
            <DialogClose
              render={
                <Button type="button" variant="outline" disabled={pending}>
                  {tCommon("cancel")}
                </Button>
              }
            />
            <Button
              type="submit"
              disabled={pending || name.trim().length === 0 || language === ""}
            >
              {pending ? t("submitting") : t("submit")}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
