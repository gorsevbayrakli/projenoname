import { redirect } from "next/navigation";

import { getCurrentUser } from "@/lib/auth-server";

/**
 * Auth guard for the whole (app) route group: real (DB-backed) session
 * validation runs here so every page under (app) is protected by default.
 * Middleware only does a cheap cookie-presence check at the edge; this layout
 * is the authoritative server-side gate.
 *
 * It also carries the first-login password change (T40). An account still
 * holding the temporary password an admin set is bounced to /change-password
 * — which lives OUTSIDE this route group precisely so this redirect cannot
 * loop.
 *
 * This redirect is the ergonomics of the rule, not the rule itself: the JSON
 * API is closed independently by `requireApiUser`, so nothing is reachable by
 * skipping the page.
 */
export default async function AppLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.mustChangePassword) redirect("/change-password");
  return <>{children}</>;
}
