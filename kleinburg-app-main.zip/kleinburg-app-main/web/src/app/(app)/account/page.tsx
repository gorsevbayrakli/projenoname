import { getLocale, getTranslations } from "next-intl/server";
import Link from "next/link";
import { redirect } from "next/navigation";

import { LocaleSwitcher } from "@/components/locale-switcher";
import { LogoutButton } from "@/components/logout-button";
import { getAccountProfile } from "@/core/account/service";
import { listAccessibleBrands } from "@/core/tenancy/access";
import { listRecentProjects } from "@/core/tenancy/projects";
import { getCurrentUser } from "@/lib/auth-server";
import { relativeTime } from "@/lib/relative-time";
import { ProfileForm } from "./profile-form";

/**
 * /account — the user's own account area (T43).
 *
 * Four things, all self-scoped: profile info, the password-change entry point,
 * the interface language, and recent work.
 *
 * ── WHAT THIS PAGE DELIBERATELY DOES NOT DO ──────────────────────────────
 * It never reads another user's row and never lists a brand or project outside
 * the caller's grants. `listRecentProjects` does the scoping through
 * `listAccessibleBrands` (hard rule 2); this page just renders its answer.
 *
 * Password changing is a LINK to /change-password, not a second form. That
 * flow shipped in T40 for the forced first-login case and already carries the
 * rules, the rate limiter and the audit write. Two forms would mean two
 * copies of the password policy, and one of them would eventually be wrong.
 */
export default async function AccountPage() {
  const t = await getTranslations("account");
  const tRelative = await getTranslations("relativeTime");
  const tLocale = await getTranslations("locale");

  // The (app) layout already guards this, but a page that reads a profile
  // states its own precondition rather than inheriting it silently.
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  // Brands are read separately from the projects so the empty state can tell
  // "you have brands but no projects yet" apart from "you have no brands" —
  // different problems, and only the second one is the administrator's to fix.
  const [profile, brands, recent] = await Promise.all([
    getAccountProfile(user.id),
    listAccessibleBrands(user.id),
    listRecentProjects(user.id),
  ]);

  /**
   * The name of the language THIS PAGE IS IN, which is not the same question
   * as where the choice is stored (#43 review, finding 2).
   *
   * `getLocale()` is next-intl's resolved answer — the output of
   * `resolveEffectiveLocale`, account preference and cookie already weighed.
   * Deriving it from `profile.uiLocale` instead was wrong for exactly the
   * users whose column is NULL: the cookie decides, the whole page renders in
   * English, and the card would announce "Şu anki dil: Türkçe".
   *
   * The SECOND question — account-bound or this-device-only — still reads the
   * column further down, because the column is the only thing that answers it.
   */
  const activeLocale = await getLocale();
  // Name the resolved locale in its own catalog entry. This used to be a
  // two-locale binary (en ? enFull : trFull), which announced "Türkçe" for
  // every locale that wasn't English — wrong the moment fr/it/es/de landed.
  // Every catalog carries a `<code>Full` key for all six locales.
  const localeName = tLocale(`${activeLocale}Full`);

  return (
    <main className="mx-auto flex w-full max-w-2xl flex-col gap-8 px-6 py-10">
      <header className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-fg">
            {t("title")}
          </h1>
          <p className="mt-1 text-sm text-fg-muted">{t("subtitle")}</p>
        </div>
        <Link
          href="/projects"
          className="shrink-0 rounded-lg px-3 py-2 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
        >
          {t("backToProjects")}
        </Link>
      </header>

      <Section title={t("profileTitle")} description={t("profileDescription")}>
        <ProfileForm
          username={profile.username}
          displayName={profile.displayName}
          email={profile.email}
        />
        <dl className="flex flex-wrap gap-x-8 gap-y-2 border-t border-border pt-4 text-sm">
          <div>
            <dt className="text-fg-subtle">{t("roleLabel")}</dt>
            <dd className="text-fg">
              {profile.role === "admin" ? t("roleAdmin") : t("roleUser")}
            </dd>
          </div>
          <div>
            <dt className="text-fg-subtle">{t("memberSince")}</dt>
            <dd className="text-fg">
              {relativeTime(new Date(profile.createdAt), tRelative)}
            </dd>
          </div>
        </dl>
      </Section>

      <Section
        title={t("languageTitle")}
        description={t("languageDescription")}
      >
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm text-fg">
              {t("languageCurrent", { language: localeName })}
            </p>
            <p className="mt-1 text-xs text-fg-muted">
              {/* Says WHERE the current choice lives, because "account" and
                  "this device" behave differently on the next device. */}
              {profile.uiLocale
                ? t("languageAccountBound")
                : t("languageCookieOnly")}
            </p>
          </div>
          <LocaleSwitcher />
        </div>
      </Section>

      <Section
        title={t("securityTitle")}
        description={t("securityDescription")}
      >
        <div>
          <Link
            href="/change-password"
            className="inline-flex h-9 items-center rounded-lg border border-border px-4 text-sm font-medium text-fg transition-colors hover:bg-bg-muted"
          >
            {t("changePassword")}
          </Link>
        </div>
      </Section>

      <Section title={t("recentTitle")} description={t("recentDescription")}>
        {recent.length === 0 ? (
          <p className="text-sm text-fg-muted">
            {brands.length === 0 ? t("recentNoBrands") : t("recentEmpty")}
          </p>
        ) : (
          <ul className="flex flex-col gap-2">
            {recent.map((project) => (
              <li key={project.id}>
                <Link
                  href={`/projects/${project.id}`}
                  className="flex flex-col gap-1 rounded-lg border border-border p-3 transition-colors hover:border-border-emphasized hover:bg-bg-muted"
                >
                  <span className="text-sm font-medium text-fg">
                    {project.name}
                  </span>
                  <span className="text-xs text-fg-muted">
                    {project.brandName} ·{" "}
                    {t("recentUpdated", {
                      when: relativeTime(
                        new Date(project.updatedAt),
                        tRelative,
                      ),
                    })}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        )}
        <div>
          <Link
            href="/projects"
            className="text-sm text-accent-fg hover:underline"
          >
            {t("allProjects")}
          </Link>
        </div>
      </Section>

      <div className="border-t border-border pt-6">
        <LogoutButton className="w-auto" />
      </div>
    </main>
  );
}

/** Shared card chrome, matching the admin panel's Section. */
function Section({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="flex flex-col gap-4 rounded-lg border border-border bg-bg p-6">
      <div>
        <h2 className="text-lg font-semibold tracking-tight text-fg">{title}</h2>
        {description ? (
          <p className="mt-1 text-sm text-fg-muted">{description}</p>
        ) : null}
      </div>
      {children}
    </section>
  );
}
