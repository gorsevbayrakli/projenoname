// @vitest-environment jsdom
/**
 * T43 — the account profile form.
 *
 * Assertions are against real Turkish sentences from messages/tr.json, the
 * house convention: a test that passes against a missing key is not a test.
 */
import { cleanup, fireEvent, screen, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

import { renderWithIntl } from "@/test/render-with-intl";
import { ProfileForm } from "./profile-form";

vi.mock("next/navigation", () => ({
  useRouter: () => ({ refresh: vi.fn(), push: vi.fn() }),
}));

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

function stubFetch(response: {
  ok: boolean;
  body?: unknown;
}): ReturnType<typeof vi.fn> {
  const fetchMock = vi.fn().mockResolvedValue({
    ok: response.ok,
    json: async () => response.body ?? {},
  });
  vi.stubGlobal("fetch", fetchMock);
  return fetchMock;
}

describe("ProfileForm", () => {
  it("shows the username as read-only, not as an editable field", () => {
    // The username is the identity the audit trail refers to. Renaming it is
    // an admin decision, so the form must show it without offering to change it.
    renderWithIntl(
      <ProfileForm username="elif" displayName={null} email={null} />,
    );

    const field = screen.getByLabelText("Kullanıcı adı") as HTMLInputElement;
    expect(field.value).toBe("elif");
    expect(field.readOnly).toBe(true);
    expect(field.disabled).toBe(true);
  });

  it("sends both fields and confirms the save", async () => {
    const fetchMock = stubFetch({ ok: true, body: { profile: {} } });
    renderWithIntl(
      <ProfileForm username="elif" displayName="Eski Ad" email={null} />,
    );

    fireEvent.change(screen.getByLabelText("Ad soyad"), {
      target: { value: "Yeni Ad" },
    });
    fireEvent.change(screen.getByLabelText("E-posta"), {
      target: { value: "yeni@ornek.com" },
    });
    fireEvent.submit(
      screen.getByRole("button", { name: "Kaydet" }).closest("form")!,
    );

    await waitFor(() => {
      expect(screen.getByRole("status").textContent).toBe(
        "Profil bilgileri kaydedildi",
      );
    });

    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toBe("/api/account/profile");
    expect(init.method).toBe("PATCH");
    expect(JSON.parse(init.body)).toEqual({
      displayName: "Yeni Ad",
      email: "yeni@ornek.com",
    });
  });

  it("renders the server's error code in the interface language", async () => {
    // The API answers in Turkish prose plus a code; the client renders the
    // CODE's copy, never the server's sentence.
    stubFetch({
      ok: false,
      body: { error: "Bu e-posta adresi başka bir hesapta kayıtlı", code: "EMAIL_TAKEN" },
    });
    renderWithIntl(
      <ProfileForm username="elif" displayName={null} email={null} />,
    );

    fireEvent.change(screen.getByLabelText("E-posta"), {
      target: { value: "alinmis@ornek.com" },
    });
    fireEvent.submit(
      screen.getByRole("button", { name: "Kaydet" }).closest("form")!,
    );

    await waitFor(() => {
      expect(screen.getByRole("alert").textContent).toBe(
        "Bu e-posta adresi başka bir hesapta kayıtlı",
      );
    });
    expect(screen.queryByRole("status")).toBeNull();
  });

  it("reports a network failure instead of claiming success", async () => {
    // Hard rule 5, at the UI layer: a thrown fetch must not leave the last
    // "saved" banner on screen.
    vi.stubGlobal("fetch", vi.fn().mockRejectedValue(new Error("offline")));
    renderWithIntl(
      <ProfileForm username="elif" displayName={null} email={null} />,
    );

    fireEvent.submit(
      screen.getByRole("button", { name: "Kaydet" }).closest("form")!,
    );

    await waitFor(() => {
      expect(screen.getByRole("alert").textContent).toBe("Kaydedilemedi");
    });
  });
});
