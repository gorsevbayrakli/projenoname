// @vitest-environment jsdom
/**
 * The account page's language card (#43 review, finding 2).
 *
 * The card answers two DIFFERENT questions and T43 answered both from one
 * field:
 *
 *   "which language am I looking at?"  — the RESOLVED locale, i.e. what
 *      next-intl actually rendered this page in;
 *   "where does that choice live?"     — the account column, which is the only
 *      thing that says account-bound vs this-device-only.
 *
 * Reading the first from `profile.uiLocale` is wrong whenever the column is
 * NULL: the cookie decides, the page renders in English, and the card claims
 * Türkçe. So the two are read from two sources here, and the test that matters
 * is the one where they disagree.
 */
import { cleanup, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { renderWithIntl } from "@/test/render-with-intl";
import messages from "../../../../messages/tr.json";

const locale = vi.fn();
vi.mock("next-intl/server", () => ({
  getLocale: () => locale(),
  // Real Turkish out of the catalog, the house convention: a test that passes
  // against a missing key is not a test.
  getTranslations: async (namespace: keyof typeof messages) => {
    const table = messages[namespace] as Record<string, string>;
    return (key: string, values?: Record<string, string>) => {
      const template = table[key];
      if (template === undefined) throw new Error(`missing key ${namespace}.${key}`);
      return values
        ? template.replace(/\{(\w+)\}/g, (_, name) => values[name] ?? "")
        : template;
    };
  },
}));

const getCurrentUser = vi.fn();
vi.mock("@/lib/auth-server", () => ({ getCurrentUser: () => getCurrentUser() }));

const getAccountProfile = vi.fn();
vi.mock("@/core/account/service", () => ({
  getAccountProfile: (id: string) => getAccountProfile(id),
}));

vi.mock("@/core/tenancy/access", () => ({
  listAccessibleBrands: async () => [],
}));
vi.mock("@/core/tenancy/projects", () => ({
  listRecentProjects: async () => [],
}));
vi.mock("next/navigation", () => ({
  redirect: () => {
    throw new Error("redirected");
  },
  useRouter: () => ({ refresh: vi.fn(), push: vi.fn() }),
}));

const AccountPage = (await import("./page")).default;

function profile(uiLocale: "tr" | "en" | null) {
  return {
    id: "user-1",
    username: "elif",
    displayName: null,
    email: null,
    uiLocale,
    role: "user" as const,
    createdAt: new Date(),
  };
}

beforeEach(() => {
  vi.clearAllMocks();
  getCurrentUser.mockResolvedValue({ id: "user-1" });
});

afterEach(cleanup);

describe("AccountPage language card", () => {
  it("names the language the page is actually rendered in, not the column", async () => {
    // THE FINDING: no account preference, cookie says English. The whole page
    // is English; reading `profile.uiLocale` here would announce "Türkçe".
    getAccountProfile.mockResolvedValue(profile(null));
    locale.mockResolvedValue("en");

    renderWithIntl(await AccountPage());

    expect(screen.getByText("Şu anki dil: English")).toBeTruthy();
  });

  it("names a new interface locale by its own name, not Turkish", async () => {
    // FR/IT/ES/DE were added after the card's original two-locale binary
    // (`activeLocale === "en" ? enFull : trFull`), which fell every non-en
    // locale through to "Türkçe". A French page must read "Français".
    getAccountProfile.mockResolvedValue(profile(null));
    locale.mockResolvedValue("fr");

    renderWithIntl(await AccountPage());

    expect(screen.getByText("Şu anki dil: Français")).toBeTruthy();
  });

  it("still distinguishes an account-bound choice from a device-only one", async () => {
    // The SECOND question, which the column is the right source for. A NULL
    // column means the choice has not travelled to the account yet, whatever
    // language the page happens to be in.
    getAccountProfile.mockResolvedValue(profile(null));
    locale.mockResolvedValue("en");

    renderWithIntl(await AccountPage());

    expect(screen.getByText(messages.account.languageCookieOnly)).toBeTruthy();
    expect(screen.queryByText(messages.account.languageAccountBound)).toBeNull();
  });

  it("reports an account-bound preference when the column holds one", async () => {
    getAccountProfile.mockResolvedValue(profile("tr"));
    locale.mockResolvedValue("tr");

    renderWithIntl(await AccountPage());

    expect(screen.getByText("Şu anki dil: Türkçe")).toBeTruthy();
    expect(screen.getByText(messages.account.languageAccountBound)).toBeTruthy();
  });
});
