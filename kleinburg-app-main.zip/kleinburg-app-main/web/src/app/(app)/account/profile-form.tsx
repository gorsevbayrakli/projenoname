"use client";

import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { apiErrorMessage, type ApiErrorTranslator } from "@/lib/api-error-copy";

const inputClass =
  "h-9 rounded-lg border border-border bg-background px-3 text-sm text-fg outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50";

/**
 * The account area's only editable form (T43): display name and e-mail.
 *
 * Follows the T40 admin-panel pattern rather than inventing a second one —
 * fetch to an endpoint that re-checks authorization server-side, then
 * `router.refresh()` so what is on screen is the server's answer, not
 * optimistic local state.
 *
 * The username is rendered here but is deliberately NOT a field: it is the
 * identity other tables and the audit trail refer to, so changing it is an
 * admin decision, not a self-service one.
 */
export function ProfileForm({
  username,
  displayName,
  email,
}: {
  username: string;
  displayName: string | null;
  email: string | null;
}) {
  const t = useTranslations("account");
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const router = useRouter();

  const [nameValue, setNameValue] = useState(displayName ?? "");
  const [emailValue, setEmailValue] = useState(email ?? "");
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setOk(null);
    setPending(true);
    try {
      const res = await fetch("/api/account/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ displayName: nameValue, email: emailValue }),
      });
      if (res.ok) {
        setOk(t("saved"));
        router.refresh();
        return;
      }
      const data = await res.json().catch(() => null);
      setError(apiErrorMessage(data, tApi, t("failed")));
    } catch {
      setError(t("failed"));
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-4">
      <div className="flex flex-col gap-1.5">
        <label
          htmlFor="account-username"
          className="text-sm font-medium text-fg"
        >
          {t("username")}
        </label>
        <input
          id="account-username"
          className={`${inputClass} opacity-60`}
          value={username}
          readOnly
          disabled
          aria-describedby="account-username-hint"
        />
        <p id="account-username-hint" className="text-xs text-fg-muted">
          {t("usernameHint")}
        </p>
      </div>

      <div className="flex flex-col gap-1.5">
        <label
          htmlFor="account-display-name"
          className="text-sm font-medium text-fg"
        >
          {t("displayName")}
        </label>
        <input
          id="account-display-name"
          className={inputClass}
          value={nameValue}
          placeholder={t("displayNamePlaceholder")}
          onChange={(e) => setNameValue(e.target.value)}
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="account-email" className="text-sm font-medium text-fg">
          {t("email")}
        </label>
        <input
          id="account-email"
          className={inputClass}
          type="email"
          value={emailValue}
          placeholder={t("emailPlaceholder")}
          onChange={(e) => setEmailValue(e.target.value)}
          aria-describedby="account-email-hint"
        />
        <p id="account-email-hint" className="text-xs text-fg-muted">
          {t("emailHint")}
        </p>
      </div>

      {error ? (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      ) : null}
      {!error && ok ? (
        <p role="status" className="text-sm text-fg-muted">
          {ok}
        </p>
      ) : null}

      <div>
        <Button type="submit" variant="secondary" disabled={pending}>
          {pending ? t("saving") : t("save")}
        </Button>
      </div>
    </form>
  );
}
