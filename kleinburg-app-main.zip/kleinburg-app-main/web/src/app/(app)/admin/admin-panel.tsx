"use client";

import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { MIN_PASSWORD_LENGTH } from "@/core/auth/password-policy";
import { isSuperAdmin } from "@/core/auth/roles";
import type { Brand } from "@/core/db/schema";
import { apiErrorMessage, type ApiErrorTranslator } from "@/lib/api-error-copy";

/** Mirrors core/admin/service.ts AdminUser, minus the Date serialisation. */
export interface AdminUserView {
  id: string;
  username: string;
  role: "admin" | "user";
  isActive: boolean;
  mustChangePassword: boolean;
  brands: Brand[];
}

/**
 * The admin panel's interactive half (T40): create a brand, create a user,
 * assign a user to a brand, reset a user's temporary password, and — since
 * #89 — promote an existing user to administrator or take those rights away.
 *
 * Every action is a fetch to an endpoint that re-checks the admin role
 * server-side. This component renders controls; it does not grant anything.
 * After a successful call it calls `router.refresh()` so the server component
 * re-reads the directory — the list on screen is always the server's answer,
 * never optimistic local state that could drift from what access control
 * actually says.
 */
export function AdminPanel({
  brands,
  users,
  currentUserId,
}: {
  brands: Brand[];
  users: AdminUserView[];
  /**
   * Who is signed in (#89). Used for ONE thing: choosing the wording of the
   * role-change confirmation, because stepping down is the click the clicker
   * cannot undo themselves. It is never a permission decision — every rule
   * that matters is the server's, and the last-admin refusal is a count in
   * `setUserRole`, not an id comparison anywhere on this page.
   */
  currentUserId: string;
}) {
  return (
    <div className="flex flex-col gap-8">
      <CreateBrandSection brands={brands} />
      <BrandCapsSection brands={brands} />
      <CreateUserSection />
      <UsersSection
        brands={brands}
        users={users}
        currentUserId={currentUserId}
      />
    </div>
  );
}

/** Shared card chrome. */
function Section({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="flex flex-col gap-4 rounded-lg border border-border bg-bg p-6">
      <div>
        <h2 className="text-lg font-semibold tracking-tight text-fg">{title}</h2>
        {description ? (
          <p className="mt-1 text-sm text-fg-muted">{description}</p>
        ) : null}
      </div>
      {children}
    </section>
  );
}

/** A submit result banner. Never carries password text — only codes/messages. */
function Feedback({ error, ok }: { error: string | null; ok: string | null }) {
  if (error) {
    return (
      <p role="alert" className="text-sm text-destructive">
        {error}
      </p>
    );
  }
  if (ok) {
    return (
      <p role="status" className="text-sm text-fg-muted">
        {ok}
      </p>
    );
  }
  return null;
}

const inputClass =
  "h-9 rounded-lg border border-border bg-background px-3 text-sm text-fg outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50";

function CreateBrandSection({ brands }: { brands: Brand[] }) {
  const t = useTranslations("admin");
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const router = useRouter();
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setOk(null);
    setPending(true);
    try {
      const res = await fetch("/api/admin/brands", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      if (res.ok) {
        setName("");
        setOk(t("brandCreated"));
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => null)) as {
        error?: string;
        code?: string;
      } | null;
      setError(apiErrorMessage(data, tApi, t("failed")));
    } catch {
      setError(t("failed"));
    } finally {
      setPending(false);
    }
  }

  return (
    <Section title={t("brandsTitle")} description={t("brandsDescription")}>
      <form onSubmit={onSubmit} className="flex flex-wrap items-end gap-3">
        <div className="flex min-w-48 flex-1 flex-col gap-1.5">
          <label htmlFor="brandName" className="text-sm font-medium text-fg">
            {t("brandName")}
          </label>
          <input
            id="brandName"
            name="brandName"
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className={inputClass}
          />
        </div>
        <Button type="submit" disabled={pending || name.trim().length === 0}>
          {pending ? t("creating") : t("createBrand")}
        </Button>
      </form>

      <Feedback error={error} ok={ok} />

      {brands.length === 0 ? (
        <p className="text-sm text-fg-subtle">{t("noBrands")}</p>
      ) : (
        <ul className="flex flex-wrap gap-2">
          {brands.map((brand) => (
            <li
              key={brand.id}
              className="rounded-md bg-bg-muted px-2.5 py-1 text-sm text-fg-muted"
            >
              {brand.name}
              {brand.isActive ? "" : ` (${t("inactive")})`}
            </li>
          ))}
        </ul>
      )}
    </Section>
  );
}

/**
 * Monthly spend caps, one row per brand (T51).
 *
 * ── WHAT THIS SECTION IS AND IS NOT ──────────────────────────────────────
 * It writes a number. It does not enforce anything: the refusal lives in
 * `enqueueGeneration`, server-side, before a job row exists, and is unreachable
 * from this file. #51 item 3 — a hidden button is not a limit — cuts both ways,
 * and the honest version of it is that this component is a form, not a control.
 *
 * ── AN EMPTY FIELD MEANS UNLIMITED, AND SAYS SO ──────────────────────────
 * There is no default and there is no placeholder number, because a suggested
 * figure is a decision made on the operator's behalf about when their work
 * stops. Clearing the field and saving REMOVES the cap; typing 0 sets a cap of
 * zero, which refuses everything. Those are different things and the copy says
 * which is which, since the difference is invisible from the field alone.
 *
 * ── THE 1 SEPTEMBER NOTE ─────────────────────────────────────────────────
 * Sonnet 5's promotional pricing ends 31 August 2026 ($2/$10 -> $3/$15 per
 * million), so from 1 September the same work costs roughly 50% more and a cap
 * denominated in dollars silently buys about a third less of it. That warning
 * is placed HERE, next to the input, rather than on /spend: it is only
 * actionable at the moment somebody is choosing the number. No price is
 * hardcoded anywhere in the product to compensate (see core/llm/spend.ts) —
 * this sentence is the compensation.
 */
function BrandCapsSection({ brands }: { brands: Brand[] }) {
  const t = useTranslations("admin");

  return (
    <Section title={t("capsTitle")} description={t("capsDescription")}>
      <p className="rounded-md border border-border bg-bg-muted p-3 text-sm text-fg-muted">
        {t("capsPricingNote")}
      </p>

      {brands.length === 0 ? (
        <p className="text-sm text-fg-subtle">{t("noBrands")}</p>
      ) : (
        <ul className="flex flex-col gap-3">
          {brands.map((brand) => (
            <BrandCapRow key={brand.id} brand={brand} />
          ))}
        </ul>
      )}
    </Section>
  );
}

function BrandCapRow({ brand }: { brand: Brand }) {
  const t = useTranslations("admin");
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const router = useRouter();
  // `monthly_cap_usd` is numeric, so the driver hands back a STRING to avoid a
  // silent precision loss. Rendered as-is rather than through Number(), which
  // would turn a stored "50.00" into "50" and make a saved value look edited.
  const [value, setValue] = useState(brand.monthlyCapUsd ?? "");
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [pending, setPending] = useState(false);
  /**
   * `<input type="number">` reports a value it could not parse as the EMPTY
   * STRING, which made "3o.oo" and "clear this brand's cap" indistinguishable
   * to the code below — and the `invalid` guard could not fire, because there
   * was nothing left to find fault with. `validity.badInput` is the browser
   * telling us which of the two happened, and it is the only thing that can.
   */
  const [badInput, setBadInput] = useState(false);
  /** Set by the first click on a clear, cleared by any edit. See `save`. */
  const [confirmingClear, setConfirmingClear] = useState(false);

  const trimmed = value.trim();
  const parsed = trimmed === "" ? null : Number(trimmed);
  const invalid =
    badInput || (parsed !== null && (!Number.isFinite(parsed) || parsed < 0));

  /**
   * Removing a cap is the one action here that switches OFF the product's only
   * spending control, and it used to happen on a single click of the same
   * button that saves a number — with an empty field, which is also what a
   * fumbled entry leaves behind. It is recoverable (the user is told, and can
   * type the number back) but it is not something to do by accident, so it
   * asks once. Nothing else on this row asks, because nothing else on this row
   * turns a limit off.
   */
  const isClearingExistingCap = parsed === null && brand.monthlyCapUsd !== null;

  function edit(next: string, currentBadInput: boolean) {
    setValue(next);
    setBadInput(currentBadInput);
    setConfirmingClear(false);
  }

  async function save() {
    if (isClearingExistingCap && !confirmingClear) {
      setError(null);
      setOk(null);
      setConfirmingClear(true);
      return;
    }
    setConfirmingClear(false);
    return saveNow();
  }

  async function saveNow() {
    setError(null);
    setOk(null);
    setPending(true);
    try {
      const res = await fetch(`/api/admin/brands/${brand.id}/cap`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        // Explicit null, never an omitted field: a dropped key must not be
        // able to switch a brand's only spending control off by accident.
        body: JSON.stringify({ capUsd: parsed }),
      });
      if (res.ok) {
        setOk(parsed === null ? t("capCleared") : t("capSaved"));
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => null)) as {
        error?: string;
        code?: string;
      } | null;
      setError(apiErrorMessage(data, tApi, t("failed")));
    } catch {
      setError(t("failed"));
    } finally {
      setPending(false);
    }
  }

  return (
    <li className="flex flex-wrap items-end gap-3 rounded-md border border-border p-3">
      <span className="min-w-32 flex-1 text-sm font-medium text-fg">
        {brand.name}
        {brand.isActive ? "" : ` (${t("inactive")})`}
      </span>

      <div className="flex flex-col gap-1.5">
        <label
          htmlFor={`cap-${brand.id}`}
          className="text-xs font-medium text-fg-muted"
        >
          {t("capLabel")}
        </label>
        <input
          id={`cap-${brand.id}`}
          name={`cap-${brand.id}`}
          type="number"
          min="0"
          step="0.01"
          inputMode="decimal"
          // No placeholder number on purpose: see the section comment.
          placeholder={t("capUnlimited")}
          value={value}
          onChange={(e) => edit(e.target.value, e.currentTarget.validity.badInput)}
          className={`${inputClass} w-40`}
          aria-invalid={invalid || undefined}
        />
      </div>

      <Button
        type="button"
        disabled={pending || invalid}
        onClick={() => void save()}
      >
        {pending
          ? t("saving")
          : confirmingClear
            ? t("capConfirmRemove")
            : t("capSave")}
      </Button>

      {/* Said in words, not implied by a changed button label alone: the
          consequence of this particular save is that the brand stops having a
          limit at all. */}
      {confirmingClear && !pending && (
        <span className="w-full text-xs text-fg-warning">
          {t("capRemoveWarning", { brand: brand.name })}
        </span>
      )}
      {invalid && !pending && (
        <span className="w-full text-xs text-fg-warning">
          {t("capInvalidHint")}
        </span>
      )}

      <span className="w-full text-xs text-fg-subtle">
        {brand.monthlyCapUsd === null
          ? t("capCurrentlyUnlimited")
          : t("capCurrently", { amount: brand.monthlyCapUsd })}
      </span>

      <div className="w-full">
        <Feedback error={error} ok={ok} />
      </div>
    </li>
  );
}

function CreateUserSection() {
  const t = useTranslations("admin");
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [temporaryPassword, setTemporaryPassword] = useState("");
  const [role, setRole] = useState<"admin" | "user">("user");
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setOk(null);
    setPending(true);
    try {
      const res = await fetch("/api/admin/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, temporaryPassword, role }),
      });
      if (res.ok) {
        setUsername("");
        // Clear the plaintext from state as soon as the request is done. The
        // confirmation deliberately does NOT repeat the password back: the
        // admin just typed it, and a success banner is a screenshot waiting to
        // happen (commit 3d2f1c8).
        setTemporaryPassword("");
        setRole("user");
        setOk(t("userCreated"));
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => null)) as {
        error?: string;
        code?: string;
      } | null;
      setError(apiErrorMessage(data, tApi, t("failed")));
    } catch {
      setError(t("failed"));
    } finally {
      setPending(false);
    }
  }

  const tooShort =
    temporaryPassword.length > 0 &&
    temporaryPassword.length < MIN_PASSWORD_LENGTH;

  return (
    <Section title={t("usersTitle")} description={t("usersDescription")}>
      <form onSubmit={onSubmit} className="flex flex-col gap-3">
        <div className="flex flex-wrap items-end gap-3">
          <div className="flex min-w-44 flex-1 flex-col gap-1.5">
            <label htmlFor="username" className="text-sm font-medium text-fg">
              {t("username")}
            </label>
            <input
              id="username"
              name="username"
              type="text"
              autoComplete="off"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className={inputClass}
            />
          </div>

          <div className="flex min-w-44 flex-1 flex-col gap-1.5">
            <label
              htmlFor="temporaryPassword"
              className="text-sm font-medium text-fg"
            >
              {t("temporaryPassword")}
            </label>
            {/*
              type="password" even though an admin is typing it for somebody
              else: it keeps the value off the screen and out of any screen
              share or screenshot, which is exactly how the first production
              credential leaked.
            */}
            <input
              id="temporaryPassword"
              name="temporaryPassword"
              type="password"
              autoComplete="new-password"
              required
              value={temporaryPassword}
              onChange={(e) => setTemporaryPassword(e.target.value)}
              className={inputClass}
            />
          </div>

          <div className="flex min-w-36 flex-col gap-1.5">
            <label htmlFor="role" className="text-sm font-medium text-fg">
              {t("role")}
            </label>
            <select
              id="role"
              name="role"
              value={role}
              onChange={(e) => setRole(e.target.value as "admin" | "user")}
              className={inputClass}
            >
              <option value="user">{t("roleUser")}</option>
              <option value="admin">{t("roleAdmin")}</option>
            </select>
          </div>

          {/*
            #40 review, finding 4. A short password greys this out; the hint
            below carries the reason and the button points AT it, so the
            disabled state is explained rather than just observed. When the
            rule is actually being broken the hint turns destructive and
            announces itself.
          */}
          <Button
            type="submit"
            aria-describedby="temporaryPasswordHint"
            disabled={
              pending ||
              tooShort ||
              username.trim().length === 0 ||
              temporaryPassword.length === 0
            }
          >
            {pending ? t("creating") : t("createUser")}
          </Button>
        </div>

        <p
          id="temporaryPasswordHint"
          role={tooShort ? "alert" : undefined}
          className={
            tooShort ? "text-xs text-destructive" : "text-xs text-fg-subtle"
          }
        >
          {t("temporaryPasswordHint", { min: MIN_PASSWORD_LENGTH })}
        </p>
      </form>

      <Feedback error={error} ok={ok} />
    </Section>
  );
}

function UsersSection({
  brands,
  users,
  currentUserId,
}: {
  brands: Brand[];
  users: AdminUserView[];
  currentUserId: string;
}) {
  const t = useTranslations("admin");

  return (
    <Section title={t("membershipTitle")} description={t("membershipDescription")}>
      {users.length === 0 ? (
        <p className="text-sm text-fg-subtle">{t("noUsers")}</p>
      ) : (
        <ul className="flex flex-col divide-y divide-border">
          {users.map((user) => (
            <UserRow
              key={user.id}
              user={user}
              brands={brands}
              isSelf={user.id === currentUserId}
            />
          ))}
        </ul>
      )}
    </Section>
  );
}

function UserRow({
  user,
  brands,
  isSelf,
}: {
  user: AdminUserView;
  brands: Brand[];
  isSelf: boolean;
}) {
  const t = useTranslations("admin");
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const router = useRouter();
  const [brandId, setBrandId] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const memberIds = new Set(user.brands.map((b) => b.id));
  const assignable = brands.filter((b) => !memberIds.has(b.id));

  async function mutate(method: "POST" | "DELETE", brand: Brand) {
    // #40 review, finding 9. Revoking was a single unconfirmed click on a `×`
    // — the one destructive control in the panel, and the easiest to hit by
    // accident. Granting stays unconfirmed: it is trivially undone by the
    // control right next to it.
    if (
      method === "DELETE" &&
      !window.confirm(
        t("confirmRevoke", { username: user.username, brand: brand.name }),
      )
    ) {
      return;
    }

    setError(null);
    setOk(null);
    setPending(true);
    try {
      const res = await fetch(`/api/admin/users/${user.id}/brands`, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ brandId: brand.id }),
      });
      if (res.ok) {
        setBrandId("");
        // Say what happened. The list below re-renders from the server, but a
        // chip quietly vanishing is not an acknowledgement.
        setOk(
          method === "DELETE"
            ? t("accessRevoked", { brand: brand.name })
            : t("accessGranted", { brand: brand.name }),
        );
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => null)) as {
        error?: string;
        code?: string;
      } | null;
      setError(apiErrorMessage(data, tApi, t("failed")));
    } catch {
      setError(t("failed"));
    } finally {
      setPending(false);
    }
  }

  return (
    <li className="flex flex-col gap-3 py-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-medium text-fg">{user.username}</span>
        {/* roles.ts: `isSuperAdmin` is the ONLY role predicate — no literals. */}
        {isSuperAdmin(user) ? (
          <span className="rounded-md bg-accent-subtle px-2 py-0.5 text-xs font-medium text-accent-fg">
            {t("roleAdmin")}
          </span>
        ) : null}
        {/*
          #40 review, finding 5. `isActive` was fetched, typed and then never
          drawn, so a deactivated account looked exactly like a working one.
          Brands already show this; users now match.
        */}
        {user.isActive ? null : (
          <span className="rounded-md bg-bg-muted px-2 py-0.5 text-xs text-fg-muted">
            {t("inactiveUser")}
          </span>
        )}
        {user.mustChangePassword ? (
          <span className="rounded-md bg-bg-muted px-2 py-0.5 text-xs text-fg-muted">
            {t("pendingPasswordChange")}
          </span>
        ) : null}
      </div>

      {user.brands.length === 0 ? (
        <p className="text-sm text-fg-subtle">{t("noMemberships")}</p>
      ) : (
        <ul className="flex flex-wrap gap-2">
          {user.brands.map((brand) => (
            <li
              key={brand.id}
              className="flex items-center gap-1.5 rounded-md bg-bg-muted px-2.5 py-1 text-sm text-fg-muted"
            >
              {brand.name}
              <button
                type="button"
                disabled={pending}
                onClick={() => mutate("DELETE", brand)}
                aria-label={t("revokeFrom", {
                  username: user.username,
                  brand: brand.name,
                })}
                className="text-fg-subtle transition-colors hover:text-destructive"
              >
                ×
              </button>
            </li>
          ))}
        </ul>
      )}

      {assignable.length > 0 ? (
        <div className="flex flex-wrap items-end gap-2">
          <select
            value={brandId}
            aria-label={t("assignTo", { username: user.username })}
            onChange={(e) => setBrandId(e.target.value)}
            className={inputClass}
          >
            <option value="">{t("selectBrand")}</option>
            {assignable.map((brand) => (
              <option key={brand.id} value={brand.id}>
                {brand.name}
              </option>
            ))}
          </select>
          <Button
            type="button"
            variant="secondary"
            disabled={pending || brandId === ""}
            onClick={() => {
              const brand = assignable.find((b) => b.id === brandId);
              if (brand) void mutate("POST", brand);
            }}
          >
            {t("assign")}
          </Button>
        </div>
      ) : null}

      <RoleControl user={user} isSelf={isSelf} />

      <ResetPasswordControl user={user} />

      <Feedback error={error} ok={ok} />
    </li>
  );
}

/**
 * Promote a user to administrator, or take those rights away (#89).
 *
 * The panel could already MINT an admin at creation time and could never
 * change one afterwards, so a handover meant a shell on the production
 * database — the same gap `ResetPasswordControl` below was added to close.
 *
 * ── WHY BOTH DIRECTIONS ARE CONFIRMED ────────────────────────────────────
 * The panel's existing rule (#40 review, finding 9) is that the destructive
 * control is confirmed and the trivially-undone one is not: revoking a brand
 * asks, granting does not, because the grant is undone by the control beside
 * it. A role change is not symmetric with that. Demotion is plainly
 * destructive — it can be the last admin, and the refusal for that case is the
 * server's, not this dialog's. But promotion is not "trivially undone" in the
 * sense that mattered there: between the mis-click and the correction the new
 * administrator can already read every brand, reset any password and change
 * anyone's role, and none of that is taken back by demoting them afterwards.
 * So both ask, and the text says what the click actually confers.
 *
 * Self-demotion gets its own wording. It is a legitimate and expected act —
 * the handover — but it is the one click here that the clicker cannot undo
 * themselves, so the dialog says so rather than treating it as routine.
 */
function RoleControl({
  user,
  isSelf,
}: {
  user: AdminUserView;
  isSelf: boolean;
}) {
  const t = useTranslations("admin");
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  // roles.ts: `isSuperAdmin` is the ONLY role predicate — no string literals.
  const promoting = !isSuperAdmin(user);
  const nextRole = promoting ? "admin" : "user";

  async function onClick() {
    // `isSelf` picks the WORDING and nothing else. Every rule that matters is
    // the server's: the last-admin refusal is a count in `setUserRole`, not an
    // id comparison, so a stale or forged `isSelf` changes a sentence and no
    // outcome.
    const message = promoting
      ? t("confirmPromote", { username: user.username })
      : isSelf
        ? t("confirmDemoteSelf")
        : t("confirmDemote", { username: user.username });
    if (!window.confirm(message)) return;

    setError(null);
    setOk(null);
    setPending(true);
    try {
      const res = await fetch(`/api/admin/users/${user.id}/role`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role: nextRole }),
      });
      if (res.ok) {
        setOk(
          promoting
            ? t("rolePromoted", { username: user.username })
            : t("roleDemoted", { username: user.username }),
        );
        // The badge beside the username is server-rendered, so the refresh is
        // what makes the change visible. If the admin just demoted THEMSELVES,
        // this same refresh is what removes the panel from under them — which
        // is the honest outcome, and the reason the dialog said so.
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => null)) as {
        error?: string;
        code?: string;
      } | null;
      // LAST_ADMIN arrives here as a 409. `apiErrorMessage` turns the code into
      // the interface language, so the operator is told what to do about it
      // ("make someone else an admin first") rather than just refused.
      setError(apiErrorMessage(data, tApi, t("failed")));
    } catch {
      setError(t("failed"));
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="flex flex-col gap-1.5">
      <Button
        type="button"
        variant="secondary"
        disabled={pending}
        onClick={() => void onClick()}
        aria-label={t("roleChangeLabel", { username: user.username })}
      >
        {pending
          ? t("roleChanging")
          : promoting
            ? t("makeAdmin")
            : t("makeUser")}
      </Button>
      <Feedback error={error} ok={ok} />
    </div>
  );
}

/**
 * Set a new temporary password for one user (#40 review, finding 1).
 *
 * The endpoint and the service behind it shipped with T40 — complete, tested
 * and documented — and then nothing called them. So the ONE thing an operator
 * needs when a user forgets their password meant opening a terminal and
 * running `npm run seed -- set-password`, which is the workflow the admin
 * panel exists to replace.
 *
 * It keeps the same discipline as user creation, for the same reason:
 *  - `type="password"`, so the value never appears on screen, in a screen
 *    share or in a screenshot;
 *  - the value is POSTed in a body, never a URL — a query string lands in
 *    access logs and browser history;
 *  - state is cleared the moment the request settles, and the success banner
 *    says THAT it was set, never WHAT was set;
 *  - the server forces `must_change_password`, so the admin-known password is
 *    always a one-time credential.
 */
function ResetPasswordControl({ user }: { user: AdminUserView }) {
  const t = useTranslations("admin");
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const tooShort = password.length > 0 && password.length < MIN_PASSWORD_LENGTH;
  const fieldId = `resetPassword-${user.id}`;
  const hintId = `${fieldId}-hint`;

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setOk(null);
    setPending(true);
    try {
      const res = await fetch(`/api/admin/users/${user.id}/password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ temporaryPassword: password }),
      });
      if (res.ok) {
        setPassword("");
        setOk(t("passwordReset"));
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => null)) as {
        error?: string;
        code?: string;
      } | null;
      setError(apiErrorMessage(data, tApi, t("failed")));
    } catch {
      setError(t("failed"));
    } finally {
      // Belt and braces: whatever happened, the plaintext does not outlive the
      // request in component state.
      setPassword("");
      setPending(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-1.5">
      <div className="flex flex-wrap items-end gap-2">
        <div className="flex min-w-48 flex-col gap-1.5">
          <label htmlFor={fieldId} className="text-sm font-medium text-fg">
            {t("newTemporaryPassword")}
          </label>
          <input
            id={fieldId}
            name={fieldId}
            type="password"
            autoComplete="new-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={inputClass}
          />
        </div>
        <Button
          type="submit"
          variant="secondary"
          aria-describedby={hintId}
          aria-label={t("resetPasswordFor", { username: user.username })}
          disabled={pending || tooShort || password.length === 0}
        >
          {pending ? t("resetting") : t("resetPassword")}
        </Button>
      </div>

      <p
        id={hintId}
        role={tooShort ? "alert" : undefined}
        className={
          tooShort ? "text-xs text-destructive" : "text-xs text-fg-subtle"
        }
      >
        {t("passwordTooShortHint", { min: MIN_PASSWORD_LENGTH })}
      </p>

      <Feedback error={error} ok={ok} />
    </form>
  );
}
