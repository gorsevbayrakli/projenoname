import { getTranslations } from "next-intl/server";
import Link from "next/link";
import { redirect } from "next/navigation";

import { listAllBrands, listAllUsers } from "@/core/admin/service";
import { isSuperAdmin } from "@/core/auth/roles";
import { getCurrentUser } from "@/lib/auth-server";
import { AdminPanel } from "./admin-panel";

/**
 * /admin — the super admin's directory panel (T40).
 *
 * The (app) layout already guarantees a session and a discharged password
 * change. This page adds the role check, SERVER-SIDE: a non-admin who types
 * the URL is redirected, and — far more importantly — every endpoint the panel
 * calls checks the role for itself (`requireApiAdmin`). Hiding the nav link is
 * a nicety; it is not what stops anyone.
 *
 * What this panel can and cannot do is the whole point of T40's design: it
 * administers the directory (brands, users, memberships) and none of its own
 * queries read a brand's projects or content.
 *
 * That is NOT the same as "an admin cannot read brand content" (#40 review,
 * finding 12) — an admin can still grant themselves membership and revoke it
 * again, reset a user's password and sign in as them, or (since T50) read any
 * brand's spend with its project names straight from /spend, by role, with no
 * membership at all. All three leave a permanent, append-only record in
 * `audit_events`, readable at /activity, so the honest claim "not QUIETLY" is
 * backed by something. See core/auth/roles.ts for the full statement and its
 * residual limits, and core/llm/admin-spend.ts for the spend exception.
 */
export default async function AdminPage() {
  const t = await getTranslations("admin");
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!isSuperAdmin(user)) redirect("/projects");

  const [brands, users] = await Promise.all([
    listAllBrands(user),
    listAllUsers(user),
  ]);

  return (
    <div className="min-h-screen bg-bg-subtle">
      <div className="mx-auto flex max-w-5xl flex-col gap-8 px-6 py-10 sm:px-8">
        <header className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-semibold tracking-tight text-fg">
              {t("title")}
            </h1>
            <p className="mt-1 text-sm text-fg-muted">{t("subtitle")}</p>
          </div>
          <Link
            href="/projects"
            className="rounded-lg border border-border bg-bg px-3 py-1.5 text-sm text-fg-muted transition-colors hover:bg-bg-muted hover:text-fg"
          >
            {t("backToProjects")}
          </Link>
        </header>

        <p className="rounded-lg border border-border bg-bg p-4 text-sm text-fg-muted">
          {t("scopeNote")}
        </p>

        <AdminPanel brands={brands} users={users} currentUserId={user.id} />
      </div>
    </div>
  );
}
