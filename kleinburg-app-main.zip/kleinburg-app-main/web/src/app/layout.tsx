import type { Metadata } from "next";
import { NextIntlClientProvider } from "next-intl";
import { getLocale } from "next-intl/server";

import { spaceGrotesk } from "@/lib/fonts";
import "./globals.css";

export const metadata: Metadata = {
  title: "Kleinburg",
  description: "Kleinburg content engine",
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  // T25: the interface locale comes from the kb_locale cookie (see
  // src/i18n/request.ts), so it resolves on every route — including /login,
  // which renders before a user exists. Wrapping the whole tree in the provider
  // is what lets any client component call useTranslations without re-declaring
  // messages per screen.
  const locale = await getLocale();

  return (
    <html lang={locale}>
      <body className={`${spaceGrotesk.variable} antialiased`}>
        <NextIntlClientProvider>{children}</NextIntlClientProvider>
      </body>
    </html>
  );
}
