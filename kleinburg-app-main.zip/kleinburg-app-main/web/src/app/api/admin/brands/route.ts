import { NextResponse } from "next/server";
import { z } from "zod";

import { createBrand, listAllBrands } from "@/core/admin/service";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiAdmin } from "@/lib/auth-server";

const createBodySchema = z.object({
  name: z.string(),
});

/**
 * GET /api/admin/brands -> { brands } — EVERY brand, not just the caller's.
 *
 * Admin-only, enforced server-side by requireApiAdmin and again inside
 * listAllBrands. Note what this deliberately does not expose: brand rows only,
 * never their projects. Reading a brand's work still requires membership and
 * still goes through requireProjectAccess (CLAUDE.md hard rule 2).
 */
export async function GET() {
  const gate = await requireApiAdmin();
  if ("response" in gate) return gate.response;

  try {
    const brands = await listAllBrands(gate.user);
    return NextResponse.json({ brands });
  } catch (e) {
    return errorResponse(e);
  }
}

/** POST /api/admin/brands -> 201 { brand }. */
export async function POST(request: Request) {
  const gate = await requireApiAdmin();
  if ("response" in gate) return gate.response;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = createBodySchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    const brand = await createBrand(gate.user, parsed.data.name);
    return NextResponse.json({ brand }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}
