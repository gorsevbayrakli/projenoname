import { NextResponse } from "next/server";
import { z } from "zod";

import { setBrandMonthlyCap } from "@/core/admin/service";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiAdmin } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

/**
 * The body. `capUsd: null` REMOVES the cap; a number SETS it. The two are
 * different requests and the schema keeps them different — there is no
 * "absent means unlimited" shortcut, because a client bug that dropped the
 * field would then silently switch a brand's only spending control off.
 *
 * `z.number().nullable()` and no coercion: the browser sends a parsed number,
 * so a string arriving here means a caller got the contract wrong and should
 * be told, not quietly rescued into a value nobody typed.
 */
const bodySchema = z.object({
  capUsd: z.number().nullable(),
});

/**
 * PATCH /api/admin/brands/[id]/cap -> { brand } — set or clear a brand's
 * monthly spend cap (T51).
 *
 * Super-admin only, twice over: `requireApiAdmin` at the edge and
 * `requireSuperAdmin` inside `setBrandMonthlyCap`, which is where the guarantee
 * actually lives — the route is convenience, the service is the gate (#51
 * item 7, the #40/#50 line).
 *
 * Note what is NOT here: any enforcement. This endpoint only writes the
 * number. The refusal happens in `enqueueGeneration`, server-side, before a
 * job row exists, and is unreachable from this file.
 */
export async function PATCH(request: Request, ctx: RouteContext) {
  const gate = await requireApiAdmin();
  if ("response" in gate) return gate.response;

  const { id } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz tavan değeri", "BRAND_CAP_INVALID", 400);
  }

  try {
    const brand = await setBrandMonthlyCap(
      gate.user,
      id,
      parsed.data.capUsd,
    );
    return NextResponse.json({ brand });
  } catch (e) {
    return errorResponse(e);
  }
}
