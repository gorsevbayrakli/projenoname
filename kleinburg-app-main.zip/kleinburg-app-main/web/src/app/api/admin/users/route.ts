import { NextResponse } from "next/server";
import { z } from "zod";

import { createUser, listAllUsers } from "@/core/admin/service";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiAdmin } from "@/lib/auth-server";

const createBodySchema = z.object({
  username: z.string(),
  /**
   * The temporary password, in the request BODY over HTTPS — never a query
   * string. A query string is logged by every proxy in the path and shows up
   * in browser history, which is the same class of mistake as passing a
   * password on a command line (commit 3d2f1c8).
   */
  temporaryPassword: z.string(),
  role: z.enum(["admin", "user"]).default("user"),
});

/** GET /api/admin/users -> { users } with memberships, never password hashes. */
export async function GET() {
  const gate = await requireApiAdmin();
  if ("response" in gate) return gate.response;

  try {
    const users = await listAllUsers(gate.user);
    return NextResponse.json({ users });
  } catch (e) {
    return errorResponse(e);
  }
}

/**
 * POST /api/admin/users -> 201 { user }.
 *
 * The response carries the created user WITHOUT any password material: the
 * admin typed the temporary password, so echoing it back adds nothing and puts
 * it in one more place (a response body, a devtools pane, a screenshot).
 */
export async function POST(request: Request) {
  const gate = await requireApiAdmin();
  if ("response" in gate) return gate.response;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = createBodySchema.safeParse(body);
  if (!parsed.success) {
    // The generic message is deliberate: a Zod issue list for THIS body would
    // quote the offending field values, and one of them is a password.
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    const user = await createUser(
      gate.user,
      parsed.data.username,
      parsed.data.temporaryPassword,
      parsed.data.role,
    );
    return NextResponse.json({ user }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}
