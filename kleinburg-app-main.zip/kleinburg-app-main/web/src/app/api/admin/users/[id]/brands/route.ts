import { NextResponse } from "next/server";
import { z } from "zod";

import { grantBrandAccess, revokeBrandAccess } from "@/core/admin/service";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiAdmin } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

const bodySchema = z.object({
  brandId: z.string().uuid(),
});

type RouteContext = { params: Promise<{ id: string }> };

/**
 * POST /api/admin/users/[id]/brands -> { ok } — grant brand membership.
 *
 * This endpoint writes the `user_brands` row that `requireProjectAccess`
 * reads, which makes it the single most security-relevant handler added by
 * T40. It is admin-only at the route (requireApiAdmin) AND at the service
 * (requireSuperAdmin); `admin/service.test.ts` proves an ordinary user cannot
 * grant themselves a brand through it.
 */
export async function POST(request: Request, ctx: RouteContext) {
  const gate = await requireApiAdmin();
  if ("response" in gate) return gate.response;

  const { id } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    await grantBrandAccess(gate.user, id, parsed.data.brandId);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}

/** DELETE /api/admin/users/[id]/brands -> { ok } — revoke brand membership. */
export async function DELETE(request: Request, ctx: RouteContext) {
  const gate = await requireApiAdmin();
  if ("response" in gate) return gate.response;

  const { id } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    await revokeBrandAccess(gate.user, id, parsed.data.brandId);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
