import { NextResponse } from "next/server";
import { z } from "zod";

import { setUserRole } from "@/core/admin/service";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiAdmin } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

/**
 * The two roles `users.role` can hold. A closed enum rather than a string, so
 * a typo or an invented third role is a 400 here and never reaches the column.
 */
const bodySchema = z.object({
  role: z.enum(["admin", "user"]),
});

type RouteContext = { params: Promise<{ id: string }> };

/**
 * PATCH /api/admin/users/[id]/role -> { ok, role } — promote or demote an
 * existing user (#89).
 *
 * PATCH rather than POST: this modifies one field of an existing resource, and
 * it is idempotent — sending the same role twice leaves the same state (the
 * service treats the second as a no-op and writes no second audit row).
 *
 * Admin-only at the route (`requireApiAdmin`) AND at the service
 * (`requireSuperAdmin` on `setUserRole`'s first line). Both layers are
 * deliberate; the service layer is the one the tests treat as authoritative,
 * because it cannot be lost by adding a second caller.
 *
 * The refusal that matters most is not authorization but LAST_ADMIN: demoting
 * the final active admin comes back as a 409 with a sentence a human can act
 * on, rather than succeeding and locking everyone out of the panel.
 */
export async function PATCH(request: Request, ctx: RouteContext) {
  const gate = await requireApiAdmin();
  if ("response" in gate) return gate.response;

  const { id } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    const updated = await setUserRole(gate.user, id, parsed.data.role);
    // The resulting role is echoed back so the caller can tell a real change
    // from a no-op without re-reading the directory.
    return NextResponse.json({ ok: true, role: updated.role });
  } catch (e) {
    return errorResponse(e);
  }
}
