import { NextResponse } from "next/server";
import { z } from "zod";

import { setTemporaryPassword } from "@/core/admin/service";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiAdmin } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

const bodySchema = z.object({
  temporaryPassword: z.string(),
});

type RouteContext = { params: Promise<{ id: string }> };

/**
 * POST /api/admin/users/[id]/password -> { ok } — set a new temporary password
 * and re-arm the forced first-login change.
 *
 * Returns `{ ok: true }` and nothing else. There is no "here is the password
 * you just set" convenience field, on purpose.
 */
export async function POST(request: Request, ctx: RouteContext) {
  const gate = await requireApiAdmin();
  if ("response" in gate) return gate.response;

  const { id } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    await setTemporaryPassword(gate.user, id, parsed.data.temporaryPassword);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
