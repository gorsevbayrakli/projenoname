/**
 * HTTP-level authorization for T40.
 *
 * `core/admin/service.test.ts` proves the service refuses non-admins. This file
 * proves the same thing one layer up, through the actual route handlers with a
 * real session cookie — because "the UI does not render the button" is not
 * authorization, and the endpoints are what an attacker actually calls.
 *
 * It also proves the other half of the first-login flow: an account still
 * owing a password change is refused by the ORDINARY project endpoints, not
 * merely redirected by a page. Without that, the forced change would be
 * decoration.
 */
import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { hashPassword } from "@/core/auth/password";
import { createSession } from "@/core/auth/session";
import { closeDb, getDb } from "@/core/db/client";
import { brands, projects, userBrands, users } from "@/core/db/schema";
import { SESSION_COOKIE } from "@/lib/session-cookie";
import { hasDb } from "@/test/db-gate";

/**
 * The session cookie the handler under test will see. Mutated per test rather
 * than re-mocking, so the module graph is imported exactly once.
 */
let currentToken: string | null = null;

/**
 * The cookie name is duplicated here because `vi.mock` factories are hoisted
 * above the imports and cannot close over one. The test right below asserts it
 * still matches SESSION_COOKIE, so a rename cannot silently turn every case in
 * this file into a vacuous 401.
 */
const COOKIE_NAME = "kb_session";

vi.mock("next/headers", () => ({
  cookies: async () => ({
    get: (name: string) =>
      name === COOKIE_NAME && currentToken
        ? { name, value: currentToken }
        : undefined,
    set: () => {},
    delete: () => {},
  }),
}));

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

const PASSWORD = "gecici-sifre-2026";

async function makeUser(opts: {
  role?: "admin" | "user";
  mustChangePassword?: boolean;
} = {}) {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({
      username: `t40-http-${randomUUID()}`,
      passwordHash: await hashPassword(PASSWORD),
      role: opts.role ?? "user",
      mustChangePassword: opts.mustChangePassword ?? false,
    })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

/** Sign in as this user for the duration of the next handler call. */
async function signIn(userId: string) {
  const { token } = await createSession(userId);
  currentToken = token;
}

function post(url: string, body: unknown): Request {
  return new Request(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

function patch(url: string, body: unknown): Request {
  return new Request(url, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("session cookie mock", () => {
  it("mocks the cookie the app actually reads", () => {
    expect(COOKIE_NAME).toBe(SESSION_COOKIE);
  });
});

describe.skipIf(!hasDb)("admin API routes", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  // ── Admin-only endpoints reject ordinary users at the HTTP layer ────────

  it("GET /api/admin/brands is 403 ADMIN_REQUIRED for an ordinary user", async () => {
    const { GET } = await import("./brands/route");
    const user = await makeUser();
    await signIn(user.id);

    const res = await GET();
    expect(res.status).toBe(403);
    expect(await res.json()).toMatchObject({ code: "ADMIN_REQUIRED" });
  });

  it("POST /api/admin/brands is 403 for an ordinary user and creates nothing", async () => {
    const { POST } = await import("./brands/route");
    const user = await makeUser();
    await signIn(user.id);

    const name = `t40-forbidden-${randomUUID()}`;
    const res = await POST(post("http://x/api/admin/brands", { name }));
    expect(res.status).toBe(403);

    const db = getDb();
    const rows = await db.select().from(brands).where(eq(brands.name, name));
    expect(rows).toHaveLength(0);
  });

  it("POST /api/admin/users is 403 for an ordinary user and creates nothing", async () => {
    const { POST } = await import("./users/route");
    const user = await makeUser();
    await signIn(user.id);

    const username = `t40-forbidden-${randomUUID()}`;
    const res = await POST(
      post("http://x/api/admin/users", {
        username,
        temporaryPassword: PASSWORD,
      }),
    );
    expect(res.status).toBe(403);

    const db = getDb();
    const rows = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    expect(rows).toHaveLength(0);
  });

  /**
   * The privilege-escalation attempt this whole feature has to survive: an
   * ordinary user calling the grant endpoint to give themselves a brand they
   * are not a member of.
   */
  it("POST /api/admin/users/[id]/brands cannot be used to self-grant a brand", async () => {
    const { POST } = await import("./users/[id]/brands/route");
    const attacker = await makeUser();
    const db = getDb();
    const [victimBrand] = await db
      .insert(brands)
      .values({ name: `t40-victim-${randomUUID()}` })
      .returning();
    createdBrandIds.push(victimBrand.id);

    await signIn(attacker.id);
    const res = await POST(
      post(`http://x/api/admin/users/${attacker.id}/brands`, {
        brandId: victimBrand.id,
      }),
      { params: Promise.resolve({ id: attacker.id }) },
    );

    expect(res.status).toBe(403);
    expect(await res.json()).toMatchObject({ code: "ADMIN_REQUIRED" });

    const grants = await db
      .select()
      .from(userBrands)
      .where(eq(userBrands.userId, attacker.id));
    expect(grants).toHaveLength(0);
  });

  /**
   * The other privilege-escalation attempt, and the more direct one (#89): an
   * ordinary user calling the role endpoint to make themselves an admin. The
   * status code is half the claim; the row still saying "user" is the rest.
   */
  it("PATCH /api/admin/users/[id]/role cannot be used to self-promote", async () => {
    const { PATCH } = await import("./users/[id]/role/route");
    const attacker = await makeUser();

    await signIn(attacker.id);
    const res = await PATCH(
      patch(`http://x/api/admin/users/${attacker.id}/role`, {
        role: "admin",
      }),
      { params: Promise.resolve({ id: attacker.id }) },
    );

    expect(res.status).toBe(403);
    expect(await res.json()).toMatchObject({ code: "ADMIN_REQUIRED" });

    const [row] = await getDb()
      .select({ role: users.role })
      .from(users)
      .where(eq(users.id, attacker.id));
    expect(row.role).toBe("user");
  });

  it("admin endpoints are 401, not 403, with no session at all", async () => {
    const { GET } = await import("./brands/route");
    currentToken = null;

    const res = await GET();
    expect(res.status).toBe(401);
    expect(await res.json()).toMatchObject({ code: "UNAUTHENTICATED" });
  });

  // ── The admin path works ───────────────────────────────────────────────

  it("an admin can create a brand and a user through the endpoints", async () => {
    const brandRoute = await import("./brands/route");
    const userRoute = await import("./users/route");
    const admin = await makeUser({ role: "admin" });
    await signIn(admin.id);

    const brandName = `t40-ok-${randomUUID()}`;
    const brandRes = await brandRoute.POST(
      post("http://x/api/admin/brands", { name: brandName }),
    );
    expect(brandRes.status).toBe(201);
    const { brand } = (await brandRes.json()) as { brand: { id: string } };
    createdBrandIds.push(brand.id);

    const username = `t40-ok-${randomUUID()}`;
    const userRes = await userRoute.POST(
      post("http://x/api/admin/users", {
        username,
        temporaryPassword: PASSWORD,
      }),
    );
    expect(userRes.status).toBe(201);
    const payload = (await userRes.json()) as {
      user: { id: string; mustChangePassword: boolean };
    };
    createdUserIds.push(payload.user.id);
    expect(payload.user.mustChangePassword).toBe(true);
  });

  /** The response body must not carry the password or the hash. */
  it("the create-user response contains no password material", async () => {
    const { POST } = await import("./users/route");
    const admin = await makeUser({ role: "admin" });
    await signIn(admin.id);

    const res = await POST(
      post("http://x/api/admin/users", {
        username: `t40-ok-${randomUUID()}`,
        temporaryPassword: PASSWORD,
      }),
    );
    const body = (await res.json()) as { user: { id: string } };
    createdUserIds.push(body.user.id);

    const raw = JSON.stringify(body);
    expect(raw).not.toContain(PASSWORD);
    expect(raw).not.toContain("argon2");
    expect(raw).not.toContain("passwordHash");
  });
});

/**
 * #40 review, finding 1. The reset endpoint shipped with T40 and the panel
 * never called it, so an operator's only recovery path for a forgotten
 * password was an SSH session and `npm run seed -- set-password`. The panel
 * now has a control; these are the guarantees that control relies on.
 */
describe.skipIf(!hasDb)("admin password reset at the HTTP layer", () => {
  it("re-arms the forced change and lets the new password in", async () => {
    const passwordRoute = await import("./users/[id]/password/route");
    const admin = await makeUser({ role: "admin" });
    const target = await makeUser();
    await signIn(admin.id);

    const fresh = "yeni-gecici-2026";
    const res = await passwordRoute.POST(
      post(`http://x/api/admin/users/${target.id}/password`, {
        temporaryPassword: fresh,
      }),
      { params: Promise.resolve({ id: target.id }) },
    );
    expect(res.status).toBe(200);

    // Forced change re-armed — an admin-known password is always one-time.
    const db = getDb();
    const [row] = await db.select().from(users).where(eq(users.id, target.id));
    expect(row.mustChangePassword).toBe(true);

    // And the new password actually works.
    const changeRoute = await import("../auth/change-password/route");
    await signIn(target.id);
    const used = await changeRoute.POST(
      post("http://x/api/auth/change-password", {
        currentPassword: fresh,
        newPassword: "kendi-sifrem-2026",
      }),
    );
    expect(used.status).toBe(200);
  });

  it("never echoes the password or a hash back", async () => {
    const passwordRoute = await import("./users/[id]/password/route");
    const admin = await makeUser({ role: "admin" });
    const target = await makeUser();
    await signIn(admin.id);

    const fresh = "yeni-gecici-2026";
    const res = await passwordRoute.POST(
      post(`http://x/api/admin/users/${target.id}/password`, {
        temporaryPassword: fresh,
      }),
      { params: Promise.resolve({ id: target.id }) },
    );
    const raw = JSON.stringify(await res.json());
    expect(raw).not.toContain(fresh);
    expect(raw).not.toContain("argon2");
    expect(raw).not.toContain("passwordHash");
  });

  it("refuses a non-admin", async () => {
    const passwordRoute = await import("./users/[id]/password/route");
    const ordinary = await makeUser();
    const target = await makeUser();
    await signIn(ordinary.id);

    const res = await passwordRoute.POST(
      post(`http://x/api/admin/users/${target.id}/password`, {
        temporaryPassword: "yeni-gecici-2026",
      }),
      { params: Promise.resolve({ id: target.id }) },
    );
    expect(res.status).toBe(403);

    // The target's password is untouched: it still opens the account.
    const changeRoute = await import("../auth/change-password/route");
    await signIn(target.id);
    const still = await changeRoute.POST(
      post("http://x/api/auth/change-password", {
        currentPassword: PASSWORD,
        newPassword: "kendi-sifrem-2026",
      }),
    );
    expect(still.status).toBe(200);
  });

  it("rejects a too-short password with the code the UI needs", async () => {
    const passwordRoute = await import("./users/[id]/password/route");
    const admin = await makeUser({ role: "admin" });
    const target = await makeUser();
    await signIn(admin.id);

    const res = await passwordRoute.POST(
      post(`http://x/api/admin/users/${target.id}/password`, {
        temporaryPassword: "kisa",
      }),
      { params: Promise.resolve({ id: target.id }) },
    );
    expect(res.status).toBe(400);
    const raw = JSON.stringify(await res.json());
    expect(raw).toContain("PASSWORD_TOO_SHORT");
    expect(raw).not.toContain("kisa");
  });
});

describe.skipIf(!hasDb)("first-login password change at the HTTP layer", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  /**
   * The redirect in (app)/layout.tsx is ergonomics. THIS is the enforcement:
   * a pending password change closes the JSON API too, so the flow cannot be
   * skipped by talking to the endpoints directly.
   */
  it("a user owing a password change is refused the ordinary API", async () => {
    const { GET } = await import("../brands/route");
    const user = await makeUser({ mustChangePassword: true });
    await signIn(user.id);

    const res = await GET();
    expect(res.status).toBe(403);
    expect(await res.json()).toMatchObject({
      code: "PASSWORD_CHANGE_REQUIRED",
    });
  });

  it("an admin owing a password change is refused the ADMIN API too", async () => {
    const { GET } = await import("./brands/route");
    const admin = await makeUser({ role: "admin", mustChangePassword: true });
    await signIn(admin.id);

    const res = await GET();
    expect(res.status).toBe(403);
    expect(await res.json()).toMatchObject({
      code: "PASSWORD_CHANGE_REQUIRED",
    });
  });

  it("the change-password endpoint itself stays reachable, and unblocks the API", async () => {
    const changeRoute = await import("../auth/change-password/route");
    const { GET } = await import("../brands/route");
    const user = await makeUser({ mustChangePassword: true });
    await signIn(user.id);

    // Blocked first.
    expect((await GET()).status).toBe(403);

    const res = await changeRoute.POST(
      post("http://x/api/auth/change-password", {
        currentPassword: PASSWORD,
        newPassword: "kendi-sifrem-2026",
      }),
    );
    expect(res.status).toBe(200);

    // And now the ordinary API answers.
    expect((await GET()).status).toBe(200);
  });

  it("a wrong current password is rejected and leaks nothing", async () => {
    const changeRoute = await import("../auth/change-password/route");
    const user = await makeUser({ mustChangePassword: true });
    await signIn(user.id);

    const res = await changeRoute.POST(
      post("http://x/api/auth/change-password", {
        currentPassword: "yanlis-sifre-2026",
        newPassword: "kendi-sifrem-2026",
      }),
    );
    expect(res.status).toBe(400);
    const raw = JSON.stringify(await res.json());
    expect(raw).toContain("CURRENT_PASSWORD_INVALID");
    expect(raw).not.toContain("yanlis-sifre-2026");
    expect(raw).not.toContain("kendi-sifrem-2026");

    // Still owing the change.
    const db = getDb();
    const [row] = await db.select().from(users).where(eq(users.id, user.id));
    expect(row.mustChangePassword).toBe(true);
  });

  /**
   * #40 review, finding 11. A stolen session could previously grind through
   * `currentPassword` guesses at full speed, because nothing counted them.
   *
   * The limiter is module state in the route, so this test deliberately runs
   * ONE user to the ceiling and then checks a SECOND user is unaffected —
   * proving the counter is keyed per user rather than global, which is the
   * difference between a rate limit and a self-inflicted outage.
   */
  it("stops brute-forcing the current password, per user", async () => {
    const changeRoute = await import("../auth/change-password/route");
    const victim = await makeUser();
    await signIn(victim.id);

    const guess = () =>
      changeRoute.POST(
        post("http://x/api/auth/change-password", {
          currentPassword: `tahmin-${randomUUID()}`,
          newPassword: "kendi-sifrem-2026",
        }),
      );

    // The ceiling is 10 failures per 15 minutes.
    let sawLimit = false;
    for (let i = 0; i < 12; i++) {
      const res = await guess();
      if (res.status === 429) {
        expect(await res.json()).toMatchObject({ code: "TOO_MANY_ATTEMPTS" });
        sawLimit = true;
        break;
      }
      expect(res.status).toBe(400);
    }
    expect(sawLimit, "guessing was never rate limited").toBe(true);

    // The CORRECT password is refused too while the lockout holds — otherwise
    // the limit would be trivially bypassed by the very guess it guards.
    await signIn(victim.id);
    const blocked = await changeRoute.POST(
      post("http://x/api/auth/change-password", {
        currentPassword: PASSWORD,
        newPassword: "kendi-sifrem-2026",
      }),
    );
    expect(blocked.status).toBe(429);

    // A different user is untouched by the neighbour's lockout.
    const bystander = await makeUser();
    await signIn(bystander.id);
    const ok = await changeRoute.POST(
      post("http://x/api/auth/change-password", {
        currentPassword: PASSWORD,
        newPassword: "kendi-sifrem-2026",
      }),
    );
    expect(ok.status).toBe(200);
  });

  /**
   * A pending password change must not become a way around brand isolation
   * either: the project endpoints are closed, and remain closed for a brand
   * the user was never a member of after the change.
   */
  it("does not become a side door into another brand's projects", async () => {
    const projectRoute = await import("../projects/route");
    const db = getDb();
    const [brand] = await db
      .insert(brands)
      .values({ name: `t40-other-${randomUUID()}` })
      .returning();
    createdBrandIds.push(brand.id);
    const owner = await makeUser();
    await db.insert(userBrands).values({ userId: owner.id, brandId: brand.id });
    await db
      .insert(projects)
      .values({ brandId: brand.id, name: `p-${randomUUID()}`, createdBy: owner.id });

    const outsider = await makeUser({ mustChangePassword: true });
    await signIn(outsider.id);

    const url = `http://x/api/projects?brandId=${brand.id}`;
    // Before the change: refused for owing the change.
    const before = await projectRoute.GET(new Request(url));
    expect(before.status).toBe(403);
    expect(await before.json()).toMatchObject({
      code: "PASSWORD_CHANGE_REQUIRED",
    });

    // After the change: refused for the real reason, brand isolation.
    const changeRoute = await import("../auth/change-password/route");
    await changeRoute.POST(
      post("http://x/api/auth/change-password", {
        currentPassword: PASSWORD,
        newPassword: "kendi-sifrem-2026",
      }),
    );

    const after = await projectRoute.GET(new Request(url));
    expect(after.status).toBe(403);
    expect(await after.json()).toMatchObject({ code: "ACCESS_DENIED" });
  });
});
