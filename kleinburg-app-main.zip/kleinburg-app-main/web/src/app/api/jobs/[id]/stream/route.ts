import { getJob } from "@/core/jobs/jobs";
import { requireProjectAccess } from "@/core/tenancy/access";
import type { GenerationJob } from "@/core/db/schema";
import { errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

// SSE + pg access require the Node.js runtime.
export const runtime = "nodejs";

/** Poll interval and hard cap so a stuck job cannot hold a connection forever. */
const POLL_MS = 1000;
const MAX_DURATION_MS = 10 * 60 * 1000; // ~10 minutes

const TERMINAL = new Set(["succeeded", "failed", "cancelled"]);

type RouteContext = { params: Promise<{ id: string }> };

/** Serialize the fields a client needs to observe job progress. */
function snapshot(job: GenerationJob) {
  return { status: job.status, output: job.output, error: job.error };
}

/**
 * The frame that ends a stream WITHOUT the job having reached a terminal state
 * (#60): the duration cap, a vanished row, a failed poll. Ending the stream
 * silently is indistinguishable on the wire from a dead connection, and the
 * client then reports a still-running generation as failed. `streamClosed`
 * says the TRANSPORT ended; `status` is the last thing we knew about the JOB.
 */
function streamClosedFrame(status: string) {
  return { status, streamClosed: true };
}

/**
 * GET /api/jobs/[id]/stream -> Server-Sent Events of a job's status.
 * Emits on every change and closes when the job reaches a terminal state.
 * When the STREAM ends without the job ending, it emits a streamClosed frame
 * first (see streamClosedFrame) so the client can tell the two apart.
 */
export async function GET(request: Request, ctx: RouteContext) {
  // Same gate as every other project-scoped endpoint (T40): an unauthenticated
  // caller gets 401, and one still owing a first-login password change gets
  // 403 PASSWORD_CHANGE_REQUIRED rather than a live job feed.
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  const { id } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  const job = await getJob(id);
  if (!job) {
    return new Response(
      JSON.stringify({ error: "İş bulunamadı", code: "JOB_NOT_FOUND" }),
      {
        status: 404,
        headers: { "Content-Type": "application/json" },
      },
    );
  }

  // Brand isolation: a user must not stream another brand's job.
  try {
    await requireProjectAccess(user.id, job.projectId);
  } catch (e) {
    return errorResponse(e);
  }

  const encoder = new TextEncoder();
  const startedAt = Date.now();

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      let closed = false;
      let timer: ReturnType<typeof setTimeout> | null = null;
      let lastPayload: string | null = null;
      // Last status we actually observed, carried by the streamClosed frame.
      let lastStatus = job.status;

      const close = () => {
        if (closed) return;
        closed = true;
        if (timer) clearTimeout(timer);
        request.signal.removeEventListener("abort", close);
        try {
          controller.close();
        } catch {
          // already closed
        }
      };

      const send = (payload: string) => {
        if (payload === lastPayload) return;
        lastPayload = payload;
        controller.enqueue(encoder.encode(`data: ${payload}\n\n`));
      };

      const emit = (current: GenerationJob) => {
        lastStatus = current.status;
        send(JSON.stringify(snapshot(current)));
      };

      /**
       * End a stream the job did not end. Emit the marker first so the client
       * can tell "I lost the stream" from "the generation failed", then close.
       */
      const closeStream = () => {
        if (closed) return;
        try {
          send(JSON.stringify(streamClosedFrame(lastStatus)));
        } catch {
          // The connection is already gone; closing is all that is left.
        }
        close();
      };

      const poll = async () => {
        if (closed) return;
        if (Date.now() - startedAt > MAX_DURATION_MS) {
          closeStream();
          return;
        }
        try {
          const current = await getJob(id);
          if (!current) {
            closeStream();
            return;
          }
          emit(current);
          if (TERMINAL.has(current.status)) {
            close();
            return;
          }
        } catch {
          closeStream();
          return;
        }
        if (!closed) timer = setTimeout(poll, POLL_MS);
      };

      // Stop polling if the client disconnects.
      request.signal.addEventListener("abort", close);

      // Emit the initial state immediately, then poll. Guarded like the poll
      // loop so an abort-before-start cannot throw synchronously.
      try {
        emit(job);
        if (TERMINAL.has(job.status)) {
          close();
          return;
        }
      } catch {
        close();
        return;
      }
      timer = setTimeout(poll, POLL_MS);
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    },
  });
}
