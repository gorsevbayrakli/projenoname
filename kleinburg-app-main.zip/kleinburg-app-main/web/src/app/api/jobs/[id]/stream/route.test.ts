/**
 * #60: the SSE route must not end a stream silently while the job is still
 * running. A silent end is indistinguishable, on the wire, from a dead
 * connection — and the client then paints an honest success as a failure.
 *
 * Every non-terminal exit (the 10-minute cap, a vanished row, a poll error)
 * has to emit a final frame that says "the STREAM closed", carrying the last
 * status we actually knew about the JOB.
 *
 * Auth, tenancy and the job store are mocked: the question here is purely what
 * bytes go over the wire, so this file needs no database.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";

const getJobMock = vi.fn();

vi.mock("@/lib/auth-server", () => ({
  requireApiUser: async () => ({ user: { id: "u1" } }),
}));
vi.mock("@/core/tenancy/access", () => ({
  requireProjectAccess: async () => {},
}));
vi.mock("@/core/jobs/jobs", () => ({
  getJob: (id: string) => getJobMock(id),
}));

import { GET } from "./route";

const MAX_DURATION_MS = 10 * 60 * 1000;

// Real UUIDs, because the route now refuses a malformed path id outright
// (#64) — a "j1" here would make every case below a vacuous 400 rather than
// the stream-framing test it is meant to be.
const JOB_ID = "44444444-4444-4444-8444-444444444444";
const PROJECT_ID = "55555555-5555-4555-8555-555555555555";

function job(status: string) {
  return {
    id: JOB_ID,
    projectId: PROJECT_ID,
    status,
    output: null,
    error: null,
  };
}

/** Every `data:` frame the route emitted, parsed. */
async function readFrames(body: ReadableStream<Uint8Array>) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let text = "";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    text += decoder.decode(value, { stream: true });
  }
  return text
    .split("\n\n")
    .filter((chunk) => chunk.startsWith("data: "))
    .map((chunk) => JSON.parse(chunk.slice("data: ".length)));
}

async function call() {
  const res = await GET(
    new Request(`http://localhost/api/jobs/${JOB_ID}/stream`),
    { params: Promise.resolve({ id: JOB_ID }) },
  );
  return res;
}

beforeEach(() => {
  getJobMock.mockReset();
  vi.useRealTimers();
});

describe("GET /api/jobs/[id]/stream", () => {
  it("closes with a terminal frame and no streamClosed marker on success", async () => {
    getJobMock.mockResolvedValueOnce(job("running"));
    getJobMock.mockResolvedValue(job("succeeded"));
    vi.useFakeTimers();

    const res = await call();
    const frames = readFrames(res.body!);
    await vi.advanceTimersByTimeAsync(2000);

    const seen = await frames;
    expect(seen.at(-1).status).toBe("succeeded");
    expect(seen.at(-1).streamClosed).toBeUndefined();
  });

  it("says the STREAM closed, not that the job failed, at the duration cap", async () => {
    getJobMock.mockResolvedValue(job("running"));
    vi.useFakeTimers();

    const res = await call();
    const frames = readFrames(res.body!);
    await vi.advanceTimersByTimeAsync(MAX_DURATION_MS + 2000);

    const seen = await frames;
    const last = seen.at(-1);
    expect(last.streamClosed).toBe(true);
    // The job was and still is running — the route may not imply otherwise.
    expect(last.status).toBe("running");
  });

  it("marks the stream closed when the job row vanishes mid-poll", async () => {
    getJobMock.mockResolvedValueOnce(job("running"));
    getJobMock.mockResolvedValue(null);
    vi.useFakeTimers();

    const res = await call();
    const frames = readFrames(res.body!);
    await vi.advanceTimersByTimeAsync(3000);

    const seen = await frames;
    expect(seen.at(-1).streamClosed).toBe(true);
    expect(seen.at(-1).status).toBe("running");
  });

  it("marks the stream closed when polling throws", async () => {
    getJobMock.mockResolvedValueOnce(job("queued"));
    getJobMock.mockRejectedValue(new Error("connection terminated"));
    vi.useFakeTimers();

    const res = await call();
    const frames = readFrames(res.body!);
    await vi.advanceTimersByTimeAsync(3000);

    const seen = await frames;
    expect(seen.at(-1).streamClosed).toBe(true);
    expect(seen.at(-1).status).toBe("queued");
  });
});
