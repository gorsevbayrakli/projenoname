import { NextResponse } from "next/server";
import { z } from "zod";

import { updateAccountProfile } from "@/core/account/service";
import { ConflictError, TooManyAttemptsError } from "@/core/tenancy/errors";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";
import { emailProbeLimiter } from "@/lib/email-probe-limiter";

/**
 * Both fields optional so the client can send one without blanking the other;
 * an empty string is a deliberate "clear this field" and the service maps it
 * to NULL.
 */
const bodySchema = z.object({
  displayName: z.string().optional(),
  email: z.string().optional(),
});

/**
 * PATCH /api/account/profile -> { profile } — the signed-in user edits their
 * OWN name and e-mail (T43).
 *
 * ── WHY THERE IS NO USER ID IN THIS ROUTE ────────────────────────────────
 * The acting user comes from the session and nowhere else. Accepting a target
 * id here, even "for admins", would make this a second user-editing surface
 * whose authorization is a route-handler `if` rather than
 * `requireSuperAdmin` — the admin endpoints under /api/admin already do that
 * job properly.
 *
 * `requireApiUser` also refuses accounts still sitting on a temporary
 * password (403 PASSWORD_CHANGE_REQUIRED), so nobody edits a profile before
 * completing the T40 forced change.
 */
export async function PATCH(request: Request) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  /**
   * The existence-oracle ceiling (#43 review, finding 4). Only e-mail-bearing
   * requests are checked, because the e-mail is the only field that can answer
   * a question about somebody else's account; a name-only save is nobody's
   * business but the caller's and stays unlimited.
   *
   * Checked BEFORE the write, so a refused probe costs no query and learns
   * nothing — the 429 is identical whether the address is taken or free.
   */
  const limiter = emailProbeLimiter();
  if (parsed.data.email !== undefined) {
    const decision = limiter.check(gate.user.id);
    if (!decision.allowed) {
      return errorResponse(
        new TooManyAttemptsError(
          "Çok fazla deneme yapıldı, biraz sonra tekrar deneyin",
          decision.retryAfterSeconds,
        ),
      );
    }
  }

  try {
    const profile = await updateAccountProfile(gate.user.id, parsed.data);
    return NextResponse.json({ profile });
  } catch (e) {
    // Only a CONFLICT is charged: it is the answer that names an address as
    // another account's without changing anything. A successful save had to
    // actually claim the address to learn it was free, which tells the caller
    // nothing about anyone else. See lib/email-probe-limiter.ts.
    if (e instanceof ConflictError && e.code === "EMAIL_TAKEN") {
      limiter.recordFailure(gate.user.id);
    }
    return errorResponse(e);
  }
}
