/**
 * HTTP-level authorization for the account area (T43).
 *
 * `core/account/service.test.ts` proves the service is self-scoped by shape —
 * it has no target-user parameter. This file proves the same thing through the
 * real route handler with a real session cookie, because the endpoint is what
 * an attacker actually calls, and the interesting question is whether a
 * hand-crafted body can steer the write at somebody else's row.
 */
import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { hashPassword } from "@/core/auth/password";
import { createSession } from "@/core/auth/session";
import { closeDb, getDb } from "@/core/db/client";
import { users } from "@/core/db/schema";
import {
  EMAIL_PROBE_MAX_ATTEMPTS,
  resetEmailProbeLimiter,
} from "@/lib/email-probe-limiter";
import { SESSION_COOKIE } from "@/lib/session-cookie";
import { hasDb } from "@/test/db-gate";

let currentToken: string | null = null;

/** Duplicated because vi.mock factories are hoisted; asserted below. */
const COOKIE_NAME = "kb_session";

vi.mock("next/headers", () => ({
  cookies: async () => ({
    get: (name: string) =>
      name === COOKIE_NAME && currentToken
        ? { name, value: currentToken }
        : undefined,
    set: () => {},
    delete: () => {},
  }),
}));

const createdUserIds: string[] = [];
const PASSWORD = "hesap-alani-sifre-2026";

async function makeUser(
  opts: { mustChangePassword?: boolean } = {},
): Promise<{ id: string; username: string }> {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({
      username: `t43-route-${randomUUID()}`,
      passwordHash: await hashPassword(PASSWORD),
      mustChangePassword: opts.mustChangePassword ?? false,
    })
    .returning();
  createdUserIds.push(user.id);
  return { id: user.id, username: user.username };
}

async function signIn(userId: string): Promise<void> {
  const { token } = await createSession(userId);
  currentToken = token;
}

function patch(body: unknown): Request {
  return new Request("http://localhost/api/account/profile", {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function readUser(id: string) {
  const db = getDb();
  const [row] = await db.select().from(users).where(eq(users.id, id));
  return row;
}

describe.skipIf(!hasDb)("api/account/profile", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    await closeDb();
  });

  it("uses the same cookie name the app sets", () => {
    // Guards every case below from silently becoming a vacuous 401.
    expect(COOKIE_NAME).toBe(SESSION_COOKIE);
  });

  it("refuses an anonymous caller", async () => {
    const { PATCH } = await import("./profile/route");
    currentToken = null;

    const res = await PATCH(patch({ displayName: "Sızıntı" }));

    expect(res.status).toBe(401);
  });

  it("writes only the CALLER's row, ignoring an injected user id", async () => {
    // The body carries someone else's id and username. Both are ignored: the
    // handler takes the acting user from the session and nowhere else.
    const { PATCH } = await import("./profile/route");
    const victim = await makeUser();
    const attacker = await makeUser();
    await signIn(attacker.id);

    const res = await PATCH(
      patch({
        id: victim.id,
        userId: victim.id,
        username: victim.username,
        displayName: "Saldırgan",
      }),
    );

    expect(res.status).toBe(200);
    expect((await readUser(attacker.id)).displayName).toBe("Saldırgan");
    // The victim is untouched — no name, and their username is intact.
    const victimRow = await readUser(victim.id);
    expect(victimRow.displayName).toBeNull();
    expect(victimRow.username).toBe(victim.username);
  });

  it("cannot change the caller's own username or role through this endpoint", async () => {
    const { PATCH } = await import("./profile/route");
    const user = await makeUser();
    await signIn(user.id);

    const res = await PATCH(
      patch({ username: "yeni-kullanici-adi", role: "admin" }),
    );

    expect(res.status).toBe(200);
    const row = await readUser(user.id);
    expect(row.username).toBe(user.username);
    expect(row.role).toBe("user");
  });

  it("refuses an account still owing the forced password change", async () => {
    // T40's gate. Editing a profile before replacing the temporary password
    // would be a way around the forced change.
    const { PATCH } = await import("./profile/route");
    const user = await makeUser({ mustChangePassword: true });
    await signIn(user.id);

    const res = await PATCH(patch({ displayName: "Erken" }));

    expect(res.status).toBe(403);
    expect((await res.json()).code).toBe("PASSWORD_CHANGE_REQUIRED");
    expect((await readUser(user.id)).displayName).toBeNull();
  });

  it("rejects a malformed e-mail with a translatable code", async () => {
    const { PATCH } = await import("./profile/route");
    const user = await makeUser();
    await signIn(user.id);

    const res = await PATCH(patch({ email: "bu-bir-eposta-degil" }));

    expect(res.status).toBe(400);
    expect((await res.json()).code).toBe("EMAIL_INVALID");
  });

  it("refuses an address another account already holds", async () => {
    const { PATCH } = await import("./profile/route");
    const first = await makeUser();
    const second = await makeUser();
    const address = `route-${randomUUID()}@example.com`;

    await signIn(first.id);
    expect((await PATCH(patch({ email: address }))).status).toBe(200);

    await signIn(second.id);
    const res = await PATCH(patch({ email: address.toUpperCase() }));

    expect(res.status).toBe(409);
    expect((await res.json()).code).toBe("EMAIL_TAKEN");
    expect((await readUser(second.id)).email).toBeNull();
  });

  /**
   * The 409 is an existence oracle, and it is now bounded (#43 review,
   * finding 4).
   *
   * `EMAIL_TAKEN` confirms that an address belongs to some other account,
   * without changing anything and without any rate limit before this. That is
   * unbounded confirmation of third-party contact details by any signed-in
   * user, on the one T43 endpoint that writes on every call.
   */
  it("stops an account probing addresses once it has collected the cap in conflicts", async () => {
    const { PATCH } = await import("./profile/route");
    resetEmailProbeLimiter();

    const owner = await makeUser();
    const prober = await makeUser();
    const address = `probe-${randomUUID()}@example.com`;
    await signIn(owner.id);
    expect((await PATCH(patch({ email: address }))).status).toBe(200);

    await signIn(prober.id);
    for (let i = 0; i < EMAIL_PROBE_MAX_ATTEMPTS; i += 1) {
      expect((await PATCH(patch({ email: address }))).status).toBe(409);
    }

    const res = await PATCH(patch({ email: address }));
    expect(res.status).toBe(429);
    // A refused probe answers nothing about the address.
    expect((await res.json()).code).not.toBe("EMAIL_TAKEN");
  });

  it("does not charge an ordinary profile save against the probe budget", async () => {
    // The counter must be invisible to a user editing their own details, or it
    // would lock people out of their own account page.
    const { PATCH } = await import("./profile/route");
    resetEmailProbeLimiter();

    const user = await makeUser();
    await signIn(user.id);
    const address = `own-${randomUUID()}@example.com`;

    for (let i = 0; i < EMAIL_PROBE_MAX_ATTEMPTS + 2; i += 1) {
      expect(
        (await PATCH(patch({ email: address, displayName: `Ad ${i}` }))).status,
      ).toBe(200);
    }
  });
});
