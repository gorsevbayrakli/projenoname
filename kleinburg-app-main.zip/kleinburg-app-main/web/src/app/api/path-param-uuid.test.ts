/**
 * #64: every dynamic route's `[id]` / `[documentId]` path segment must be
 * UUID-validated before it reaches the data layer.
 *
 * Those segments are compared against `uuid` columns. Postgres answers a
 * non-UUID string with SQLSTATE 22P02, which `errorResponse` owns no branch
 * for, so a hand-crafted `DELETE /api/projects/abc` used to come back as a
 * generic 500 UNEXPECTED *and* write a line into the operator's error log —
 * for what is plainly a client input error. The same ids arriving in a BODY
 * are already `.uuid()`-checked (admin/users/[id]/brands, projects POST), so
 * the gap was an oversight, not a decision.
 *
 * The whole data layer is mocked here on purpose. The question this file asks
 * is not "what does Postgres do with 'abc'" — it is "does the request get that
 * far at all". Asserting the core function was never called is the real claim;
 * the 400 is how the caller learns about it. With no validation in the route
 * the mocks happily accept the junk id and the handler returns its success
 * status, which is exactly the failure being fixed.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";

const requireProjectAccess = vi.fn();
const renameProject = vi.fn();
const deleteProject = vi.fn();
const setProjectPlatforms = vi.fn();
const addDocument = vi.fn();
const deleteDocument = vi.fn();
const saveStepContent = vi.fn();
const recommendPostCounts = vi.fn();
const recordAuditEvent = vi.fn();
const recordContentAuditEvent = vi.fn();
const enqueueGeneration = vi.fn();
const getJob = vi.fn();
const setBrandMonthlyCap = vi.fn();
const grantBrandAccess = vi.fn();
const revokeBrandAccess = vi.fn();
const setTemporaryPassword = vi.fn();
const setUserRole = vi.fn();

const USER = { id: "11111111-1111-4111-8111-111111111111", username: "elif" };

vi.mock("@/lib/auth-server", () => ({
  requireApiUser: async () => ({ user: USER }),
  requireApiAdmin: async () => ({ user: USER }),
}));
vi.mock("@/core/tenancy/access", () => ({
  requireProjectAccess: (...a: unknown[]) => requireProjectAccess(...a),
}));
vi.mock("@/core/tenancy/projects", () => ({
  renameProject: (...a: unknown[]) => renameProject(...a),
  deleteProject: (...a: unknown[]) => deleteProject(...a),
  setProjectPlatforms: (...a: unknown[]) => setProjectPlatforms(...a),
}));
vi.mock("@/core/ingest/documents", () => ({
  addDocument: (...a: unknown[]) => addDocument(...a),
  deleteDocument: (...a: unknown[]) => deleteDocument(...a),
}));
vi.mock("@/core/ingest/extract", () => ({
  // The documents route fetches and parses for real otherwise; irrelevant here.
  extractText: async () => "metin",
  MAX_FILE_BYTES: 10 * 1024 * 1024,
}));
vi.mock("@/core/pipeline/inputs", () => ({
  saveStepContent: (...a: unknown[]) => saveStepContent(...a),
}));
vi.mock("@/core/pipeline/cadence", () => ({
  recommendPostCounts: (...a: unknown[]) => recommendPostCounts(...a),
}));
vi.mock("@/core/audit/service", () => ({
  recordAuditEvent: (...a: unknown[]) => recordAuditEvent(...a),
  recordContentAuditEvent: (...a: unknown[]) => recordContentAuditEvent(...a),
}));
vi.mock("@/core/jobs/worker", () => ({
  enqueueGeneration: (...a: unknown[]) => enqueueGeneration(...a),
}));
vi.mock("@/core/jobs/jobs", () => ({
  getJob: (...a: unknown[]) => getJob(...a),
}));
vi.mock("@/core/admin/service", () => ({
  setBrandMonthlyCap: (...a: unknown[]) => setBrandMonthlyCap(...a),
  grantBrandAccess: (...a: unknown[]) => grantBrandAccess(...a),
  revokeBrandAccess: (...a: unknown[]) => revokeBrandAccess(...a),
  setTemporaryPassword: (...a: unknown[]) => setTemporaryPassword(...a),
  setUserRole: (...a: unknown[]) => setUserRole(...a),
}));

const GOOD = "22222222-2222-4222-8222-222222222222";
const GOOD_DOC = "33333333-3333-4333-8333-333333333333";
/** Every shape a path segment can take that is not a UUID. */
const BAD_IDS = ["abc", "1", "", "not-a-uuid", `${GOOD} or 1=1`];

const PROJECT = { id: GOOD, name: "Proje" };
const BRAND = { id: GOOD, name: "Marka" };

function req(body?: unknown, method = "POST"): Request {
  return new Request("http://x/api", {
    method,
    headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
}

/**
 * One dynamic route, described by: how to invoke it with a given id, the core
 * function that must NOT be reached, and the status a VALID id produces.
 *
 * `params` deliberately takes the id so the same closure serves both the
 * malformed and the well-formed case — a helper that only ever ran the bad
 * path could be satisfied by a route that rejects everything.
 */
interface RouteCase {
  name: string;
  call: (id: string) => Promise<Response>;
  guarded: () => ReturnType<typeof vi.fn>;
  okStatus: number;
}

const CASES: RouteCase[] = [
  {
    name: "PATCH /api/projects/[id]",
    call: async (id) => {
      const { PATCH } = await import("./projects/[id]/route");
      return PATCH(req({ name: "yeni" }, "PATCH"), {
        params: Promise.resolve({ id }),
      });
    },
    guarded: () => renameProject,
    okStatus: 200,
  },
  {
    name: "DELETE /api/projects/[id]",
    call: async (id) => {
      const { DELETE } = await import("./projects/[id]/route");
      return DELETE(req(undefined, "DELETE"), {
        params: Promise.resolve({ id }),
      });
    },
    guarded: () => deleteProject,
    okStatus: 200,
  },
  {
    name: "PUT /api/projects/[id]/platforms",
    call: async (id) => {
      const { PUT } = await import("./projects/[id]/platforms/route");
      return PUT(req({ platforms: ["instagram"] }, "PUT"), {
        params: Promise.resolve({ id }),
      });
    },
    guarded: () => setProjectPlatforms,
    okStatus: 200,
  },
  {
    name: "POST /api/projects/[id]/platforms/advice",
    call: async (id) => {
      const { POST } = await import("./projects/[id]/platforms/advice/route");
      return POST(req({ platforms: ["instagram"] }), {
        params: Promise.resolve({ id }),
      });
    },
    guarded: () => recommendPostCounts,
    okStatus: 200,
  },
  {
    name: "POST /api/projects/[id]/documents",
    call: async (id) => {
      const { POST } = await import("./projects/[id]/documents/route");
      return POST(req({ url: "https://example.com/a" }), {
        params: Promise.resolve({ id }),
      });
    },
    guarded: () => addDocument,
    okStatus: 201,
  },
  {
    name: "DELETE /api/projects/[id]/documents/[documentId] (project id)",
    call: async (id) => {
      const { DELETE } = await import(
        "./projects/[id]/documents/[documentId]/route"
      );
      return DELETE(req(undefined, "DELETE"), {
        params: Promise.resolve({ id, documentId: GOOD_DOC }),
      });
    },
    guarded: () => deleteDocument,
    okStatus: 200,
  },
  {
    name: "DELETE /api/projects/[id]/documents/[documentId] (document id)",
    call: async (documentId) => {
      const { DELETE } = await import(
        "./projects/[id]/documents/[documentId]/route"
      );
      return DELETE(req(undefined, "DELETE"), {
        params: Promise.resolve({ id: GOOD, documentId }),
      });
    },
    guarded: () => deleteDocument,
    okStatus: 200,
  },
  {
    name: "PUT /api/projects/[id]/steps/[step]/content",
    call: async (id) => {
      const { PUT } = await import(
        "./projects/[id]/steps/[step]/content/route"
      );
      return PUT(req({ content: { a: 1 } }, "PUT"), {
        params: Promise.resolve({ id, step: "brand_context" }),
      });
    },
    guarded: () => saveStepContent,
    okStatus: 200,
  },
  {
    name: "POST /api/projects/[id]/steps/[step]/download",
    call: async (id) => {
      const { POST } = await import(
        "./projects/[id]/steps/[step]/download/route"
      );
      return POST(req({ format: "csv" }), {
        params: Promise.resolve({ id, step: "brand_context" }),
      });
    },
    guarded: () => recordAuditEvent,
    okStatus: 200,
  },
  {
    name: "POST /api/projects/[id]/steps/[step]/generate",
    call: async (id) => {
      const { POST } = await import(
        "./projects/[id]/steps/[step]/generate/route"
      );
      return POST(req({}), {
        params: Promise.resolve({ id, step: "brand_context" }),
      });
    },
    guarded: () => enqueueGeneration,
    okStatus: 202,
  },
  {
    name: "GET /api/jobs/[id]/stream",
    call: async (id) => {
      const { GET } = await import("./jobs/[id]/stream/route");
      const res = await GET(req(undefined, "GET"), {
        params: Promise.resolve({ id }),
      });
      // A 200 here is an open SSE stream; drain it so the test cannot hang.
      // Only a 200 — an error response is a JSON body the caller still reads.
      if (res.status === 200 && res.body) await res.body.cancel();
      return res;
    },
    guarded: () => getJob,
    okStatus: 200,
  },
  {
    name: "PATCH /api/admin/brands/[id]/cap",
    call: async (id) => {
      const { PATCH } = await import("./admin/brands/[id]/cap/route");
      return PATCH(req({ capUsd: null }, "PATCH"), {
        params: Promise.resolve({ id }),
      });
    },
    guarded: () => setBrandMonthlyCap,
    okStatus: 200,
  },
  {
    name: "POST /api/admin/users/[id]/brands",
    call: async (id) => {
      const { POST } = await import("./admin/users/[id]/brands/route");
      return POST(req({ brandId: GOOD }), {
        params: Promise.resolve({ id }),
      });
    },
    guarded: () => grantBrandAccess,
    okStatus: 200,
  },
  {
    name: "DELETE /api/admin/users/[id]/brands",
    call: async (id) => {
      const { DELETE } = await import("./admin/users/[id]/brands/route");
      return DELETE(req({ brandId: GOOD }, "DELETE"), {
        params: Promise.resolve({ id }),
      });
    },
    guarded: () => revokeBrandAccess,
    okStatus: 200,
  },
  {
    name: "POST /api/admin/users/[id]/password",
    call: async (id) => {
      const { POST } = await import("./admin/users/[id]/password/route");
      return POST(req({ temporaryPassword: "gecici-2026" }), {
        params: Promise.resolve({ id }),
      });
    },
    guarded: () => setTemporaryPassword,
    okStatus: 200,
  },
  {
    name: "PATCH /api/admin/users/[id]/role",
    call: async (id) => {
      const { PATCH } = await import("./admin/users/[id]/role/route");
      return PATCH(req({ role: "admin" }, "PATCH"), {
        params: Promise.resolve({ id }),
      });
    },
    guarded: () => setUserRole,
    okStatus: 200,
  },
];

describe("dynamic route path params are UUID-validated (#64)", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    requireProjectAccess.mockResolvedValue({ project: PROJECT, brand: BRAND });
    renameProject.mockResolvedValue(PROJECT);
    deleteProject.mockResolvedValue(undefined);
    setProjectPlatforms.mockResolvedValue(PROJECT);
    addDocument.mockResolvedValue({ id: GOOD_DOC, filename: "a" });
    deleteDocument.mockResolvedValue(true);
    saveStepContent.mockResolvedValue(undefined);
    recommendPostCounts.mockResolvedValue({ postCounts: {} });
    recordAuditEvent.mockResolvedValue(undefined);
    recordContentAuditEvent.mockResolvedValue(undefined);
    enqueueGeneration.mockResolvedValue({ id: GOOD });
    // 'succeeded' is terminal, so the SSE route closes the stream at once.
    getJob.mockResolvedValue({
      id: GOOD,
      projectId: GOOD,
      status: "succeeded",
      output: null,
      error: null,
    });
    setBrandMonthlyCap.mockResolvedValue(BRAND);
    grantBrandAccess.mockResolvedValue(undefined);
    revokeBrandAccess.mockResolvedValue(undefined);
    setTemporaryPassword.mockResolvedValue(undefined);
    setUserRole.mockResolvedValue({ id: GOOD, role: "admin" });
  });

  for (const c of CASES) {
    it(`${c.name} refuses a malformed id with 400 INVALID_REQUEST`, async () => {
      for (const bad of BAD_IDS) {
        vi.clearAllMocks();
        const res = await c.call(bad);
        expect(
          res.status,
          `${c.name} accepted the malformed id ${JSON.stringify(bad)}`,
        ).toBe(400);
        expect(await res.json()).toMatchObject({ code: "INVALID_REQUEST" });
        // The real claim: the junk never reached a uuid column.
        expect(c.guarded()).not.toHaveBeenCalled();
        expect(requireProjectAccess).not.toHaveBeenCalled();
      }
    });

    it(`${c.name} still serves a well-formed id`, async () => {
      const res = await c.call(GOOD);
      expect(res.status).toBe(c.okStatus);
    });
  }
});
