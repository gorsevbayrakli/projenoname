import { NextResponse } from "next/server";
import { z } from "zod";

import { deleteProject, renameProject } from "@/core/tenancy/projects";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

const renameBodySchema = z.object({
  name: z.string(),
});

type RouteContext = { params: Promise<{ id: string }> };

/** PATCH /api/projects/[id] -> 200 { project }. */
export async function PATCH(request: Request, ctx: RouteContext) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  const { id } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = renameBodySchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    const project = await renameProject(user.id, id, parsed.data.name);
    return NextResponse.json({ project });
  } catch (e) {
    return errorResponse(e);
  }
}

/** DELETE /api/projects/[id] -> 200 { ok: true }. */
export async function DELETE(_request: Request, ctx: RouteContext) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  const { id } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  try {
    await deleteProject(user.id, id);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
