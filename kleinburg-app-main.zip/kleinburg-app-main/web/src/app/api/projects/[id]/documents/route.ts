import { NextResponse } from "next/server";
import { z } from "zod";

import type { DocumentKind } from "@/core/db/schema";
import { addDocument } from "@/core/ingest/documents";
import { extractText, MAX_FILE_BYTES } from "@/core/ingest/extract";
import { requireProjectAccess } from "@/core/tenancy/access";
import { ValidationError } from "@/core/tenancy/errors";
import { errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

// Extraction touches node-only libs (unpdf/mammoth/officeparser); Node runtime.
export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string }> };

const urlBodySchema = z.object({
  url: z.string().url().refine((u) => /^https?:\/\//i.test(u), {
    message: "Yalnızca http(s) adresleri desteklenir",
  }),
});

/** Map a filename/mimetype to a file DocumentKind, or throw ValidationError. */
function fileKindFor(filename: string, mimetype: string): DocumentKind {
  const ext = filename.toLowerCase().split(".").pop() ?? "";
  if (ext === "pdf" || mimetype === "application/pdf") return "pdf";
  if (
    ext === "docx" ||
    mimetype ===
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ) {
    return "docx";
  }
  if (
    ext === "pptx" ||
    mimetype ===
      "application/vnd.openxmlformats-officedocument.presentationml.presentation"
  ) {
    return "pptx";
  }
  throw new ValidationError(
    "Desteklenmeyen dosya türü (yalnızca .pdf, .docx, .pptx)",
    "DOC_UNSUPPORTED_TYPE",
  );
}

/**
 * POST /api/projects/[id]/documents -> 201 { document }.
 *
 * Two request shapes:
 *  - multipart/form-data with a `file` field (pdf/docx/pptx), OR
 *  - application/json `{ url }` (kind = url).
 *
 * The response omits extractedText to stay light.
 */
export async function POST(request: Request, ctx: RouteContext) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  const { id } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  try {
    await requireProjectAccess(user.id, id);

    const contentType = request.headers.get("content-type") ?? "";
    let filename: string;
    let kind: DocumentKind;
    let extractedText: string;

    if (contentType.includes("multipart/form-data")) {
      // Best-effort early reject before buffering the multipart body. The
      // multipart envelope adds overhead, so allow a margin (the per-file
      // size check below stays the authoritative gate).
      const declaredLength = Number(request.headers.get("content-length"));
      if (
        Number.isFinite(declaredLength) &&
        declaredLength > MAX_FILE_BYTES * 1.1 + 4096
      ) {
        throw new ValidationError("Dosya 10MB sınırını aşıyor", "FILE_TOO_LARGE");
      }
      const form = await request.formData();
      const file = form.get("file");
      if (!(file instanceof File)) {
        throw new ValidationError("Dosya bulunamadı", "FILE_MISSING");
      }
      if (file.size > MAX_FILE_BYTES) {
        throw new ValidationError("Dosya 10MB sınırını aşıyor", "FILE_TOO_LARGE");
      }
      kind = fileKindFor(file.name, file.type);
      const buffer = Buffer.from(await file.arrayBuffer());
      extractedText = await extractText(kind, { buffer });
      filename = file.name;
    } else {
      let body: unknown;
      try {
        body = await request.json();
      } catch {
        throw new ValidationError("Geçersiz istek", "INVALID_REQUEST");
      }
      const parsed = urlBodySchema.safeParse(body);
      if (!parsed.success) {
        throw new ValidationError("Geçerli bir http(s) adresi girin", "URL_INVALID");
      }
      kind = "url";
      extractedText = await extractText(kind, { url: parsed.data.url });
      filename = parsed.data.url;
    }

    const document = await addDocument(id, filename, kind, extractedText);
    return NextResponse.json(
      {
        document: {
          id: document.id,
          filename: document.filename,
          kind: document.kind,
          createdAt: document.createdAt,
        },
      },
      { status: 201 },
    );
  } catch (e) {
    return errorResponse(e);
  }
}
