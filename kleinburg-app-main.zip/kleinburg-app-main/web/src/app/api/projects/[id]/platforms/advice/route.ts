import { NextResponse } from "next/server";
import { z } from "zod";

import { requireProjectAccess } from "@/core/tenancy/access";
import { recommendPostCounts } from "@/core/pipeline/cadence";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

/**
 * POST /api/projects/[id]/platforms/advice -> 200 { counts, rationale }.
 *
 * A posting-cadence recommendation for the chosen platforms, grounded in the
 * project's brand context (T34).
 *
 * Deliberately its own endpoint behind an explicit button rather than
 * something step 6 computes on load: it costs an LLM call, and billing the
 * user for merely revisiting a step would be indefensible.
 */
const bodySchema = z.object({
  platforms: z.array(z.string()),
});

type RouteContext = { params: Promise<{ id: string }> };

export async function POST(request: Request, ctx: RouteContext) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  const { id } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    await requireProjectAccess(user.id, id);
    // user.id is passed through so the synthetic job this opens records WHO
    // spent the money, the same as any queued generation does.
    const advice = await recommendPostCounts(
      id,
      parsed.data.platforms,
      user.id,
    );
    return NextResponse.json(advice);
  } catch (e) {
    return errorResponse(e);
  }
}
