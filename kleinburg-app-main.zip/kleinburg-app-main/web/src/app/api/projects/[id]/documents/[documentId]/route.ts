import { NextResponse } from "next/server";

import { deleteDocument } from "@/core/ingest/documents";
import { NotFoundError } from "@/core/tenancy/errors";
import { requireProjectAccess } from "@/core/tenancy/access";
import { errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

export const runtime = "nodejs";

type RouteContext = { params: Promise<{ id: string; documentId: string }> };

/** DELETE /api/projects/[id]/documents/[documentId] -> 200 { ok: true }. */
export async function DELETE(_request: Request, ctx: RouteContext) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  const { id, documentId } = await ctx.params;
  const invalid = invalidUuidParams(id, documentId);
  if (invalid) return invalid;

  try {
    await requireProjectAccess(user.id, id);
    const removed = await deleteDocument(id, documentId);
    if (!removed) throw new NotFoundError("Belge bulunamadı", "DOCUMENT_NOT_FOUND");
    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
