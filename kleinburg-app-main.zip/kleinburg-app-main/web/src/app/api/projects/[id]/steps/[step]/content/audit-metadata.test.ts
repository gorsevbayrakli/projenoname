/**
 * #65: the `selectedCount` the content route promises to record must actually
 * be recorded.
 *
 * The route's own comment says the derived number is deliberately kept because
 * "they narrowed 12 posts to 3" is meaningful — but the guard tested
 * `Array.isArray(selections)`, and `selections` is `{selectedIndices:number[]}`
 * (core/pipeline/inputs.ts). `Array.isArray({selectedIndices:[...]})` is always
 * false, so the field was never written and, because `audit_events` is
 * append-only, that history can never be backfilled.
 *
 * The ROUTE is the side that was wrong: the object form is the persisted
 * `Selections` type and is what all three call sites send
 * (secondary-data-step, sm-pillars-step, creative-sparks-step). So this file
 * pins the shape the clients actually post, and asserts the audit row carries
 * the count derived from it.
 *
 * Everything below the route is mocked — the claim is about what metadata the
 * handler hands to `recordContentAuditEvent`, which needs no database.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";

const recordContentAuditEvent = vi.fn();
const saveStepContent = vi.fn();

const USER = { id: "11111111-1111-4111-8111-111111111111", username: "elif" };
const PROJECT_ID = "22222222-2222-4222-8222-222222222222";
const BRAND = { id: "33333333-3333-4333-8333-333333333333", name: "Marka" };

vi.mock("@/lib/auth-server", () => ({
  requireApiUser: async () => ({ user: USER }),
}));
vi.mock("@/core/tenancy/access", () => ({
  requireProjectAccess: async () => ({
    project: { id: PROJECT_ID, name: "Proje" },
    brand: BRAND,
  }),
}));
vi.mock("@/core/pipeline/inputs", () => ({
  saveStepContent: (...a: unknown[]) => saveStepContent(...a),
}));
vi.mock("@/core/audit/service", () => ({
  recordContentAuditEvent: (...a: unknown[]) => recordContentAuditEvent(...a),
}));

import { PUT } from "./route";

/** The metadata object the handler passed to the audit recorder. */
async function putAndReadMetadata(body: unknown) {
  const res = await PUT(
    new Request("http://x/api", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }),
    { params: Promise.resolve({ id: PROJECT_ID, step: "sm_pillars" }) },
  );
  expect(res.status).toBe(200);
  expect(recordContentAuditEvent).toHaveBeenCalledTimes(1);
  return (
    recordContentAuditEvent.mock.calls[0][0] as {
      action: string;
      metadata: Record<string, unknown>;
    }
  );
}

describe("content route audit metadata (#65)", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    saveStepContent.mockResolvedValue(undefined);
    recordContentAuditEvent.mockResolvedValue(undefined);
  });

  it("records selectedCount from the shape the clients actually send", async () => {
    // Verbatim the body sm-pillars-step.tsx et al. post.
    const event = await putAndReadMetadata({
      selections: { selectedIndices: [0, 4, 7] },
    });

    expect(event.action).toBe("content_select");
    expect(event.metadata).toMatchObject({
      fields: "selections",
      selectedCount: 3,
    });
  });

  it("records selectedCount 0 when the user deselects everything", async () => {
    // The narrowing story is only honest if an empty choice is a recorded 0
    // and not an absent field indistinguishable from "never sent selections".
    const event = await putAndReadMetadata({
      selections: { selectedIndices: [] },
    });

    expect(event.metadata.selectedCount).toBe(0);
  });

  it("omits selectedCount when the request carries no selections", async () => {
    const event = await putAndReadMetadata({ content: { a: 1 } });

    expect(event.action).toBe("content_edit");
    expect(event.metadata).toMatchObject({ fields: "content" });
    expect(event.metadata).not.toHaveProperty("selectedCount");
  });

  it("records the count on an edit that also changes the selection", async () => {
    const event = await putAndReadMetadata({
      content: { a: 1 },
      selections: { selectedIndices: [2, 5] },
    });

    // The edit is the stronger claim and the recorded action, but the
    // selection still happened and its count is still the derived fact.
    expect(event.action).toBe("content_edit");
    expect(event.metadata).toMatchObject({
      fields: "content,selections",
      selectedCount: 2,
    });
  });

  it("omits selectedCount rather than guessing when selections is null", async () => {
    // null is the documented "use all items" value, not a narrowing.
    const event = await putAndReadMetadata({ selections: null });

    expect(event.metadata).not.toHaveProperty("selectedCount");
  });
});
