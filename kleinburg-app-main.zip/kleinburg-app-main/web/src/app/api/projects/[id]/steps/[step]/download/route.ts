import { NextResponse } from "next/server";
import { z } from "zod";

import { recordAuditEvent } from "@/core/audit/service";
import { workflowStep } from "@/core/db/schema";
import { requireProjectAccess } from "@/core/tenancy/access";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

// This route touches pg; it must run on the Node.js runtime.
export const runtime = "nodejs";

const stepSchema = z.enum(workflowStep.enumValues);

const bodySchema = z.object({
  /**
   * A closed set, not free text. The value lands in a permanent row and an
   * enum is the cheapest way to guarantee a client cannot write prose into it.
   */
  format: z.enum(["csv", "xlsx"]),
  /** Which platform's calendar, when the export is for one. Optional. */
  platform: z.string().max(50).optional(),
});

type RouteContext = { params: Promise<{ id: string; step: string }> };

/**
 * POST /api/projects/[id]/steps/[step]/download -> { ok: true }
 *
 * ── WHY THIS ENDPOINT EXISTS AT ALL ──────────────────────────────────────
 * Elif asked for downloads to be audited (T41 category 4). The calendar export
 * is built ENTIRELY in the browser — `lib/calendar-export.ts` turns rows the
 * page already has into a Blob and hands it to the user. The bytes never touch
 * the server, so there is no request to observe and no other place a record
 * could come from.
 *
 * So this is a beacon: the client tells the server that a download happened.
 *
 * ── WHAT THAT IS AND IS NOT WORTH ────────────────────────────────────────
 * BE HONEST about the difference between this row and the others. Every other
 * audit action records something the server DID and therefore knows to be
 * true. This one records something the client REPORTS. A user who blocks the
 * request, disables JavaScript after the page loads, or simply copies the
 * table out of the DOM takes the content with no row written; nothing here can
 * prevent that, because the data was already in their browser the moment they
 * were authorized to view the step.
 *
 * It is therefore evidence of normal use, not proof of exfiltration, and the
 * trail must not be read as "these are all the times content left the system".
 * Making it stronger would mean moving export generation to the server so the
 * download is a real request — a worthwhile change, but a different issue: it
 * would move XLSX generation off the client and change the shipped download
 * behaviour, which is not something to fold into an audit-trail task.
 *
 * The endpoint still runs the FULL access gate rather than trusting the
 * beacon. Without it, any authenticated user could write audit rows naming any
 * project id — poisoning the log of a brand they cannot see, which would be a
 * worse bug than the missing record it set out to fix.
 */
export async function POST(request: Request, ctx: RouteContext) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  const { id, step } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  const parsedStep = stepSchema.safeParse(step);
  if (!parsedStep.success) {
    return apiError("Geçersiz adım", "INVALID_STEP", 400);
  }

  let raw: unknown;
  try {
    raw = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = bodySchema.safeParse(raw);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    const { project, brand } = await requireProjectAccess(user.id, id);

    // Not coalesced (see COALESCED_ACTIONS): a download is a discrete act of
    // taking content out, and "how many times was this exported" is a question
    // worth being able to answer exactly.
    await recordAuditEvent({
      action: "content_download",
      actorUserId: user.id,
      actorUsername: user.username,
      brandId: brand.id,
      brandName: brand.name,
      projectId: project.id,
      projectName: project.name,
      step: parsedStep.data,
      metadata: {
        format: parsed.data.format,
        ...(parsed.data.platform ? { platform: parsed.data.platform } : {}),
      },
    });

    return NextResponse.json({ ok: true });
  } catch (e) {
    return errorResponse(e);
  }
}
