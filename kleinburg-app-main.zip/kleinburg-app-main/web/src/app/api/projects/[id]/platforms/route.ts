import { NextResponse } from "next/server";
import { z } from "zod";

import { setProjectPlatforms } from "@/core/tenancy/projects";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

/**
 * Loose on purpose: the codes are validated against the registry inside
 * setProjectPlatforms, which drops unregistered ones and rejects only a
 * selection that ends up empty. Pinning a z.enum here would mean a second
 * copy of the platform list — the exact duplication T29 removed.
 */
const bodySchema = z.object({
  platforms: z.array(z.string()),
  // Values are range-checked in setProjectPlatforms, which owns the cap.
  postCounts: z.record(z.string(), z.number()).optional(),
});

type RouteContext = { params: Promise<{ id: string }> };

/** PUT /api/projects/[id]/platforms -> 200 { project }. */
export async function PUT(request: Request, ctx: RouteContext) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  const { id } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    const project = await setProjectPlatforms(
      user.id,
      id,
      parsed.data.platforms,
      parsed.data.postCounts ?? {},
    );
    return NextResponse.json({ project });
  } catch (e) {
    return errorResponse(e);
  }
}
