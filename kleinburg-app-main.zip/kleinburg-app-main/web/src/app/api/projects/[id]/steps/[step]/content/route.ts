import { NextResponse } from "next/server";
import { z } from "zod";

import { recordContentAuditEvent } from "@/core/audit/service";
import { workflowStep } from "@/core/db/schema";
import { saveStepContent, type Selections } from "@/core/pipeline/inputs";
import { requireProjectAccess } from "@/core/tenancy/access";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

// This route touches pg; it must run on the Node.js runtime.
export const runtime = "nodejs";

const stepSchema = z.enum(workflowStep.enumValues);

const CONTENT_OR_SELECTIONS_MESSAGE = "content veya selections gerekli";

/**
 * The persisted `Selections` shape (core/pipeline/inputs.ts), spelled out here
 * only to derive `selectedCount` for the audit row (#65).
 *
 * The body's `selections` is `z.unknown()` because each step owns its own
 * content shape and this route does not police it — but the CURATION shape is
 * shared by every step that supports selection, and it is an object, never an
 * array. The guard here used to be `Array.isArray(selections)`, which is false
 * for `{selectedIndices:[...]}`, so the count the comment below promises was
 * never once written. Parsing the real shape is what makes it true.
 */
const selectionsShape = z.object({ selectedIndices: z.array(z.number()) });

// content and selections are opaque jsonb (each step owns its own shape); we
// only require that at least one is present so a no-op PUT is rejected.
const bodySchema = z
  .object({
    content: z.unknown().optional(),
    selections: z.unknown().optional(),
  })
  .refine((b) => b.content !== undefined || b.selections !== undefined, {
    message: CONTENT_OR_SELECTIONS_MESSAGE,
  });

type RouteContext = { params: Promise<{ id: string; step: string }> };

/**
 * PUT /api/projects/[id]/steps/[step]/content -> 200 { ok: true }.
 *
 * The generic auto-save endpoint the generative step UIs call on inline edit /
 * selection. Upserts step_contents for (project, step), patching only the
 * provided field(s). Content is jsonb, so T16–T21 reuse this verbatim.
 */
export async function PUT(request: Request, ctx: RouteContext) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  const { id, step } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  const parsedStep = stepSchema.safeParse(step);
  if (!parsedStep.success) {
    return apiError("Geçersiz adım", "INVALID_STEP", 400);
  }

  let raw: unknown;
  try {
    raw = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsedBody = bodySchema.safeParse(raw);
  if (!parsedBody.success) {
    // The only refinement on bodySchema is the content/selections one, so a
    // failure here is that specific code; anything else degrades to generic.
    const issue = parsedBody.error.issues[0]?.message;
    return issue === CONTENT_OR_SELECTIONS_MESSAGE
      ? apiError(issue, "CONTENT_OR_SELECTIONS_REQUIRED", 400)
      : apiError(issue ?? "Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    // Brand isolation gate: throws Access/NotFound mapped by errorResponse.
    const { project, brand } = await requireProjectAccess(user.id, id);
    await saveStepContent(id, parsedStep.data, {
      content: parsedBody.data.content,
      selections: parsedBody.data.selections as Selections | undefined,
    });

    // ── T41 category 4: the high-volume one ──────────────────────────────
    // This is the autosave endpoint, so a naive record-per-request would write
    // a row per keystroke-debounce. `recordContentAuditEvent` collapses a
    // burst into one row per five-minute window (see core/audit/events.ts) —
    // by suppressing the INSERT, never by updating a row, because the table is
    // append-only.
    //
    // Which action: a body carrying `content` is an EDIT, one carrying only
    // `selections` is a curation choice. Both may be present, and then the
    // edit is the stronger claim and the one recorded; `fields` keeps the
    // distinction for a reader.
    //
    // The content itself is NOT recorded. `step_contents` already holds what
    // was written; this row answers who and when, which is the question Elif
    // asked ("kim yazdı") and the only one worth paying for in a table that is
    // never deleted. `selectedCount` is the one derived number kept, because
    // "they narrowed 12 posts to 3" is meaningful and costs 8 bytes.
    const hasContent = parsedBody.data.content !== undefined;
    const selections = parsedBody.data.selections;
    // Reads `selections.selectedIndices`, the shape the clients actually post
    // and the shape the column actually holds — see selectionsShape above.
    const parsedSelections = selectionsShape.safeParse(selections);
    await recordContentAuditEvent({
      action: hasContent ? "content_edit" : "content_select",
      actorUserId: user.id,
      actorUsername: user.username,
      brandId: brand.id,
      brandName: brand.name,
      projectId: project.id,
      projectName: project.name,
      step: parsedStep.data,
      metadata: {
        fields: [hasContent ? "content" : null, selections ? "selections" : null]
          .filter(Boolean)
          .join(","),
        ...(parsedSelections.success
          ? { selectedCount: parsedSelections.data.selectedIndices.length }
          : {}),
      },
    });

    return NextResponse.json({ ok: true }, { status: 200 });
  } catch (e) {
    return errorResponse(e);
  }
}
