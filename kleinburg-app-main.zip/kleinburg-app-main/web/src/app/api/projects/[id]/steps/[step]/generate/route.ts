import { NextResponse } from "next/server";
import { z } from "zod";

import { recordAuditEvent } from "@/core/audit/service";
import { workflowStep } from "@/core/db/schema";
import { enqueueGeneration } from "@/core/jobs/worker";
import { requireProjectAccess } from "@/core/tenancy/access";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";
import { invalidUuidParams } from "@/lib/route-params";

// This route touches pg + pg-boss; it must run on the Node.js runtime.
export const runtime = "nodejs";

const stepSchema = z.enum(workflowStep.enumValues);

type RouteContext = { params: Promise<{ id: string; step: string }> };

/**
 * POST /api/projects/[id]/steps/[step]/generate -> 202 { jobId }.
 * Enqueues a durable generation job for the given workflow step.
 */
export async function POST(request: Request, ctx: RouteContext) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  const { id, step } = await ctx.params;
  const invalid = invalidUuidParams(id);
  if (invalid) return invalid;

  const parsedStep = stepSchema.safeParse(step);
  if (!parsedStep.success) {
    return apiError("Geçersiz adım", "INVALID_STEP", 400);
  }

  // Optional JSON body is the job input; empty/invalid body defaults to {}.
  let input: unknown = {};
  try {
    const text = await request.text();
    if (text.trim().length > 0) input = JSON.parse(text);
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    // Brand isolation gate: throws Access/NotFound mapped by errorResponse.
    const { project, brand } = await requireProjectAccess(user.id, id);
    const job = await enqueueGeneration(id, parsedStep.data, input, user.id);

    // T41 category 3: who ran which step on which project. Recorded AFTER the
    // gate, so the trail contains authorized triggers only — a refused request
    // is not a generation and belongs in the access log, not here.
    //
    // The job input is NOT copied in. It is user prose of unbounded length and
    // `generation_jobs.input` already holds it verbatim; `jobId` is the join
    // key to it, and to the `llm_calls` rows that carry the cost #42 wants.
    await recordAuditEvent({
      action: "generation_start",
      actorUserId: user.id,
      actorUsername: user.username,
      brandId: brand.id,
      brandName: brand.name,
      projectId: project.id,
      projectName: project.name,
      step: parsedStep.data,
      metadata: { jobId: job.id },
    });

    return NextResponse.json({ jobId: job.id }, { status: 202 });
  } catch (e) {
    return errorResponse(e);
  }
}
