import { NextResponse } from "next/server";
import { z } from "zod";

import {
  createProject,
  listProjects,
  PROJECT_LANGUAGES,
} from "@/core/tenancy/projects";
import { apiError, errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";

const listQuerySchema = z.object({
  brandId: z.string().uuid(),
});

const createBodySchema = z.object({
  brandId: z.string().uuid(),
  name: z.string(),
  // No default: an omitted language is a client bug, not a request to
  // generate the whole campaign in English.
  language: z.enum(PROJECT_LANGUAGES),
});

/** GET /api/projects?brandId=UUID -> { projects } under that brand. */
export async function GET(request: Request) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  const { searchParams } = new URL(request.url);
  const parsed = listQuerySchema.safeParse({
    brandId: searchParams.get("brandId"),
  });
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    const projects = await listProjects(user.id, parsed.data.brandId);
    return NextResponse.json({ projects });
  } catch (e) {
    return errorResponse(e);
  }
}

/** POST /api/projects -> 201 { project }. */
export async function POST(request: Request) {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = createBodySchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  try {
    const project = await createProject(
      user.id,
      parsed.data.brandId,
      parsed.data.name,
      parsed.data.language,
    );
    return NextResponse.json({ project }, { status: 201 });
  } catch (e) {
    return errorResponse(e);
  }
}
