import { NextResponse } from "next/server";

import { listAccessibleBrands } from "@/core/tenancy/access";
import { errorResponse } from "@/lib/api-errors";
import { requireApiUser } from "@/lib/auth-server";

/** GET /api/brands -> { brands } the current user can access. */
export async function GET() {
  const gate = await requireApiUser();
  if ("response" in gate) return gate.response;
  const { user } = gate;

  try {
    const brands = await listAccessibleBrands(user.id);
    return NextResponse.json({ brands });
  } catch (e) {
    return errorResponse(e);
  }
}
