/**
 * The login route's ceiling (#41 review, finding 1) — at the HTTP layer, which
 * is the layer an attacker actually reaches.
 *
 * The vulnerability: `/api/auth/login` was unauthenticated AND unthrottled.
 * `middleware.ts` excludes `api/auth` from its matcher, and the only
 * `AttemptLimiter` in the codebase guarded `/api/auth/change-password`. Every
 * failed attempt awaited an INSERT into `audit_events` — a table with no DELETE
 * path — so a loop of garbage credentials grew it without bound. And because
 * directory actions are ATOMIC on their audit row, a full table rolls back
 * `grantBrandAccess`, `createBrand`, `createUser` and `setTemporaryPassword`:
 * an unauthenticated party locking the super admin out of his own admin panel,
 * with `DROP TRIGGER` + `DELETE` as the only way back.
 *
 * The assertion that matters most is not "the 11th request is refused" — it is
 * that a refused request writes NO ROW. A 429 that still recorded the attempt
 * would leave the flood intact and only change its status code.
 */
import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { hashPassword } from "@/core/auth/password";
import { maskUnknownUsername } from "@/core/audit/events";
import { resetAuthFailureAuditBudget } from "@/core/audit/auth-failures";
import { closeDb, getDb } from "@/core/db/client";
import { auditEvents, users } from "@/core/db/schema";
import { hasDb } from "@/test/db-gate";

vi.mock("next/headers", () => ({
  cookies: async () => ({
    get: () => undefined,
    set: () => {},
    delete: () => {},
  }),
}));

const { POST } = await import("./login/route");

const createdUserIds: string[] = [];
const PASSWORD = "dogru-parola-2026";

/** The route's limiter, matching the constant in `login/route.ts`. */
const MAX_ATTEMPTS = 10;

function post(username: string, password: string) {
  return POST(
    new Request("http://localhost/api/auth/login", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ username, password }),
    }),
  );
}

async function makeUser() {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({
      username: `t41-rl-${randomUUID()}`,
      passwordHash: await hashPassword(PASSWORD),
    })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

/** How many audit rows exist for an unresolvable name (stored as a digest). */
async function rowsForUnknown(name: string) {
  return getDb()
    .select()
    .from(auditEvents)
    .where(eq(auditEvents.actorUsername, maskUnknownUsername(name)));
}

describe.skipIf(!hasDb)("login route rate limit", () => {
  beforeAll(() => {
    getDb();
    resetAuthFailureAuditBudget();
  });

  afterAll(async () => {
    if (createdUserIds.length > 0) {
      await getDb().delete(users).where(inArray(users.id, createdUserIds));
    }
    await closeDb();
  });

  it("refuses further attempts once the ceiling is reached, and writes no row for them", async () => {
    resetAuthFailureAuditBudget();
    const ghost = `t41-rl-ghost-${randomUUID()}`;

    for (let i = 0; i < MAX_ATTEMPTS; i += 1) {
      const res = await post(ghost, "yanlis");
      expect(res.status).toBe(401);
    }
    const atCeiling = await rowsForUnknown(ghost);
    expect(atCeiling).toHaveLength(MAX_ATTEMPTS);

    // Past the ceiling: refused, and — the point of the whole fix — silent in
    // the audit table. Ten more requests, not one more permanent row.
    for (let i = 0; i < 10; i += 1) {
      const res = await post(ghost, "yanlis");
      expect(res.status).toBe(429);
    }
    expect(await rowsForUnknown(ghost)).toHaveLength(MAX_ATTEMPTS);
  });

  it("does not leak whether the username exists", async () => {
    // The 429 must arrive for a real account on exactly the same terms as for
    // an imaginary one, or the throttle becomes the enumeration oracle the
    // generic 401 was written to avoid.
    resetAuthFailureAuditBudget();
    const user = await makeUser();

    for (let i = 0; i < MAX_ATTEMPTS; i += 1) {
      expect((await post(user.username, "yanlis")).status).toBe(401);
    }
    expect((await post(user.username, "yanlis")).status).toBe(429);
    // Even the CORRECT password is refused while throttled — the limiter runs
    // before `authenticate`, which is what makes a throttled attempt free.
    expect((await post(user.username, PASSWORD)).status).toBe(429);
  });

  it("counts case-insensitively, so varying the case is not a free reset", async () => {
    resetAuthFailureAuditBudget();
    const ghost = `t41-rl-case-${randomUUID()}`;

    for (let i = 0; i < MAX_ATTEMPTS; i += 1) {
      await post(i % 2 === 0 ? ghost : ghost.toUpperCase(), "yanlis");
    }
    expect((await post(ghost, "yanlis")).status).toBe(429);
  });

  it("clears the counter on a successful login", async () => {
    resetAuthFailureAuditBudget();
    const user = await makeUser();

    for (let i = 0; i < MAX_ATTEMPTS - 1; i += 1) {
      expect((await post(user.username, "yanlis")).status).toBe(401);
    }
    expect((await post(user.username, PASSWORD)).status).toBe(200);

    // A user who fumbled nine times and then got it right must not be sitting
    // one attempt from a lockout.
    for (let i = 0; i < MAX_ATTEMPTS; i += 1) {
      expect((await post(user.username, "yanlis")).status).toBe(401);
    }
  });
});
