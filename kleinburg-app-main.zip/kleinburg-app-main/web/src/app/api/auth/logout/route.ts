import { cookies } from "next/headers";
import { NextResponse } from "next/server";

import { deleteSession } from "@/core/auth/session";
import { clearSessionCookie, SESSION_COOKIE } from "@/lib/auth-server";

export async function POST() {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) {
    await deleteSession(token);
  }
  clearSessionCookie(store);
  return NextResponse.json({ ok: true });
}
