import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { z } from "zod";

import { AttemptLimiter } from "@/core/auth/attempt-limiter";
import { authenticate } from "@/core/auth/session";
import { TooManyAttemptsError } from "@/core/tenancy/errors";
import { apiError, errorResponse } from "@/lib/api-errors";
import { setSessionCookie } from "@/lib/auth-server";

const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

// Single generic message: never reveal whether the username or the password
// was the wrong one (user-enumeration defense).
const GENERIC_ERROR = "Kullanıcı adı veya şifre hatalı";

const TOO_MANY_ERROR =
  "Çok fazla hatalı giriş denemesi yapıldı, biraz sonra tekrar deneyin";

/**
 * The ceiling on login guessing (#41 review, finding 1).
 *
 * This route was the one unauthenticated, unlimited path in the app:
 * `middleware.ts` excludes `api/auth` from its matcher and the only
 * `AttemptLimiter` in the codebase guarded `/api/auth/change-password`. Every
 * failed attempt writes a permanent row into `audit_events`, a table with no
 * DELETE path — so an unlimited login route was an unauthenticated way to grow
 * that table without bound and, because directory actions are atomic on their
 * audit row, eventually to lock the super admin out of the admin panel.
 *
 * Ten failures per fifteen minutes, matching change-password: high enough that
 * a person fumbling their own password never meets it, low enough that guessing
 * is pointless.
 *
 * Module-level, so it lives as long as the server process — correct for the
 * single Render web service this deploys to (`numInstances: 1`) and WRONG the
 * day it becomes two, at which point this has to move to shared storage.
 *
 * ── WHY THE KEY IS THE USERNAME ──────────────────────────────────────────
 * There is nothing better available. The session id does not exist yet, and the
 * client IP behind Render's proxy is either the proxy (`request.ip`) or
 * whatever the client claims (`X-Forwarded-For`) — keying a security control on
 * a header the attacker writes is worse than not keying on it at all.
 *
 * So this bounds attempts PER USERNAME, which is the credential-guessing
 * defence, and it does not by itself bound an attacker who varies the username
 * on every request. That second, larger hole is closed one layer down by the
 * row budget in `core/audit/auth-failures.ts` — this limiter deliberately does
 * NOT try to solve it with a global counter, because a global counter on this
 * route would let an unauthenticated flood refuse logins to everybody
 * including the admin: the same denial of service in a new costume.
 *
 * Normalised (trim + lowercase) so that varying the case is not a free reset.
 *
 * ── THE COST, STATED ─────────────────────────────────────────────────────
 * Keying on the username means a third party who knows an account name can
 * burn its ten attempts and keep that ONE user out for up to fifteen minutes.
 * That is the standard price of per-account throttling and it is accepted here
 * because the window is short and self-healing, a successful login clears it,
 * and the alternative — no limit at all — is what made this finding critical.
 * The 429 is returned identically for real and imaginary usernames, so it is
 * not an existence oracle.
 */
const loginLimiter = new AttemptLimiter({
  maxAttempts: 10,
  windowMs: 15 * 60 * 1000,
});

function limiterKey(username: string): string {
  return username.trim().toLowerCase();
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  // Checked BEFORE `authenticate`, which is the whole point: a throttled
  // attempt costs no argon2 verify and — critically — writes no audit row.
  const key = limiterKey(parsed.data.username);
  const decision = loginLimiter.check(key);
  if (!decision.allowed) {
    return errorResponse(
      new TooManyAttemptsError(TOO_MANY_ERROR, decision.retryAfterSeconds),
    );
  }

  const result = await authenticate(
    parsed.data.username,
    parsed.data.password,
  );
  if (!result) {
    loginLimiter.recordFailure(key);
    return apiError(GENERIC_ERROR, "INVALID_CREDENTIALS", 401);
  }

  // Proved they know the password: wipe the slate, so a user who fumbled twice
  // does not stay near the ceiling for the next quarter hour.
  loginLimiter.reset(key);

  const store = await cookies();
  setSessionCookie(store, result.token, result.expiresAt);
  return NextResponse.json({ ok: true });
}
