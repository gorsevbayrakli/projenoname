import { NextResponse } from "next/server";
import { z } from "zod";

import { AttemptLimiter } from "@/core/auth/attempt-limiter";
import { changePassword } from "@/core/auth/change-password";
import { TooManyAttemptsError, ValidationError } from "@/core/tenancy/errors";
import { apiError, errorResponse } from "@/lib/api-errors";
import { getCurrentUser } from "@/lib/auth-server";

const bodySchema = z.object({
  currentPassword: z.string(),
  newPassword: z.string(),
});

/**
 * The ceiling on `currentPassword` guessing (#40 review, finding 11).
 *
 * Module-level, so it lives as long as the server process. That is correct for
 * the single Render web service this deploys to and WRONG the day it becomes
 * more than one — at that point the counter has to move to shared storage, or
 * an attacker just spreads their guesses across instances.
 *
 * Ten failures per fifteen minutes: high enough that a person fumbling their
 * own password never meets it, low enough that guessing is pointless.
 */
const changePasswordLimiter = new AttemptLimiter({
  maxAttempts: 10,
  windowMs: 15 * 60 * 1000,
});

/**
 * POST /api/auth/change-password -> { ok: true }.
 *
 * The ONE authenticated endpoint that deliberately does not use
 * `requireApiUser`: that guard rejects an account owing a first-login password
 * change, and this is the request that discharges the obligation. It calls
 * `getCurrentUser` instead, so a valid session is still required — the user id
 * comes from the session and is never taken from the body.
 *
 * Neither password appears in the response or in any error message; see
 * core/auth/change-password.ts.
 */
export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return apiError("Oturum gerekli", "UNAUTHENTICATED", 401);
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) {
    // Generic on purpose: a Zod issue list would quote the password fields.
    return apiError("Geçersiz istek", "INVALID_REQUEST", 400);
  }

  // Keyed by the SESSION's user id, never by anything in the body — the body is
  // attacker-controlled and could otherwise be varied to dodge the counter.
  const decision = changePasswordLimiter.check(user.id);
  if (!decision.allowed) {
    return errorResponse(
      new TooManyAttemptsError(
        "Çok fazla hatalı deneme yapıldı, biraz sonra tekrar deneyin",
        decision.retryAfterSeconds,
      ),
    );
  }

  try {
    await changePassword(
      user.id,
      parsed.data.currentPassword,
      parsed.data.newPassword,
    );
    // Succeeded: the caller proved they know the password, so the slate is
    // wiped. Otherwise a user who fumbled twice would stay near the ceiling.
    changePasswordLimiter.reset(user.id);
    return NextResponse.json({ ok: true });
  } catch (e) {
    // Only a WRONG CURRENT PASSWORD counts. A too-short or reused new password
    // is a legitimate user correcting themselves, and charging them for it
    // would lock people out of the forced-change page they cannot leave.
    if (e instanceof ValidationError && e.code === "CURRENT_PASSWORD_INVALID") {
      changePasswordLimiter.recordFailure(user.id);
    }
    return errorResponse(e);
  }
}
