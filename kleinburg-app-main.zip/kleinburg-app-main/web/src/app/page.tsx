import { LoginScreen } from "@/components/login-screen";

/**
 * `/` — the front door (T45).
 *
 * This used to be the create-next-app theme showcase, which is what a visitor
 * to the bare domain saw. It is now the sign-in screen itself, so the product
 * introduces itself at its own address; a visitor who already has a session is
 * forwarded on by LoginScreen.
 */
export default function RootPage() {
  return <LoginScreen />;
}
