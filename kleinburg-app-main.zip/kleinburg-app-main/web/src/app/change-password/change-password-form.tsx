"use client";

import { useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { MIN_PASSWORD_LENGTH } from "@/core/auth/password-policy";
import { apiErrorMessage, type ApiErrorTranslator } from "@/lib/api-error-copy";

/**
 * The first-login password change form (T40).
 *
 * Every field is `type="password"` with an explicit autoComplete hint, so the
 * values never render as readable text and a password manager stores the new
 * one rather than the temporary one. Nothing here writes a password to state
 * that outlives the submit, logs it, or puts it in a URL.
 */
export function ChangePasswordForm() {
  const t = useTranslations("changePassword");
  const tApi = useTranslations("apiErrors") satisfies ApiErrorTranslator;
  const router = useRouter();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  // Checked in the browser purely as a courtesy — the server checks length and
  // sameness itself, and the server is the one that decides.
  const mismatch =
    confirmPassword.length > 0 && newPassword !== confirmPassword;
  const tooShort =
    newPassword.length > 0 && newPassword.length < MIN_PASSWORD_LENGTH;

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (newPassword !== confirmPassword) {
      setError(t("mismatch"));
      return;
    }
    setError(null);
    setPending(true);
    try {
      const res = await fetch("/api/auth/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword, newPassword }),
      });
      if (res.ok) {
        // Drop the plaintext from component state the moment it is no longer
        // needed, then leave the page.
        setCurrentPassword("");
        setNewPassword("");
        setConfirmPassword("");
        router.push("/projects");
        router.refresh();
        return;
      }
      const data = (await res.json().catch(() => null)) as {
        error?: string;
        code?: string;
      } | null;
      setError(apiErrorMessage(data, tApi, t("failed")));
    } catch {
      setError(t("failed"));
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="flex flex-col gap-4">
      <PasswordField
        id="currentPassword"
        label={t("current")}
        autoComplete="current-password"
        value={currentPassword}
        onChange={setCurrentPassword}
      />
      <PasswordField
        id="newPassword"
        label={t("new")}
        autoComplete="new-password"
        value={newPassword}
        onChange={setNewPassword}
        hint={t("hint", { min: MIN_PASSWORD_LENGTH })}
      />
      <PasswordField
        id="confirmPassword"
        label={t("confirm")}
        autoComplete="new-password"
        value={confirmPassword}
        onChange={setConfirmPassword}
      />

      {/*
        #40 review, finding 4. The submit button greys out on a short password
        with nothing said about why, which reads as a broken app rather than an
        unmet rule. The reason is stated here and the button POINTS at it via
        aria-describedby, so it is announced to a screen reader too.
      */}
      {tooShort ? (
        <p
          id="tooShortReason"
          role="alert"
          className="text-sm text-destructive"
        >
          {t("tooShort", { min: MIN_PASSWORD_LENGTH })}
        </p>
      ) : null}
      {mismatch ? (
        <p id="mismatchReason" role="alert" className="text-sm text-destructive">
          {t("mismatch")}
        </p>
      ) : null}
      {error ? (
        <p role="alert" className="text-sm text-destructive">
          {error}
        </p>
      ) : null}

      <Button
        type="submit"
        size="lg"
        aria-describedby={
          [tooShort ? "tooShortReason" : null, mismatch ? "mismatchReason" : null]
            .filter(Boolean)
            .join(" ") || undefined
        }
        disabled={
          pending ||
          mismatch ||
          tooShort ||
          currentPassword.length === 0 ||
          newPassword.length === 0
        }
      >
        {pending ? t("submitting") : t("submit")}
      </Button>
    </form>
  );
}

function PasswordField({
  id,
  label,
  autoComplete,
  value,
  onChange,
  hint,
}: {
  id: string;
  label: string;
  autoComplete: string;
  value: string;
  onChange: (value: string) => void;
  hint?: string;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <label htmlFor={id} className="text-sm font-medium text-fg">
        {label}
      </label>
      <input
        id={id}
        name={id}
        type="password"
        autoComplete={autoComplete}
        required
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-9 rounded-lg border border-border bg-background px-3 text-sm text-fg outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50"
      />
      {hint ? <p className="text-xs text-fg-subtle">{hint}</p> : null}
    </div>
  );
}
