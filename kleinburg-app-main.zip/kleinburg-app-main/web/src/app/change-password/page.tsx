import { getTranslations } from "next-intl/server";
import Link from "next/link";
import { redirect } from "next/navigation";

import { LocaleSwitcher } from "@/components/locale-switcher";
import { LogoutButton } from "@/components/logout-button";
import { getCurrentUser } from "@/lib/auth-server";
import { ChangePasswordForm } from "./change-password-form";

/**
 * /change-password — where the first-login forced change happens (T40).
 *
 * Deliberately OUTSIDE the (app) route group: that group's layout redirects
 * here, so a page inside it would redirect to itself forever. It carries its
 * own auth guard instead.
 *
 * Reachable voluntarily too, not only when forced. Blocking the non-forced case
 * would be more code for less: the endpoint already demands the current
 * password, so letting anyone rotate their own is strictly good.
 *
 * ── WHY THE USERNAME AND THE SIGN-OUT BUTTON ARE HERE ────────────────────
 * #40 review, finding 2. Being outside the (app) group also means being
 * outside its chrome, and this page shipped with neither. A user who mistyped
 * the temporary password had no way out: the form was the only control, the
 * page never said which account it was for, and the (app) layout redirected
 * them straight back here from anywhere else. Clearing cookies by hand was the
 * only escape. The username answers "am I even the right user?" and sign-out
 * answers "then let me start again", which together are the whole recovery
 * path when the admin has to re-issue the password.
 */
export default async function ChangePasswordPage() {
  const t = await getTranslations("changePassword");
  const tAccount = await getTranslations("account");
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  return (
    <main className="mx-auto flex min-h-screen max-w-sm flex-col justify-center gap-8 px-6 py-16">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-fg">
            {t("title")}
          </h1>
          <p className="mt-2 text-sm text-fg-muted">
            {user.mustChangePassword ? t("forcedSubtitle") : t("subtitle")}
          </p>
        </div>
        <LocaleSwitcher />
      </div>
      <ChangePasswordForm />

      <div className="flex flex-col gap-3 border-t border-border pt-6">
        <p className="text-sm text-fg-muted">
          {t("signedInAs", { username: user.username })}
        </p>
        {/* T43: the account area sends people here voluntarily, so the
            VOLUNTARY case needs a way back. Hidden while the change is
            forced — the (app) layout would bounce them straight back here,
            and offering an exit that cannot work is worse than none. */}
        {user.mustChangePassword ? null : (
          <Link
            href="/account"
            className="text-sm text-fg-muted transition-colors hover:text-fg"
          >
            {tAccount("backToAccount")}
          </Link>
        )}
        <LogoutButton />
      </div>
    </main>
  );
}
