"use server";

import { cookies } from "next/headers";

import { setAccountLocale } from "@/core/account/service";
import { getCurrentUser } from "@/lib/auth-server";
import {
  LOCALE_COOKIE,
  LOCALE_COOKIE_MAX_AGE,
  resolveLocale,
} from "./locales";

/** What the switcher learns about a language change. */
export type SetLocaleResult =
  | { ok: true }
  | { ok: false; reason: "PREFERENCE_WRITE_FAILED" };

/**
 * Persists the interface language (T25, extended by T43).
 *
 * ── WHY IT WRITES BOTH PLACES ────────────────────────────────────────────
 * T25 stored one cookie. T43 adds an account column so the choice survives a
 * device change, and the switcher now writes BOTH:
 *
 *  - the ACCOUNT, when signed in, because that is the copy that travels;
 *  - the COOKIE, always, because it is the only copy a signed-out visitor has.
 *
 * Writing both is what keeps the precedence rule (account beats cookie) from
 * ever being visible as a surprise. The two only disagree when ANOTHER device
 * changed the account, and resolving that in the account's favour is exactly
 * the requested behaviour. Keeping the cookie warm also means the login page
 * after a sign-out still greets the user in the language they were just using.
 *
 * ── WHY THE ACCOUNT IS WRITTEN FIRST (#43 review, finding 1) ─────────────
 * This function originally set the cookie and then wrote the account
 * best-effort, on the grounds that "the cookie has already taken effect, so
 * the user sees the language they asked for". T43 INVERTED that reasoning in
 * the same commit by making the account beat the cookie
 * (`resolveEffectiveLocale`). With that precedence, a user whose account says
 * `tr` who clicks EN and whose account write fails gets a cookie saying `en`,
 * an account still saying `tr` — and `tr` wins. The interface does not change,
 * `router.refresh()` re-renders in Turkish, and nothing explains why.
 *
 * So the AUTHORITATIVE copy goes first and the cookie only follows a success.
 * A failure leaves both copies on the old language — consistent, not half
 * applied — and is reported to the caller, which surfaces it (hard rule 5:
 * this swallow had no fallback and lost real user intent, unlike
 * `readAccountLocale`, where the cookie genuinely answers the question).
 *
 * The value is narrowed through resolveLocale, so a hand-crafted request can
 * never write an arbitrary string into the cookie or the column.
 */
export async function setLocale(value: string): Promise<SetLocaleResult> {
  const locale = resolveLocale(value);

  const user = await getCurrentUser();
  if (user) {
    try {
      await setAccountLocale(user.id, locale);
    } catch (e) {
      // Loud on the server, visible in the UI. The locale itself is safe to
      // log (it is one of two constants); the user id names whose preference
      // was lost without quoting anything they typed.
      console.error(
        `[i18n] account locale write FAILED userId=${user.id} locale=${locale} -> ${
          e instanceof Error ? e.message : String(e)
        }. Cookie deliberately NOT written: the account preference wins, so a ` +
          `cookie-only write would look like the click did nothing.`,
      );
      return { ok: false, reason: "PREFERENCE_WRITE_FAILED" };
    }
  }

  const store = await cookies();
  store.set(LOCALE_COOKIE, locale, {
    path: "/",
    maxAge: LOCALE_COOKIE_MAX_AGE,
    sameSite: "lax",
    // Readable by the server only; nothing client-side needs to read it back
    // (the active locale reaches the client through NextIntlClientProvider).
    httpOnly: true,
  });

  return { ok: true };
}
