/**
 * The UI-locale vocabulary, re-exported from core.
 *
 * ── WHY THE DEFINITION MOVED (T43) ───────────────────────────────────────
 * The locale is now also an ACCOUNT field, so core/account/service.ts has to
 * validate it — and core may not depend on anything outside core. The
 * definitions therefore live in `core/i18n/locales.ts` and this module stays
 * as the import path every UI-side caller (middleware, request config, the
 * switcher, the login screen) already uses.
 *
 * Nothing was renamed and no behaviour changed: this is a direction-of-
 * dependency fix, not a rewrite.
 */
export {
  DEFAULT_LOCALE,
  LOCALES,
  LOCALE_COOKIE,
  LOCALE_COOKIE_MAX_AGE,
  isLocale,
  resolveEffectiveLocale,
  resolveLocale,
  type Locale,
} from "@/core/i18n/locales";
