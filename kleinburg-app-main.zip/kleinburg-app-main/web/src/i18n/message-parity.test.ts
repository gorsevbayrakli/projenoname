import fs from "node:fs";
import path from "node:path";

import { describe, expect, it } from "vitest";

import { LOCALES } from "@/core/i18n/locales";

const MESSAGES_DIR = path.join(process.cwd(), "messages");

function flatten(obj: unknown, prefix = ""): string[] {
  if (obj === null || typeof obj !== "object") return [prefix];
  return Object.entries(obj as Record<string, unknown>).flatMap(([k, v]) =>
    flatten(v, prefix ? `${prefix}.${k}` : k),
  );
}

function keysOf(file: string): Set<string> {
  const raw = fs.readFileSync(path.join(MESSAGES_DIR, file), "utf8");
  return new Set(flatten(JSON.parse(raw)));
}

const files = fs
  .readdirSync(MESSAGES_DIR)
  .filter((f) => f.endsWith(".json"))
  .sort();
const reference = keysOf("tr.json");

describe("message catalog parity", () => {
  for (const file of files) {
    it(`${file} has exactly the tr.json key set`, () => {
      const keys = keysOf(file);
      const missing = [...reference].filter((k) => !keys.has(k)).sort();
      const extra = [...keys].filter((k) => !reference.has(k)).sort();
      expect({ missing, extra }).toEqual({ missing: [], extra: [] });
    });
  }

  it("LOCALES and message files correspond one-to-one", () => {
    const fileLocales = new Set(files.map((f) => f.replace(/\.json$/, "")));
    const localesWithoutFile = [...LOCALES].filter((l) => !fileLocales.has(l));
    const filesWithoutLocale = [...fileLocales].filter(
      (l) => !(LOCALES as readonly string[]).includes(l),
    );
    expect({ localesWithoutFile, filesWithoutLocale }).toEqual({
      localesWithoutFile: [],
      filesWithoutLocale: [],
    });
  });
});
