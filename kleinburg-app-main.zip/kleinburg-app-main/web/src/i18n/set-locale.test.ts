/**
 * The language switch is a TWO-PLACE write, and this file is about what
 * happens when only one of them succeeds (#43 review, finding 1).
 *
 * Since T43 the account preference BEATS the cookie (resolveEffectiveLocale).
 * That inverted the old "cookie first, account best-effort" reasoning: if the
 * cookie is written and the account write then fails, the account still holds
 * the OLD locale, so the account still wins and the interface does not change.
 * The user clicks EN, sees Turkish, and is told nothing.
 *
 * So the order and the failure contract are load-bearing, and both are asserted
 * here: the authoritative copy is written FIRST, the cookie only follows a
 * success, and a failure is reported back to the caller instead of swallowed.
 */
import { beforeEach, describe, expect, it, vi } from "vitest";

const cookieSet = vi.fn();
vi.mock("next/headers", () => ({
  cookies: async () => ({ set: cookieSet }),
}));

const getCurrentUser = vi.fn();
vi.mock("@/lib/auth-server", () => ({
  getCurrentUser: () => getCurrentUser(),
}));

const setAccountLocale = vi.fn();
vi.mock("@/core/account/service", () => ({
  setAccountLocale: (userId: string, locale: string | null) =>
    setAccountLocale(userId, locale),
}));

const { setLocale } = await import("./set-locale");

beforeEach(() => {
  vi.clearAllMocks();
  getCurrentUser.mockResolvedValue(null);
  setAccountLocale.mockResolvedValue(undefined);
});

describe("setLocale", () => {
  it("writes only the cookie for a signed-out visitor, and reports success", async () => {
    // The login page renders before anyone is authenticated: there is no
    // account to write, and that is not a failure.
    const result = await setLocale("en");

    expect(result).toEqual({ ok: true });
    expect(setAccountLocale).not.toHaveBeenCalled();
    expect(cookieSet).toHaveBeenCalledWith(
      "kb_locale",
      "en",
      expect.objectContaining({ path: "/", httpOnly: true }),
    );
  });

  it("writes the account preference and the cookie when signed in", async () => {
    getCurrentUser.mockResolvedValue({ id: "user-1" });

    const result = await setLocale("en");

    expect(result).toEqual({ ok: true });
    expect(setAccountLocale).toHaveBeenCalledWith("user-1", "en");
    expect(cookieSet).toHaveBeenCalledOnce();
  });

  it("reports failure and leaves the cookie alone when the account write fails", async () => {
    // THE FINDING. The account keeps its old locale, so writing the cookie
    // anyway would produce a device whose cookie says EN, whose interface is
    // still Turkish, and whose user was told nothing. Not writing it keeps the
    // two copies in agreement; the returned failure is what reaches the user.
    getCurrentUser.mockResolvedValue({ id: "user-1" });
    setAccountLocale.mockRejectedValue(new Error("connection terminated"));
    const consoleError = vi.spyOn(console, "error").mockImplementation(() => {});

    const result = await setLocale("en");

    expect(result).toEqual({ ok: false, reason: "PREFERENCE_WRITE_FAILED" });
    expect(cookieSet).not.toHaveBeenCalled();
    // Hard rule 5: not silent on the server either.
    expect(consoleError).toHaveBeenCalledOnce();
    consoleError.mockRestore();
  });

  it("narrows an unsupported value instead of writing it", async () => {
    const result = await setLocale("zz");

    expect(result).toEqual({ ok: true });
    expect(cookieSet).toHaveBeenCalledWith(
      "kb_locale",
      "tr",
      expect.anything(),
    );
  });
});
