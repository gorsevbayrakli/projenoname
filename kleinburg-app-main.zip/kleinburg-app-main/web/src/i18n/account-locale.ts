import { getCurrentUser } from "@/lib/auth-server";

/**
 * The signed-in user's stored interface-language preference, or null (T43).
 *
 * Split into its own module so `request.ts` stays readable and so the two
 * rules below are stated once, in the place that enforces them:
 *
 * 1. NEVER THROWS. This runs inside next-intl's request config, on every
 *    render, including error pages. A database hiccup must degrade the
 *    language to the cookie's answer, not blank the application — nobody
 *    should see a stack trace because a preference lookup timed out. This is
 *    the one place a swallowed error is correct rather than hard-rule-5
 *    silence: the failure has a real fallback and no user intent is lost.
 *
 * 2. NO SESSION, NO QUERY. `getCurrentUser` returns null without touching the
 *    database when the session cookie is absent, which is the signed-out case
 *    — the login page keeps its pure cookie path and pays nothing.
 */
export async function readAccountLocale(): Promise<string | null> {
  try {
    const user = await getCurrentUser();
    return user?.uiLocale ?? null;
  } catch {
    return null;
  }
}
