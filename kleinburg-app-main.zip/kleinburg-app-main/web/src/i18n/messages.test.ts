import { describe, expect, it } from "vitest";

import de from "../../messages/de.json";
import en from "../../messages/en.json";
import es from "../../messages/es.json";
import fr from "../../messages/fr.json";
// Aliased: a bare `it` import shadows Vitest's `it` test function.
import itMessages from "../../messages/it.json";
import tr from "../../messages/tr.json";
import { API_ERROR_CODES } from "@/core/errors/codes";
import { AUDIT_ACTIONS, workflowStep } from "@/core/db/schema";
import { LOCALES } from "./locales";
import { WIZARD_STEPS } from "@/lib/workflow-steps";

/**
 * The practical guard against a half-translated UI (T25): a key added to one
 * catalog and forgotten in the other fails here rather than rendering a raw
 * key path (or throwing) in front of a user.
 *
 * It also checks for EMPTY values, because an empty string is the other way a
 * "translated" key silently shows nothing.
 */

type Json = Record<string, unknown>;

/** Every leaf key path in a nested message object, dot-joined and sorted. */
function keyPaths(obj: Json, prefix = ""): string[] {
  const out: string[] = [];
  for (const [key, value] of Object.entries(obj)) {
    const path = prefix ? `${prefix}.${key}` : key;
    if (value !== null && typeof value === "object" && !Array.isArray(value)) {
      out.push(...keyPaths(value as Json, path));
    } else {
      out.push(path);
    }
  }
  return out.sort();
}

/** The leaf value at a dot path, or undefined. */
function valueAt(obj: Json, path: string): unknown {
  return path
    .split(".")
    .reduce<unknown>(
      (acc, part) =>
        acc && typeof acc === "object"
          ? (acc as Json)[part]
          : undefined,
      obj,
    );
}

const catalogs: Record<string, Json> = { tr, en, fr, it: itMessages, es, de };

describe("message catalogs", () => {
  it("ships a catalog for every supported locale", () => {
    expect(Object.keys(catalogs).sort()).toEqual([...LOCALES].sort());
  });

  it("tr and en have IDENTICAL key sets", () => {
    const trKeys = keyPaths(tr);
    const enKeys = keyPaths(en);

    // Reported as explicit diffs so a failure names the missing keys rather
    // than dumping two large sorted arrays.
    const missingInEn = trKeys.filter((k) => !enKeys.includes(k));
    const missingInTr = enKeys.filter((k) => !trKeys.includes(k));

    expect({ missingInEn, missingInTr }).toEqual({
      missingInEn: [],
      missingInTr: [],
    });
  });

  it("has a non-empty string for every key in every locale", () => {
    for (const [locale, catalog] of Object.entries(catalogs)) {
      for (const path of keyPaths(catalog)) {
        const value = valueAt(catalog, path);
        expect(
          typeof value === "string" && value.trim().length > 0,
          `${locale}.${path} must be a non-empty string`,
        ).toBe(true);
      }
    }
  });

  /**
   * The guard that stops an untranslated API error from shipping: every code
   * the API can emit must have copy in EVERY catalog. Add a code to
   * core/errors/codes.ts without a catalog entry and this fails here, not in
   * front of a user reading Turkish in an English UI.
   */
  it("has apiErrors copy for every emitted error code in every locale", () => {
    for (const [locale, catalog] of Object.entries(catalogs)) {
      for (const code of API_ERROR_CODES) {
        const value = valueAt(catalog, `apiErrors.${code}`);
        expect(
          typeof value === "string" && value.trim().length > 0,
          `${locale}.apiErrors.${code} is missing`,
        ).toBe(true);
      }
    }
  });

  /**
   * #40 review, finding 6. The server's message names the required length;
   * the client's must too, or the user is told their password is wrong
   * without being told what would be right. The placeholder is filled from
   * MIN_PASSWORD_LENGTH by `lib/api-error-copy.ts`, so a catalog that drops it
   * silently loses the number — this is what catches that.
   */
  it("keeps the {min} placeholder in PASSWORD_TOO_SHORT in every locale", () => {
    for (const [locale, catalog] of Object.entries(catalogs)) {
      expect(
        valueAt(catalog, "apiErrors.PASSWORD_TOO_SHORT"),
        `${locale}.apiErrors.PASSWORD_TOO_SHORT must state the minimum length`,
      ).toContain("{min}");
    }
  });

  it("has no apiErrors copy for a code the API cannot emit", () => {
    for (const [locale, catalog] of Object.entries(catalogs)) {
      const declared = Object.keys(
        (catalog.apiErrors ?? {}) as Record<string, unknown>,
      ).sort();
      expect(declared, `${locale} has stale apiErrors keys`).toEqual(
        [...API_ERROR_CODES].sort(),
      );
    }
  });

  /**
   * T27. Every step where the user contributes something (uploads, types, or
   * curates) must say what to contribute, not only what the step produces.
   * The first live run was wasted because step 4 explained the second and left
   * the first to inference, and the user reasonably wrote a campaign goal where
   * the prompt expected a subject.
   *
   * Generative-only steps are excluded on purpose: the user supplies nothing.
   */
  const STEPS_TAKING_USER_INPUT = [
    "documents",
    "secondaryData",
    "userInput",
    "creativeSparks",
    "smPillars",
  ];

  it("tells the user what to contribute on every step that takes input", () => {
    for (const [locale, catalog] of Object.entries(catalogs)) {
      for (const step of STEPS_TAKING_USER_INPUT) {
        const value = valueAt(catalog, `steps.${step}.inputHint`);
        expect(
          typeof value === "string" && value.length > 0,
          `${locale}.steps.${step}.inputHint is missing`,
        ).toBe(true);
      }
    }
  });

  it("shows a worked example on the step that sets the sparks subject", () => {
    // Step 4 is the one that failed. A rule alone did not prove enough there:
    // the example is what makes "a subject, not a goal" unmistakable.
    for (const [locale, catalog] of Object.entries(catalogs)) {
      for (const key of ["example", "exampleLabel"]) {
        const value = valueAt(catalog, `steps.userInput.${key}`);
        expect(
          typeof value === "string" && value.length > 0,
          `${locale}.steps.userInput.${key} is missing`,
        ).toBe(true);
      }
    }
  });

  /**
   * T45. The login page's product description is the first sentence anybody
   * reads about this app, and it is the product owner's to write (approved by
   * Elif on 2026-07-20). It lives in the catalogs like any other string, so
   * rewording it stays a one-line edit per locale rather than a code change —
   * which is the property that let it ship as a marked draft and be approved
   * later without touching a component.
   */
  it("carries the product description in every catalog", () => {
    for (const [locale, catalog] of Object.entries(catalogs)) {
      const value = valueAt(catalog, "auth.productDescription");
      expect(
        typeof value === "string" && value.trim().length > 0,
        `${locale}.auth.productDescription is missing — the login page renders it`,
      ).toBe(true);
    }
  });

  /**
   * T41. Same guard as `apiErrors`, for the audit trail: the /activity page
   * renders `auditActions.<ACTION>` for every action it can show, and a
   * missing key throws in next-intl rather than degrading. Adding an action to
   * `AUDIT_ACTIONS` without catalog copy must fail here, not on the page an
   * admin opens during a security review.
   *
   * Checked in BOTH directions, so a stale key left behind by a removed action
   * is caught too — the enum is a migration, and a catalog that still names a
   * dropped action misleads whoever reads it next.
   */
  it("has a label for every audit action in every locale", () => {
    for (const [locale, catalog] of Object.entries(catalogs)) {
      const declared = Object.keys(
        (catalog.auditActions ?? {}) as Record<string, unknown>,
      ).sort();
      expect(declared, `${locale} auditActions is out of sync`).toEqual(
        [...AUDIT_ACTIONS].sort(),
      );

      for (const action of AUDIT_ACTIONS) {
        const value = valueAt(catalog, `auditActions.${action}`);
        expect(
          typeof value === "string" && value.trim().length > 0,
          `${locale}.auditActions.${action} is missing`,
        ).toBe(true);
      }
    }
  });

  it("defines a label for all 8 wizard steps in every locale", () => {
    for (const [locale, catalog] of Object.entries(catalogs)) {
      for (const step of WIZARD_STEPS) {
        const value = valueAt(catalog, `stepLabels.${step.key}`);
        expect(
          typeof value === "string" && value.length > 0,
          `${locale}.stepLabels.${step.key} is missing`,
        ).toBe(true);
      }
    }
  });

  /**
   * #42. The 8 wizard steps above are the NAVIGATION; `workflow_step` is the
   * database enum, and it also carries values that are not wizard steps
   * (`platform_cadence`). /spend renders `stepLabels.<step>` for whatever the
   * per-step breakdown returns, and next-intl THROWS on a missing key — so an
   * enum value added without catalog copy takes the page down rather than
   * degrading. That is exactly how the cadence step could have shipped.
   */
  it("has a label for every workflow_step the spend breakdown can return", () => {
    for (const [locale, catalog] of Object.entries(catalogs)) {
      for (const step of workflowStep.enumValues) {
        const value = valueAt(catalog, `stepLabels.${step}`);
        expect(
          typeof value === "string" && value.trim().length > 0,
          `${locale}.stepLabels.${step} is missing — /spend renders it`,
        ).toBe(true);
      }
    }
  });
});
