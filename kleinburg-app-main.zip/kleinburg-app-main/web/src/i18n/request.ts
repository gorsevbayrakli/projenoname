import { cookies } from "next/headers";
import { getRequestConfig } from "next-intl/server";

import { APP_TIMEZONE } from "@/core/i18n/timezone";
import { LOCALE_COOKIE, resolveEffectiveLocale } from "./locales";
import { readAccountLocale } from "./account-locale";

/**
 * next-intl request config, "without i18n routing" flavour.
 *
 * The locale comes from the `kb_locale` COOKIE and, since T43, from the signed-
 * in user's account preference. Neither comes from a URL prefix. Reasons (T25
 * decision): the login page must be translatable before a user exists, and
 * prefixed routing would mean rewriting every route, every Link href and the
 * auth middleware for zero user-visible gain in an internal tool.
 *
 * PRECEDENCE (T43): account preference > cookie > `tr`. The full reasoning is
 * on resolveEffectiveLocale. The cookie path is untouched for signed-out
 * visitors, which is what keeps the login page translatable.
 *
 * An unknown/missing value on both sides falls back to `tr`, so existing users
 * see exactly the interface they had before.
 *
 * TIMEZONE (#58). Explicit, not inherited. With no `timeZone` next-intl falls
 * back to the process zone, which on Render is UTC because render.yaml sets no
 * TZ — and the client provider is handed that same resolved zone, so the
 * browser never corrects it. Every `{…, date, …}` placeholder in the catalogs
 * was therefore rendered on a UTC calendar for users reading an Istanbul one.
 * The spend-cap refusal is where it hurt: it prints `month.until`, which is
 * local midnight on the 1st (21:00Z on the last day of the month), so the
 * refusal named the reset a day early every single month. Pinning the zone to
 * `APP_TIMEZONE` — the same constant the cap boundary is drawn in — makes the
 * printed date and the boundary it describes the same day by construction.
 */
export default getRequestConfig(async () => {
  const store = await cookies();
  const cookieLocale = store.get(LOCALE_COOKIE)?.value;
  const accountLocale = await readAccountLocale();

  const locale = resolveEffectiveLocale({ accountLocale, cookieLocale });

  return {
    locale,
    timeZone: APP_TIMEZONE,
    messages: (await import(`../../messages/${locale}.json`)).default,
  };
});
