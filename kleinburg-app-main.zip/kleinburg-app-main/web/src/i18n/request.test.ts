import { createTranslator } from "next-intl";
import { describe, expect, it, vi } from "vitest";

import { spendMonthOf } from "@/core/llm/cap";
import { withTimeZone } from "@/test/with-timezone";

// The request config runs inside a Next request; neither the cookie store nor
// the account lookup is what this file is about, so both are stubbed to the
// signed-out path (no cookie, no account preference => the `tr` default).
vi.mock("next/headers", () => ({
  cookies: async () => ({ get: () => undefined }),
}));
vi.mock("./account-locale", () => ({
  readAccountLocale: async () => null,
}));
// Vitest resolves `next-intl/server` to the react-client build, which refuses
// to run `getRequestConfig` outside a server component. The react-server build
// it stands in for is the identity function — it exists purely to type the
// callback (see next-intl's getRequestConfig.js: `return createRequestConfig`)
// — so this substitutes the same behaviour without switching the whole suite
// to the react-server export condition. What is under test is our callback's
// return value, which the mock does not touch.
vi.mock("next-intl/server", () => ({
  getRequestConfig: <T>(createRequestConfig: T) => createRequestConfig,
}));

const { default: getConfig } = await import("./request");

const config = () => getConfig({ requestLocale: Promise.resolve(undefined) });

/**
 * #58. `getRequestConfig` returned only { locale, messages }, so next-intl fell
 * back to the process zone for every `{…, date, …}` placeholder in the
 * catalogs — UTC on Render, which sets no TZ — and the client provider
 * inherited that same resolved zone, so the browser never rescued it.
 *
 * The cap refusal is where that showed: `capRefusalDetails` sends
 * `month.until`, which is local midnight on the 1st in Istanbul, i.e. 21:00Z
 * on the last day of the month. Rendered in UTC it names the previous day, so
 * an operator waiting for the reset waited a day too long and found generation
 * still blocked with no explanation.
 */
describe("i18n request config", () => {
  it("pins an explicit timeZone", async () => {
    expect((await config()).timeZone).toBe("Europe/Istanbul");
  });

  it("renders the cap reset on the day the cap actually resets", async () => {
    const { locale, messages, timeZone } = await config();
    // next-intl types `messages` as optionally absent; the catalog IS the
    // subject here, so an empty one must fail loudly rather than render "".
    if (!messages) throw new Error("request config returned no messages");

    // Not a hand-written fixture: the instant comes from the cap module that
    // produces it in production. Any August instant yields the same boundary,
    // 2026-08-31T21:00:00Z — a Z-time on the 31st that is the 1st in Istanbul,
    // which is exactly the case a Z-midnight fixture cannot exercise.
    const resetsAt = spendMonthOf(new Date("2026-08-15T12:00:00.000Z")).until;
    expect(resetsAt.toISOString()).toBe("2026-08-31T21:00:00.000Z");

    // Pinned to UTC because that is what Render runs; without the config's
    // timeZone the translator would resolve the zone from here.
    const rendered = withTimeZone("UTC", () => {
      const t = createTranslator({
        locale,
        messages,
        timeZone,
        namespace: "apiErrors",
      });
      return t("SPEND_CAP_EXCEEDED", {
        brand: "Kleinburg",
        cap: "$50.00",
        spent: "$50.12",
        estimatedCalls: 0,
        measured: "$50.12",
        estimated: "$0.00",
        resetsAt,
      });
    });

    expect(rendered).toContain("1 Eylül 2026");
    expect(rendered).not.toContain("31 Ağustos 2026");
  });
});
