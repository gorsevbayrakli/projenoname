/**
 * T43 — "the user's own projects" is a SCOPED query.
 *
 * The account area shows a recent-work list. Hard rule 2 says a user must never
 * learn that a project or a brand they cannot access exists. These tests are the
 * proof: every one of them asserts an ABSENCE, because the failure mode here is
 * a leak, not a missing row.
 *
 * The sharpest case is `createdBy`: authorship is NOT access. A user who built a
 * project and later lost the brand grant must stop seeing it, and the project
 * name (often a client's name) must not survive in their list.
 */
import { randomUUID } from "node:crypto";
import { and, eq, inArray } from "drizzle-orm";
import { afterAll, beforeAll, describe, expect, it } from "vitest";

import { closeDb, getDb } from "../db/client";
import { brands, projects, userBrands, users } from "../db/schema";
import { hasDb } from "@/test/db-gate";
import { listRecentProjects } from "./projects";

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

async function makeUser(): Promise<string> {
  const db = getDb();
  const [row] = await db
    .insert(users)
    .values({ username: `t43-${randomUUID()}`, passwordHash: "x" })
    .returning();
  createdUserIds.push(row.id);
  return row.id;
}

async function makeBrand(opts: { isActive?: boolean } = {}): Promise<string> {
  const db = getDb();
  const [row] = await db
    .insert(brands)
    .values({ name: `t43-brand-${randomUUID()}`, isActive: opts.isActive ?? true })
    .returning();
  createdBrandIds.push(row.id);
  return row.id;
}

async function grant(userId: string, brandId: string): Promise<void> {
  await getDb().insert(userBrands).values({ userId, brandId });
}

async function revoke(userId: string, brandId: string): Promise<void> {
  await getDb()
    .delete(userBrands)
    .where(and(eq(userBrands.userId, userId), eq(userBrands.brandId, brandId)));
}

async function makeProject(brandId: string, createdBy: string): Promise<string> {
  const db = getDb();
  const [row] = await db
    .insert(projects)
    .values({ brandId, name: `t43-proj-${randomUUID()}`, createdBy })
    .returning();
  return row.id;
}

describe.skipIf(!hasDb)("tenancy/listRecentProjects", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      // Cascades to user_brands and projects.
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("returns projects from granted, active brands with their brand name", async () => {
    const userId = await makeUser();
    const brandId = await makeBrand();
    await grant(userId, brandId);
    const projectId = await makeProject(brandId, userId);

    const recent = await listRecentProjects(userId);

    expect(recent.map((p) => p.id)).toContain(projectId);
    const row = recent.find((p) => p.id === projectId);
    expect(row?.brandId).toBe(brandId);
    expect(typeof row?.brandName).toBe("string");
  });

  it("never returns a project from a brand the user was not granted", async () => {
    const mine = await makeUser();
    const stranger = await makeUser();
    const myBrand = await makeBrand();
    const otherBrand = await makeBrand();
    await grant(mine, myBrand);
    await grant(stranger, otherBrand);
    await makeProject(myBrand, mine);
    const secretId = await makeProject(otherBrand, stranger);

    const recent = await listRecentProjects(mine);

    expect(recent.map((p) => p.id)).not.toContain(secretId);
    expect(recent.map((p) => p.brandId)).not.toContain(otherBrand);
  });

  it("does not leak a project the user CREATED after their grant is revoked", async () => {
    // Authorship is not access. This is the case a `createdBy = me` query,
    // the obvious way to write "my projects", would get wrong.
    //
    // The user KEEPS a second, unrelated grant on purpose. With no grants left
    // the function short-circuits to [] and would pass this test even if the
    // scoping were authorship-based — the bug would hide behind the empty case.
    const userId = await makeUser();
    const keptBrandId = await makeBrand();
    const lostBrandId = await makeBrand();
    await grant(userId, keptBrandId);
    await grant(userId, lostBrandId);
    const projectId = await makeProject(lostBrandId, userId);
    await makeProject(keptBrandId, userId);

    expect((await listRecentProjects(userId)).map((p) => p.id)).toContain(
      projectId,
    );

    await revoke(userId, lostBrandId);

    const after = await listRecentProjects(userId);
    expect(after.map((p) => p.id)).not.toContain(projectId);
    expect(after.map((p) => p.brandId)).not.toContain(lostBrandId);
    // Still returning rows, so the absence above is scoping and not emptiness.
    expect(after.length).toBeGreaterThan(0);
  });

  it("shows a TEAMMATE's project in a brand the user shares", async () => {
    // The other half of "access, not authorship". A `created_by = me` query
    // would silently hide every colleague's work in a brand the user shares,
    // which is the whole point of a shared brand.
    const me = await makeUser();
    const teammate = await makeUser();
    const brandId = await makeBrand();
    await grant(me, brandId);
    await grant(teammate, brandId);
    const theirProject = await makeProject(brandId, teammate);

    expect((await listRecentProjects(me)).map((p) => p.id)).toContain(
      theirProject,
    );
  });

  it("hides projects of a deactivated brand even while the grant stands", async () => {
    const userId = await makeUser();
    const brandId = await makeBrand({ isActive: false });
    await grant(userId, brandId);
    const projectId = await makeProject(brandId, userId);

    const recent = await listRecentProjects(userId);

    expect(recent.map((p) => p.id)).not.toContain(projectId);
  });

  it("returns nothing at all for a user with no brand grants", async () => {
    const userId = await makeUser();
    const brandId = await makeBrand();
    const otherUser = await makeUser();
    await grant(otherUser, brandId);
    await makeProject(brandId, otherUser);

    expect(await listRecentProjects(userId)).toEqual([]);
  });

  it("orders newest-updated first and honours the limit", async () => {
    const userId = await makeUser();
    const brandId = await makeBrand();
    await grant(userId, brandId);
    const first = await makeProject(brandId, userId);
    const second = await makeProject(brandId, userId);
    const third = await makeProject(brandId, userId);

    const all = await listRecentProjects(userId);
    const mine = all.filter((p) => [first, second, third].includes(p.id));
    expect(mine.map((p) => p.id)).toEqual([third, second, first]);

    const limited = await listRecentProjects(userId, 2);
    expect(limited).toHaveLength(2);
    expect(limited[0].id).toBe(third);
  });
});
