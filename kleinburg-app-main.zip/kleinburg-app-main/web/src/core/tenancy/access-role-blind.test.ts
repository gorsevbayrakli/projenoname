import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

/**
 * The structural guarantee behind T50, asserted against the SOURCE rather than
 * against behaviour, because behaviour cannot distinguish "there is no role
 * exception" from "there is one that today's tests happen to miss".
 *
 * `core/tenancy/access.ts` is the common door for every project-scoped read in
 * the product. T50 granted an admin permission over SPEND; putting that
 * permission in the door would have handed it to every present and future
 * caller of the door as well. So the door stays role-blind, and this test is
 * what keeps it that way after everyone has forgotten why.
 *
 * IT LIVES HERE, IN ITS OWN UNGATED FILE, ON PURPOSE. It used to sit inside
 * `admin-spend.test.ts`'s `describe.skipIf(!hasDb)`, which meant the guard was
 * absent from a plain `npm test` and would only have caught a role exception
 * added to the brand-isolation door if whoever added it happened to have
 * Postgres running. It reads one file off disk and touches no database, so
 * nothing about it ever needed the gate. `core/llm/every-call-recorded.test.ts`
 * is the sibling source-scan guard and is ungated for the same reason.
 */

const ACCESS_TS = fileURLToPath(new URL("./access.ts", import.meta.url));

describe("tenancy/access is role-blind", () => {
  it("reads the real access.ts, so a green run cannot be vacuous", () => {
    // Without this the assertions below pass trivially the day the file is
    // renamed or moved — the failure mode this project has already paid for
    // three times.
    const source = readFileSync(ACCESS_TS, "utf8");
    expect(source).toMatch(/export\s+(async\s+)?function\s+\w/);
  });

  it("core/tenancy/access.ts still contains zero role exceptions", () => {
    const source = readFileSync(ACCESS_TS, "utf8");
    // Strip comments: prose about roles is fine, CODE about roles is not.
    const code = source
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .replace(/\/\/.*$/gm, "");

    expect(code).not.toMatch(/isSuperAdmin/);
    expect(code).not.toMatch(/requireSuperAdmin/);
    expect(code).not.toMatch(/["']admin["']/);
    expect(code).not.toMatch(/\brole\b/);
  });
});
