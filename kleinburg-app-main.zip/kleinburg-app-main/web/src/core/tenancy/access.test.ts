import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import { brands, projects, userBrands, users } from "../db/schema";
import {
  listAccessibleBrands,
  requireBrandAccess,
  requireProjectAccess,
  userCanAccessBrand,
} from "./access";
import { AccessError, NotFoundError } from "./errors";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

async function makeUser() {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({
      username: `t7-${randomUUID()}`,
      passwordHash: "x",
    })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

async function makeBrand(opts: { isActive?: boolean } = {}) {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: `brand-${randomUUID()}`, isActive: opts.isActive ?? true })
    .returning();
  createdBrandIds.push(brand.id);
  return brand;
}

async function grant(userId: string, brandId: string) {
  const db = getDb();
  await db.insert(userBrands).values({ userId, brandId });
}

async function makeProject(brandId: string, createdBy: string) {
  const db = getDb();
  const [project] = await db
    .insert(projects)
    .values({ brandId, name: `proj-${randomUUID()}`, createdBy })
    .returning();
  return project;
}

describe.skipIf(!hasDb)("tenancy/access", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      // Deleting brands cascades to user_brands and projects.
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("listAccessibleBrands returns only granted, active brands", async () => {
    const userA = await makeUser();
    const brand1 = await makeBrand();
    const brand2 = await makeBrand();
    const inactive = await makeBrand({ isActive: false });
    await grant(userA.id, brand1.id);
    await grant(userA.id, inactive.id); // granted but inactive -> excluded

    const list = await listAccessibleBrands(userA.id);
    const ids = list.map((b) => b.id);
    expect(ids).toContain(brand1.id);
    expect(ids).not.toContain(brand2.id);
    expect(ids).not.toContain(inactive.id);
  });

  it("userCanAccessBrand reflects grants and brand state", async () => {
    const userA = await makeUser();
    const userB = await makeUser();
    const brand1 = await makeBrand();
    const brand2 = await makeBrand();
    await grant(userA.id, brand1.id);

    expect(await userCanAccessBrand(userA.id, brand1.id)).toBe(true);
    expect(await userCanAccessBrand(userA.id, brand2.id)).toBe(false);
    expect(await userCanAccessBrand(userB.id, brand1.id)).toBe(false);
  });

  it("userCanAccessBrand is false for an inactive granted brand", async () => {
    const userA = await makeUser();
    const inactive = await makeBrand({ isActive: false });
    await grant(userA.id, inactive.id);
    expect(await userCanAccessBrand(userA.id, inactive.id)).toBe(false);
  });

  it("requireProjectAccess resolves for an accessible project", async () => {
    const userA = await makeUser();
    const brand1 = await makeBrand();
    await grant(userA.id, brand1.id);
    const project = await makeProject(brand1.id, userA.id);

    const result = await requireProjectAccess(userA.id, project.id);
    expect(result.project.id).toBe(project.id);
    expect(result.brand.id).toBe(brand1.id);
  });

  it("requireProjectAccess throws AccessError across brand boundaries", async () => {
    const userA = await makeUser();
    const userB = await makeUser();
    const brand2 = await makeBrand();
    await grant(userB.id, brand2.id);
    const project = await makeProject(brand2.id, userB.id);

    await expect(requireProjectAccess(userA.id, project.id)).rejects.toBeInstanceOf(
      AccessError,
    );
  });

  it("requireProjectAccess throws NotFoundError for a missing project", async () => {
    const userA = await makeUser();
    await expect(
      requireProjectAccess(userA.id, randomUUID()),
    ).rejects.toBeInstanceOf(NotFoundError);
  });

  it("requireProjectAccess throws AccessError when the brand is inactive", async () => {
    const userA = await makeUser();
    const brand = await makeBrand();
    await grant(userA.id, brand.id);
    const project = await makeProject(brand.id, userA.id);
    // Deactivate the brand after the fact.
    const db = getDb();
    await db.update(brands).set({ isActive: false }).where(eq(brands.id, brand.id));

    await expect(
      requireProjectAccess(userA.id, project.id),
    ).rejects.toBeInstanceOf(AccessError);
  });

  it("requireBrandAccess returns the brand or throws AccessError", async () => {
    const userA = await makeUser();
    const brand1 = await makeBrand();
    const brand2 = await makeBrand();
    await grant(userA.id, brand1.id);

    const brand = await requireBrandAccess(userA.id, brand1.id);
    expect(brand.id).toBe(brand1.id);

    await expect(requireBrandAccess(userA.id, brand2.id)).rejects.toBeInstanceOf(
      AccessError,
    );
  });
});
