import { desc, eq, inArray } from "drizzle-orm";

import { getDb } from "../db/client";
import { projects, type Project } from "../db/schema";
import { MAX_POST_COUNT, sortPlatforms } from "../platforms";
import {
  listAccessibleBrands,
  requireBrandAccess,
  requireProjectAccess,
} from "./access";
import { ConflictError, ValidationError } from "./errors";

/** The seven supported project languages (mirrors the projectLanguage enum). */
export const PROJECT_LANGUAGES = [
  "en",
  "tr",
  "fr",
  "de",
  "es",
  "it",
  "pt",
] as const;
export type ProjectLanguage = (typeof PROJECT_LANGUAGES)[number];

const DUPLICATE_NAME_MESSAGE = "Bu markada bu isimde bir proje zaten var";

/** Postgres unique_violation SQLSTATE. */
const PG_UNIQUE_VIOLATION = "23505";

/**
 * True if the error is a Postgres unique-constraint violation. Drizzle wraps the
 * underlying pg error, so the SQLSTATE `code` may live on the error itself or on
 * its `cause`.
 */
function isUniqueViolation(err: unknown): boolean {
  const hasCode = (e: unknown): boolean =>
    typeof e === "object" &&
    e !== null &&
    "code" in e &&
    (e as { code?: unknown }).code === PG_UNIQUE_VIOLATION;

  if (hasCode(err)) return true;
  if (err instanceof Error && hasCode(err.cause)) return true;
  return false;
}

/** Rethrow a duplicate-name conflict as ConflictError; propagate anything else. */
function mapUniqueViolation(err: unknown): never {
  if (isUniqueViolation(err)) {
    throw new ConflictError(DUPLICATE_NAME_MESSAGE, "PROJECT_NAME_TAKEN");
  }
  throw err;
}

/** Trim and validate a project name, throwing ValidationError when empty. */
function normalizeName(name: string): string {
  const trimmed = name.trim();
  if (trimmed.length === 0) {
    throw new ValidationError("Proje adı boş olamaz", "PROJECT_NAME_EMPTY");
  }
  return trimmed;
}

function assertLanguage(language: string): asserts language is ProjectLanguage {
  if (!(PROJECT_LANGUAGES as readonly string[]).includes(language)) {
    throw new ValidationError(
      `Geçersiz dil: ${language}`,
      "PROJECT_LANGUAGE_INVALID",
    );
  }
}

/**
 * List projects under a brand the user can access, newest-updated first.
 * Enforces brand access before touching project rows.
 */
export async function listProjects(
  userId: string,
  brandId: string,
): Promise<Project[]> {
  await requireBrandAccess(userId, brandId);
  const db = getDb();
  return db
    .select()
    .from(projects)
    .where(eq(projects.brandId, brandId))
    .orderBy(desc(projects.updatedAt));
}

/** A project row plus the brand it belongs to, for the account area (T43). */
export interface RecentProject {
  id: string;
  name: string;
  brandId: string;
  brandName: string;
  language: ProjectLanguage;
  updatedAt: Date;
}

/** How many rows the account area asks for when the caller does not say. */
export const DEFAULT_RECENT_PROJECT_LIMIT = 8;

/** Upper bound, so a caller cannot turn "recent work" into a full export. */
export const MAX_RECENT_PROJECT_LIMIT = 50;

/**
 * The user's own recent work across every brand they can reach (T43).
 *
 * ── WHY THIS GOES THROUGH listAccessibleBrands ───────────────────────────
 * Hard rule 2. The obvious implementation of "my projects" is
 * `where created_by = me`, and it is WRONG in both directions: it shows
 * projects in brands the user has since lost, and it hides the work of
 * teammates in brands the user legitimately shares. Access is the brand grant,
 * never authorship.
 *
 * It would also be possible to join `user_brands` inline here, but that would
 * be a second copy of the access predicate free to drift from the first. This
 * asks the existing helper what the user may see, then reads only inside that
 * answer — one extra query, no way to disagree with `requireBrandAccess`.
 * An empty answer short-circuits: with no accessible brands there is nothing
 * to scope a project query to, and an unscoped one is the bug.
 */
export async function listRecentProjects(
  userId: string,
  limit: number = DEFAULT_RECENT_PROJECT_LIMIT,
): Promise<RecentProject[]> {
  const accessible = await listAccessibleBrands(userId);
  if (accessible.length === 0) return [];

  const brandNameById = new Map(accessible.map((b) => [b.id, b.name]));
  const capped = Math.min(
    Math.max(Math.trunc(limit), 1),
    MAX_RECENT_PROJECT_LIMIT,
  );

  const db = getDb();
  const rows = await db
    .select()
    .from(projects)
    .where(inArray(projects.brandId, [...brandNameById.keys()]))
    .orderBy(desc(projects.updatedAt))
    .limit(capped);

  return rows.map((project) => ({
    id: project.id,
    name: project.name,
    brandId: project.brandId,
    // Non-null by construction: the query only returned rows whose brandId is
    // a key of this map.
    brandName: brandNameById.get(project.brandId)!,
    language: project.language,
    updatedAt: project.updatedAt,
  }));
}

/**
 * Create a project under a brand the user can access. Rejects empty names and
 * invalid languages; maps the unique(brandId, name) conflict to a clear error.
 */
export async function createProject(
  userId: string,
  brandId: string,
  name: string,
  // Required on purpose. A project's language decides what every generation
  // step writes in and cannot be changed once content exists, so it is the
  // caller's explicit decision, never something this layer guesses.
  language: ProjectLanguage,
): Promise<Project> {
  await requireBrandAccess(userId, brandId);
  const trimmed = normalizeName(name);
  assertLanguage(language);

  const db = getDb();
  try {
    const [project] = await db
      .insert(projects)
      .values({ brandId, name: trimmed, language, createdBy: userId })
      .returning();
    return project;
  } catch (err) {
    mapUniqueViolation(err);
  }
}

/**
 * Rename a project the user can access. updatedAt is bumped automatically via
 * the schema's $onUpdate. Maps the unique(brandId, name) conflict to a clear
 * error.
 */
export async function renameProject(
  userId: string,
  projectId: string,
  newName: string,
): Promise<Project> {
  await requireProjectAccess(userId, projectId);
  const trimmed = normalizeName(newName);

  const db = getDb();
  try {
    const [project] = await db
      .update(projects)
      .set({ name: trimmed })
      .where(eq(projects.id, projectId))
      .returning();
    return project;
  } catch (err) {
    mapUniqueViolation(err);
  }
}

/**
 * Set which platforms a project generates for (T29, wizard step 6).
 *
 * At least one is required: the pillars step is written for a known set of
 * platforms, and an empty set would silently produce platform-agnostic pillars
 * that then have nowhere to go. Unregistered codes are dropped rather than
 * rejected — the stored set is normalised to registry order so callers never
 * have to sort it, and a code that disappears from the registry later must not
 * strand a project it cannot save.
 */
export async function setProjectPlatforms(
  userId: string,
  projectId: string,
  platforms: readonly string[],
  /** Posts per platform (T34). Unlisted platforms keep the registry default. */
  postCounts: Record<string, unknown> = {},
): Promise<Project> {
  await requireProjectAccess(userId, projectId);
  const cleaned = sortPlatforms(platforms);
  if (cleaned.length === 0) {
    throw new ValidationError("En az bir platform seçilmeli", "PROJECT_PLATFORMS_EMPTY");
  }

  // Only counts for chosen platforms are stored, and each must be a whole
  // number of posts within one month. A rejected value is a client bug worth
  // surfacing, not something to silently round.
  const counts: Record<string, number> = {};
  for (const code of cleaned) {
    const raw = postCounts[code];
    if (raw === undefined || raw === null) continue;
    if (
      typeof raw !== "number" ||
      !Number.isInteger(raw) ||
      raw < 1 ||
      raw > MAX_POST_COUNT
    ) {
      throw new ValidationError(
        `Gönderi sayısı 1 ile ${MAX_POST_COUNT} arasında olmalı`,
        "PROJECT_POST_COUNT_INVALID",
      );
    }
    counts[code] = raw;
  }

  const db = getDb();
  const [project] = await db
    .update(projects)
    .set({ platforms: cleaned, postCounts: counts })
    .where(eq(projects.id, projectId))
    .returning();
  return project;
}

/**
 * Delete a project the user can access. Child rows (documents, step_contents,
 * jobs) cascade at the database level once those tables exist.
 *
 * THE CASCADE REACHES MONEY. `generation_jobs` cascades on to `llm_calls`, and
 * `llm_calls` is the spend ledger /spend reads (#42). So deleting a project
 * silently removes real, already-invoiced spend from its brand's total, with no
 * tombstone and no way for any query to notice the gap afterwards — the brand
 * figure simply gets smaller.
 *
 * AND IT REACHES THE CAP, WHICH IS WORSE. Since T51 the monthly cap prices
 * unpriced calls from what this brand's priced calls actually cost. This
 * function needs only `requireProjectAccess` — any ordinary member — so a brand
 * with priced calls in project A and unpriced ones in project B loses every
 * rate it has the moment someone deletes project A. Under the cap's first rule,
 * which refused whenever any call could not be priced, that refused EVERY
 * project in the brand, immediately, clearable only by a super admin: one
 * ordinary user, one ordinary delete, a whole-brand outage.
 *
 * The cap no longer does that — unpriceable calls are held to a bounded worst
 * case and refuse only if even that does not fit under the ceiling
 * (`core/llm/cap.ts`) — so this delete degrades an estimate instead of stopping
 * a brand. The connection is written down here because it is not visible from
 * either side on its own, and because the next thing built on `llm_calls` will
 * inherit it.
 *
 * This is a HARD delete on purpose (T7: no soft-delete anywhere in tenancy) and
 * changing it is a product decision, not a refactor. It is stated here and in
 * the /spend caveat (`spend.deletionNote`) rather than left to be discovered,
 * because the figure it silently changes is the one a spending cap gets set
 * from. If spend ever has to survive deletion, the fix is a retention copy of
 * the aggregate, not loosening the cascade.
 */
export async function deleteProject(
  userId: string,
  projectId: string,
): Promise<void> {
  await requireProjectAccess(userId, projectId);
  const db = getDb();
  await db.delete(projects).where(eq(projects.id, projectId));
}
