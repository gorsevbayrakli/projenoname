import { and, asc, eq } from "drizzle-orm";

import { getDb } from "../db/client";
import {
  brands,
  projects,
  userBrands,
  type Brand,
  type Project,
} from "../db/schema";
import { AccessError, NotFoundError } from "./errors";

/**
 * Brands the user is granted access to (via user_brands) and that are still
 * active, ordered by name. Inactive brands are never returned even if a grant
 * row exists.
 */
export async function listAccessibleBrands(userId: string): Promise<Brand[]> {
  const db = getDb();
  const rows = await db
    .select({ brand: brands })
    .from(userBrands)
    .innerJoin(brands, eq(userBrands.brandId, brands.id))
    .where(and(eq(userBrands.userId, userId), eq(brands.isActive, true)))
    .orderBy(asc(brands.name));
  return rows.map((r) => r.brand);
}

/**
 * True iff the user has a user_brands grant for the brand AND the brand is
 * active. This is the primitive both requireBrandAccess and requireProjectAccess
 * build on.
 */
export async function userCanAccessBrand(
  userId: string,
  brandId: string,
): Promise<boolean> {
  const db = getDb();
  const [row] = await db
    .select({ brandId: userBrands.brandId })
    .from(userBrands)
    .innerJoin(brands, eq(userBrands.brandId, brands.id))
    .where(
      and(
        eq(userBrands.userId, userId),
        eq(userBrands.brandId, brandId),
        eq(brands.isActive, true),
      ),
    )
    .limit(1);
  return Boolean(row);
}

/**
 * THE single project access gate. Loads the project and its brand, then:
 *  - throws NotFoundError if the project does not exist,
 *  - throws AccessError if the brand is inactive or the user has no grant,
 *  - otherwise returns { project, brand }.
 *
 * Every project-scoped read/write MUST pass through this function so that brand
 * isolation is enforced in exactly one place.
 */
export async function requireProjectAccess(
  userId: string,
  projectId: string,
): Promise<{ project: Project; brand: Brand }> {
  const db = getDb();
  const [row] = await db
    .select({ project: projects, brand: brands })
    .from(projects)
    .innerJoin(brands, eq(projects.brandId, brands.id))
    .where(eq(projects.id, projectId))
    .limit(1);

  if (!row) throw new NotFoundError("Proje bulunamadı", "PROJECT_NOT_FOUND");

  if (!row.brand.isActive) throw new AccessError();

  const [grant] = await db
    .select({ brandId: userBrands.brandId })
    .from(userBrands)
    .where(
      and(
        eq(userBrands.userId, userId),
        eq(userBrands.brandId, row.brand.id),
      ),
    )
    .limit(1);

  if (!grant) throw new AccessError();

  return { project: row.project, brand: row.brand };
}

/**
 * Assert the user can access the brand, returning it. Throws AccessError when
 * the brand is inactive, missing, or ungranted.
 */
export async function requireBrandAccess(
  userId: string,
  brandId: string,
): Promise<Brand> {
  const allowed = await userCanAccessBrand(userId, brandId);
  if (!allowed) throw new AccessError();

  const db = getDb();
  const [brand] = await db
    .select()
    .from(brands)
    .where(eq(brands.id, brandId))
    .limit(1);

  // userCanAccessBrand already confirmed an active, granted brand exists.
  if (!brand) throw new AccessError();
  return brand;
}
