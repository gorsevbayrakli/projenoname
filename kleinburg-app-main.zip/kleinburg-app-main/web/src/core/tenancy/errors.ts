/**
 * Tenancy error types. Framework-neutral (no react/next) so route handlers can
 * map them to HTTP status codes: AccessError -> 403, NotFoundError -> 404.
 *
 * Each carries a `code` alongside its Turkish `message`. The message stays the
 * honest server-side truth and the log line; the code is what lets the client
 * render the same failure in the interface language (see core/errors/codes.ts).
 * Every class defaults its code, and every throw site may override it with a
 * more specific one.
 */

import type { ApiErrorCode } from "@/core/errors/codes";

/** The user is authenticated but not permitted to touch this resource. */
export class AccessError extends Error {
  readonly code: ApiErrorCode;
  constructor(
    message = "Bu kaynağa erişim yetkiniz yok",
    code: ApiErrorCode = "ACCESS_DENIED",
  ) {
    super(message);
    this.name = "AccessError";
    this.code = code;
  }
}

/** The requested resource does not exist. */
export class NotFoundError extends Error {
  readonly code: ApiErrorCode;
  constructor(message = "Kaynak bulunamadı", code: ApiErrorCode = "NOT_FOUND") {
    super(message);
    this.name = "NotFoundError";
    this.code = code;
  }
}

/** User input failed validation (empty name, bad language, …). Maps to 400. */
export class ValidationError extends Error {
  readonly code: ApiErrorCode;
  /**
   * `options.cause` carries the underlying throw when a ValidationError is
   * raised in response to one (a parser blowing up on an unreadable file, say).
   * The message stays the user-facing sentence; the cause is what an operator
   * needs to tell "this user's file is bad" from "our parser is broken", and
   * dropping it is exactly the silent swallow hard rule 5 forbids (#59).
   * It is never serialised to the client — `errorResponse` sends only
   * `{ message, code }`.
   */
  constructor(
    message: string,
    code: ApiErrorCode = "INVALID_REQUEST",
    options?: { cause?: unknown },
  ) {
    super(message, options);
    this.name = "ValidationError";
    this.code = code;
  }
}

/** The request conflicts with existing state (duplicate name). Maps to 409. */
export class ConflictError extends Error {
  readonly code: ApiErrorCode;
  constructor(message: string, code: ApiErrorCode = "CONFLICT") {
    super(message);
    this.name = "ConflictError";
    this.code = code;
  }
}

/**
 * The caller has made too many failed attempts at a credential check and is
 * being made to wait (#40 review, finding 11). Maps to 429.
 *
 * Lives here with the other deliberate errors so it travels the same
 * `errorResponse` path and carries the same `{ message, code }` shape. It is
 * NOT an AccessError: the caller may well be entitled to the operation, they
 * are simply going too fast, and conflating the two would make a locked-out
 * user look like an unauthorized one in the logs.
 */
export class TooManyAttemptsError extends Error {
  readonly code: ApiErrorCode;
  /** Whole seconds the caller should wait before retrying. */
  readonly retryAfterSeconds: number;
  constructor(
    message = "Çok fazla deneme yapıldı, biraz sonra tekrar deneyin",
    retryAfterSeconds = 0,
    code: ApiErrorCode = "TOO_MANY_ATTEMPTS",
  ) {
    super(message);
    this.name = "TooManyAttemptsError";
    this.code = code;
    this.retryAfterSeconds = retryAfterSeconds;
  }
}
