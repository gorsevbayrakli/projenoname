import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import { brands, projects, userBrands, users } from "../db/schema";
import { AccessError } from "./errors";
import {
  createProject,
  deleteProject,
  listProjects,
  renameProject,
  setProjectPlatforms,
  type ProjectLanguage,
} from "./projects";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

async function makeUser() {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({ username: `t7p-${randomUUID()}`, passwordHash: "x" })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

async function makeBrand(opts: { isActive?: boolean } = {}) {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: `brand-${randomUUID()}`, isActive: opts.isActive ?? true })
    .returning();
  createdBrandIds.push(brand.id);
  return brand;
}

async function grant(userId: string, brandId: string) {
  const db = getDb();
  await db.insert(userBrands).values({ userId, brandId });
}

/** userA -> brand1 (granted); userB -> brand2 (granted). */
async function setup() {
  const userA = await makeUser();
  const userB = await makeUser();
  const brand1 = await makeBrand();
  const brand2 = await makeBrand();
  await grant(userA.id, brand1.id);
  await grant(userB.id, brand2.id);
  return { userA, userB, brand1, brand2 };
}

describe.skipIf(!hasDb)("tenancy/projects", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("createProject succeeds for an accessible brand", async () => {
    const { userA, brand1 } = await setup();
    const name = `p-${randomUUID()}`;
    const project = await createProject(userA.id, brand1.id, name, "tr");
    expect(project.brandId).toBe(brand1.id);
    expect(project.name).toBe(name);
    expect(project.language).toBe("tr");
    expect(project.createdBy).toBe(userA.id);
  });

  it("createProject trims the name", async () => {
    const { userA, brand1 } = await setup();
    const core = `p-${randomUUID()}`;
    const project = await createProject(userA.id, brand1.id, `  ${core}  `, "en");
    expect(project.name).toBe(core);
  });

  it("createProject throws AccessError for an inaccessible brand", async () => {
    const { userA, brand2 } = await setup();
    await expect(
      createProject(userA.id, brand2.id, `p-${randomUUID()}`, "en"),
    ).rejects.toBeInstanceOf(AccessError);
  });

  it("createProject rejects an empty name", async () => {
    const { userA, brand1 } = await setup();
    await expect(createProject(userA.id, brand1.id, "   ", "en")).rejects.toThrow();
  });

  it("createProject rejects an invalid language", async () => {
    const { userA, brand1 } = await setup();
    await expect(
      createProject(
        userA.id,
        brand1.id,
        `p-${randomUUID()}`,
        "klingon" as ProjectLanguage,
      ),
    ).rejects.toThrow();
  });

  it("createProject rejects a duplicate (brandId, name)", async () => {
    const { userA, brand1 } = await setup();
    const name = `dup-${randomUUID()}`;
    await createProject(userA.id, brand1.id, name, "en");
    await expect(createProject(userA.id, brand1.id, name, "en")).rejects.toThrow(
      "Bu markada bu isimde bir proje zaten var",
    );
  });

  it("listProjects returns brand projects for an accessible brand", async () => {
    const { userA, brand1 } = await setup();
    const p1 = await createProject(userA.id, brand1.id, `p-${randomUUID()}`, "en");
    const p2 = await createProject(userA.id, brand1.id, `p-${randomUUID()}`, "en");
    const list = await listProjects(userA.id, brand1.id);
    const ids = list.map((p) => p.id);
    expect(ids).toContain(p1.id);
    expect(ids).toContain(p2.id);
  });

  it("listProjects throws AccessError for an inaccessible brand", async () => {
    const { userA, brand2 } = await setup();
    await expect(listProjects(userA.id, brand2.id)).rejects.toBeInstanceOf(
      AccessError,
    );
  });

  it("renameProject renames an accessible project", async () => {
    const { userA, brand1 } = await setup();
    const project = await createProject(userA.id, brand1.id, `p-${randomUUID()}`, "en");
    const newName = `r-${randomUUID()}`;
    const renamed = await renameProject(userA.id, project.id, newName);
    expect(renamed.name).toBe(newName);
  });

  it("renameProject rejects a duplicate name in the same brand", async () => {
    const { userA, brand1 } = await setup();
    const existing = `e-${randomUUID()}`;
    await createProject(userA.id, brand1.id, existing, "en");
    const project = await createProject(userA.id, brand1.id, `p-${randomUUID()}`, "en");
    await expect(renameProject(userA.id, project.id, existing)).rejects.toThrow(
      "Bu markada bu isimde bir proje zaten var",
    );
  });

  it("setProjectPlatforms stores the chosen platforms", async () => {
    const { userA, brand1 } = await setup();
    const project = await createProject(userA.id, brand1.id, `p-${randomUUID()}`, "en");

    const updated = await setProjectPlatforms(userA.id, project.id, ["facebook"]);

    expect(updated.platforms).toEqual(["facebook"]);
  });

  it("setProjectPlatforms normalises to registry order and drops junk", async () => {
    const { userA, brand1 } = await setup();
    const project = await createProject(userA.id, brand1.id, `p-${randomUUID()}`, "en");

    // Reversed, duplicated, and with a code that is not registered.
    const updated = await setProjectPlatforms(userA.id, project.id, [
      "facebook",
      "instagram",
      "facebook",
      "myspace",
    ]);

    expect(updated.platforms).toEqual(["instagram", "facebook"]);
  });

  it("setProjectPlatforms rejects an empty selection", async () => {
    const { userA, brand1 } = await setup();
    const project = await createProject(userA.id, brand1.id, `p-${randomUUID()}`, "en");

    // Empty outright, and empty after unregistered codes are dropped: both
    // would otherwise leave the pillars step generating for nothing.
    await expect(
      setProjectPlatforms(userA.id, project.id, []),
    ).rejects.toThrow("En az bir platform seçilmeli");
    await expect(
      setProjectPlatforms(userA.id, project.id, ["myspace"]),
    ).rejects.toThrow("En az bir platform seçilmeli");
  });

  it("setProjectPlatforms throws AccessError across brand boundaries", async () => {
    const { userA, userB, brand2 } = await setup();
    const project = await createProject(userB.id, brand2.id, `p-${randomUUID()}`, "en");

    await expect(
      setProjectPlatforms(userA.id, project.id, ["instagram"]),
    ).rejects.toBeInstanceOf(AccessError);
  });

  it("a new project starts with no platforms chosen", async () => {
    const { userA, brand1 } = await setup();
    const project = await createProject(userA.id, brand1.id, `p-${randomUUID()}`, "en");

    // Empty means "not chosen yet"; wizard step 6 is what fills it.
    expect(project.platforms).toEqual([]);
  });

  it("renameProject throws AccessError across brand boundaries", async () => {
    const { userA, userB, brand2 } = await setup();
    const project = await createProject(userB.id, brand2.id, `p-${randomUUID()}`, "en");
    await expect(
      renameProject(userA.id, project.id, `r-${randomUUID()}`),
    ).rejects.toBeInstanceOf(AccessError);
  });

  it("deleteProject removes an accessible project", async () => {
    const { userA, brand1 } = await setup();
    const project = await createProject(userA.id, brand1.id, `p-${randomUUID()}`, "en");
    await deleteProject(userA.id, project.id);

    const db = getDb();
    const rows = await db
      .select()
      .from(projects)
      .where(eq(projects.id, project.id));
    expect(rows).toHaveLength(0);
  });

  it("deleteProject throws AccessError across brand boundaries", async () => {
    const { userA, userB, brand2 } = await setup();
    const project = await createProject(userB.id, brand2.id, `p-${randomUUID()}`, "en");
    await expect(deleteProject(userA.id, project.id)).rejects.toBeInstanceOf(
      AccessError,
    );
  });
});
