/**
 * The one timezone this application's calendar is drawn in.
 *
 * ── WHY A SHARED CONSTANT (#58, #66) ─────────────────────────────────────
 * Kleinburg is an internal tool used from Istanbul, but it runs on Render,
 * which sets no `TZ` — so the Node process is UTC. Anything that turns an
 * instant into a DAY therefore has to say which zone it means; leaving it to
 * the runtime silently means "UTC" in production and "the developer's laptop"
 * in a test, and those two agree often enough to hide the bug.
 *
 * Both defects were the same one, three hours wide:
 *
 *   #58 — next-intl was configured with no `timeZone`, so the spend-cap
 *   refusal rendered `month.until` (local midnight on the 1st, i.e. 21:00Z on
 *   the last day) in UTC and named the reset a day early, every month.
 *
 *   #66 — the relative-time absolute stamp read the day off the process zone,
 *   so anything edited between 00:00 and 03:00 Istanbul was dated yesterday.
 *
 * `SPEND_MONTH_TIMEZONE` in core/llm/cap.ts already litigated the choice and
 * had it right; it now derives from this constant so the cap boundary and the
 * date printed next to it cannot drift apart. The reasoning for the choice
 * itself — a named IANA zone rather than a fixed +03:00 offset, and a local
 * calendar rather than the invoice's — stays there, where the trade is made.
 *
 * Not a per-user preference. If one is ever wanted, the cap message must still
 * format its reset instant in the SPEND zone, because that is the zone the
 * reset actually happens in.
 */
export const APP_TIMEZONE = "Europe/Istanbul";
