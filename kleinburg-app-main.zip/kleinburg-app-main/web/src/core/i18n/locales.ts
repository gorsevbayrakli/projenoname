/**
 * UI locales for the application chrome (T25).
 *
 * IMPORTANT: this is the INTERFACE language, which is a different concept from
 * the CONTENT language (`projects.language` / lib/languages.ts — the 7 languages
 * the engine generates content in). The two never mix: a user may run the UI in
 * English while generating Turkish content.
 *
 * Pure module (no next/react imports) so it can be read from middleware, server
 * components, client components and tests alike.
 */

export const LOCALES = ["tr", "en", "fr", "it", "es", "de"] as const;

export type Locale = (typeof LOCALES)[number];

/** Turkish is the default — the app's original and primary interface language. */
export const DEFAULT_LOCALE: Locale = "tr";

/** Cookie holding the user's interface-language choice. No DB column, no URL prefix. */
export const LOCALE_COOKIE = "kb_locale";

/** One year: the choice should outlive a session without being permanent. */
export const LOCALE_COOKIE_MAX_AGE = 60 * 60 * 24 * 365;

/** Narrows an untrusted cookie value to a supported locale. */
export function isLocale(value: unknown): value is Locale {
  return typeof value === "string" && (LOCALES as readonly string[]).includes(value);
}

/** The locale for an untrusted value, falling back to the default. */
export function resolveLocale(value: unknown): Locale {
  return isLocale(value) ? value : DEFAULT_LOCALE;
}

/**
 * The interface language for a request, given both possible sources (T43).
 *
 * ── PRECEDENCE: ACCOUNT BEATS COOKIE ─────────────────────────────────────
 * A stored account preference wins over the `kb_locale` cookie. The reason is
 * the requirement itself: the preference exists so the choice survives a
 * device change, and a cookie is per-device by definition. If the cookie won,
 * signing in on a new laptop would show the old language and the account
 * setting would be decorative.
 *
 * They only disagree when another device wrote the cookie, and in that case
 * the account is the more recent DELIBERATE statement — the switcher writes
 * both at once (see set-locale.ts), so a cookie that differs is a leftover.
 *
 * NULL account preference means "not chosen", not "choose Turkish": the cookie
 * then decides, which is exactly T25 behaviour and what every account created
 * before T43 gets.
 *
 * Signed-out visitors pass `accountLocale: null` and keep the pure cookie
 * path. This is load-bearing, not a fallback: the login page renders before
 * anyone is authenticated, so there is no account to read a preference from.
 */
export function resolveEffectiveLocale(source: {
  accountLocale?: unknown;
  cookieLocale?: unknown;
}): Locale {
  if (isLocale(source.accountLocale)) return source.accountLocale;
  return resolveLocale(source.cookieLocale);
}
