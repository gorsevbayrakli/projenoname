/**
 * T43 — interface-language precedence.
 *
 * The rule in one line: an account preference beats the cookie, and NULL means
 * "no preference" rather than "Turkish". The signed-out path is the one that
 * must not regress — the login page renders before any account exists.
 */
import { describe, expect, it } from "vitest";

import {
  DEFAULT_LOCALE,
  LOCALES,
  isLocale,
  resolveEffectiveLocale,
  resolveLocale,
} from "./locales";

describe("resolveEffectiveLocale", () => {
  it("prefers the account preference over the cookie when they disagree", () => {
    // The device-change case: this laptop's cookie says Turkish, the account
    // says English, and the account is the choice that is meant to travel.
    expect(
      resolveEffectiveLocale({ accountLocale: "en", cookieLocale: "tr" }),
    ).toBe("en");
    expect(
      resolveEffectiveLocale({ accountLocale: "tr", cookieLocale: "en" }),
    ).toBe("tr");
  });

  it("falls back to the cookie when the account has no preference", () => {
    expect(
      resolveEffectiveLocale({ accountLocale: null, cookieLocale: "en" }),
    ).toBe("en");
    expect(
      resolveEffectiveLocale({ accountLocale: undefined, cookieLocale: "en" }),
    ).toBe("en");
  });

  it("keeps the pure cookie path for signed-out visitors", () => {
    // No account at all: exactly T25 behaviour, which the login page depends on.
    expect(resolveEffectiveLocale({ cookieLocale: "en" })).toBe("en");
    expect(resolveEffectiveLocale({ cookieLocale: "tr" })).toBe("tr");
  });

  it("falls back to the default when neither source says anything", () => {
    expect(resolveEffectiveLocale({})).toBe(DEFAULT_LOCALE);
    expect(
      resolveEffectiveLocale({ accountLocale: null, cookieLocale: undefined }),
    ).toBe(DEFAULT_LOCALE);
  });

  it("ignores junk in either source rather than trusting it", () => {
    // A retired or hand-crafted value must never reach next-intl, which would
    // try to import a message catalogue that does not exist.
    expect(
      resolveEffectiveLocale({ accountLocale: "xx", cookieLocale: "en" }),
    ).toBe("en");
    expect(
      resolveEffectiveLocale({ accountLocale: "", cookieLocale: "../../etc" }),
    ).toBe(DEFAULT_LOCALE);
    expect(
      resolveEffectiveLocale({ accountLocale: 42, cookieLocale: {} }),
    ).toBe(DEFAULT_LOCALE);
  });
});

describe("expanded locale vocabulary (#16)", () => {
  it("offers the four new interface languages", () => {
    for (const l of ["fr", "it", "es", "de"] as const) {
      expect(LOCALES).toContain(l);
      expect(isLocale(l)).toBe(true);
      expect(resolveLocale(l)).toBe(l);
    }
  });

  it("still rejects an unknown locale to the default", () => {
    expect(isLocale("xx")).toBe(false);
    expect(resolveLocale("xx")).toBe("tr");
  });
});
