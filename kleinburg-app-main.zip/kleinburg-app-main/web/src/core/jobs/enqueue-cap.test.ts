import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import {
  brands,
  generationJobs,
  llmCalls,
  projects,
  stepContents,
} from "../db/schema";
import { SpendCapExceededError } from "../llm/cap";
import { createJob } from "./jobs";
import { enqueueGeneration } from "./worker";

import { hasDb } from "@/test/db-gate";

/**
 * The cap at the ONE DOOR to the queue (T51 items 3, 4 and 6).
 *
 * These tests are about `enqueueGeneration` specifically, not about the
 * arithmetic (that is `cap-enforcement.test.ts`). What they pin is the part a
 * reviewer cannot see from the cap module alone: that the refusal happens
 * BEFORE anything durable is written, that it is inside the enqueue function
 * rather than in a route that a second route could bypass, and that it leaves
 * work already in flight completely alone.
 *
 * The refusal path never reaches pg-boss, so these run without the queue. The
 * ALLOWED path does reach it, which is why the "does not interrupt" test below
 * asserts on the existing rows rather than enqueueing a second job.
 */

const createdBrandIds: string[] = [];

async function makeBrand(monthlyCapUsd: string | null) {
  const [brand] = await getDb()
    .insert(brands)
    .values({ name: `brand-${randomUUID()}`, monthlyCapUsd })
    .returning();
  createdBrandIds.push(brand.id);
  return brand;
}

async function makeProject(brandId: string) {
  const [project] = await getDb()
    .insert(projects)
    .values({ brandId, name: `p-${randomUUID()}` })
    .returning();
  return project;
}

/** Put `usd` of already-spent, fully priced money on the brand, dated now. */
async function spend(projectId: string, usd: number) {
  const [job] = await getDb()
    .insert(generationJobs)
    .values({ projectId, step: "sm_pillars", status: "succeeded", input: {} })
    .returning();
  await getDb().insert(llmCalls).values({
    jobId: job.id,
    model: "anthropic/claude-sonnet-5",
    promptTokens: 1000,
    completionTokens: 0,
    costUsd: String(usd),
    durationMs: 10,
  });
  return job;
}

describe.skipIf(!hasDb)("enqueueGeneration and the monthly cap", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("REFUSES a brand at its cap, and writes nothing at all", async () => {
    // The spend is dated by the column default, i.e. genuinely now, so this
    // exercises the same "current month" the production path computes.
    const brand = await makeBrand("5.00");
    const project = await makeProject(brand.id);
    const spent = await spend(project.id, 6);

    await expect(
      enqueueGeneration(project.id, "brand_context", {}, null),
    ).rejects.toThrow(SpendCapExceededError);

    // No job row was created. This is the difference between a refusal and a
    // failure: a refused generation must not leave a 'failed' row behind for
    // an operator to wonder about, nor a queued one for the worker to find.
    const rows = await getDb()
      .select()
      .from(generationJobs)
      .where(eq(generationJobs.projectId, project.id));
    expect(rows.map((r) => r.id)).toEqual([spent.id]);

    // And no partial content (hard rule 4/5).
    const contents = await getDb()
      .select()
      .from(stepContents)
      .where(eq(stepContents.projectId, project.id));
    expect(contents).toHaveLength(0);
  });

  it("tells the refused caller which cap stopped them", async () => {
    const brand = await makeBrand("5.00");
    const project = await makeProject(brand.id);
    await spend(project.id, 7.5);

    const error = await enqueueGeneration(
      project.id,
      "brand_context",
      {},
      null,
    ).catch((e) => e);

    expect(error).toBeInstanceOf(SpendCapExceededError);
    expect(error.message).toContain(brand.name);
    expect(error.message).toContain("$5.00");
    expect(error.message).toContain("$7.50");
    // 409, via ConflictError, so `errorResponse` maps it with no route change.
    expect(error.code).toBe("SPEND_CAP_EXCEEDED");
  });

  it("does NOT interrupt work already queued or running", async () => {
    // #51 item 6. A run in flight has already spent money; killing it wastes
    // that AND the content it would have produced.
    const brand = await makeBrand("5.00");
    const project = await makeProject(brand.id);
    await spend(project.id, 99);

    const queued = await createJob(project.id, "brand_context", {}, null);
    const [running] = await getDb()
      .update(generationJobs)
      .set({ status: "running" })
      .where(eq(generationJobs.id, queued.id))
      .returning();
    expect(running.status).toBe("running");

    // A refusal happens for NEW work…
    await expect(
      enqueueGeneration(project.id, "sm_posts", {}, null),
    ).rejects.toThrow(SpendCapExceededError);

    // …and the in-flight job is untouched by it.
    const [after] = await getDb()
      .select()
      .from(generationJobs)
      .where(eq(generationJobs.id, queued.id));
    expect(after.status).toBe("running");
    expect(after.error).toBeNull();
  });

  it("does not consult the cap at all for an uncapped brand", async () => {
    // An uncapped brand with enormous spend must reach the queue exactly as
    // before. It fails at pg-boss here (no queue running in this suite), which
    // is itself the proof that it got PAST the cap — a cap refusal would have
    // been a SpendCapExceededError instead.
    const brand = await makeBrand(null);
    const project = await makeProject(brand.id);
    await spend(project.id, 10_000);

    const error = await enqueueGeneration(
      project.id,
      "brand_context",
      {},
      null,
    ).catch((e) => e);
    expect(error).not.toBeInstanceOf(SpendCapExceededError);
  });

  it("refuses a project that does not exist rather than skipping the cap", async () => {
    // A missing project has no brand, so it has no budget either. Treating
    // that as "uncapped" would be a way around the cap.
    await expect(
      enqueueGeneration(randomUUID(), "brand_context", {}, null),
    ).rejects.toThrow(/Proje bulunamadı/);
  });
});
