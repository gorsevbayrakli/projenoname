import { PgBoss } from "pg-boss";

/**
 * Queue name for step-generation jobs. pg-boss carries only { jobId }; the
 * durable truth lives in the generation_jobs table (see ./jobs.ts).
 */
export const GENERATE_QUEUE = "generate-step";

let bossPromise: Promise<PgBoss> | null = null;

/**
 * Lazy singleton over a started PgBoss instance. pg-boss manages its own schema
 * (the `pgboss` namespace) in the same database as our drizzle tables; that is
 * expected and separate from our migrations. Framework-neutral: this file uses
 * only node built-ins and pg-boss, never react/next.
 */
export function getBoss(): Promise<PgBoss> {
  if (bossPromise) return bossPromise;

  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error(
      "DATABASE_URL is not set. pg-boss needs it to run the job queue.",
    );
  }

  bossPromise = (async () => {
    const boss = new PgBoss({ connectionString });
    // Surface pg-boss internal errors rather than swallowing them silently.
    boss.on("error", (err: unknown) => {
      console.error("[pg-boss] error", err);
    });
    await boss.start();
    // pg-boss v10 requires queues to be created before use.
    await boss.createQueue(GENERATE_QUEUE);
    return boss;
  })().catch((err) => {
    // Do not cache a rejected promise: reset so a later call can retry startup
    // instead of permanently returning this rejection.
    bossPromise = null;
    throw err;
  });

  return bossPromise;
}

/** Stop the boss and clear the singleton (for tests / graceful shutdown). */
export async function stopBoss(): Promise<void> {
  if (!bossPromise) return;
  const boss = await bossPromise;
  bossPromise = null;
  await boss.stop({ graceful: false });
}
