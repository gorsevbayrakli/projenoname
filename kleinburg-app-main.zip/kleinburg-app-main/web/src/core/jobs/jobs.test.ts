import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import { brands, projects, users } from "../db/schema";
import {
  createJob,
  getJob,
  markCancelled,
  markFailed,
  markRunning,
  markSucceeded,
  openSyntheticJob,
  supersedeActiveJobs,
} from "./jobs";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

async function makeUser() {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({ username: `t9j-${randomUUID()}`, passwordHash: "x" })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

async function makeProject() {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: `brand-${randomUUID()}` })
    .returning();
  createdBrandIds.push(brand.id);
  const [project] = await db
    .insert(projects)
    .values({ brandId: brand.id, name: `p-${randomUUID()}` })
    .returning();
  return project;
}

describe.skipIf(!hasDb)("jobs repository", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("createJob inserts a queued job", async () => {
    const user = await makeUser();
    const project = await makeProject();
    const job = await createJob(
      project.id,
      "brand_context",
      { foo: "bar" },
      user.id,
    );
    expect(job.status).toBe("queued");
    expect(job.projectId).toBe(project.id);
    expect(job.step).toBe("brand_context");
    expect(job.input).toEqual({ foo: "bar" });
    expect(job.createdBy).toBe(user.id);
    expect(job.startedAt).toBeNull();
    expect(job.finishedAt).toBeNull();
  });

  it("markRunning claims a queued job: returns row, clears stale fields", async () => {
    const project = await makeProject();
    const job = await createJob(project.id, "brand_context", {}, null);
    const claimed = await markRunning(job.id);
    expect(claimed).not.toBeNull();
    expect(claimed?.status).toBe("running");
    expect(claimed?.startedAt).not.toBeNull();
    expect(claimed?.error).toBeNull();
    expect(claimed?.finishedAt).toBeNull();
    expect(claimed?.output).toBeNull();
    const after = await getJob(job.id);
    expect(after?.status).toBe("running");
    expect(after?.startedAt).not.toBeNull();
    expect(after?.finishedAt).toBeNull();
  });

  it("markRunning does not claim a cancelled job: returns null, stays cancelled", async () => {
    const project = await makeProject();
    const job = await createJob(project.id, "brand_context", {}, null);
    await markCancelled(job.id);
    const claimed = await markRunning(job.id);
    expect(claimed).toBeNull();
    const after = await getJob(job.id);
    expect(after?.status).toBe("cancelled");
  });

  it("markSucceeded sets output + finishedAt + succeeded (running job)", async () => {
    const project = await makeProject();
    const job = await createJob(project.id, "brand_context", {}, null);
    await markRunning(job.id);
    const result = await markSucceeded(job.id, { result: 42 });
    expect(result).not.toBeNull();
    const after = await getJob(job.id);
    expect(after?.status).toBe("succeeded");
    expect(after?.output).toEqual({ result: 42 });
    expect(after?.finishedAt).not.toBeNull();
  });

  it("markFailed records the error (running job)", async () => {
    const project = await makeProject();
    const job = await createJob(project.id, "brand_context", {}, null);
    await markRunning(job.id);
    const result = await markFailed(job.id, "boom");
    expect(result).not.toBeNull();
    const after = await getJob(job.id);
    expect(after?.status).toBe("failed");
    expect(after?.error).toBe("boom");
    expect(after?.finishedAt).not.toBeNull();
  });

  it("markFailed fails a QUEUED job (enqueue/send failure path), not just running", async () => {
    // A queued job whose pg-boss send failed must become terminal 'failed',
    // never an orphan 'queued'. markFailed must transition queued -> failed.
    const project = await makeProject();
    const job = await createJob(project.id, "brand_context", {}, null);
    const result = await markFailed(job.id, "İş kuyruğa alınamadı");
    expect(result).not.toBeNull();
    const after = await getJob(job.id);
    expect(after?.status).toBe("failed");
    expect(after?.error).toBe("İş kuyruğa alınamadı");
  });

  it("markSucceeded/markFailed no-op on a job cancelled mid-run (status guard)", async () => {
    const project = await makeProject();
    // Simulate: job claimed (running), then cancelled by a superseding enqueue.
    const job = await createJob(project.id, "brand_context", {}, null);
    await markRunning(job.id);
    await supersedeActiveJobs(project.id); // cancels the running job
    // A late completion must NOT resurrect the cancelled row.
    expect(await markSucceeded(job.id, { late: true })).toBeNull();
    expect(await markFailed(job.id, "late error")).toBeNull();
    const after = await getJob(job.id);
    expect(after?.status).toBe("cancelled");
    expect(after?.output).toBeNull();
    expect(after?.error).toBeNull();
  });

  it("markCancelled sets cancelled + finishedAt and returns the row", async () => {
    const project = await makeProject();
    const job = await createJob(project.id, "brand_context", {}, null);
    expect(await markCancelled(job.id)).not.toBeNull();
    const after = await getJob(job.id);
    expect(after?.status).toBe("cancelled");
    expect(after?.finishedAt).not.toBeNull();
  });

  // The other direction of "a cancelled job can never become succeeded": a
  // succeeded job must never become cancelled either. Unguarded, this rewrote
  // the terminal row and moved its finishedAt, so a generation the user already
  // has content for would report itself cancelled.
  it("markCancelled no-ops on a terminal job (status guard)", async () => {
    const project = await makeProject();

    const done = await createJob(project.id, "brand_context", {}, null);
    await markRunning(done.id);
    const succeeded = await markSucceeded(done.id, { result: 1 });
    expect(await markCancelled(done.id)).toBeNull();
    const afterDone = await getJob(done.id);
    expect(afterDone?.status).toBe("succeeded");
    expect(afterDone?.output).toEqual({ result: 1 });
    expect(afterDone?.finishedAt).toEqual(succeeded!.finishedAt);

    const broken = await createJob(project.id, "brand_context", {}, null);
    await markRunning(broken.id);
    await markFailed(broken.id, "boom");
    expect(await markCancelled(broken.id)).toBeNull();
    const afterBroken = await getJob(broken.id);
    expect(afterBroken?.status).toBe("failed");
    expect(afterBroken?.error).toBe("boom");
  });

  it("getJob returns null for a missing id", async () => {
    expect(await getJob(randomUUID())).toBeNull();
  });

  it("supersedeActiveJobs cancels prior active jobs except the excepted one, scoped to the project", async () => {
    const projectA = await makeProject();
    const projectB = await makeProject();

    const queued = await createJob(projectA.id, "brand_context", {}, null);
    const running = await createJob(projectA.id, "secondary_data", {}, null);
    await markRunning(running.id);
    const keep = await createJob(projectA.id, "user_input", {}, null);
    const otherProject = await createJob(projectB.id, "brand_context", {}, null);

    await supersedeActiveJobs(projectA.id, keep.id);

    expect((await getJob(queued.id))?.status).toBe("cancelled");
    expect((await getJob(running.id))?.status).toBe("cancelled");
    // The excepted job stays active.
    expect((await getJob(keep.id))?.status).toBe("queued");
    // Another project's job is untouched.
    expect((await getJob(otherProject.id))?.status).toBe("queued");
  });

  it("supersedeActiveJobs leaves a synthetic (non-queued) job alone", async () => {
    // "One active job per project" is about QUEUED generations. A synthetic
    // ledger row (cadence advice, see pipeline/cadence.ts) is not queued, is
    // never claimed and is already in flight for a call the user is being
    // billed for — cancelling it would put a lie in generation_jobs about work
    // that did in fact run.
    const project = await makeProject();
    const synthetic = await openSyntheticJob(
      project.id,
      "platform_cadence",
      {},
      null,
    );
    const active = await createJob(project.id, "brand_context", {}, null);

    await supersedeActiveJobs(project.id);

    expect((await getJob(synthetic.id))?.status).toBe("running");
    expect((await getJob(active.id))?.status).toBe("cancelled");
  });

  it("supersedeActiveJobs does not touch terminal jobs", async () => {
    const project = await makeProject();
    const done = await createJob(project.id, "brand_context", {}, null);
    await markRunning(done.id);
    await markSucceeded(done.id, { ok: true });
    const active = await createJob(project.id, "secondary_data", {}, null);

    await supersedeActiveJobs(project.id);

    expect((await getJob(done.id))?.status).toBe("succeeded");
    expect((await getJob(active.id))?.status).toBe("cancelled");
  });
});
