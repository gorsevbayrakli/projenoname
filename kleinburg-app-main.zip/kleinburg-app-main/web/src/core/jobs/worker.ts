import type { Job, PgBoss } from "pg-boss";
import { eq } from "drizzle-orm";

import { getDb } from "../db/client";
import { brands, projects, type GenerationJob, type WorkflowStep } from "../db/schema";
import { assertBrandWithinCap } from "../llm/cap";
import { NotFoundError } from "../tenancy/errors";
import { upsertStepContent, type JobInput } from "../pipeline/inputs";
import { runStep } from "../pipeline/run-step";
import { GENERATE_QUEUE, getBoss } from "./boss";
import {
  createJob,
  markFailed,
  markRunning,
  markSucceeded,
  supersedeActiveJobs,
} from "./jobs";

/** Payload pg-boss carries; the durable job row holds everything else. */
type GeneratePayload = { jobId: string };

/**
 * pg-boss job-level retry is disabled (retryLimit 0). A 'failed' generation_jobs
 * row must be truly terminal and never silently re-run behind the SSE stream's
 * back. Transient-error retry (429/timeout ×2 backoff) belongs at the OpenRouter
 * API-call level inside runStep (T10/T12), NOT at the whole-job level — re-running
 * the entire step is wasteful and makes generation_jobs lie about outcome.
 *
 * `expireInSeconds` is stated EXPLICITLY next to retryLimit because the two
 * decisions only make sense together, and the pg-boss default silently broke
 * the pair. The default is 900s (FIFTEEN_MINUTES in pg-boss's plans.js): a
 * generation that runs longer has its queue message expired and marked failed
 * while handleGenerateJob is still executing and will later write 'succeeded'
 * to generation_jobs. generation_jobs stays correct — it is the durable truth
 * and nothing re-runs, since retryLimit is 0 — but pg-boss's own tables then
 * contradict it, which would mislead any queue monitoring built on them.
 *
 * The number is the worst case a step can legitimately occupy the handler for,
 * derived rather than guessed:
 *   - the OpenAI SDK client is built with no `timeout`/`maxRetries` override,
 *     so its defaults apply: 10 min per request, 2 SDK-level retries
 *     → up to 30 min for one `chat.completions.create`;
 *   - generateStructured wraps that in MAX_ATTEMPTS = 3 with 0.5s + 1.5s
 *     backoff → up to ~90 min per call;
 *   - secondary_data is TWO sequential calls (#52) → up to ~180 min.
 * 4 hours is that 180 min plus room for the surrounding DB work. Erring long is
 * the safe direction here: an over-long expiry only delays pg-boss noticing a
 * genuinely stuck message, while an under-short one manufactures a false
 * failure for work that is still running.
 */
const RETRY_OPTIONS = {
  retryLimit: 0,
  expireInSeconds: 4 * 60 * 60,
} as const;

/**
 * Process a single generation job by id. Exported so tests (and future callers)
 * can drive it directly without a pg-boss round-trip.
 *
 * The generation itself is core/pipeline runStep (T12); markRunning/markSucceeded/
 * markFailed and their status guards are unchanged. `deps.runStep` is injectable
 * so tests drive the worker without a live LLM call.
 */
export interface HandleJobDeps {
  runStep?: typeof runStep;
}

export async function handleGenerateJob(
  jobId: string,
  deps: HandleJobDeps = {},
): Promise<void> {
  const run = deps.runStep ?? runStep;
  // Atomic CLAIM: only a still-'queued' row transitions to 'running'. If the row
  // was cancelled/superseded (or is otherwise not claimable), bail without
  // throwing so pg-boss does not retry a job that was intentionally cancelled.
  const claimed = await markRunning(jobId);
  if (!claimed) {
    console.log(
      `[worker] job ${jobId} not claimable (cancelled/superseded/not-queued); skipping`,
    );
    return;
  }

  try {
    const row: GenerationJob = claimed;

    // Run the real generation pipeline (T12): gather prior content, render the
    // step's prompt, call generateStructured, return the validated output. A
    // missing prerequisite or a schema-invalid model output throws here and is
    // recorded as a failed job below (honest failure, no partial save).
    const output = await run(
      row.projectId,
      row.step,
      (row.input ?? {}) as JobInput,
      row.id,
    );

    // markSucceeded is guarded on status='running'; if the job was cancelled
    // WHILE this body ran, it returns null and the row stays 'cancelled' — a
    // superseded job can never reach 'succeeded'. We upsert step_contents ONLY
    // when the succeed transition actually won the guard, so a cancelled-mid-run
    // job never leaves stale content behind. A fresh generation clears prior
    // selections (indices change), handled by upsertStepContent.
    const succeeded = await markSucceeded(jobId, output);
    if (succeeded) {
      await upsertStepContent(row.projectId, row.step, output);
    } else {
      console.log(
        `[worker] job ${jobId} was cancelled mid-run; not marking succeeded`,
      );
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    // Also guarded on status='running': a job cancelled mid-run is not
    // overwritten with 'failed'. Only rethrow (to signal pg-boss) when we
    // actually recorded the failure on a still-running row.
    const failed = await markFailed(jobId, message);
    if (failed) {
      // Record the terminal 'failed' row, then rethrow so pg-boss marks its own
      // message failed. With retryLimit 0 it will not retry, so 'failed' stays
      // terminal and never silently re-runs behind the SSE stream's back.
      throw err;
    }
    console.log(
      `[worker] job ${jobId} errored but was already cancelled; leaving as cancelled`,
    );
  }
}

/**
 * Register the queue worker. pg-boss delivers a batch of jobs; each carries
 * { jobId } and we process them one at a time. Called once at server startup
 * (see src/instrumentation.ts).
 */
export async function registerWorker(): Promise<void> {
  const boss = await getBoss();
  await boss.work<GeneratePayload>(
    GENERATE_QUEUE,
    async (jobs: Job<GeneratePayload>[]) => {
      for (const job of jobs) {
        await handleGenerateJob(job.data.jobId);
      }
    },
  );
}

/**
 * Enqueue a generation job for a project step. Returns the created job row.
 *
 * The "one active job per project" invariant is enforced at the DB layer, not by
 * pg-boss: supersedeActiveJobs cancels prior queued/running rows, and the atomic
 * claim in handleGenerateJob makes any cancelled row bail before it runs. pg-boss
 * under the default 'standard' queue policy guarantees nothing here, so we do not
 * pass a singletonKey.
 *
 * Ordering matters for durability: createJob → send → supersede. We only
 * supersede AFTER a successful send, so a failed send never cancels the
 * previously-active good job. On send failure the new row is marked 'failed'
 * (terminal, not an orphan 'queued') and we rethrow so the route returns 500.
 * The just-sent message racing with supersede is fine: older jobs' messages hit
 * the claim guard and bail.
 *
 * ── THE MONTHLY CAP IS CHECKED HERE, FIRST (T51) ─────────────────────────
 * Before `createJob`, so a refused generation leaves NOTHING behind: no job
 * row, no queue message, no `llm_calls`, no partial content. #51 item 4 —
 * a refusal is an honest failure, not a half-run.
 *
 * And in THIS function rather than in the route, because #51 item 3 is that a
 * hidden button is not a limit. The route is one caller; this is the only door
 * to the queue, so a future route, a retry helper or a script cannot reach
 * generation around the cap without deleting this line. The UI's job is to
 * explain the refusal in advance, never to be the thing that enforces it.
 *
 * `new Date()` is read once, here, and passed down: `assertBrandWithinCap`
 * takes the instant as an argument so that a test can put the clock on a month
 * boundary without touching the real one.
 */
export async function enqueueGeneration(
  projectId: string,
  step: WorkflowStep,
  input: unknown,
  createdBy: string | null,
): Promise<GenerationJob> {
  await assertBrandWithinCap(await loadBrandOfProject(projectId), new Date());

  const job = await createJob(projectId, step, input, createdBy);

  const boss: PgBoss = await getBoss();
  try {
    await boss.send(GENERATE_QUEUE, { jobId: job.id }, { ...RETRY_OPTIONS });
  } catch (err) {
    await markFailed(job.id, "İş kuyruğa alınamadı");
    throw err;
  }

  await supersedeActiveJobs(projectId, job.id);

  return job;
}

/**
 * The brand a project belongs to, for the cap check.
 *
 * NOT an authorization step and not a substitute for one: by the time this
 * runs, `requireProjectAccess` has already decided whether the caller may
 * touch this project (hard rule 2). This only answers "whose budget does this
 * spend against". A missing project throws rather than skipping the cap —
 * silently permitting generation for a project that does not exist would be
 * both a lie and, if the id were ever attacker-influenced, a way around the
 * cap entirely.
 */
async function loadBrandOfProject(projectId: string) {
  const [row] = await getDb()
    .select({
      id: brands.id,
      name: brands.name,
      monthlyCapUsd: brands.monthlyCapUsd,
    })
    .from(projects)
    .innerJoin(brands, eq(projects.brandId, brands.id))
    .where(eq(projects.id, projectId))
    .limit(1);

  if (!row) {
    throw new NotFoundError("Proje bulunamadı", "PROJECT_NOT_FOUND");
  }
  return row;
}
