import { randomUUID } from "node:crypto";
import type { PgBoss } from "pg-boss";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { and, eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import { brands, projects, stepContents } from "../db/schema";
import * as boss from "./boss";
import { stopBoss } from "./boss";
import * as jobs from "./jobs";
import { createJob, getJob, markCancelled } from "./jobs";
import { enqueueGeneration, handleGenerateJob } from "./worker";

import { hasDb } from "@/test/db-gate";

// The full pg-boss round-trip is opt-in: it starts the queue and can be slow.
const runIntegration = hasDb && process.env.RUN_PGBOSS_TEST === "1";

const createdBrandIds: string[] = [];

async function makeProject() {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: `brand-${randomUUID()}` })
    .returning();
  createdBrandIds.push(brand.id);
  const [project] = await db
    .insert(projects)
    .values({ brandId: brand.id, name: `p-${randomUUID()}` })
    .returning();
  return project;
}

describe.skipIf(!hasDb)("worker handler (direct)", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("runs the step, upserts step_contents, and marks succeeded", async () => {
    const project = await makeProject();
    const job = await createJob(
      project.id,
      "brand_context",
      { hello: "world" },
      null,
    );

    const output = { brandContext: "## CONTEXT\nGenerated." };
    const runStep = vi.fn().mockResolvedValue(output);

    await handleGenerateJob(job.id, { runStep });

    // runStep was called with the durable job row's fields.
    expect(runStep).toHaveBeenCalledWith(
      project.id,
      "brand_context",
      { hello: "world" },
      job.id,
    );

    const after = await getJob(job.id);
    expect(after?.status).toBe("succeeded");
    expect(after?.output).toEqual(output);
    expect(after?.startedAt).not.toBeNull();
    expect(after?.finishedAt).not.toBeNull();

    // step_contents was upserted with the generated content, selections cleared.
    const [content] = await getDb()
      .select()
      .from(stepContents)
      .where(
        and(
          eq(stepContents.projectId, project.id),
          eq(stepContents.step, "brand_context"),
        ),
      );
    expect(content?.content).toEqual(output);
    expect(content?.selections).toBeNull();
  });

  it("does not run a cancelled/superseded job: no throw, stays cancelled", async () => {
    const project = await makeProject();
    const job = await createJob(project.id, "brand_context", {}, null);
    await markCancelled(job.id);

    const runStep = vi.fn().mockResolvedValue({ brandContext: "x" });
    // The claim guard must make the handler bail without throwing or running.
    await expect(handleGenerateJob(job.id, { runStep })).resolves.toBeUndefined();
    expect(runStep).not.toHaveBeenCalled();

    const after = await getJob(job.id);
    expect(after?.status).toBe("cancelled");
    expect(after?.output).toBeNull();
    expect(after?.startedAt).toBeNull();
  });

  it("does not run a missing job and does not throw", async () => {
    await expect(handleGenerateJob(randomUUID())).resolves.toBeUndefined();
  });

  it("marks the job failed with the error text on a processing error", async () => {
    const project = await makeProject();
    const job = await createJob(project.id, "brand_context", {}, null);

    const spy = vi
      .spyOn(jobs, "markSucceeded")
      .mockRejectedValueOnce(new Error("save boom"));
    const runStep = vi.fn().mockResolvedValue({ brandContext: "x" });

    try {
      await expect(handleGenerateJob(job.id, { runStep })).rejects.toThrow(
        "save boom",
      );
    } finally {
      spy.mockRestore();
    }

    const after = await getJob(job.id);
    expect(after?.status).toBe("failed");
    expect(after?.error).toBe("save boom");
    expect(after?.finishedAt).not.toBeNull();
  });

  it("does not upsert step_contents or succeed when cancelled mid-run", async () => {
    const project = await makeProject();
    const job = await createJob(project.id, "brand_context", {}, null);

    // Simulate a concurrent cancel that lands WHILE runStep is in flight: the
    // job is superseded/cancelled during the run, so the markSucceeded guard
    // (status='running') fails and no content is written.
    const runStep = vi.fn().mockImplementation(async () => {
      await markCancelled(job.id);
      return { brandContext: "should not be saved" };
    });

    await expect(handleGenerateJob(job.id, { runStep })).resolves.toBeUndefined();

    const after = await getJob(job.id);
    expect(after?.status).toBe("cancelled");
    expect(after?.output).toBeNull();

    const rows = await getDb()
      .select()
      .from(stepContents)
      .where(
        and(
          eq(stepContents.projectId, project.id),
          eq(stepContents.step, "brand_context"),
        ),
      );
    expect(rows).toHaveLength(0);
  });

  // pg-boss expires an active message after 15 minutes unless told otherwise,
  // and a generation can legitimately run far longer than that. When it does,
  // the queue marks the message failed while the handler is still working and
  // will later write 'succeeded' to generation_jobs — pg-boss's own tables then
  // contradict the durable truth. The send options are where that is decided,
  // so this asserts what is actually sent rather than the constant's shape.
  it("sends the queue message with retries off and an explicit, generous expiry", async () => {
    const project = await makeProject();
    const send = vi.fn(async () => "msg-id");
    const spy = vi
      .spyOn(boss, "getBoss")
      .mockResolvedValue({ send } as unknown as PgBoss);

    try {
      await enqueueGeneration(project.id, "brand_context", { ping: true }, null);
    } finally {
      spy.mockRestore();
    }

    expect(send).toHaveBeenCalledTimes(1);
    // The fake's own signature takes no args, so reach the recorded ones
    // through the call tuple rather than teaching the mock a shape it does not
    // need — what is asserted is what enqueueGeneration PASSED.
    const options = (send.mock.calls[0] as unknown as unknown[])[2] as {
      retryLimit?: number;
      expireInSeconds?: number;
    };
    expect(options.retryLimit).toBe(0);
    // The pg-boss default is 900. Anything at or below it re-opens the bug.
    expect(options.expireInSeconds).toBeGreaterThan(900);
    expect(options.expireInSeconds).toBe(4 * 60 * 60);
  });
});

// Optional end-to-end: enqueue through pg-boss and poll until succeeded.
// Enable with RUN_PGBOSS_TEST=1. Kept opt-in so the default suite stays fast
// and free of pg-boss startup flakiness (see task notes).
describe.skipIf(!runIntegration)("pg-boss round trip", () => {
  afterAll(async () => {
    await stopBoss();
    const db = getDb();
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("supersedes the prior active job only after a successful send", async () => {
    const project = await makeProject();
    // A prior active (queued) job for the same project.
    const prior = await createJob(project.id, "brand_context", {}, null);

    // No worker is registered yet (this test runs before the worker test), so we
    // can observe the queued/cancelled states before anything runs.
    // enqueueGeneration sends first, then supersedes.
    const fresh = await enqueueGeneration(
      project.id,
      "secondary_data",
      { ping: true },
      null,
    );

    // supersede ran after a successful send: the prior job is cancelled and the
    // new job is queued (no worker to advance it).
    expect((await getJob(prior.id))?.status).toBe("cancelled");
    expect((await getJob(fresh.id))?.status).toBe("queued");
  }, 30_000);

  it("enqueue -> worker -> succeeded", async () => {
    const { registerWorker } = await import("./worker");
    await registerWorker();

    const project = await makeProject();
    const job = await enqueueGeneration(
      project.id,
      "brand_context",
      { ping: true },
      null,
    );

    // Poll for terminal state.
    const deadline = Date.now() + 20_000;
    let status = job.status;
    while (Date.now() < deadline) {
      const current = await getJob(job.id);
      status = current?.status ?? status;
      if (status === "succeeded" || status === "failed") break;
      await new Promise((r) => setTimeout(r, 250));
    }
    expect(status).toBe("succeeded");
  }, 30_000);
});
