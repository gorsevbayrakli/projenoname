import { and, eq, inArray, ne, notInArray } from "drizzle-orm";

import { getDb } from "../db/client";
import {
  generationJobs,
  type GenerationJob,
  type WorkflowStep,
} from "../db/schema";

/**
 * Job repository: the honest, durable source of truth for generation jobs.
 * Framework-neutral (no react/next). pg-boss is only the transport; every real
 * status transition is recorded here.
 */

/**
 * `workflow_step` values that are NOT wizard steps and never go through the
 * queue: rows opened purely so a billed LLM call has a `job_id`.
 *
 * Listed here rather than inferred, because the two places that care want
 * opposite things from it: `openSyntheticJob` will only create these, and
 * `supersedeActiveJobs` will only skip these.
 */
export const SYNTHETIC_STEPS = ["platform_cadence"] as const;

export type SyntheticStep = (typeof SYNTHETIC_STEPS)[number];

/**
 * Open a job row for an LLM call made OUTSIDE the queue, and return it.
 *
 * Inserted straight into 'running' with `startedAt` set: it is not queued, so
 * there is nothing to claim and no `markRunning` to run. Close it afterwards
 * with the ordinary `markSucceeded` / `markFailed` — their status guards are
 * satisfied by 'running' and cannot be lost, because `supersedeActiveJobs`
 * skips these steps.
 *
 * Why a row at all: `llm_calls.job_id` is NOT NULL, so a call with no job is a
 * call with no ledger entry — spend that is not merely unpriced but entirely
 * absent, invisible even to the unpriced-call count that the honesty of the
 * whole /spend page rests on.
 */
export async function openSyntheticJob(
  projectId: string,
  step: SyntheticStep,
  input: unknown,
  createdBy: string | null,
): Promise<GenerationJob> {
  const db = getDb();
  const [job] = await db
    .insert(generationJobs)
    .values({
      projectId,
      step,
      input: input ?? {},
      status: "running",
      createdBy,
      startedAt: new Date(),
    })
    .returning();
  return job;
}

/** Insert a new job in the 'queued' state and return the row. */
export async function createJob(
  projectId: string,
  step: WorkflowStep,
  input: unknown,
  createdBy: string | null,
): Promise<GenerationJob> {
  const db = getDb();
  const [job] = await db
    .insert(generationJobs)
    .values({
      projectId,
      step,
      input: input ?? {},
      status: "queued",
      createdBy,
    })
    .returning();
  return job;
}

/**
 * Atomically CLAIM a queued job: transition to 'running' only if it is still
 * 'queued'. Returns the claimed row, or null if nothing was claimed (the row was
 * cancelled/superseded/already-running/not-found). This is the guard that keeps
 * a cancelled or superseded job from ever executing. Clearing error/finishedAt/
 * output on claim also makes a (re)started row carry no stale failure fields.
 */
export async function markRunning(
  jobId: string,
): Promise<GenerationJob | null> {
  const db = getDb();
  const [job] = await db
    .update(generationJobs)
    .set({
      status: "running",
      startedAt: new Date(),
      error: null,
      finishedAt: null,
      output: null,
    })
    .where(and(eq(generationJobs.id, jobId), eq(generationJobs.status, "queued")))
    .returning();
  return job ?? null;
}

/**
 * Transition a RUNNING job to 'succeeded'. Guarded on status='running' so a job
 * cancelled/superseded mid-run cannot be resurrected into 'succeeded' (closes the
 * TOCTOU between the claim and completion). Returns the row, or null if the job
 * was no longer running (e.g. cancelled while the work was in flight).
 */
export async function markSucceeded(
  jobId: string,
  output: unknown,
): Promise<GenerationJob | null> {
  const db = getDb();
  const [job] = await db
    .update(generationJobs)
    .set({ status: "succeeded", output, finishedAt: new Date() })
    .where(
      and(eq(generationJobs.id, jobId), eq(generationJobs.status, "running")),
    )
    .returning();
  return job ?? null;
}

/**
 * Transition an active ('queued' or 'running') job to 'failed'. Guarded so a
 * 'cancelled' (or already-terminal) job is never overwritten with 'failed':
 * a running job that errors AND a queued job that failed to enqueue both become
 * 'failed', but a job cancelled mid-run stays 'cancelled'. Returns the row, or
 * null if nothing transitioned.
 */
export async function markFailed(
  jobId: string,
  errorMessage: string,
): Promise<GenerationJob | null> {
  const db = getDb();
  const [job] = await db
    .update(generationJobs)
    .set({ status: "failed", error: errorMessage, finishedAt: new Date() })
    .where(
      and(
        eq(generationJobs.id, jobId),
        inArray(generationJobs.status, ["queued", "running"]),
      ),
    )
    .returning();
  return job ?? null;
}

/**
 * Transition an active ('queued' or 'running') job to 'cancelled' and stamp
 * finishedAt. Guarded like markFailed, and for the mirror-image reason: a
 * terminal job must not be reopened. Without the predicate this would overwrite
 * a 'succeeded' row with 'cancelled' and move its finishedAt, which turns the
 * rule "a cancelled job can never become succeeded" into a rule that also runs
 * backwards — a finished generation the user already has content for would
 * report itself cancelled. The invariant was previously protected only by the
 * absence of a production caller; it is now protected by the query.
 *
 * Returns the row, or null if nothing transitioned, so a caller can tell
 * whether the cancel actually won — the same contract as the rest of the module.
 */
export async function markCancelled(
  jobId: string,
): Promise<GenerationJob | null> {
  const db = getDb();
  const [job] = await db
    .update(generationJobs)
    .set({ status: "cancelled", finishedAt: new Date() })
    .where(
      and(
        eq(generationJobs.id, jobId),
        inArray(generationJobs.status, ["queued", "running"]),
      ),
    )
    .returning();
  return job ?? null;
}

/** Load a single job by id, or null if it does not exist. */
export async function getJob(jobId: string): Promise<GenerationJob | null> {
  const db = getDb();
  const [job] = await db
    .select()
    .from(generationJobs)
    .where(eq(generationJobs.id, jobId))
    .limit(1);
  return job ?? null;
}

/**
 * Cancel this project's still-active jobs (queued or running), except an
 * optional job to keep. Enforces the "single active job per project" rule when
 * a new job is enqueued.
 *
 * Synthetic rows are exempt. The rule is about queued GENERATIONS competing for
 * the worker; a synthetic row is not queued, is never claimed, and is open only
 * for the duration of a call the user is already being billed for. Cancelling
 * it would write a status into generation_jobs that contradicts work which
 * actually ran.
 */
export async function supersedeActiveJobs(
  projectId: string,
  exceptJobId?: string,
): Promise<void> {
  const db = getDb();
  const activeStatuses = ["queued", "running"] as const;
  const conditions = [
    eq(generationJobs.projectId, projectId),
    inArray(generationJobs.status, [...activeStatuses]),
    notInArray(generationJobs.step, [...SYNTHETIC_STEPS]),
  ];
  if (exceptJobId) {
    conditions.push(ne(generationJobs.id, exceptJobId));
  }
  await db
    .update(generationJobs)
    .set({ status: "cancelled", finishedAt: new Date() })
    .where(and(...conditions));
}
