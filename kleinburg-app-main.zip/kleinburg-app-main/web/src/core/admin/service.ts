/**
 * Directory administration (T40): the super admin's operations for creating
 * brands, creating users, granting/revoking brand membership, and changing an
 * existing user's role.
 *
 * ── THE ONE RULE THIS MODULE MUST NOT BREAK ──────────────────────────────
 * This module crosses the brand boundary on purpose — it is the ONLY module
 * that does. It reads every brand and every user because that is what an
 * admin panel is for. What it deliberately does NOT do is touch a project, a
 * document, a step_content or a generation_job: no query in this file reads a
 * brand's work. `core/tenancy/access.ts` is untouched by T40 and remains the
 * single gate for all of that, with no admin bypass in it.
 *
 * That is a statement about THIS MODULE, not about what an admin can
 * ultimately reach (#40 review, finding 12). `grantBrandAccess` and
 * `setTemporaryPassword` below are both routes to a brand's content — the
 * first by self-granting membership and revoking it afterwards, the second by
 * signing in as the user. Both are still open; what T41 changed is that both
 * now leave a DURABLE record.
 *
 * And since T50 there is a third route that does not pass through this module
 * at all: `core/llm/admin-spend.ts` lets an admin read ANY brand's spend,
 * project names included, with no membership and no round trip. That is
 * Elif's explicit decision, not an oversight, and it is audited the same way
 * (`spend_view_admin`). So the claim this file may make is the narrow one:
 * nothing HERE reads brand content, and no route anywhere reads it QUIETLY.
 * "An admin cannot read brand content" is not a claim this repo makes.
 *
 * ── EVERY FUNCTION HERE IS AUDITED, ATOMICALLY ───────────────────────────
 * Every directory operation here writes an `audit_events` row inside the SAME
 * TRANSACTION as the change they make. If the audit row cannot be written the
 * operation is rolled back and the admin gets an error — deliberately, because
 * an unrecorded membership grant is the exact failure issue #41 exists to
 * prevent, and a grant that did not happen is strictly better than one nobody
 * can see. The reasoning, and why the auth/content paths are best-effort
 * instead, is in core/audit/service.ts.
 *
 * Every exported function takes the ACTING user as its first argument and
 * calls `requireSuperAdmin` on the first line. That ordering is load-bearing:
 * an ordinary user must get AccessError before any lookup happens, so the
 * endpoints cannot be used as an existence oracle for usernames or brands.
 *
 * ── PASSWORD HANDLING ────────────────────────────────────────────────────
 * A plaintext password enters this module as an argument and leaves as an
 * argon2id hash. It is never returned, never logged, never put in an error
 * message, and never written to any row but `users.password_hash`. The user
 * DTOs below omit `passwordHash` structurally, so a route handler cannot leak
 * a hash by spreading a row into a response. (Commit 3d2f1c8: a password that
 * reaches a screen or a log is a password that has to be rotated.)
 */

import { and, asc, count, eq, ne } from "drizzle-orm";

import { recordAuditEventTx } from "../audit/service";
import { hashPassword, MIN_PASSWORD_LENGTH } from "../auth/password";
import { requireSuperAdmin } from "../auth/roles";
import { getDb } from "../db/client";
import {
  brands,
  userBrands,
  users,
  type Brand,
  type User,
} from "../db/schema";
import { ConflictError, NotFoundError, ValidationError } from "../tenancy/errors";

/**
 * The acting user.
 *
 * `username` joined `id`/`role` with T41: every function here writes an audit
 * row naming the actor, and the row snapshots the NAME (see
 * `core/db/schema.ts` on why audit rows carry no foreign keys). Route handlers
 * pass `gate.user`, a freshly validated session row, so the snapshot is
 * current rather than a value the caller invented.
 */
export type Actor = Pick<User, "id" | "role" | "username">;

/**
 * A user as the admin panel sees one. `passwordHash` is absent by
 * construction, not by convention — the only way to leak it is to add it here
 * on purpose.
 */
export interface AdminUser {
  id: string;
  username: string;
  role: User["role"];
  isActive: boolean;
  mustChangePassword: boolean;
  createdAt: Date;
  /** Brands this user is a member of, name-ordered. */
  brands: Brand[];
}

/** Postgres unique_violation SQLSTATE. */
const PG_UNIQUE_VIOLATION = "23505";

function isUniqueViolation(err: unknown): boolean {
  const hasCode = (e: unknown): boolean =>
    typeof e === "object" &&
    e !== null &&
    "code" in e &&
    (e as { code?: unknown }).code === PG_UNIQUE_VIOLATION;
  if (hasCode(err)) return true;
  return err instanceof Error && hasCode(err.cause);
}

function normalizeBrandName(name: string): string {
  const trimmed = name.trim();
  if (trimmed.length === 0) {
    throw new ValidationError("Marka adı boş olamaz", "BRAND_NAME_EMPTY");
  }
  return trimmed;
}

function normalizeUsername(username: string): string {
  const trimmed = username.trim();
  if (trimmed.length === 0) {
    throw new ValidationError("Kullanıcı adı boş olamaz", "USERNAME_EMPTY");
  }
  return trimmed;
}

/**
 * Length check for any password this module stores. The message names the
 * requirement but NEVER the value being rejected — an error string is the
 * shortest path from a password to a log file.
 */
export function assertPasswordAcceptable(password: string): void {
  if (password.length < MIN_PASSWORD_LENGTH) {
    throw new ValidationError(
      `Şifre en az ${MIN_PASSWORD_LENGTH} karakter olmalı`,
      "PASSWORD_TOO_SHORT",
    );
  }
}

// ── Brands ────────────────────────────────────────────────────────────────

/**
 * Every brand in the system, active or not, name-ordered.
 *
 * This is the admin's directory view and is intentionally NOT
 * `listAccessibleBrands`: the admin must see brands they are not a member of,
 * otherwise they could never assign the first user to a new one. It returns
 * brand ROWS only — names and flags — and nothing about a brand's projects.
 */
export async function listAllBrands(actor: Actor): Promise<Brand[]> {
  requireSuperAdmin(actor);
  const db = getDb();
  return db.select().from(brands).orderBy(asc(brands.name));
}

/**
 * Create a brand. Duplicate names are a 409, not a silent no-op.
 *
 * The insert and its audit row share a TRANSACTION (T41). See the "atomic vs
 * best-effort" section of `core/audit/service.ts`: every directory action in
 * this file either happens WITH its record or does not happen.
 */
export async function createBrand(actor: Actor, name: string): Promise<Brand> {
  requireSuperAdmin(actor);
  const trimmed = normalizeBrandName(name);
  const db = getDb();
  try {
    return await db.transaction(async (tx) => {
      const [brand] = await tx
        .insert(brands)
        .values({ name: trimmed })
        .returning();
      await recordAuditEventTx(tx, {
        action: "brand_create",
        actorUserId: actor.id,
        actorUsername: actor.username,
        brandId: brand.id,
        brandName: brand.name,
      });
      return brand;
    });
  } catch (err) {
    if (isUniqueViolation(err)) {
      throw new ConflictError(
        "Bu isimde bir marka zaten var",
        "BRAND_NAME_TAKEN",
      );
    }
    throw err;
  }
}

/**
 * The largest cap that may be typed. `numeric(12,2)` holds ten integer digits,
 * so anything at or above 10^10 would be rejected by the database as an
 * overflow — a 500 pretending to be a user error. This turns it into a 400
 * with a reason, well below the limit, at a figure no monthly bill on this
 * product will ever approach honestly.
 */
export const MAX_MONTHLY_CAP_USD = 1_000_000;

/**
 * Set (or clear) a brand's monthly spend cap — T51, super admin only.
 *
 * `null` REMOVES the cap. It is a distinct outcome from `0`, which is a cap
 * that refuses everything, and the two must not be conflated anywhere: one is
 * "do not measure this brand", the other is "this brand may spend nothing".
 * Both are legitimate things an admin might mean, so both are accepted and
 * both are recorded.
 *
 * ── AUDITED ATOMICALLY, AND WHY THAT MATTERS MORE HERE THAN IT LOOKS ─────
 * The change and its `brand_cap_set` row share a transaction, like every other
 * directory operation in this file. The specific erasure it closes: raise the
 * cap, spend past what was agreed, lower it back. Afterwards `brands` is
 * byte-identical to a database where the cap never moved, and `llm_calls`
 * cannot contradict it because it records what was SPENT, never what was
 * PERMITTED at the time. Without this row that round trip is invisible — the
 * same shape as the grant/read/revoke round trip that opened #41.
 *
 * So the row carries BOTH values. A trail of absolute settings would force a
 * reader to reconstruct the sequence to notice a temporary raise; a row that
 * says "500 -> 100" is legible on its own.
 *
 * ── WHAT IT DELIBERATELY DOES NOT DO ─────────────────────────────────────
 * It does not touch running or queued work. Lowering a cap below what a brand
 * has already spent this month refuses the NEXT job; it does not cancel the
 * current one (#51 item 6). Nor does it validate the cap against what the
 * brand has already spent: setting a cap below current spend is a coherent
 * thing to want ("stop, now"), and refusing it would be the tool arguing with
 * the operator about their own budget.
 */
export async function setBrandMonthlyCap(
  actor: Actor,
  brandId: string,
  capUsd: number | null,
): Promise<Brand> {
  requireSuperAdmin(actor);

  if (capUsd !== null) {
    if (!Number.isFinite(capUsd) || capUsd < 0) {
      throw new ValidationError(
        "Tavan negatif olamaz",
        "BRAND_CAP_INVALID",
      );
    }
    if (capUsd > MAX_MONTHLY_CAP_USD) {
      throw new ValidationError(
        `Tavan en fazla ${MAX_MONTHLY_CAP_USD} USD olabilir`,
        "BRAND_CAP_INVALID",
      );
    }
  }

  // toFixed(2) rather than handing a float to the driver: the column is
  // numeric(12,2) and "50.005" typed into a form should become a stored 50.01
  // here, visibly, rather than being rounded somewhere in the driver where no
  // one can see it happen.
  const stored = capUsd === null ? null : capUsd.toFixed(2);
  // WHAT THE AUDIT ROW IS ABOUT. The comment above wants the rounding to be
  // visible, and the trail is where it used to disappear: the row took the raw
  // input, so submitting 50.004 against a stored "50.00" wrote
  // `direction: "raised", capUsd: 50.004` for a write that changed nothing.
  // An audit trail describing a change that did not happen is worse than no
  // row, because it is the only evidence anyone has. So everything below
  // reports the value that reached the COLUMN.
  const storedCapUsd = stored === null ? null : Number(stored);

  const db = getDb();
  return db.transaction(async (tx) => {
    // Read the previous value inside the transaction, so the "from" in the
    // audit row is the value this update actually replaced and not one another
    // admin overwrote between the read and the write.
    const [before] = await tx
      .select({
        id: brands.id,
        name: brands.name,
        monthlyCapUsd: brands.monthlyCapUsd,
      })
      .from(brands)
      .where(eq(brands.id, brandId))
      .limit(1);
    if (!before) throw new NotFoundError("Marka bulunamadı", "BRAND_NOT_FOUND");

    const [updated] = await tx
      .update(brands)
      .set({ monthlyCapUsd: stored })
      .where(eq(brands.id, brandId))
      .returning();

    await recordAuditEventTx(tx, {
      action: "brand_cap_set",
      actorUserId: actor.id,
      actorUsername: actor.username,
      brandId: updated.id,
      brandName: updated.name,
      metadata: {
        // Numbers, not strings, so a reader can sort and compare them; null is
        // preserved as null because "unlimited" is not the number zero.
        previousCapUsd:
          before.monthlyCapUsd === null ? null : Number(before.monthlyCapUsd),
        capUsd: storedCapUsd,
        // The two words a reader scanning the trail is actually looking for.
        // A raise is the one that needs explaining, so it is named rather than
        // left to be inferred by comparing the pair above.
        direction: describeCapChange(
          before.monthlyCapUsd === null ? null : Number(before.monthlyCapUsd),
          storedCapUsd,
        ),
      },
    });

    return updated;
  });
}

/** How a cap moved, in one word, for the audit row. */
function describeCapChange(from: number | null, to: number | null): string {
  if (from === to) return "unchanged";
  if (from === null) return "set";
  if (to === null) return "removed";
  return to > from ? "raised" : "lowered";
}

// ── Users ─────────────────────────────────────────────────────────────────

/** Every user with their brand memberships. Never includes password hashes. */
export async function listAllUsers(actor: Actor): Promise<AdminUser[]> {
  requireSuperAdmin(actor);
  const db = getDb();

  const rows = await db
    .select({
      id: users.id,
      username: users.username,
      role: users.role,
      isActive: users.isActive,
      mustChangePassword: users.mustChangePassword,
      createdAt: users.createdAt,
    })
    .from(users)
    .orderBy(asc(users.username));

  const memberships = await db
    .select({ userId: userBrands.userId, brand: brands })
    .from(userBrands)
    .innerJoin(brands, eq(userBrands.brandId, brands.id))
    .orderBy(asc(brands.name));

  const byUser = new Map<string, Brand[]>();
  for (const m of memberships) {
    const list = byUser.get(m.userId) ?? [];
    list.push(m.brand);
    byUser.set(m.userId, list);
  }

  return rows.map((r) => ({ ...r, brands: byUser.get(r.id) ?? [] }));
}

/**
 * Create a user with an admin-set temporary password.
 *
 * `mustChangePassword` is forced to true and is NOT a parameter: an admin
 * cannot create an account that skips the first-login change, because the whole
 * point is that the admin knows this password.
 *
 * Returns an AdminUser — no password material of any kind travels back out.
 */
export async function createUser(
  actor: Actor,
  username: string,
  temporaryPassword: string,
  role: User["role"] = "user",
): Promise<AdminUser> {
  requireSuperAdmin(actor);
  const trimmed = normalizeUsername(username);
  assertPasswordAcceptable(temporaryPassword);

  const passwordHash = await hashPassword(temporaryPassword);
  const db = getDb();
  try {
    return await db.transaction(async (tx) => {
      const [row] = await tx
        .insert(users)
        .values({
          username: trimmed,
          passwordHash,
          role,
          mustChangePassword: true,
        })
        .returning({
          id: users.id,
          username: users.username,
          role: users.role,
          isActive: users.isActive,
          mustChangePassword: users.mustChangePassword,
          createdAt: users.createdAt,
        });
      await recordAuditEventTx(tx, {
        action: "user_create",
        actorUserId: actor.id,
        actorUsername: actor.username,
        targetUserId: row.id,
        targetUsername: row.username,
        // The ROLE is recorded because "who made this account an admin" is a
        // question the trail must answer. The temporary password is not, is
        // not passed here, and could not survive `sanitizeAuditMetadata` if it
        // were.
        metadata: { role: row.role },
      });
      return { ...row, brands: [] };
    });
  } catch (err) {
    if (isUniqueViolation(err)) {
      throw new ConflictError(
        "Bu kullanıcı adı zaten kullanılıyor",
        "USERNAME_TAKEN",
      );
    }
    throw err;
  }
}

/**
 * Replace a user's password with a new temporary one and re-arm the
 * first-login change.
 *
 * Existing sessions are deliberately left alone, matching what the `seed
 * set-password` CLI has always done (the sessions table cascades on user
 * delete, not on password change). Changing that here would be a silent
 * regression in behaviour the rest of the system depends on; if forced logout
 * on reset is wanted it should be its own decision, applied in both places.
 */
export async function setTemporaryPassword(
  actor: Actor,
  userId: string,
  temporaryPassword: string,
): Promise<void> {
  requireSuperAdmin(actor);
  assertPasswordAcceptable(temporaryPassword);

  const passwordHash = await hashPassword(temporaryPassword);
  const db = getDb();

  await db.transaction(async (tx) => {
    const updated = await tx
      .update(users)
      .set({ passwordHash, mustChangePassword: true })
      .where(eq(users.id, userId))
      .returning({ id: users.id, username: users.username });

    if (updated.length === 0) {
      throw new NotFoundError("Kullanıcı bulunamadı", "USER_NOT_FOUND");
    }

    // The #40 review's second route into a brand: reset a user's password and
    // sign in as them, reaching content with no membership row at any point.
    // This row is the only thing that makes that route visible afterwards, so
    // it is atomic with the reset — a reset that could not be recorded does
    // not happen.
    await recordAuditEventTx(tx, {
      action: "user_password_reset",
      actorUserId: actor.id,
      actorUsername: actor.username,
      targetUserId: updated[0].id,
      targetUsername: updated[0].username,
    });
  });
}

/**
 * Change an EXISTING user's role — promote to admin, or demote to user (#89).
 *
 * `createUser` could always MINT an admin; nothing could ever change one. So
 * the handover an owner actually performs — promote the successor, step down —
 * meant `psql` on the production database, which is precisely the thing this
 * panel exists to remove.
 *
 * ── THE ONE RULE: NEVER ZERO ADMINS ──────────────────────────────────────
 * A demotion that removes the last active admin is refused. This is not
 * defensive padding; it is the difference between a mis-click and an
 * unrecoverable installation. There is no self-service route back: no
 * role-change endpoint would be reachable (every one of them starts with
 * `requireSuperAdmin`), no page would render the panel, and the only remedy
 * would be a shell on the production database — the exact tool this feature
 * exists to make unnecessary.
 *
 * Counted over ACTIVE admins only, and that qualifier is the whole point. An
 * inactive account cannot sign in — `authenticate` rejects it and
 * `validateSession` returns null for it — so it is not a way back into the
 * panel, and counting one would let the last USABLE admin be demoted while the
 * guard reported everything was fine. A guard that can be satisfied by an
 * account nobody can log into is not a guard.
 *
 * The count is taken INSIDE the transaction, and the check is by COUNT rather
 * than by comparing ids: `actor` is a snapshot passed in by the caller, and "am
 * I the last admin" must be answered by the database.
 *
 * That alone was NOT enough, and the gap is worth stating because it is
 * invisible from the call site. Being in a transaction is not being alone in
 * one. Under READ COMMITTED the count and the update are two statements with
 * two snapshots, so two demotions of two DIFFERENT admins could each count the
 * other as the survivor, each allow itself, and both commit — zero admins, the
 * one outcome with no way back except a shell. The guard now takes a row lock
 * (`FOR UPDATE`) on every active admin BEFORE counting, which forces concurrent
 * demotions to queue rather than to overlap: the second one re-reads, finds
 * itself alone, and is refused. `service.test.ts` proves it with two genuinely
 * overlapping transactions — delete the `.for("update")` and it goes red.
 *
 * ── SELF-DEMOTION IS ALLOWED ─────────────────────────────────────────────
 * Deliberately. Stepping down once a successor exists is the handover path,
 * and refusing it would leave the outgoing owner permanently an admin — the
 * privilege nobody could remove. Only the last-admin rule blocks it, and the
 * row records `selfChange` so the trail says which kind it was.
 *
 * ── A NO-OP WRITES NOTHING ───────────────────────────────────────────────
 * Setting the role a user already has returns them unchanged, with NO update
 * and NO audit row. This deliberately differs from `grantBrandAccess`, which
 * records a re-grant that changed nothing — and the difference is real rather
 * than an inconsistency. A repeated grant leaves the admin HOLDING access to a
 * brand's content whether or not the row was new, so the act is worth
 * recording on its own. Setting a role to its current value confers nothing
 * that was not already true and opens no route to anything. Writing
 * "admin → admin" into a category a reader filters precisely to find privilege
 * changes would be noise at best, and at worst read as a change that never
 * happened.
 *
 * ── WHEN IT TAKES EFFECT: THE NEXT REQUEST ───────────────────────────────
 * Immediately, and nothing here needs to invalidate anything. The role is not
 * carried in the cookie, the session row or any cache: the cookie holds an
 * opaque token, `validateSession` joins `users` on EVERY request and returns
 * that row, and `requireApiAdmin` / the page guards read `role` off it. So a
 * demoted admin with an open tab is refused on their very next request without
 * logging out, and sessions are correctly left alone (as `setTemporaryPassword`
 * leaves them). `service.test.ts` asserts this against a live session rather
 * than trusting the paragraph — if the role were ever copied into `sessions`,
 * that test goes red.
 */
export async function setUserRole(
  actor: Actor,
  userId: string,
  role: User["role"],
): Promise<AdminUser> {
  requireSuperAdmin(actor);
  const db = getDb();

  return db.transaction(async (tx) => {
    const [target] = await tx
      .select({
        id: users.id,
        username: users.username,
        role: users.role,
        isActive: users.isActive,
        mustChangePassword: users.mustChangePassword,
        createdAt: users.createdAt,
      })
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);
    if (!target) {
      throw new NotFoundError("Kullanıcı bulunamadı", "USER_NOT_FOUND");
    }

    // No-op: return the user as they are. See the header — no write, no row.
    if (target.role === role) {
      return { ...target, brands: await brandsOf(tx, target.id) };
    }

    if (target.role === "admin" && role === "user") {
      // ── THE LOCK THAT MAKES THE COUNT BELOW MEAN ANYTHING ───────────────
      // Take a row lock on EVERY active admin before counting them. Without
      // this the guard is a check-then-act across two snapshots, and under
      // READ COMMITTED (Postgres's default, and this app's) two concurrent
      // demotions of two DIFFERENT admins each see the other as "the one who
      // remains", each allow themselves, and both commit — zero admins, which
      // is the single outcome this whole guard exists to prevent, and the one
      // with no way back except a shell on the production database.
      //
      // ALL active admins, target included — not just "the others". The two
      // racing transactions demote different rows, so a lock set that excluded
      // each one's own target would not intersect and they would sail past
      // each other. Locking the whole set is what guarantees they collide.
      //
      // ORDER BY id: two transactions taking the same locks in the same order
      // queue up; in an arbitrary order they can each hold what the other
      // wants and deadlock. Cheap insurance — this set is a handful of rows.
      //
      // The lock is only taken on the demotion path. Promotions add an admin
      // and cannot empty the table, so serialising them would buy nothing.
      await tx
        .select({ id: users.id })
        .from(users)
        .where(and(eq(users.role, "admin"), eq(users.isActive, true)))
        .orderBy(asc(users.id))
        .for("update");

      // Still a COUNT, and still the database's answer rather than the
      // caller's snapshot. What changed is only WHEN it is trustworthy: a
      // concurrent demotion is now either already committed (this statement's
      // snapshot sees it) or still queued behind the locks above (it cannot
      // commit before this transaction ends). There is no third case left.
      const [{ remaining }] = await tx
        .select({ remaining: count() })
        .from(users)
        .where(
          and(
            eq(users.role, "admin"),
            eq(users.isActive, true),
            ne(users.id, target.id),
          ),
        );
      // `target.isActive` matters: demoting an already-inactive admin removes
      // nobody's ability to reach the panel, because they had none.
      if (remaining === 0 && target.isActive) {
        throw new ConflictError(
          "Sistemdeki son yöneticinin yetkisi kaldırılamaz. Önce başka bir kullanıcıyı yönetici yapın.",
          "LAST_ADMIN",
        );
      }
    }

    const [updated] = await tx
      .update(users)
      .set({ role })
      .where(eq(users.id, target.id))
      .returning({
        id: users.id,
        username: users.username,
        role: users.role,
        isActive: users.isActive,
        mustChangePassword: users.mustChangePassword,
        createdAt: users.createdAt,
      });

    await recordAuditEventTx(tx, {
      action: "user_role_change",
      actorUserId: actor.id,
      actorUsername: actor.username,
      targetUserId: updated.id,
      targetUsername: updated.username,
      metadata: {
        // BOTH values, not just the new one. A trail of absolute settings makes
        // a reader reconstruct the sequence to see who granted the privilege;
        // a row that says "user -> admin" is legible on its own.
        previousRole: target.role,
        role: updated.role,
        // The word a reader scanning for "who was made an admin" is looking
        // for, rather than one they have to infer by comparing the pair above.
        direction: role === "admin" ? "promoted" : "demoted",
        // The handover case, named in the row rather than left to be spotted by
        // comparing two uuids (same reasoning as `membership_grant`'s
        // `selfGrant`).
        selfChange: actor.id === updated.id,
      },
    });

    return { ...updated, brands: await brandsOf(tx, updated.id) };
  });
}

/** One user's brands, name-ordered — the `AdminUser.brands` shape. */
async function brandsOf(
  tx: Parameters<Parameters<ReturnType<typeof getDb>["transaction"]>[0]>[0],
  userId: string,
): Promise<Brand[]> {
  const rows = await tx
    .select({ brand: brands })
    .from(userBrands)
    .innerJoin(brands, eq(userBrands.brandId, brands.id))
    .where(eq(userBrands.userId, userId))
    .orderBy(asc(brands.name));
  return rows.map((r) => r.brand);
}

// ── Membership ────────────────────────────────────────────────────────────

/**
 * Grant a user access to a brand — i.e. write the `user_brands` row that
 * `requireProjectAccess` reads. Idempotent.
 *
 * This is the ONE place membership is created from inside the app, which is
 * what keeps the access gate's input auditable: there is no second, invisible
 * route to a brand's data.
 *
 * The check-then-insert runs in a TRANSACTION (#40 review, finding 10). Read
 * and write were previously two independent statements, so a user or brand
 * deleted between them turned a deliberate 404 into a raw foreign-key
 * violation — a 500 pretending to be a user error, which is the exact failure
 * the existence checks exist to prevent. Nothing in the app deletes users or
 * brands today, so this is not reachable yet; it is fixed now because the
 * window is invisible from the call site and will not announce itself when a
 * delete control is added.
 */
export async function grantBrandAccess(
  actor: Actor,
  userId: string,
  brandId: string,
): Promise<void> {
  requireSuperAdmin(actor);
  const db = getDb();

  await db.transaction(async (tx) => {
    // Explicit existence checks: a bad id would otherwise surface as a raw
    // foreign-key violation, which is a 500 pretending to be a user error.
    // They also supply the NAMES the audit row snapshots.
    const [user] = await tx
      .select({ id: users.id, username: users.username })
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);
    if (!user) throw new NotFoundError("Kullanıcı bulunamadı", "USER_NOT_FOUND");

    const [brand] = await tx
      .select({ id: brands.id, name: brands.name })
      .from(brands)
      .where(eq(brands.id, brandId))
      .limit(1);
    if (!brand) throw new NotFoundError("Marka bulunamadı", "BRAND_NOT_FOUND");

    await tx
      .insert(userBrands)
      .values({ userId, brandId })
      .onConflictDoNothing();

    // Inside the transaction, so the membership row and its record commit
    // together. This is THE row T41 exists for: paired with the revoke below
    // it makes an admin's grant -> read -> revoke round trip visible after the
    // fact, which `revokeBrandAccess`'s hard DELETE previously erased.
    //
    // Written even when the insert was a no-op (the user was already a
    // member). A re-grant is a deliberate admin act and the trail records what
    // was DONE, not what changed; suppressing the row when the state already
    // matched would make repeated grants invisible, and "nothing changed" is
    // exactly the cover an attacker would want.
    await recordAuditEventTx(tx, {
      action: "membership_grant",
      actorUserId: actor.id,
      actorUsername: actor.username,
      targetUserId: user.id,
      targetUsername: user.username,
      brandId: brand.id,
      brandName: brand.name,
      // The self-grant is the case the #40 review singled out, so it is called
      // out in the row itself rather than left for a reader to spot by
      // comparing two uuids.
      metadata: { selfGrant: actor.id === user.id },
    });
  });
}

/**
 * Revoke a user's access to a brand. Idempotent.
 *
 * Still a hard DELETE of the `user_brands` row — but no longer a hard delete
 * of the FACT (T41). The membership row goes; the `membership_revoke` audit
 * row stays, in a table that cannot be updated or deleted. So the database can
 * now distinguish "was granted access and it was revoked" from "was never
 * granted access", which is the specific claim #40's review found to be false
 * (finding 12) and the reason issue #41 was opened.
 *
 * The delete and the record share a TRANSACTION. If the audit row cannot be
 * written the revoke is rolled back, because a revoke that erases the
 * membership without leaving evidence is the exact shape of the problem being
 * fixed.
 *
 * The lookups run BEFORE the delete on purpose: afterwards the membership row
 * is gone, and with it any way to name what was revoked.
 */
export async function revokeBrandAccess(
  actor: Actor,
  userId: string,
  brandId: string,
): Promise<void> {
  requireSuperAdmin(actor);
  const db = getDb();

  await db.transaction(async (tx) => {
    const [user] = await tx
      .select({ id: users.id, username: users.username })
      .from(users)
      .where(eq(users.id, userId))
      .limit(1);
    const [brand] = await tx
      .select({ id: brands.id, name: brands.name })
      .from(brands)
      .where(eq(brands.id, brandId))
      .limit(1);

    const deleted = await tx
      .delete(userBrands)
      .where(
        and(eq(userBrands.userId, userId), eq(userBrands.brandId, brandId)),
      )
      .returning({ userId: userBrands.userId });

    // Unlike grant, the existence checks are NOT turned into 404s: revoke has
    // always been idempotent and callers rely on that. A revoke of something
    // that was not there is still recorded, with `removedMembership: false` so
    // a reader can tell the difference between an effective revoke and a
    // no-op. Names fall back to the raw id when the row is already gone —
    // a uuid is a worse record than a name, and far better than no record.
    await recordAuditEventTx(tx, {
      action: "membership_revoke",
      actorUserId: actor.id,
      actorUsername: actor.username,
      targetUserId: userId,
      targetUsername: user?.username ?? null,
      brandId,
      brandName: brand?.name ?? null,
      metadata: {
        selfRevoke: actor.id === userId,
        removedMembership: deleted.length > 0,
      },
    });
  });
}
