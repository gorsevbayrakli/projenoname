/**
 * The ATOMIC half of the audit trail, tested rather than asserted (#41 review,
 * finding 5).
 *
 * `core/audit/service.ts` makes a strong claim about the directory category:
 * the audit row is written inside the SAME TRANSACTION as the action, so "if
 * the row cannot be written, the action is rolled back". The claim was correct
 * in the code and completely untested — nothing anywhere proved that a failing
 * audit write actually undoes the brand, the user or the membership. A promise
 * of that weight held up only by reading the source is one refactor away from
 * quietly becoming false: move the `recordAuditEventTx` call outside the
 * `db.transaction` callback and every existing test still passes.
 *
 * So: inject a writer that throws, and assert the row did NOT land.
 *
 * The audit module is mocked instead of, say, breaking the table, because the
 * table CANNOT be broken on demand — it has no DELETE path and dropping the
 * trigger to simulate an outage would be the tampering the design forbids.
 * `recordAuditEventTx` is the exact seam the atomicity claim is made about, so
 * failing it is the faithful simulation of "the audit write failed".
 */
import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";
import { and, eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import { brands, userBrands, users } from "../db/schema";
import { hashPassword } from "../auth/password";

import { hasDb } from "@/test/db-gate";

/** Flipped by each test; the mock below reads it at call time. */
let auditWriteFails = false;

const AUDIT_DOWN = "audit writer is down";

vi.mock("../audit/service", async (importOriginal) => {
  const actual =
    await importOriginal<typeof import("../audit/service")>();
  return {
    ...actual,
    recordAuditEventTx: async (
      ...args: Parameters<typeof actual.recordAuditEventTx>
    ) => {
      if (auditWriteFails) throw new Error(AUDIT_DOWN);
      return actual.recordAuditEventTx(...args);
    },
  };
});

const { createBrand, createUser, grantBrandAccess, setUserRole } = await import(
  "./service",
);
type Actor = import("./service").Actor;

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

const TEMP = "gecici-sifre-2026";

async function makeAdmin(): Promise<Actor> {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({
      username: `t41-rb-${randomUUID()}`,
      passwordHash: await hashPassword(TEMP),
      role: "admin",
    })
    .returning();
  createdUserIds.push(user.id);
  return { id: user.id, role: user.role, username: user.username };
}

async function makeBrand() {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: `t41-rb-brand-${randomUUID()}` })
    .returning();
  createdBrandIds.push(brand.id);
  return brand;
}

describe.skipIf(!hasDb)("directory actions roll back when the audit write fails", () => {
  beforeAll(() => {
    getDb();
  });

  beforeEach(() => {
    auditWriteFails = false;
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("createBrand: no brand row survives a failed audit write", async () => {
    const admin = await makeAdmin();
    const name = `t41-rb-rollback-${randomUUID()}`;

    auditWriteFails = true;
    await expect(createBrand(admin, name)).rejects.toThrow(AUDIT_DOWN);

    const rows = await getDb().select().from(brands).where(eq(brands.name, name));
    expect(rows).toHaveLength(0);
  });

  it("createUser: no user row survives a failed audit write", async () => {
    const admin = await makeAdmin();
    const username = `t41-rb-user-${randomUUID()}`;

    auditWriteFails = true;
    await expect(createUser(admin, username, TEMP)).rejects.toThrow(AUDIT_DOWN);

    const rows = await getDb()
      .select()
      .from(users)
      .where(eq(users.username, username));
    expect(rows).toHaveLength(0);
  });

  it("grantBrandAccess: no membership row survives a failed audit write", async () => {
    // The row this whole issue exists for. An unaudited membership grant is
    // strictly worse than no grant, so this is the assertion that matters most.
    const admin = await makeAdmin();
    const brand = await makeBrand();

    auditWriteFails = true;
    await expect(grantBrandAccess(admin, admin.id, brand.id)).rejects.toThrow(
      AUDIT_DOWN,
    );

    const rows = await getDb()
      .select()
      .from(userBrands)
      .where(
        and(eq(userBrands.userId, admin.id), eq(userBrands.brandId, brand.id)),
      );
    expect(rows).toHaveLength(0);
  });

  it("setUserRole: the role change does not survive a failed audit write", async () => {
    // A privilege change is the one this matters most for after the grant: an
    // admin created with no record is an admin nobody can account for.
    const admin = await makeAdmin();
    const target = await makeAdmin();

    auditWriteFails = true;
    await expect(setUserRole(admin, target.id, "user")).rejects.toThrow(
      AUDIT_DOWN,
    );

    const [row] = await getDb()
      .select({ role: users.role })
      .from(users)
      .where(eq(users.id, target.id));
    expect(row.role).toBe("admin");
  });

  it("commits both together when the audit write succeeds", async () => {
    // The other half: without this, a test that always rolled back would pass
    // even if the action never worked at all.
    const admin = await makeAdmin();
    const brand = await makeBrand();

    await grantBrandAccess(admin, admin.id, brand.id);

    const rows = await getDb()
      .select()
      .from(userBrands)
      .where(
        and(eq(userBrands.userId, admin.id), eq(userBrands.brandId, brand.id)),
      );
    expect(rows).toHaveLength(1);
  });
});
