/**
 * T40 admin service — and, more importantly, the proof that adding an admin
 * panel did not put a hole in CLAUDE.md hard rule 2.
 *
 * Three distinct claims are tested here:
 *
 *  1. Every admin operation refuses an ordinary user (AccessError /
 *     ADMIN_REQUIRED), and refuses BEFORE it looks anything up — so the
 *     endpoints cannot be used to probe for usernames or brand names.
 *  2. The super admin's boundary crossing is exactly as wide as intended: it
 *     reaches the DIRECTORY (all brands, all users) and stops dead at brand
 *     CONTENT. An admin who is not a member of a brand gets the same
 *     AccessError from requireProjectAccess as anybody else.
 *  3. No admin path returns password material.
 */
import { randomUUID } from "node:crypto";
import { setTimeout as sleep } from "node:timers/promises";
import { afterAll, afterEach, beforeAll, describe, expect, it } from "vitest";
import { and, desc, eq, inArray } from "drizzle-orm";
import { Pool } from "pg";

import { hashPassword, verifyPassword } from "../auth/password";
import { createSession, validateSession } from "../auth/session";
import { closeDb, getDb } from "../db/client";
import { auditEvents, brands, projects, userBrands, users } from "../db/schema";
import { requireBrandAccess, requireProjectAccess } from "../tenancy/access";
import { listProjects } from "../tenancy/projects";
import { AccessError, ConflictError, NotFoundError, ValidationError } from "../tenancy/errors";
import {
  createBrand,
  createUser,
  grantBrandAccess,
  listAllBrands,
  listAllUsers,
  revokeBrandAccess,
  setTemporaryPassword,
  setUserRole,
  type Actor,
  type AdminUser,
} from "./service";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

/** A password comfortably over MIN_PASSWORD_LENGTH. */
const TEMP = "gecici-sifre-2026";

async function makeUser(role: "admin" | "user" = "user") {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({
      username: `t40-${randomUUID()}`,
      passwordHash: await hashPassword(TEMP),
      role,
    })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

async function makeBrand(opts: { isActive?: boolean } = {}) {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: `t40-brand-${randomUUID()}`, isActive: opts.isActive ?? true })
    .returning();
  createdBrandIds.push(brand.id);
  return brand;
}

async function makeProject(brandId: string, createdBy: string) {
  const db = getDb();
  const [project] = await db
    .insert(projects)
    .values({ brandId, name: `t40-proj-${randomUUID()}`, createdBy })
    .returning();
  return project;
}

function track<T extends { id: string }>(user: T): T {
  createdUserIds.push(user.id);
  return user;
}
function trackBrand<T extends { id: string }>(brand: T): T {
  createdBrandIds.push(brand.id);
  return brand;
}

describe.skipIf(!hasDb)("admin/service", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  // ── 1. Authorization ───────────────────────────────────────────────────

  describe("refuses every operation to a non-admin", () => {
    /**
     * Table-driven on purpose: a new admin operation added without a
     * requireSuperAdmin call is the exact failure this file exists to catch,
     * and a list is the cheapest place to notice one is missing.
     */
    const ordinary: Actor = { id: randomUUID(), role: "user", username: "siradan-kullanici" };

    it("listAllBrands", async () => {
      await expect(listAllBrands(ordinary)).rejects.toBeInstanceOf(AccessError);
    });

    it("createBrand", async () => {
      await expect(createBrand(ordinary, "Yeni Marka")).rejects.toBeInstanceOf(
        AccessError,
      );
    });

    it("listAllUsers", async () => {
      await expect(listAllUsers(ordinary)).rejects.toBeInstanceOf(AccessError);
    });

    it("createUser", async () => {
      await expect(
        createUser(ordinary, `x-${randomUUID()}`, TEMP),
      ).rejects.toBeInstanceOf(AccessError);
    });

    it("setTemporaryPassword", async () => {
      await expect(
        setTemporaryPassword(ordinary, randomUUID(), TEMP),
      ).rejects.toBeInstanceOf(AccessError);
    });

    it("grantBrandAccess", async () => {
      await expect(
        grantBrandAccess(ordinary, randomUUID(), randomUUID()),
      ).rejects.toBeInstanceOf(AccessError);
    });

    it("revokeBrandAccess", async () => {
      await expect(
        revokeBrandAccess(ordinary, randomUUID(), randomUUID()),
      ).rejects.toBeInstanceOf(AccessError);
    });

    it("setUserRole", async () => {
      await expect(
        setUserRole(ordinary, randomUUID(), "admin"),
      ).rejects.toBeInstanceOf(AccessError);
    });

    it("carries the ADMIN_REQUIRED code, so the UI can say why", async () => {
      await expect(listAllBrands(ordinary)).rejects.toMatchObject({
        code: "ADMIN_REQUIRED",
      });
    });
  });

  /**
   * The role check must come before any database lookup. If createBrand
   * validated the name first, a non-admin could tell an existing brand name
   * from a free one by the error code they got back.
   */
  it("checks the role BEFORE validating input (no existence oracle)", async () => {
    const ordinary: Actor = { id: randomUUID(), role: "user", username: "siradan-kullanici" };
    const existing = await makeBrand();

    // An empty name would be BRAND_NAME_EMPTY; a taken name BRAND_NAME_TAKEN.
    // A non-admin must get ADMIN_REQUIRED for both — indistinguishable.
    await expect(createBrand(ordinary, "")).rejects.toMatchObject({
      code: "ADMIN_REQUIRED",
    });
    await expect(createBrand(ordinary, existing.name)).rejects.toMatchObject({
      code: "ADMIN_REQUIRED",
    });
  });

  /** A non-admin must not be able to grant themselves a brand. */
  it("a non-admin cannot grant themselves access to a brand", async () => {
    const attacker = await makeUser("user");
    const victimBrand = await makeBrand();

    await expect(
      grantBrandAccess({ id: attacker.id, role: "user", username: attacker.username }, attacker.id, victimBrand.id),
    ).rejects.toBeInstanceOf(AccessError);

    // And the grant really did not happen.
    const db = getDb();
    const rows = await db
      .select()
      .from(userBrands)
      .where(eq(userBrands.userId, attacker.id));
    expect(rows).toHaveLength(0);
    await expect(
      requireBrandAccess(attacker.id, victimBrand.id),
    ).rejects.toBeInstanceOf(AccessError);
  });

  // ── 2. The shape of the admin's boundary crossing ──────────────────────

  it("the admin DOES see every brand, including ones they are not a member of", async () => {
    const admin = await makeUser("admin");
    const foreign = await makeBrand();

    const all = await listAllBrands({ id: admin.id, role: "admin", username: admin.username });
    expect(all.map((b) => b.id)).toContain(foreign.id);
  });

  /**
   * THE test, and it is about the ACCESS GATE rather than about the product.
   * `core/tenancy/access.ts` has no admin branch — T40 did not add one and #50
   * did not either — so an admin who is not a member of a brand is refused its
   * projects by that gate exactly like any other stranger.
   *
   * The product-level boundary is narrower than this test looks. #50 gave the
   * super admin every brand's SPEND, project names included, without
   * membership, through `core/llm/admin-spend.ts`; and an admin can still
   * reach content by granting themselves membership or by resetting a user's
   * password. All three are audited. So the true statement is that the gate
   * does not know about roles, not that an admin cannot get in — see
   * `core/auth/roles.ts` for the full list of routes.
   */
  it("the admin is REFUSED another brand's project content", async () => {
    const admin = await makeUser("admin");
    const member = await makeUser("user");
    const brand = await makeBrand();
    const db = getDb();
    await db.insert(userBrands).values({ userId: member.id, brandId: brand.id });
    const project = await makeProject(brand.id, member.id);

    // The admin can see that the brand exists...
    const all = await listAllBrands({ id: admin.id, role: "admin", username: admin.username });
    expect(all.map((b) => b.id)).toContain(brand.id);

    // ...and is still refused its project content BY THESE GATES. (Not the
    // same as "cannot read anything inside it": spend is reachable by role
    // since #50, and membership is one click away. See the block comment.)
    await expect(
      requireProjectAccess(admin.id, project.id),
    ).rejects.toBeInstanceOf(AccessError);
    await expect(
      requireBrandAccess(admin.id, brand.id),
    ).rejects.toBeInstanceOf(AccessError);
    await expect(listProjects(admin.id, brand.id)).rejects.toBeInstanceOf(
      AccessError,
    );
  });

  /**
   * The deliberate route in: the admin grants themselves membership, which
   * writes a user_brands row. Access follows from the row, never from the
   * role.
   *
   * Note what this does and does NOT prove (#40 review, finding 12). It proves
   * the row must exist WHILE the admin is reading. It does not prove the visit
   * is auditable: `revokeBrandAccess` hard-deletes the row and there is no
   * audit table, so afterwards nothing distinguishes this from a brand that
   * was never opened. Issue #41 is what makes the evidence durable.
   */
  it("an admin reaches a brand's content only by granting themselves membership", async () => {
    const admin = await makeUser("admin");
    const brand = await makeBrand();
    const project = await makeProject(brand.id, admin.id);
    const actor: Actor = { id: admin.id, role: "admin", username: admin.username };

    await expect(
      requireProjectAccess(admin.id, project.id),
    ).rejects.toBeInstanceOf(AccessError);

    await grantBrandAccess(actor, admin.id, brand.id);

    // Now it works — and the reason is a visible row, not a hidden role check.
    const { project: got } = await requireProjectAccess(admin.id, project.id);
    expect(got.id).toBe(project.id);

    const db = getDb();
    const evidence = await db
      .select()
      .from(userBrands)
      .where(eq(userBrands.userId, admin.id));
    expect(evidence).toHaveLength(1);

    // And revoking takes it away again.
    await revokeBrandAccess(actor, admin.id, brand.id);
    await expect(
      requireProjectAccess(admin.id, project.id),
    ).rejects.toBeInstanceOf(AccessError);
  });

  /**
   * A user created through the panel starts with access to NOTHING. The panel
   * cannot accidentally mint an account that can see every brand.
   */
  it("a newly created user can reach no brand at all", async () => {
    const admin = await makeUser("admin");
    const brand = await makeBrand();
    await makeProject(brand.id, admin.id);

    const created = track(
      await createUser({ id: admin.id, role: "admin", username: admin.username }, `t40-${randomUUID()}`, TEMP),
    );

    expect(created.brands).toEqual([]);
    await expect(
      requireBrandAccess(created.id, brand.id),
    ).rejects.toBeInstanceOf(AccessError);
  });

  /** A grant to brand A must not leak brand B. */
  it("a grant is scoped to exactly one brand", async () => {
    const admin = await makeUser("admin");
    const actor: Actor = { id: admin.id, role: "admin", username: admin.username };
    const brandA = trackBrand(await createBrand(actor, `A-${randomUUID()}`));
    const brandB = trackBrand(await createBrand(actor, `B-${randomUUID()}`));
    const user = track(
      await createUser(actor, `t40-${randomUUID()}`, TEMP),
    );
    const projectB = await makeProject(brandB.id, admin.id);

    await grantBrandAccess(actor, user.id, brandA.id);

    expect((await requireBrandAccess(user.id, brandA.id)).id).toBe(brandA.id);
    await expect(requireBrandAccess(user.id, brandB.id)).rejects.toBeInstanceOf(
      AccessError,
    );
    await expect(
      requireProjectAccess(user.id, projectB.id),
    ).rejects.toBeInstanceOf(AccessError);
  });

  // ── 3. Password material never comes back out ──────────────────────────

  it("createUser returns no password material", async () => {
    const admin = await makeUser("admin");
    const created = track(
      await createUser({ id: admin.id, role: "admin", username: admin.username }, `t40-${randomUUID()}`, TEMP),
    );

    const serialised = JSON.stringify(created);
    expect(serialised).not.toContain(TEMP);
    expect(serialised).not.toContain("argon2");
    expect(created).not.toHaveProperty("passwordHash");
  });

  it("listAllUsers returns no password hashes", async () => {
    const admin = await makeUser("admin");
    const list = await listAllUsers({ id: admin.id, role: "admin", username: admin.username });

    expect(list.length).toBeGreaterThan(0);
    for (const u of list) {
      expect(u).not.toHaveProperty("passwordHash");
    }
    expect(JSON.stringify(list)).not.toContain("argon2");
  });

  it("a validation error never contains the password itself", async () => {
    const admin = await makeUser("admin");
    try {
      await createUser({ id: admin.id, role: "admin", username: admin.username }, `t40-${randomUUID()}`, "kisa");
      throw new Error("expected a length rejection");
    } catch (e) {
      expect(e).toBeInstanceOf(ValidationError);
      expect((e as ValidationError).code).toBe("PASSWORD_TOO_SHORT");
      expect((e as Error).message).not.toContain("kisa");
    }
  });

  // ── Behaviour ──────────────────────────────────────────────────────────

  it("createUser stores a working hash and forces a first-login change", async () => {
    const admin = await makeUser("admin");
    const created = track(
      await createUser({ id: admin.id, role: "admin", username: admin.username }, `t40-${randomUUID()}`, TEMP),
    );

    expect(created.mustChangePassword).toBe(true);

    const db = getDb();
    const [row] = await db
      .select()
      .from(users)
      .where(eq(users.id, created.id));
    expect(await verifyPassword(TEMP, row.passwordHash)).toBe(true);
    expect(row.passwordHash).not.toContain(TEMP);
  });

  it("createUser rejects a duplicate username with a 409-shaped error", async () => {
    const admin = await makeUser("admin");
    const actor: Actor = { id: admin.id, role: "admin", username: admin.username };
    const name = `t40-${randomUUID()}`;
    track(await createUser(actor, name, TEMP));

    await expect(createUser(actor, name, TEMP)).rejects.toMatchObject({
      code: "USERNAME_TAKEN",
    });
    await expect(createUser(actor, name, TEMP)).rejects.toBeInstanceOf(
      ConflictError,
    );
  });

  it("createBrand rejects duplicates and empty names", async () => {
    const admin = await makeUser("admin");
    const actor: Actor = { id: admin.id, role: "admin", username: admin.username };
    const name = `t40-brand-${randomUUID()}`;
    trackBrand(await createBrand(actor, name));

    await expect(createBrand(actor, name)).rejects.toMatchObject({
      code: "BRAND_NAME_TAKEN",
    });
    await expect(createBrand(actor, "   ")).rejects.toMatchObject({
      code: "BRAND_NAME_EMPTY",
    });
  });

  it("setTemporaryPassword re-arms the forced change", async () => {
    const admin = await makeUser("admin");
    const actor: Actor = { id: admin.id, role: "admin", username: admin.username };
    const user = track(await createUser(actor, `t40-${randomUUID()}`, TEMP));

    const db = getDb();
    await db
      .update(users)
      .set({ mustChangePassword: false })
      .where(eq(users.id, user.id));

    const next = "yeni-gecici-sifre-2026";
    await setTemporaryPassword(actor, user.id, next);

    const [row] = await db.select().from(users).where(eq(users.id, user.id));
    expect(row.mustChangePassword).toBe(true);
    expect(await verifyPassword(next, row.passwordHash)).toBe(true);
  });

  it("setTemporaryPassword reports a missing user honestly", async () => {
    const admin = await makeUser("admin");
    await expect(
      setTemporaryPassword({ id: admin.id, role: "admin", username: admin.username }, randomUUID(), TEMP),
    ).rejects.toBeInstanceOf(NotFoundError);
  });

  it("grantBrandAccess is idempotent and reports bad ids", async () => {
    const admin = await makeUser("admin");
    const actor: Actor = { id: admin.id, role: "admin", username: admin.username };
    const user = track(await createUser(actor, `t40-${randomUUID()}`, TEMP));
    const brand = await makeBrand();

    await grantBrandAccess(actor, user.id, brand.id);
    await grantBrandAccess(actor, user.id, brand.id); // no throw

    const db = getDb();
    const rows = await db
      .select()
      .from(userBrands)
      .where(eq(userBrands.userId, user.id));
    expect(rows).toHaveLength(1);

    await expect(
      grantBrandAccess(actor, randomUUID(), brand.id),
    ).rejects.toMatchObject({ code: "USER_NOT_FOUND" });
    await expect(
      grantBrandAccess(actor, user.id, randomUUID()),
    ).rejects.toMatchObject({ code: "BRAND_NOT_FOUND" });
  });

  it("listAllUsers reports each user's memberships", async () => {
    const admin = await makeUser("admin");
    const actor: Actor = { id: admin.id, role: "admin", username: admin.username };
    const user = track(await createUser(actor, `t40-${randomUUID()}`, TEMP));
    const brand = await makeBrand();
    await grantBrandAccess(actor, user.id, brand.id);

    const list = await listAllUsers(actor);
    const found = list.find((u) => u.id === user.id)!;
    expect(found.brands.map((b) => b.id)).toEqual([brand.id]);
  });

  // ── setUserRole ────────────────────────────────────────────────────────

  /**
   * Changing an EXISTING user's role. The half `createUser` never covered:
   * the panel could mint an admin but never promote or demote one, so a
   * handover meant a shell.
   *
   * The last-admin guard is global by nature — it counts every active admin in
   * the installation — which means it cannot be tested against a database that
   * already contains other admins (the seeded one, and every admin the tests
   * above create). So the block below QUARANTINES them: every active admin
   * that is not this test's own is deactivated for the duration and restored
   * in `afterEach`, whatever happens. Restoring in a finally-shaped hook is not
   * politeness; a crashed test that left the seeded admin inactive would lock
   * the developer out of their own dev panel, which is the very failure this
   * feature is about.
   */
  describe("setUserRole", () => {
    /** Admins that existed before this block and were parked for its duration. */
    let quarantined: string[] = [];

    async function quarantineOtherAdmins(keep: string[]): Promise<void> {
      const db = getDb();
      const others = await db
        .select({ id: users.id })
        .from(users)
        .where(and(eq(users.role, "admin"), eq(users.isActive, true)));
      quarantined = others.map((o) => o.id).filter((id) => !keep.includes(id));
      if (quarantined.length > 0) {
        await db
          .update(users)
          .set({ isActive: false })
          .where(inArray(users.id, quarantined));
      }
    }

    afterEach(async () => {
      if (quarantined.length > 0) {
        await getDb()
          .update(users)
          .set({ isActive: true })
          .where(inArray(users.id, quarantined));
        quarantined = [];
      }
    });

    /** The newest audit row about this user, or undefined. */
    async function lastRoleChangeRow(targetUserId: string) {
      const [row] = await getDb()
        .select()
        .from(auditEvents)
        .where(
          and(
            eq(auditEvents.action, "user_role_change"),
            eq(auditEvents.targetUserId, targetUserId),
          ),
        )
        .orderBy(desc(auditEvents.occurredAt))
        .limit(1);
      return row;
    }

    it("promotes a user, and the audit row names BOTH the old and the new role", async () => {
      const admin = await makeUser("admin");
      const actor: Actor = { id: admin.id, role: "admin", username: admin.username };
      const target = await makeUser("user");

      const updated = await setUserRole(actor, target.id, "admin");
      expect(updated.role).toBe("admin");

      const [row] = await getDb()
        .select({ role: users.role })
        .from(users)
        .where(eq(users.id, target.id));
      expect(row.role).toBe("admin");

      // "an admin changed a role" without the direction is not worth
      // recording: a trail of absolute settings forces a reader to reconstruct
      // the sequence to see who granted the privilege.
      const audit = await lastRoleChangeRow(target.id);
      expect(audit).toBeDefined();
      expect(audit.actorUserId).toBe(admin.id);
      expect(audit.targetUsername).toBe(target.username);
      expect(audit.metadata).toMatchObject({
        previousRole: "user",
        role: "admin",
        direction: "promoted",
        selfChange: false,
      });
    });

    it("demotes an admin while another admin remains", async () => {
      const actorAdmin = await makeUser("admin");
      const target = await makeUser("admin");
      const actor: Actor = {
        id: actorAdmin.id,
        role: "admin",
        username: actorAdmin.username,
      };
      await quarantineOtherAdmins([actorAdmin.id, target.id]);

      const updated = await setUserRole(actor, target.id, "user");
      expect(updated.role).toBe("user");

      const audit = await lastRoleChangeRow(target.id);
      expect(audit.metadata).toMatchObject({
        previousRole: "admin",
        role: "user",
        direction: "demoted",
      });
    });

    it("REFUSES to demote the last remaining admin", async () => {
      // The mis-click that turns an install into a shell job: nobody left who
      // can reach the panel to undo it.
      const onlyAdmin = await makeUser("admin");
      const actor: Actor = {
        id: onlyAdmin.id,
        role: "admin",
        username: onlyAdmin.username,
      };
      await quarantineOtherAdmins([onlyAdmin.id]);

      await expect(
        setUserRole(actor, onlyAdmin.id, "user"),
      ).rejects.toMatchObject({ code: "LAST_ADMIN" });
      await expect(
        setUserRole(actor, onlyAdmin.id, "user"),
      ).rejects.toBeInstanceOf(ConflictError);

      // Refused means UNCHANGED, not "refused and changed anyway".
      const [row] = await getDb()
        .select({ role: users.role })
        .from(users)
        .where(eq(users.id, onlyAdmin.id));
      expect(row.role).toBe("admin");

      expect(await lastRoleChangeRow(onlyAdmin.id)).toBeUndefined();
    });

    it("ALLOWS self-demotion once another admin remains (the handover path)", async () => {
      // Promote the successor, then step down. Only the last-admin rule blocks
      // a self-demotion; being the actor does not.
      const outgoing = await makeUser("admin");
      const actor: Actor = {
        id: outgoing.id,
        role: "admin",
        username: outgoing.username,
      };
      const successor = await makeUser("user");
      await quarantineOtherAdmins([outgoing.id, successor.id]);

      await expect(
        setUserRole(actor, outgoing.id, "user"),
      ).rejects.toMatchObject({ code: "LAST_ADMIN" });

      await setUserRole(actor, successor.id, "admin");
      const updated = await setUserRole(actor, outgoing.id, "user");

      expect(updated.role).toBe("user");
      const audit = await lastRoleChangeRow(outgoing.id);
      expect(audit.metadata).toMatchObject({
        previousRole: "admin",
        role: "user",
        selfChange: true,
      });
    });

    it("does not count an INACTIVE admin as a remaining admin", async () => {
      // An inactive account cannot sign in (`validateSession` and
      // `authenticate` both reject it), so it is not a way back into the
      // panel. Counting it would let the last USABLE admin be demoted.
      const onlyAdmin = await makeUser("admin");
      const actor: Actor = {
        id: onlyAdmin.id,
        role: "admin",
        username: onlyAdmin.username,
      };
      const parkedAdmin = await makeUser("admin");
      await getDb()
        .update(users)
        .set({ isActive: false })
        .where(eq(users.id, parkedAdmin.id));
      await quarantineOtherAdmins([onlyAdmin.id, parkedAdmin.id]);

      await expect(
        setUserRole(actor, onlyAdmin.id, "user"),
      ).rejects.toMatchObject({ code: "LAST_ADMIN" });
    });

    it("writes NO audit row when the role is already what was asked for", async () => {
      const admin = await makeUser("admin");
      const actor: Actor = { id: admin.id, role: "admin", username: admin.username };
      const target = await makeUser("user");

      const before = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.targetUserId, target.id));

      const updated = await setUserRole(actor, target.id, "user");
      expect(updated.role).toBe("user");

      const after = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.targetUserId, target.id));
      expect(after).toHaveLength(before.length);
    });

    it("reports a missing user honestly", async () => {
      const admin = await makeUser("admin");
      await expect(
        setUserRole(
          { id: admin.id, role: "admin", username: admin.username },
          randomUUID(),
          "admin",
        ),
      ).rejects.toMatchObject({ code: "USER_NOT_FOUND" });
    });

    /**
     * The claim a role change lives or dies by: it takes effect on the NEXT
     * REQUEST, not at the next sign-in. If the role were carried in the
     * session or any cache, a demoted admin would keep admin powers with an
     * open tab and the operator would believe the demotion worked.
     *
     * `validateSession` joins `users` on every call and returns that row, so
     * the role is read live. This test is what stops that from silently
     * becoming false — swap the join for a value copied into `sessions` and it
     * goes red.
     */
    it("a demoted admin's EXISTING session reports the new role immediately", async () => {
      const actorAdmin = await makeUser("admin");
      const actor: Actor = {
        id: actorAdmin.id,
        role: "admin",
        username: actorAdmin.username,
      };
      const target = await makeUser("admin");
      await quarantineOtherAdmins([actorAdmin.id, target.id]);

      // A session opened while they were still an admin.
      const { token } = await createSession(target.id);
      expect((await validateSession(token))?.user.role).toBe("admin");

      await setUserRole(actor, target.id, "user");

      // Same token, no re-login: the very next request already sees "user".
      expect((await validateSession(token))?.user.role).toBe("user");
    });

    /**
     * THE RACE. Two demotions running at the same time must not BOTH pass the
     * last-admin guard — the outcome that guard exists to make impossible.
     *
     * Under READ COMMITTED, a count and an update are two statements with two
     * snapshots. Two transactions demoting two DIFFERENT admins each count the
     * other one as "the admin who remains", each concludes it is safe, and both
     * commit: zero admins, nobody who can reach the panel, back to a shell on
     * the production database.
     *
     * ── WHY THIS TEST IS SHAPED THE WAY IT IS ────────────────────────────
     * Calling `setUserRole` twice in a row would pass against the broken code,
     * because sequential calls never overlap. The window only exists while one
     * transaction is OPEN and another runs inside it, so the test has to hold
     * one open on purpose.
     *
     * A THIRD connection (`probe`, its own pool — the service's pool hands each
     * transaction a connection of its own and we must not take one from it)
     * pins `a`'s row with `FOR UPDATE`. That is the pause button: it stops
     * whichever statement first needs `a`, and it stops it at a different point
     * depending on whether the fix is in.
     *
     *   BROKEN: p1 counts (sees `b`, allows itself), then blocks on `UPDATE a`.
     *   While it is parked there, p2 counts (sees `a`, still an admin because
     *   p1 has not committed), allows itself, and COMMITS `b` → user. Release
     *   the probe, p1 commits `a` → user. Both fulfil, nought admins left, and
     *   the count assertion below goes red.
     *
     *   FIXED: p1 blocks at the locking read, BEFORE it counts anything, so it
     *   never forms the stale opinion. p2 wants the same rows and queues behind
     *   it. Release the probe and they run one at a time: the first demotes,
     *   the second re-reads, finds itself alone, and is refused with LAST_ADMIN.
     *
     * The sleeps are what make the interleaving deterministic rather than hoped
     * for: p1 must be parked before p2 starts, or the broken code can happen to
     * be safe (p2 committing before p1's count) and the test would pass for the
     * wrong reason.
     */
    it("two OVERLAPPING demotions cannot both pass the guard and leave zero admins", async () => {
      const a = await makeUser("admin");
      const b = await makeUser("admin");
      const actor: Actor = { id: a.id, role: "admin", username: a.username };
      await quarantineOtherAdmins([a.id, b.id]);

      /** Settle without rejecting, so an early rejection is never unhandled. */
      const settle = <T>(p: Promise<T>) =>
        p.then(
          (value) => ({ ok: true as const, value }),
          (error: unknown) => ({ ok: false as const, error }),
        );

      const probe = new Pool({ connectionString: process.env.DATABASE_URL });
      const held = await probe.connect();
      let results: (
        | { ok: true; value: AdminUser }
        | { ok: false; error: unknown }
      )[];
      try {
        await held.query("BEGIN");
        await held.query("SELECT id FROM users WHERE id = $1 FOR UPDATE", [a.id]);

        const p1 = settle(setUserRole(actor, a.id, "user"));
        await sleep(500); // p1 is now parked on `a`.
        const p2 = settle(setUserRole(actor, b.id, "user"));
        await sleep(500); // p2 has either finished (broken) or queued (fixed).

        await held.query("ROLLBACK");
        results = await Promise.all([p1, p2]);
      } finally {
        held.release();
        await probe.end();
      }

      // The only assertion that matters: SOMEBODY can still reach the panel.
      const admins = await getDb()
        .select({ id: users.id })
        .from(users)
        .where(and(eq(users.role, "admin"), eq(users.isActive, true)));
      expect(admins.length).toBeGreaterThanOrEqual(1);

      // And the loser was told why, rather than silently doing nothing.
      const refused = results.filter((r) => !r.ok);
      expect(refused).toHaveLength(1);
      expect(refused[0]).toMatchObject({ error: { code: "LAST_ADMIN" } });
    });
  });
});
