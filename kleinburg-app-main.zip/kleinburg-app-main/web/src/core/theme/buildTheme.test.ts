import { readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

import {
  buildRadiusVars,
  buildSemanticVars,
  buildThemeCss,
  type DesignTokens,
  flattenGlobalColors,
  isMetaKey,
  resolveReference,
  semanticVarName,
  toKebabCase,
  tokenEntries,
  type TokenGroup,
} from "./buildTheme";

const globals: TokenGroup = {
  white: "#ffffff",
  purple: { "100": "#ebe6ff", "600": "#6642ff", $note: "meta" },
  $note: "meta",
};

describe("isMetaKey / tokenEntries ($-key filtering)", () => {
  it("treats $-prefixed keys as metadata", () => {
    expect(isMetaKey("$note")).toBe(true);
    expect(isMetaKey("$description")).toBe(true);
    expect(isMetaKey("DEFAULT")).toBe(false);
    expect(isMetaKey("focusRing")).toBe(false);
  });

  it("filters metadata keys out of token entries", () => {
    expect(tokenEntries(globals).map(([k]) => k)).toEqual(["white", "purple"]);
  });
});

describe("toKebabCase", () => {
  it("converts camelCase", () => {
    expect(toKebabCase("focusRing")).toBe("focus-ring");
  });

  it("passes through already-kebab names", () => {
    expect(toKebabCase("bg")).toBe("bg");
    expect(toKebabCase("focus-ring")).toBe("focus-ring");
  });
});

describe("flattenGlobalColors", () => {
  it("emits flat and ramp values, skipping metadata", () => {
    expect(flattenGlobalColors(globals)).toEqual([
      ["--color-white", "#ffffff"],
      ["--color-purple-100", "#ebe6ff"],
      ["--color-purple-600", "#6642ff"],
    ]);
  });
});

describe("resolveReference", () => {
  it("resolves ramp references to global var()", () => {
    expect(resolveReference("{color.global.purple.600}", globals)).toBe(
      "var(--color-purple-600)",
    );
  });

  it("resolves flat references (white/black)", () => {
    expect(resolveReference("{color.global.white}", globals)).toBe(
      "var(--color-white)",
    );
  });

  it("throws on unknown targets and malformed references", () => {
    expect(() => resolveReference("{color.global.teal.500}", globals)).toThrow();
    expect(() => resolveReference("{color.global.purple.999}", globals)).toThrow();
    expect(() => resolveReference("not-a-reference", globals)).toThrow();
  });
});

describe("semanticVarName (DEFAULT + kebab handling)", () => {
  it("maps DEFAULT to the base name", () => {
    expect(semanticVarName("bg", "DEFAULT")).toBe("--color-bg");
    expect(semanticVarName("accent", "DEFAULT")).toBe("--color-accent");
  });

  it("kebab-cases camelCase keys", () => {
    expect(semanticVarName("accent", "focusRing")).toBe(
      "--color-accent-focus-ring",
    );
  });
});

describe("buildSemanticVars", () => {
  it("resolves semantic tokens to global var() references", () => {
    const semantic: TokenGroup = {
      accent: {
        DEFAULT: "{color.global.purple.600}",
        focusRing: "{color.global.purple.100}",
        contrast: "{color.global.white}",
        $note: "meta",
      },
    };
    expect(buildSemanticVars(semantic, globals)).toEqual([
      ["--color-accent", "var(--color-purple-600)"],
      ["--color-accent-focus-ring", "var(--color-purple-100)"],
      ["--color-accent-contrast", "var(--color-white)"],
    ]);
  });
});

describe("buildRadiusVars", () => {
  it("emits radius vars and skips metadata", () => {
    expect(buildRadiusVars({ sm: "8px", md: "12px", $note: "meta" })).toEqual([
      ["--radius-sm", "8px"],
      ["--radius-md", "12px"],
    ]);
  });
});

describe("buildThemeCss over the real design/tokens.json", () => {
  const tokensPath = resolve(
    dirname(fileURLToPath(import.meta.url)),
    "../../../..",
    "design",
    "tokens.json",
  );
  const raw = readFileSync(tokensPath, "utf8");

  it("is deterministic (two runs produce identical output)", () => {
    const a = buildThemeCss(JSON.parse(raw) as DesignTokens);
    const b = buildThemeCss(JSON.parse(raw) as DesignTokens);
    expect(a).toBe(b);
  });

  it("contains the expected header, brand values and structure", () => {
    const css = buildThemeCss(JSON.parse(raw) as DesignTokens);
    expect(css.startsWith("/* GENERATED from design/tokens.json")).toBe(true);
    expect(css).toContain("--color-purple-600: #6642ff;");
    expect(css).toContain("--color-accent: var(--color-purple-600);");
    expect(css).toContain("--color-accent-focus-ring: var(--color-purple-400);");
    expect(css).toContain("--color-bg: var(--color-white);");
    expect(css).toContain("--radius-lg: 16px;");
    expect(css).toContain(".dark {");
    expect(css).not.toContain("$note");
    expect(css).not.toContain("$description");
  });
});
