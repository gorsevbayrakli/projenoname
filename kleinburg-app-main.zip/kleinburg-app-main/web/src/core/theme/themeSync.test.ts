import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { buildSemanticVars } from "./buildTheme";

// Guard against mapping drift: every semantic CSS variable emitted by the
// generator must be exposed in globals.css's @theme block, otherwise the
// matching Tailwind utility silently does not exist.
describe("generated tokens stay in sync with @theme mappings", () => {
  it("every semantic var appears in globals.css", () => {
    const tokens = JSON.parse(
      readFileSync(join(__dirname, "../../../../design/tokens.json"), "utf8"),
    );
    const globals = readFileSync(join(__dirname, "../../app/globals.css"), "utf8");
    const vars = buildSemanticVars(tokens.color.semantic, tokens.color.global);
    const missing = vars
      .map(([name]) => name)
      .filter((name) => !globals.includes(name));
    expect(missing).toEqual([]);
  });
});
