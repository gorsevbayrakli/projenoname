/**
 * Pure token-transform functions for the theme pipeline:
 * design/tokens.json -> src/app/theme.generated.css
 *
 * Framework-neutral (no react/next imports). The CLI wrapper lives in
 * scripts/build-theme.ts; run it via `npm run build:theme`.
 */

export type TokenLeaf = string;
export interface TokenGroup {
  [key: string]: TokenLeaf | TokenGroup;
}
export type TokenNode = TokenLeaf | TokenGroup;

/** `$`-prefixed keys ($description, $note, $mode, ...) are metadata, not tokens. */
export function isMetaKey(key: string): boolean {
  return key.startsWith("$");
}

/** camelCase -> kebab-case (focusRing -> focus-ring). Already-kebab input passes through. */
export function toKebabCase(name: string): string {
  return name.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
}

/** Entries of a token group with metadata keys removed, in source (stable) order. */
export function tokenEntries(group: TokenGroup): Array<[string, TokenNode]> {
  return Object.entries(group).filter(([key]) => !isMetaKey(key));
}

/**
 * Flatten the global color ramps to CSS var declarations.
 * white -> --color-white; gray.50 -> --color-gray-50.
 */
export function flattenGlobalColors(
  globals: TokenGroup,
): Array<[string, string]> {
  const out: Array<[string, string]> = [];
  for (const [family, node] of tokenEntries(globals)) {
    if (typeof node === "string") {
      out.push([`--color-${toKebabCase(family)}`, node]);
    } else {
      for (const [step, value] of tokenEntries(node)) {
        if (typeof value !== "string") {
          throw new Error(`Unexpected nesting under color.global.${family}.${step}`);
        }
        out.push([`--color-${toKebabCase(family)}-${step}`, value]);
      }
    }
  }
  return out;
}

const REFERENCE_RE = /^\{color\.global\.([a-zA-Z0-9]+)(?:\.([a-zA-Z0-9]+))?\}$/;

/**
 * Resolve a `{color.global.x[.y]}` reference to the global CSS var it points at.
 * Throws on malformed references or references to values that do not exist.
 */
export function resolveReference(ref: string, globals: TokenGroup): string {
  const match = REFERENCE_RE.exec(ref);
  if (!match) {
    throw new Error(`Unsupported token reference: ${ref}`);
  }
  const [, family, step] = match;
  const familyNode = globals[family];
  if (familyNode === undefined) {
    throw new Error(`Reference to unknown color family: ${ref}`);
  }
  if (step === undefined) {
    if (typeof familyNode !== "string") {
      throw new Error(`Reference ${ref} points at a ramp, not a value`);
    }
    return `var(--color-${toKebabCase(family)})`;
  }
  if (typeof familyNode === "string" || typeof familyNode[step] !== "string") {
    throw new Error(`Reference to unknown color step: ${ref}`);
  }
  return `var(--color-${toKebabCase(family)}-${step})`;
}

/** Semantic var name: DEFAULT -> --color-<family>; focusRing -> --color-<family>-focus-ring. */
export function semanticVarName(family: string, key: string): string {
  const base = `--color-${toKebabCase(family)}`;
  return key === "DEFAULT" ? base : `${base}-${toKebabCase(key)}`;
}

/**
 * Semantic tokens (bg/fg/border/accent) resolved to var() references
 * into the global palette.
 */
export function buildSemanticVars(
  semantic: TokenGroup,
  globals: TokenGroup,
): Array<[string, string]> {
  const out: Array<[string, string]> = [];
  for (const [family, node] of tokenEntries(semantic)) {
    if (typeof node === "string") {
      throw new Error(`Semantic family ${family} must be a group`);
    }
    for (const [key, value] of tokenEntries(node)) {
      if (typeof value !== "string") {
        throw new Error(`Unexpected nesting under semantic.${family}.${key}`);
      }
      out.push([semanticVarName(family, key), resolveReference(value, globals)]);
    }
  }
  return out;
}

/** Radius scale -> --radius-sm/md/lg/xl declarations. */
export function buildRadiusVars(radius: TokenGroup): Array<[string, string]> {
  const out: Array<[string, string]> = [];
  for (const [key, value] of tokenEntries(radius)) {
    if (typeof value !== "string") {
      throw new Error(`Unexpected nesting under radius.${key}`);
    }
    out.push([`--radius-${toKebabCase(key)}`, value]);
  }
  return out;
}

function declarations(vars: Array<[string, string]>, indent = "  "): string {
  return vars.map(([name, value]) => `${indent}${name}: ${value};`).join("\n");
}

export interface DesignTokens extends TokenGroup {
  color: TokenGroup & { global: TokenGroup; semantic: TokenGroup };
  radius: TokenGroup;
}

/**
 * Build the full generated stylesheet. Deterministic: output depends only on
 * tokens.json content (source key order is preserved as-is).
 */
export function buildThemeCss(tokens: DesignTokens): string {
  const globals = tokens.color.global;
  const semantic = tokens.color.semantic;

  const globalVars = flattenGlobalColors(globals);
  const semanticVars = buildSemanticVars(semantic, globals);
  const radiusVars = buildRadiusVars(tokens.radius);

  return [
    "/* GENERATED from design/tokens.json — do not edit by hand; run npm run build:theme */",
    "",
    ":root {",
    "  /* Global palette */",
    declarations(globalVars),
    "",
    "  /* Semantic tokens (light) */",
    declarations(semanticVars),
    "",
    "  /* Radius scale */",
    declarations(radiusVars),
    "}",
    "",
    "/* Placeholder: dark tokens are not defined yet in design/tokens.json,",
    "   so .dark re-declares the light semantic values until they arrive. */",
    ".dark {",
    declarations(semanticVars),
    "}",
    "",
  ].join("\n");
}
