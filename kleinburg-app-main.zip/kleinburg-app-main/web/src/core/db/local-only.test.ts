import { describe, expect, it } from "vitest";

import {
  assertLocalDatabase,
  LOCAL_DB_HOSTS,
  localDatabaseRefusal,
} from "./local-only";

/**
 * The guard that keeps `seed demo` — the one command in this repo with a
 * PASSWORD WRITTEN IN ITS SOURCE — off any database that is not local.
 *
 * These are the load-bearing tests of that command. Everything else `seed demo`
 * does is convenience; this is the part that decides whether a known credential
 * can be planted in production. Each case below was watched fail before the
 * guard existed, and again with the guard deliberately broken (see the commit
 * message for which line was removed for each).
 *
 * The fixtures are chosen so a correct and a broken guard land in DIFFERENT
 * STATES rather than merely different messages: the remote host is a real
 * Render-shaped internal hostname with NODE_ENV unset, which is exactly the
 * shape a pasted production URL has and which a NODE_ENV-only guard waves
 * through.
 */

const LOCAL_URL = "postgres://kleinburg:kleinburg@localhost:5432/kleinburg";

/**
 * A Render internal database hostname. NOT a URL that looks dangerous: it has
 * no "prod" in it, no public domain, and nothing about it reads as remote at a
 * glance — which is the whole reason the host has to be checked rather than
 * eyeballed.
 */
const RENDER_URL =
  "postgres://kleinburg:s3cret@dpg-d1abc23fte5s73abcdef-a/kleinburg_x9y2";

describe("assertLocalDatabase", () => {
  it("refuses when NODE_ENV is production, even against a local URL", () => {
    expect(() =>
      assertLocalDatabase({ nodeEnv: "production", databaseUrl: LOCAL_URL }),
    ).toThrow(/NODE_ENV/);
  });

  it("refuses a remote host when NODE_ENV is unset", () => {
    // The Render case: nobody sets NODE_ENV in the shell they paste the URL
    // into, so NODE_ENV alone would let this through.
    expect(() =>
      assertLocalDatabase({ nodeEnv: undefined, databaseUrl: RENDER_URL }),
    ).toThrow(/dpg-d1abc23fte5s73abcdef-a/);
  });

  it("refuses a remote host when NODE_ENV is development", () => {
    expect(() =>
      assertLocalDatabase({ nodeEnv: "development", databaseUrl: RENDER_URL }),
    ).toThrow(/not a local database host/i);
  });

  it("accepts localhost", () => {
    expect(() =>
      assertLocalDatabase({ nodeEnv: undefined, databaseUrl: LOCAL_URL }),
    ).not.toThrow();
  });

  it("accepts 127.0.0.1", () => {
    expect(() =>
      assertLocalDatabase({
        nodeEnv: "development",
        databaseUrl: "postgres://kleinburg:kleinburg@127.0.0.1:5432/kleinburg",
      }),
    ).not.toThrow();
  });

  it("accepts the docker compose service host", () => {
    expect(() =>
      assertLocalDatabase({
        nodeEnv: undefined,
        databaseUrl: "postgres://kleinburg:kleinburg@postgres:5432/kleinburg",
      }),
    ).not.toThrow();
  });

  it("refuses when DATABASE_URL is not set at all", () => {
    // Fail CLOSED: an absent URL is not "probably local".
    expect(() =>
      assertLocalDatabase({ nodeEnv: undefined, databaseUrl: undefined }),
    ).toThrow(/DATABASE_URL is not set/);
  });

  it("refuses a DATABASE_URL that cannot be parsed", () => {
    expect(() =>
      assertLocalDatabase({ nodeEnv: undefined, databaseUrl: "not a url" }),
    ).toThrow(/could not be parsed/i);
  });

  it("refuses a remote host that merely CONTAINS an allowed host name", () => {
    // A substring match would accept this; the check is on the whole hostname.
    expect(() =>
      assertLocalDatabase({
        nodeEnv: undefined,
        databaseUrl: "postgres://u:p@localhost.evil.example.com:5432/db",
      }),
    ).toThrow(/not a local database host/i);
  });

  it("names both the reason and the offending value in the message", () => {
    // The operator has to be able to see WHY without reading this file.
    const refusal = localDatabaseRefusal({
      nodeEnv: undefined,
      databaseUrl: RENDER_URL,
    });
    expect(refusal).not.toBeNull();
    expect(refusal).toContain("dpg-d1abc23fte5s73abcdef-a");
    expect(refusal).toContain("create-admin");
  });

  it("returns null (no refusal) for a local database", () => {
    expect(
      localDatabaseRefusal({ nodeEnv: undefined, databaseUrl: LOCAL_URL }),
    ).toBeNull();
  });

  it("never puts the connection string's password in the refusal", () => {
    // The message is printed to a terminal and pasted into issues.
    const refusal = localDatabaseRefusal({
      nodeEnv: undefined,
      databaseUrl: RENDER_URL,
    });
    expect(refusal).not.toContain("s3cret");
  });

  it("allows no override: an env var named like one is not consulted", () => {
    // There is deliberately no escape hatch. If this test ever needs changing,
    // read the header of scripts/seed.ts first.
    expect(() =>
      assertLocalDatabase({
        nodeEnv: "production",
        databaseUrl: LOCAL_URL,
        // @ts-expect-error — proving the option does not exist in the type.
        force: true,
      }),
    ).toThrow(/NODE_ENV/);
  });

  it("the allowed host list is exactly the local ones", () => {
    expect([...LOCAL_DB_HOSTS].sort()).toEqual([
      "127.0.0.1",
      "::1",
      "host.docker.internal",
      "kleinburg-postgres-dev",
      "localhost",
      "postgres",
    ]);
  });
});
