import { sql } from "drizzle-orm";
import {
  boolean,
  index,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  primaryKey,
  text,
  timestamp,
  unique,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

/**
 * The two roles (T40). `admin` is the SUPER admin: one operator who administers
 * every brand. There is deliberately no per-brand manager role — Elif's call on
 * 20 July: add one later if the need is real, rather than model a hierarchy
 * nobody has asked for yet.
 *
 * The enum predates T40 and was inert (nothing ever read `users.role`). T40
 * gives the existing `admin` value its meaning rather than introducing a third
 * value, so every account the `seed create-admin` CLI has already made becomes
 * a super admin with no data migration.
 *
 * What `admin` does NOT grant: reading another brand's projects or content.
 * See core/admin/README-scope in core/auth/roles.ts.
 */
export const userRole = pgEnum("user_role", ["admin", "user"]);

export const projectLanguage = pgEnum("project_language", [
  "en",
  "tr",
  "fr",
  "de",
  "es",
  "it",
  "pt",
]);

export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    username: text("username").unique().notNull(),
    passwordHash: text("password_hash").notNull(),
    role: userRole("role").notNull().default("user"),
    /**
     * True while the account still carries the temporary password an admin set
     * (T40). There is no email infrastructure, so an invite link is out of scope:
     * the admin sets a temporary password out-of-band and the user must replace
     * it before reaching anything else.
     *
     * Defaults to FALSE, not true: the column is added to a live table and every
     * existing account chose its own password already. Only the admin
     * create-user / reset-password paths set it, so nobody is locked out by the
     * migration.
     */
    mustChangePassword: boolean("must_change_password")
      .notNull()
      .default(false),
    /**
     * Human-readable name shown in the account area (T43). NULLABLE on purpose:
     * `username` is the identity, this is decoration. Every account that existed
     * before T43 has none, and demanding one at migration time would mean
     * inventing names for real people.
     */
    displayName: text("display_name"),
    /**
     * Contact e-mail (T43). NEW COLUMN — the users table had no e-mail at all
     * before this task, so "profile info: name and e-mail" required a schema
     * change rather than a form over existing fields.
     *
     * It is contact information ONLY. Login is by username and there is no mail
     * infrastructure, so this address does not authenticate anybody and cannot
     * recover an account. If a password-reset-by-mail flow ever lands, this
     * column needs a verified-at companion before it can be trusted for that.
     */
    email: text("email"),
    /**
     * Interface-language preference bound to the account (T43, extends T25).
     *
     * NULL means "no account preference" and the `kb_locale` cookie decides —
     * which is the state every pre-T43 account starts in, so nobody's language
     * changes under them on deploy.
     *
     * Plain text rather than a pgEnum: the supported set lives in
     * `src/i18n/locales.ts`, a pure module that middleware, client and tests all
     * read. A second copy in an enum would be a migration every time a language
     * is added, for a value that is narrowed through `resolveLocale` on read
     * anyway.
     */
    uiLocale: text("ui_locale"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    // CASE-INSENSITIVE is the load-bearing part: `lower()` is why this is a
    // uniqueIndex and not a plain unique() on the column, so "A@x.com" and
    // "a@x.com" cannot both be claimed.
    // The `is not null` predicate is NOT a correctness requirement — Postgres
    // already treats NULLs as distinct in a unique index, so rows with no
    // address never collide either way. It is a deliberate narrowing: most
    // accounts have no email, and keeping them out makes the index smaller.
    uniqueIndex("users_email_lower_unique_idx")
      .on(sql`lower(${table.email})`)
      .where(sql`${table.email} is not null`),
  ],
);

export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull().unique(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    // The FK Postgres checks on every `users` delete (admin delete-user, and the
    // cascade in the test teardowns). Unindexed it is a sequential scan of every
    // session ever issued, and this table only shrinks lazily: an expired row is
    // deleted when its own token is next presented (core/auth/session.ts), so a
    // login that is never logged out and never revisited stays forever.
    // Deliberately NOT indexed here: `expires_at`. Nothing sweeps it — the lazy
    // cleanup above is keyed on `token_hash` — and `expires_at` is UPDATED on
    // every authenticated request to slide the idle window, so an index on it
    // would be rewritten request-for-request to serve no reader at all. Add it
    // with the sweep, not before.
    index("sessions_user_idx").on(table.userId),
  ],
);

export const brands = pgTable("brands", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").unique().notNull(),
  isActive: boolean("is_active").notNull().default(true),
  /**
   * The brand's monthly spend ceiling in USD, or NULL for no ceiling (T51).
   *
   * NULL IS THE DEFAULT AND IT MEANS UNLIMITED. Elif's decision: a mechanism
   * that refuses production must not switch itself on with a number nobody
   * chose, so the column ships null everywhere and the super admin sets it per
   * brand. `0` is a real, deliberate value meaning "refuse everything" — it is
   * NOT the same as null, and no code here may coalesce one into the other.
   *
   * Per BRAND rather than per project or per account, because the invoice is
   * per month and one brand's overrun should not stop another brand's work.
   *
   * numeric(12,2) rather than the numeric(12,6) of `llm_calls.cost_usd`: a
   * ceiling is a decision a human types ("50"), not a measurement, and six
   * decimal places on a typed budget invites a cap of $49.999999 that reads as
   * $50 in every UI. The MEASUREMENT keeps its full precision; only the
   * threshold is rounded to money.
   *
   * A DOLLAR figure, and that has a dated edge worth knowing: Sonnet 5's
   * promotional pricing ends 31 Aug 2026 ($2/$10 -> $3/$15 per million), so
   * from 1 September the same work costs about 50% more and a cap set today
   * silently buys ~a third less of it. No price is hardcoded anywhere in this
   * codebase to compensate (see core/llm/spend.ts); instead the admin UI says
   * so where the number is typed, which is the only place the warning can
   * actually change a decision.
   */
  monthlyCapUsd: numeric("monthly_cap_usd", { precision: 12, scale: 2 }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const userBrands = pgTable(
  "user_brands",
  {
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    brandId: uuid("brand_id")
      .notNull()
      .references(() => brands.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [primaryKey({ columns: [table.userId, table.brandId] })],
);

export const projects = pgTable(
  "projects",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    brandId: uuid("brand_id")
      .notNull()
      .references(() => brands.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    language: projectLanguage("language").notNull().default("en"),
    /**
     * Which social platforms this project generates for (T29). Codes come from
     * core/platforms.ts; NOT a pgEnum, so registering LinkedIn or TikTok stays
     * a code change with no migration.
     *
     * Empty means "not chosen yet" and blocks the pillars step: wizard step 6
     * requires at least one. Existing projects were backfilled to {instagram},
     * which is what they were implicitly generating before this column.
     */
    platforms: text("platforms").array().notNull().default([]),
    /**
     * How many posts to generate per platform, keyed by platform code (T34).
     * Elif's call: asked per platform, because LinkedIn twice a week and
     * Instagram five times a week are both reasonable and one total cannot
     * express that. Capped at 30 (one month) in the service layer.
     *
     * A separate column rather than folding the count into `platforms`: the
     * code list is read in six places and turning it into objects would break
     * all of them, while an additive map breaks none. A missing entry falls
     * back to the default count.
     */
    postCounts: jsonb("post_counts").notNull().default({}),
    createdBy: uuid("created_by").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [unique().on(table.brandId, table.name)],
);

export const documentKind = pgEnum("document_kind", [
  "pdf",
  "docx",
  "pptx",
  "url",
]);

/**
 * The wizard's steps, in workflow order — plus, at the end, the values that
 * exist only to give a NON-wizard LLM call somewhere to hang off.
 *
 * `platform_cadence` is the latter. The cadence suggestion on step 6 is a real,
 * billed LLM call that is not a wizard step: it has no queue, no step_contents
 * row and nothing runs it. It still needs a `generation_jobs` row, because
 * `llm_calls.job_id` is NOT NULL and a billed call with nowhere to be recorded
 * is invisible spend. Giving it its OWN enum value rather than borrowing
 * `user_input` keeps the per-step breakdown on /spend honest: cadence shows up
 * as cadence instead of inflating a step that never made the call.
 *
 * Declaration order is load-bearing: Postgres sorts an enum by it, and
 * `getProjectSpend` orders `byStep` on it. Non-wizard values therefore go LAST,
 * so they sort below the workflow rather than into the middle of it.
 */
export const workflowStep = pgEnum("workflow_step", [
  "brand_context",
  "secondary_data",
  "user_input",
  "creative_sparks",
  "sm_pillars",
  "sm_posts",
  "content_calendar",
  "platform_cadence",
]);

export const jobStatus = pgEnum("job_status", [
  "queued",
  "running",
  "succeeded",
  "failed",
  "cancelled",
]);

/** Source documents uploaded/ingested for a project (extracted to text). */
export const documents = pgTable(
  "documents",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    filename: text("filename").notNull(),
    kind: documentKind("kind").notNull(),
    extractedText: text("extracted_text").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    // Same rationale as generation_jobs_project_idx / llm_calls_job_idx in
    // migration 0010; `documents` was missed in that pass. Every project-scoped
    // read filters on project_id — getWizardStatus (every wizard page render),
    // getDocumentTexts (every generation), listDocuments — and it is the FK
    // Postgres checks on every `projects` delete. A sequential scan is dearest
    // here of all the tables: `extracted_text` holds whole document bodies, so
    // this is the widest row in the schema.
    // COMPOSITE, not just project_id: two of those three readers close with
    // `orderBy(asc(documents.createdAt))`, which the trailing column serves for
    // free. The leading column still answers the lookup and the FK check alone.
    index("documents_project_idx").on(table.projectId, table.createdAt),
  ],
);

/**
 * The generated (and user-selected) content for each workflow step of a project.
 * One row per (project, step); `content` is the structured output, `selections`
 * the user's chosen subset when a step supports curation.
 */
export const stepContents = pgTable(
  "step_contents",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    step: workflowStep("step").notNull(),
    content: jsonb("content").notNull(),
    selections: jsonb("selections"),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [unique().on(table.projectId, table.step)],
);

/**
 * Durable record of a single generation job. pg-boss carries the transport, but
 * this table is the honest source of truth for status/output/error per step.
 */
export const generationJobs = pgTable(
  "generation_jobs",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    step: workflowStep("step").notNull(),
    status: jobStatus("status").notNull().default("queued"),
    input: jsonb("input").notNull(),
    output: jsonb("output"),
    error: text("error"),
    createdBy: uuid("created_by").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    startedAt: timestamp("started_at", { withTimezone: true }),
    finishedAt: timestamp("finished_at", { withTimezone: true }),
  },
  (table) => [
    // Every spend query joins llm_calls -> generation_jobs and then filters or
    // groups on project_id; supersedeActiveJobs and the job lookups filter on
    // it too. Without this the planner had only the primary key and did a
    // sequential scan of the whole table on each of the six queries a single
    // /spend page view issues.
    index("generation_jobs_project_idx").on(table.projectId),
  ],
);

/**
 * One row per LLM API call: the durable usage/cost ledger. Written by the
 * OpenRouter client after every (successful) structured generation. Kept
 * separate from generation_jobs so a single job step can span multiple calls.
 */
export const llmCalls = pgTable(
  "llm_calls",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    jobId: uuid("job_id")
      .notNull()
      .references(() => generationJobs.id, { onDelete: "cascade" }),
    model: text("model").notNull(),
    promptTokens: integer("prompt_tokens").notNull().default(0),
    completionTokens: integer("completion_tokens").notNull().default(0),
    // Nullable: not every OpenRouter response reports a cost.
    costUsd: numeric("cost_usd", { precision: 12, scale: 6 }),
    durationMs: integer("duration_ms").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    // The join key for every /spend query, and the FK Postgres has to check on
    // a generation_jobs delete. Postgres indexes a primary key automatically
    // but never a foreign key, so this table was scanned end-to-end on each of
    // the six queries a /spend page view issues.
    index("llm_calls_job_idx").on(table.jobId),
  ],
);

/**
 * Every action the audit trail (T41) records, in the four categories Elif
 * decided on 20 July. `noun.verb`, so a reader can group by prefix without a
 * lookup table.
 *
 * This list is CLOSED and it is a pgEnum on purpose. A `text` column would let
 * a typo'd action name land in the table forever with no way to correct it
 * (the table is append-only — see below), and grouping the log by action is
 * the first thing anybody does with it. Adding an action is a migration, which
 * is the right amount of friction for a permanent record.
 */
export const AUDIT_ACTIONS = [
  // ── 1. Admin directory actions ───────────────────────────────────────
  // The category that exists to close #40's gap: a membership grant and its
  // revoke both leave a row here, so grant -> read -> revoke is no longer
  // invisible after the fact.
  "brand_create",
  "user_create",
  "user_password_reset",
  "membership_grant",
  "membership_revoke",
  /**
   * An EXISTING user's role being changed by an admin (#89).
   *
   * `user_create` already records the role an account was born with, which
   * covered exactly half the question: it says who minted an admin, and
   * nothing at all about who promoted one afterwards or who took the rights
   * away. Both are privilege mutations by an admin — the same shape as the
   * grant/revoke pair above — so the same category and the same ATOMIC write.
   *
   * The row carries `previousRole` as well as `role`. An absolute setting
   * would force a reader to reconstruct the sequence to see which direction a
   * change went, and "an admin changed a role" without the direction is not
   * worth the row (same reasoning as `brand_cap_set`).
   */
  "user_role_change",

  // ── 2. Login / logout, failures included ─────────────────────────────
  "auth_login",
  "auth_login_failed",
  "auth_logout",
  /**
   * A user changing their OWN password. Not in Elif's list literally, included
   * deliberately: paired with `user_password_reset` it is what tells a reader
   * whether the temporary password an admin set is still live. A reset with no
   * matching change means a second person still knows a working credential,
   * which is exactly the #40 "sign in as them" route.
   */
  "user_password_change",
  /**
   * A user changing their OWN e-mail (#43 review, finding 5).
   *
   * T43 argued this needed no row because e-mail does not authenticate. True
   * today, and beside the point: it is the account's only contact channel, it
   * is silently mutable by whoever holds the session, and `users.email` is
   * already shaped for the reset-by-mail flow that would make it an auth
   * factor. `audit_events` has no DELETE path and therefore cannot be
   * backfilled, so the choice is not "audit now or audit later" — it is
   * "audit now or never have the history".
   *
   * Display-name and language changes deliberately do NOT get an action. They
   * are display preferences with no security meaning, and a permanent table
   * with no delete path is the wrong place to dilute.
   */
  "user_email_change",

  // ── 3. Generation triggers (ties into #42) ───────────────────────────
  "generation_start",

  // ── 4. Content edits, selection changes, downloads ───────────────────
  "content_edit",
  "content_select",
  "content_download",

  // ── 5. The super admin's cross-brand spend view (T50) ────────────────
  /**
   * The super admin opened spend for a brand they hold NO `user_brands` row
   * on (T50). The only READ this table records, and the only one it should:
   * every other read in the product is already bounded by
   * `requireProjectAccess`, whereas this one is a deliberate hole in that
   * boundary and therefore the exact thing #40/#41 promised would leave a
   * trace.
   *
   * NOT written when the admin views a brand they ARE a member of — that view
   * is ordinary membership and carries no crossing to record. See
   * `core/llm/admin-spend.ts`.
   */
  "spend_view_admin",

  // ── 6. The super admin setting a brand's monthly cap (T51) ───────────
  /**
   * The super admin changed `brands.monthly_cap_usd` — raised it, lowered it,
   * set it for the first time, or removed it entirely.
   *
   * Why this needs a row at all: the cap is the only control in the product
   * that can REFUSE work, and it is silently and instantly reversible. Without
   * this row, "raise the cap, spend past what Elif agreed to, lower it back"
   * leaves a database byte-identical to one where the cap was never touched —
   * exactly the erasure `membership_revoke` exists to close for memberships
   * (#41), arriving via a different column. The spend numbers themselves do
   * not close it either: `llm_calls` records what was spent, never what was
   * permitted at the time, so a month that ran to $400 under a $100 cap is
   * indistinguishable from one that ran to $400 under a $500 cap.
   *
   * The row carries BOTH the previous and the new value in metadata, because
   * a trail of absolute values requires a reader to reconstruct the sequence
   * to see a temporary raise, and the pair makes each row legible alone.
   *
   * Filed under the DIRECTORY category, which makes its write ATOMIC with the
   * change (see core/audit/events.ts): an unrecorded cap change is the precise
   * thing this action exists to prevent, so it is better not to change the cap
   * at all. Unlike `spend_view_admin` this is a MUTATION by an admin on the
   * shape of the directory, so it needs no category of its own.
   */
  "brand_cap_set",
] as const;

export const auditAction = pgEnum("audit_action", AUDIT_ACTIONS);

/**
 * The append-only record of who did what (T41).
 *
 * ── WHY THERE ARE NO FOREIGN KEYS ────────────────────────────────────────
 * Every other table here references its parents. This one references nothing,
 * and that is the single most important decision in its shape.
 *
 * An audit row is a statement about the PAST. A foreign key would subject it
 * to the referential integrity of the PRESENT, and every available ON DELETE
 * action is wrong for that:
 *   - `cascade` would DELETE audit rows when a user or brand is deleted, which
 *     hands anyone who wants to erase their trail a one-step way to do it and
 *     directly contradicts append-only;
 *   - `set null` would UPDATE the row, and an append-only table must not be
 *     updated at all — the trigger below rejects it, so the delete would fail
 *     with a trigger error instead, breaking the unrelated delete;
 *   - `restrict` would make the audit trail permanently block user deletion.
 *
 * So the ids are plain uuids: a join key when the row still exists, a dangling
 * reference when it does not, and never a lever on this table.
 *
 * ── WHY IDENTITIES ARE SNAPSHOTTED AS TEXT ───────────────────────────────
 * Because of the above, a reader cannot rely on a join to answer "who". Each
 * row therefore carries the human-readable name AS IT WAS at the time
 * (`actor_username`, `target_username`, `brand_name`, `project_name`). A user
 * renamed or deleted next year does not turn last year's log into a list of
 * anonymous uuids, and a brand that is dropped does not erase the record of
 * who was granted access to it. Snapshotting also means the log reads
 * correctly without touching `users` or `brands` at all, which keeps the
 * viewing query from becoming a second cross-brand read path.
 *
 * ── APPEND-ONLY ──────────────────────────────────────────────────────────
 * Enforced in TWO places, because one is not enough:
 *   - application: `core/audit/service.ts` exports no update and no delete;
 *   - database: a BEFORE UPDATE OR DELETE trigger that RAISEs. Written by hand
 *     into the migration, since Drizzle does not model triggers.
 * See `core/audit/service.ts` for what that trigger does and does not promise.
 *
 * ── WHAT IS NOT HERE ─────────────────────────────────────────────────────
 * No content bodies (the point of the row is who and when; `step_contents`
 * already holds what). No passwords, hashes, session tokens or API keys —
 * `metadata` is sanitised by `core/audit/events.ts` before it ever arrives.
 * No IP address: see the note in `core/audit/service.ts`.
 */
export const auditEvents = pgTable(
  "audit_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    occurredAt: timestamp("occurred_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    action: auditAction("action").notNull(),
    /**
     * Who acted. NULL only when nobody is known — a failed login against a
     * username that does not exist. `actor_username` is notNull regardless, so
     * every row names somebody even when it cannot identify them.
     */
    actorUserId: uuid("actor_user_id"),
    actorUsername: text("actor_username").notNull(),
    /** Who was acted UPON: the subject of an admin directory action. */
    targetUserId: uuid("target_user_id"),
    targetUsername: text("target_username"),
    brandId: uuid("brand_id"),
    brandName: text("brand_name"),
    projectId: uuid("project_id"),
    projectName: text("project_name"),
    /** Which workflow step, for generation and content actions. */
    step: workflowStep("step"),
    /**
     * A small, sanitised bag of extras: `{ jobId }`, `{ format: "xlsx" }`,
     * `{ selectedCount: 4 }`. Capped in size by `sanitizeAuditMetadata` so it
     * cannot quietly become the place a content body ends up.
     */
    metadata: jsonb("metadata").notNull().default({}),
  },
  (table) => [
    // The admin view: everything, newest first.
    index("audit_events_occurred_at_idx").on(table.occurredAt.desc()),
    // The ordinary-user view: my rows, newest first. A composite index, not
    // two, because the scope predicate is never optional for a non-admin.
    index("audit_events_actor_idx").on(
      table.actorUserId,
      table.occurredAt.desc(),
    ),
    // The coalescing probe in `recordContentAuditEvent`: "did this actor
    // already log this action on this project recently?". Runs on every
    // autosave, so it gets its own index rather than riding on the one above.
    index("audit_events_coalesce_idx").on(
      table.actorUserId,
      table.projectId,
      table.action,
      table.occurredAt.desc(),
    ),
  ],
);

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Session = typeof sessions.$inferSelect;
export type NewSession = typeof sessions.$inferInsert;
export type Brand = typeof brands.$inferSelect;
export type NewBrand = typeof brands.$inferInsert;
export type UserBrand = typeof userBrands.$inferSelect;
export type NewUserBrand = typeof userBrands.$inferInsert;
export type Project = typeof projects.$inferSelect;
export type NewProject = typeof projects.$inferInsert;
export type Document = typeof documents.$inferSelect;
export type NewDocument = typeof documents.$inferInsert;
export type StepContent = typeof stepContents.$inferSelect;
export type NewStepContent = typeof stepContents.$inferInsert;
export type GenerationJob = typeof generationJobs.$inferSelect;
export type NewGenerationJob = typeof generationJobs.$inferInsert;
export type LlmCall = typeof llmCalls.$inferSelect;
export type NewLlmCall = typeof llmCalls.$inferInsert;
export type AuditEvent = typeof auditEvents.$inferSelect;
export type NewAuditEvent = typeof auditEvents.$inferInsert;
export type AuditAction = (typeof AUDIT_ACTIONS)[number];
export type WorkflowStep = (typeof workflowStep.enumValues)[number];
export type JobStatus = (typeof jobStatus.enumValues)[number];
export type DocumentKind = (typeof documentKind.enumValues)[number];
