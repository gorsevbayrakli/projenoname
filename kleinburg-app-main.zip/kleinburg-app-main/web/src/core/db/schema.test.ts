import { afterAll, describe, expect, it } from "vitest";
import { eq, inArray, sql } from "drizzle-orm";
import { closeDb, getDb } from "./client";
import {
  brands,
  documents,
  generationJobs,
  projects,
  sessions,
  stepContents,
  userBrands,
  users,
} from "./schema";

import { hasDb } from "@/test/db-gate";

// Unique-per-run suffix so parallel/repeated runs never collide.
const run = crypto.randomUUID().slice(0, 8);
const name = (base: string) => `${base}-${run}`;

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

async function makeUser(username: string) {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({ username: name(username), passwordHash: "x" })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

async function makeBrand(brandName: string) {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: name(brandName) })
    .returning();
  createdBrandIds.push(brand.id);
  return brand;
}

describe.skipIf(!hasDb)("schema constraints", () => {
  afterAll(async () => {
    const db = getDb();
    // Cascades take care of sessions, user_brands and projects.
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("deleting a brand cascades to its projects and user_brands rows", async () => {
    const db = getDb();
    const user = await makeUser("cascade-user");
    const brand = await makeBrand("cascade-brand");
    const [project] = await db
      .insert(projects)
      .values({ brandId: brand.id, name: name("proj"), createdBy: user.id })
      .returning();
    await db.insert(userBrands).values({ userId: user.id, brandId: brand.id });

    await db.delete(brands).where(eq(brands.id, brand.id));

    const projectRows = await db
      .select()
      .from(projects)
      .where(eq(projects.id, project.id));
    expect(projectRows).toHaveLength(0);
    const accessRows = await db
      .select()
      .from(userBrands)
      .where(eq(userBrands.brandId, brand.id));
    expect(accessRows).toHaveLength(0);
  });

  it("deleting a user sets project.createdBy to null but keeps the project", async () => {
    const db = getDb();
    const user = await makeUser("setnull-user");
    const brand = await makeBrand("setnull-brand");
    const [project] = await db
      .insert(projects)
      .values({ brandId: brand.id, name: name("proj"), createdBy: user.id })
      .returning();

    await db.delete(users).where(eq(users.id, user.id));

    const [survivor] = await db
      .select()
      .from(projects)
      .where(eq(projects.id, project.id));
    expect(survivor).toBeDefined();
    expect(survivor.createdBy).toBeNull();
  });

  it("rejects duplicate project names within a brand, allows them across brands", async () => {
    const db = getDb();
    const brandA = await makeBrand("uniq-brand-a");
    const brandB = await makeBrand("uniq-brand-b");
    const projectName = name("shared-project");

    await db.insert(projects).values({ brandId: brandA.id, name: projectName });
    await expect(
      db.insert(projects).values({ brandId: brandA.id, name: projectName }),
    ).rejects.toThrow();
    await expect(
      db.insert(projects).values({ brandId: brandB.id, name: projectName }),
    ).resolves.toBeDefined();
  });

  it("deleting a project cascades to documents, step_contents and generation_jobs", async () => {
    const db = getDb();
    const brand = await makeBrand("child-cascade-brand");
    const [project] = await db
      .insert(projects)
      .values({ brandId: brand.id, name: name("child-proj") })
      .returning();

    const [doc] = await db
      .insert(documents)
      .values({
        projectId: project.id,
        filename: "brief.pdf",
        kind: "pdf",
        extractedText: "hello",
      })
      .returning();
    const [content] = await db
      .insert(stepContents)
      .values({
        projectId: project.id,
        step: "brand_context",
        content: { a: 1 },
      })
      .returning();
    const [job] = await db
      .insert(generationJobs)
      .values({ projectId: project.id, step: "brand_context", input: {} })
      .returning();

    await db.delete(projects).where(eq(projects.id, project.id));

    expect(
      await db.select().from(documents).where(eq(documents.id, doc.id)),
    ).toHaveLength(0);
    expect(
      await db
        .select()
        .from(stepContents)
        .where(eq(stepContents.id, content.id)),
    ).toHaveLength(0);
    expect(
      await db
        .select()
        .from(generationJobs)
        .where(eq(generationJobs.id, job.id)),
    ).toHaveLength(0);
  });

  it("step_contents rejects a duplicate (projectId, step) but allows a different step", async () => {
    const db = getDb();
    const brand = await makeBrand("stepuniq-brand");
    const [project] = await db
      .insert(projects)
      .values({ brandId: brand.id, name: name("stepuniq-proj") })
      .returning();

    await db
      .insert(stepContents)
      .values({ projectId: project.id, step: "brand_context", content: {} });
    await expect(
      db
        .insert(stepContents)
        .values({ projectId: project.id, step: "brand_context", content: {} }),
    ).rejects.toThrow();
    await expect(
      db
        .insert(stepContents)
        .values({ projectId: project.id, step: "secondary_data", content: {} }),
    ).resolves.toBeDefined();
  });

  it("generation_jobs defaults status to 'queued'", async () => {
    const db = getDb();
    const brand = await makeBrand("jobdefault-brand");
    const [project] = await db
      .insert(projects)
      .values({ brandId: brand.id, name: name("jobdefault-proj") })
      .returning();

    const [job] = await db
      .insert(generationJobs)
      .values({ projectId: project.id, step: "brand_context", input: {} })
      .returning();
    expect(job.status).toBe("queued");
  });

  it("deleting a user sets generation_jobs.createdBy to null but keeps the job", async () => {
    const db = getDb();
    const user = await makeUser("jobcreator-user");
    const brand = await makeBrand("jobcreator-brand");
    const [project] = await db
      .insert(projects)
      .values({ brandId: brand.id, name: name("jobcreator-proj") })
      .returning();
    const [job] = await db
      .insert(generationJobs)
      .values({
        projectId: project.id,
        step: "brand_context",
        input: {},
        createdBy: user.id,
      })
      .returning();

    await db.delete(users).where(eq(users.id, user.id));

    const [survivor] = await db
      .select()
      .from(generationJobs)
      .where(eq(generationJobs.id, job.id));
    expect(survivor).toBeDefined();
    expect(survivor.createdBy).toBeNull();
  });

  it("deleting a user cascades to their sessions", async () => {
    const db = getDb();
    const user = await makeUser("session-user");
    const [session] = await db
      .insert(sessions)
      .values({
        userId: user.id,
        tokenHash: name("token"),
        expiresAt: new Date(Date.now() + 60_000),
      })
      .returning();

    await db.delete(users).where(eq(users.id, user.id));

    const rows = await db
      .select()
      .from(sessions)
      .where(eq(sessions.id, session.id));
    expect(rows).toHaveLength(0);
  });

  /**
   * Every FK that a delete cascade or a hot read path walks, and the column it
   * leads on. Declaring an index in `schema.ts` does nothing on its own — the
   * migration has to be generated and applied — and that is exactly how
   * `documents.project_id` went missing (#69): the table was written without an
   * index argument and no migration from 0001 onward added one, while three
   * project-scoped readers and the `projects` delete cascade all needed it.
   * This asserts against `pg_indexes`, i.e. the migrated database, so a
   * declaration that never became a migration is RED rather than reassuring.
   */
  const FK_INDEXES: ReadonlyArray<
    [table: string, index: string, lead: string]
  > = [
    ["documents", "documents_project_idx", "project_id"],
    ["sessions", "sessions_user_idx", "user_id"],
    ["generation_jobs", "generation_jobs_project_idx", "project_id"],
    ["llm_calls", "llm_calls_job_idx", "job_id"],
  ];

  it.each(FK_INDEXES)(
    "%s has %s, applied and leading on %s",
    async (table, indexName, lead) => {
      const db = getDb();
      const { rows } = await db.execute<{ indexdef: string }>(
        sql`select indexdef from pg_indexes
            where schemaname = 'public'
              and tablename = ${table}
              and indexname = ${indexName}`,
      );

      expect(rows).toHaveLength(1);
      // Leading column decides whether the index can answer the lookup at all;
      // a trailing column (documents' created_at) is a bonus, not the contract.
      expect(rows[0].indexdef).toMatch(new RegExp(`USING btree \\(${lead}\\b`));
    },
  );
});
