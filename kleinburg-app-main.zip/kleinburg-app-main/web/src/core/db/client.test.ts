import { afterAll, describe, expect, it } from "vitest";
import { sql } from "drizzle-orm";
import { closeDb, getDb } from "./client";

import { hasDb } from "@/test/db-gate";

describe("db client", () => {
  afterAll(async () => {
    await closeDb();
  });

  it.skipIf(!hasDb)("connects and runs select 1", async () => {
    const db = getDb();
    const result = await db.execute(sql`select 1 as one`);
    expect(result.rows[0]).toEqual({ one: 1 });
  });
});
