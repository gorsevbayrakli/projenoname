/**
 * "Is this DATABASE_URL a LOCAL database?" — the guard that makes it safe for a
 * script to hold a password in its source.
 *
 * ── WHY THIS EXISTS ──────────────────────────────────────────────────────
 * `scripts/seed.ts` deliberately keeps passwords out of argv, because the first
 * production admin credential leaked through shell history (see that file's
 * header). `seed demo` goes further in the wrong direction: its password is
 * written down in the repository, readable by anyone who can read the source,
 * and it never changes. That is acceptable for exactly one reason — the account
 * cannot be created anywhere it would matter. This module is that reason.
 *
 * So the guard is not a convenience check. It is the ONLY thing standing
 * between a public credential and a real database, and it is why `seed demo`
 * was allowed to exist at all.
 *
 * ── FAIL CLOSED ──────────────────────────────────────────────────────────
 * Every uncertain case refuses: no DATABASE_URL, an unparseable one, a URL with
 * no hostname. "We could not tell" is not "it is probably fine" — the cost of a
 * wrong accept is a known password on a real database, and the cost of a wrong
 * refuse is a developer typing a connection string.
 *
 * ── NO OVERRIDE, ON PURPOSE ──────────────────────────────────────────────
 * There is no `--force`, no `ALLOW_*` env var, no "I know what I am doing"
 * flag. An escape hatch here is not a safety valve, it is the bug: the only
 * person who would reach for it is somebody who has already decided the guard
 * is wrong, at the moment they are least able to judge that. If an account is
 * genuinely needed in production, `seed create-admin` already exists and
 * prompts for a password nobody else knows. Do not add one.
 *
 * Framework-neutral and side-effect free: it reads no globals of its own, so
 * the caller passes the environment in and the tests need no env mutation.
 */

/**
 * Hostnames that mean "a database on this developer's machine".
 *
 * An ALLOWLIST, never a blocklist. A blocklist would have to enumerate every
 * hosting provider's naming scheme and would be wrong the day a new one
 * appears; the set of hosts that count as local is small, known, and does not
 * grow. Render's internal hostnames (`dpg-…-a`) are refused because they are
 * not on this list, not because anything here knows what Render is.
 *
 * Matched WHOLE, never as a substring: `localhost.evil.example.com` is a real
 * remote host that a `.includes("localhost")` check would hand the credential
 * to. See the test of that name.
 *
 *   - `localhost`, `127.0.0.1`, `::1` — the loopback names.
 *   - `postgres`, `kleinburg-postgres-dev` — the service and container names in
 *     `docker-compose.dev.yml`, which is how the database is addressed from
 *     inside the compose network rather than from the host.
 *   - `host.docker.internal` — the host machine as seen from a container.
 */
export const LOCAL_DB_HOSTS: ReadonlySet<string> = new Set([
  "localhost",
  "127.0.0.1",
  "::1",
  "postgres",
  "kleinburg-postgres-dev",
  "host.docker.internal",
]);

/** The environment a locality decision is made from. Passed in, never read. */
export interface DatabaseEnv {
  nodeEnv: string | undefined;
  databaseUrl: string | undefined;
}

/** Where to send somebody the guard has just refused. */
const ALTERNATIVE =
  "If you genuinely need an account on this database, use `npm run seed -- create-admin <username>`, " +
  "which prompts for a password that is not written down in this repository.";

/**
 * The hostname of a connection string, or null when it cannot be determined.
 *
 * Returns null rather than throwing, so every "we could not tell" collapses
 * into the same refusal path as an outright remote host.
 */
function hostnameOf(databaseUrl: string): string | null {
  let parsed: URL;
  try {
    parsed = new URL(databaseUrl);
  } catch {
    return null;
  }
  // IPv6 hostnames come back bracketed ("[::1]"); the allowlist holds the bare
  // form, which is also what a human reads in an error message.
  const host = parsed.hostname.replace(/^\[|\]$/g, "");
  return host === "" ? null : host;
}

/**
 * Why this environment must not be seeded, or null when it is safe.
 *
 * Separate from `assertLocalDatabase` so the decision can be asserted on
 * without catching, and so the message can be checked for what it must NOT
 * contain (the connection string's password).
 */
export function localDatabaseRefusal(env: DatabaseEnv): string | null {
  if (env.nodeEnv === "production") {
    return (
      "Refusing to seed demo data: NODE_ENV is \"production\". " +
      "This command creates an account whose password is written in the source of this repository. " +
      ALTERNATIVE
    );
  }

  if (!env.databaseUrl) {
    return (
      "Refusing to seed demo data: DATABASE_URL is not set, so there is no way to tell " +
      "whether the target database is local. Start the local database with `npm run db:up` " +
      "and set DATABASE_URL (see .env.example)."
    );
  }

  const host = hostnameOf(env.databaseUrl);
  if (host === null) {
    return (
      "Refusing to seed demo data: DATABASE_URL could not be parsed as a connection URL, " +
      "so its host cannot be checked. " +
      ALTERNATIVE
    );
  }

  if (!LOCAL_DB_HOSTS.has(host)) {
    // Names the HOST only. The rest of the connection string holds a password,
    // and this message is printed to terminals and pasted into issues.
    return (
      `Refusing to seed demo data: DATABASE_URL points at "${host}", which is not a local database host. ` +
      `This command creates an account whose password is written in the source of this repository, ` +
      `so it only runs against ${[...LOCAL_DB_HOSTS].join(", ")}. ` +
      ALTERNATIVE
    );
  }

  return null;
}

/**
 * Throw unless the environment describes a local database.
 *
 * Takes no options beyond the environment — see the "no override" note above.
 */
export function assertLocalDatabase(env: DatabaseEnv): void {
  const refusal = localDatabaseRefusal(env);
  if (refusal !== null) throw new Error(refusal);
}
