/**
 * The failed-login audit write, and the ceiling that stops it becoming a
 * denial of service (#41 review, finding 1).
 *
 * ═══ THE VULNERABILITY THIS MODULE CLOSES ═════════════════════════════════
 * `authenticate` records every failed login. The login route is unauthenticated
 * and, before this change, unlimited: `middleware.ts` excludes `api/auth` from
 * its matcher and `AttemptLimiter` was wired only to `/api/auth/change-password`.
 * So anyone on the internet could POST garbage credentials in a loop and write
 * permanent ~250-byte rows into a table that has no DELETE path by design.
 *
 * The damage does not stop at disk. Directory actions are ATOMIC — the audit
 * row is written inside the same transaction as the change — so the moment
 * writes to `audit_events` start failing, `grantBrandAccess`, `revokeBrandAccess`,
 * `createBrand`, `createUser` and `setTemporaryPassword` all roll back. An
 * unauthenticated party could lock the super admin out of the admin panel, and
 * the only way back would be `DROP TRIGGER` + `DELETE`: precisely the act the
 * design defines as tampering.
 *
 * ═══ THE FIX, AND WHY IT IS SHAPED THIS WAY ═══════════════════════════════
 * Two independent levers, because neither alone is enough:
 *
 *  1. RATE LIMIT THE ROUTE (`app/api/auth/login/route.ts`). Keyed by the
 *     attempted username, ten failures per fifteen minutes, refused BEFORE
 *     `authenticate` runs — so a throttled attempt costs no argon2 verify and
 *     writes no row. This is the ordinary credential-guessing control and it
 *     bounds rows per username.
 *
 *  2. THE BUDGET IN THIS FILE. A per-username limiter does nothing against an
 *     attacker who varies the username on every request, which is the actual
 *     flood. So the number of failed-login audit ROWS is itself capped by a
 *     sliding window. Past the cap the login still fails exactly as before —
 *     the attacker learns nothing, and no legitimate user is refused service —
 *     but no row is written, and the drop is logged loudly.
 *
 * ═══ WHY DROPPING ROWS IS LEGITIMATE HERE, AND ONLY HERE ══════════════════
 * `auth_login_failed` is already in the BEST-EFFORT category (see `service.ts`):
 * the design has always accepted that this row may be lost rather than let an
 * audit-table problem refuse a login. The budget is that same decision applied
 * one step earlier, to a failure mode the module's own doctrine names — "an
 * attacker could trigger it deliberately by filling the table".
 *
 * It does NOT touch the atomic guarantee. Directory actions still write their
 * row inside their transaction and still roll back if it fails. Nothing in this
 * file is reachable from that path. The invariant is intact; what changed is
 * that an unauthenticated party can no longer drive the table to the point
 * where the invariant starts refusing legitimate admin work.
 *
 * ═══ TWO BUDGETS, NOT ONE ════════════════════════════════════════════════
 * Known and unknown usernames get SEPARATE windows. With a single shared
 * budget, an attacker spraying random names would exhaust it and thereby
 * suppress the rows recording a genuine attack on a real account — the flood
 * would be a tool for hiding the thing the trail exists to show. Split, the
 * noisy half cannot starve the meaningful half.
 *
 * ═══ WHAT THIS IS NOT ════════════════════════════════════════════════════
 * In-process and in-memory, exactly like `AttemptLimiter` and for the same
 * reason: the deployment target is a SINGLE Render web service (render.yaml
 * pins `numInstances: 1`). The day that becomes two, both this budget and the
 * route limiter have to move to Postgres or Redis, or an attacker simply
 * spreads the load across instances and gets N times the cap.
 *
 * It is also not a defence against the argon2 CPU burn on the login path —
 * every request still verifies against a dummy hash to keep the response time
 * constant. That is a pre-existing, ordinary request-flood concern and belongs
 * in front of the app (Render/Cloudflare), not here. It costs CPU for the
 * duration of the flood; it does not leave anything permanent behind, which is
 * the difference that made this finding critical.
 */

import { AttemptLimiter } from "../auth/attempt-limiter";
import { maskUnknownUsername } from "./events";
import { recordAuditEvent } from "./service";

/** Failed-login rows written per window, PER BUCKET (known / unknown). */
export const AUTH_FAILURE_AUDIT_MAX_PER_WINDOW = 20;

/** The window. Matches the change-password limiter, for one story to tell. */
export const AUTH_FAILURE_AUDIT_WINDOW_MS = 15 * 60 * 1000;

/** The two budget keys. Separate windows — see the header. */
const KNOWN_BUCKET = "known";
const UNKNOWN_BUCKET = "unknown";

/**
 * A fresh budget. `AttemptLimiter` is a sliding-window counter with a pruning
 * map, which is exactly what is needed here; it is reused rather than
 * reimplemented. Exported so tests can inject one with a controlled clock
 * instead of mutating a module-level singleton.
 */
export function createAuthFailureAuditBudget(now?: () => number): AttemptLimiter {
  return new AttemptLimiter({
    maxAttempts: AUTH_FAILURE_AUDIT_MAX_PER_WINDOW,
    windowMs: AUTH_FAILURE_AUDIT_WINDOW_MS,
    now,
  });
}

/** The process-wide budget used in production. */
let defaultBudget = createAuthFailureAuditBudget();

/**
 * TEST-ONLY. Clears the process-wide budget.
 *
 * `authenticate` does not take a budget argument — adding one would put a test
 * concern in a security-critical signature — so a suite that drives more than
 * `AUTH_FAILURE_AUDIT_MAX_PER_WINDOW` failed logins needs a way to start each
 * test from a clean window. Without it the tests would be order-dependent, and
 * a test that sometimes silently stops writing rows is worse than no test.
 *
 * Never call this from application code: it would hand an attacker the cap.
 */
export function resetAuthFailureAuditBudget(): void {
  defaultBudget = createAuthFailureAuditBudget();
}

export interface FailedLoginAuditInput {
  /** The string typed into the username box. Never stored raw when unknown. */
  attemptedUsername: string;
  /** The matched user's id, or null when no such username exists. */
  actorUserId: string | null;
  /** Why it failed. Never distinguishes "no such user" from "wrong password". */
  reason: "invalid" | "inactive";
}

/**
 * Record one failed login, best-effort, within budget.
 *
 * `actorUserId === null` is the signal that the username did not resolve, and
 * it drives both decisions: which budget bucket is charged, and whether the
 * typed string is stored verbatim or hashed (`maskUnknownUsername`).
 */
export async function recordFailedLoginAuditEvent(
  input: FailedLoginAuditInput,
  budget: AttemptLimiter = defaultBudget,
): Promise<void> {
  // Note the default is evaluated per call, so `resetAuthFailureAuditBudget`
  // is seen by callers that pass nothing.
  const known = input.actorUserId !== null;
  const bucket = known ? KNOWN_BUCKET : UNKNOWN_BUCKET;

  const decision = budget.check(bucket);
  if (!decision.allowed) {
    // Loud, not silent (hard rule 5). The attempted username is deliberately
    // NOT in this line: on this path it is attacker-controlled, and when it is
    // unknown it may be somebody's password.
    console.error(
      `[audit] failed-login audit budget exhausted bucket=${bucket} ` +
        `cap=${AUTH_FAILURE_AUDIT_MAX_PER_WINDOW}/${AUTH_FAILURE_AUDIT_WINDOW_MS}ms ` +
        `retryAfterSeconds=${decision.retryAfterSeconds} -> row DROPPED. ` +
        `A sustained burst of failed logins is in progress; the trail is ` +
        `rate-limited, not lost.`,
    );
    return;
  }
  budget.recordFailure(bucket);

  await recordAuditEvent({
    action: "auth_login_failed",
    actorUserId: input.actorUserId,
    actorUsername: known
      ? input.attemptedUsername
      : maskUnknownUsername(input.attemptedUsername),
    metadata: { reason: input.reason },
  });
}
