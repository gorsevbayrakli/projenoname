/**
 * Where the audit mask's HMAC key comes from, and what happens when it is not
 * there (#55).
 *
 * ── WHY THIS IS ITS OWN FILE ─────────────────────────────────────────────
 * It is the config half of `maskUnknownUsername`, and it could have lived
 * next to it in events.ts. It does not, for a mechanical reason: the boot
 * check runs from `src/instrumentation.ts`, and Next bundles that file for the
 * EDGE runtime as well as Node. events.ts imports `node:crypto`, which the
 * edge bundle cannot resolve, so importing it from instrumentation.ts fails
 * `next build` outright — a dynamic import does not save it, because the
 * module is app source and gets bundled rather than externalised. This module
 * therefore imports nothing, which is what lets the check run at boot.
 *
 * No database, no next, no react (hard rule 1).
 */

/**
 * Shortest key accepted. 32 characters is not a cryptographic requirement of
 * HMAC — it is a floor that a placeholder ("changeme", a project name) fails
 * and a generated secret passes, so the check catches the realistic mistake.
 */
export const MIN_AUDIT_MASK_KEY_LENGTH = 32;

/**
 * The key used when `AUDIT_MASK_KEY` is absent OUTSIDE production, so local
 * dev and CI keep working with no configuration.
 *
 * This is NOT a secret. It is in the repo, so a digest produced under it is
 * exactly as reversible as the unkeyed digest this replaced. It must never be
 * used in production, and `resolveAuditMaskKey` refuses it there by value —
 * otherwise a copy-paste out of this file into the Render dashboard would look
 * configured and protect nothing.
 */
export const DEVELOPMENT_AUDIT_MASK_KEY =
  "kleinburg-development-audit-mask-key-not-a-secret";

/** Why a configured key was rejected. */
export type AuditMaskKeyProblem =
  | "missing"
  | "too_short"
  | "development_placeholder";

function inspectAuditMaskKey(env: NodeJS.ProcessEnv): {
  key: string;
  problem: AuditMaskKeyProblem | null;
} {
  const configured = (env.AUDIT_MASK_KEY ?? "").trim();
  if (configured === "")
    return { key: DEVELOPMENT_AUDIT_MASK_KEY, problem: "missing" };
  if (configured === DEVELOPMENT_AUDIT_MASK_KEY)
    return {
      key: DEVELOPMENT_AUDIT_MASK_KEY,
      problem: "development_placeholder",
    };
  if (configured.length < MIN_AUDIT_MASK_KEY_LENGTH)
    return { key: DEVELOPMENT_AUDIT_MASK_KEY, problem: "too_short" };
  return { key: configured, problem: null };
}

const PROBLEM_DESCRIPTION: Record<AuditMaskKeyProblem, string> = {
  missing: "is not set",
  too_short: `is shorter than ${MIN_AUDIT_MASK_KEY_LENGTH} characters`,
  development_placeholder:
    "is set to the development placeholder from mask-key.ts, which is public",
};

function auditMaskKeyError(problem: AuditMaskKeyProblem): Error {
  return new Error(
    `AUDIT_MASK_KEY ${PROBLEM_DESCRIPTION[problem]}. ` +
      "The audit trail masks the username of a failed login by HMAC, and " +
      "without a real key that mask is reversible from a database dump " +
      "(see maskUnknownUsername, #55). Set AUDIT_MASK_KEY in the Render " +
      "dashboard (service → Environment) to a random string of at least " +
      `${MIN_AUDIT_MASK_KEY_LENGTH} characters — e.g. \`openssl rand -hex 32\` ` +
      "— and redeploy. Keep it out of the database and its backups: it is " +
      "only worth having while it does not travel with the data it protects.",
  );
}

function isProduction(env: NodeJS.ProcessEnv): boolean {
  return env.NODE_ENV === "production";
}

/**
 * The key to HMAC with, or a throw in production when there is not one.
 *
 * Fails CLOSED in production deliberately. The alternative — quietly using the
 * development key — would leave the code looking fixed while delivering the
 * unkeyed digest #55 exists to remove, and nobody would find out, because a
 * reversible mask looks identical to an irreversible one until someone has the
 * dump. A failed login erroring is loud and recoverable; a silent downgrade is
 * neither. In practice this throw should be unreachable, because the same
 * check runs at boot (see `validateAuditMaskKey`).
 */
export function resolveAuditMaskKey(
  env: NodeJS.ProcessEnv = process.env,
): string {
  const { key, problem } = inspectAuditMaskKey(env);
  if (problem && isProduction(env)) throw auditMaskKeyError(problem);
  return key;
}

/**
 * The boot check. Throws in production, warns everywhere else, and returns the
 * problem it found (or null) so a caller can assert on it.
 *
 * Runs at boot rather than at first use because the first use is a FAILED
 * LOGIN: leaving it to runtime means the config error surfaces at 3am, on the
 * one code path already having a bad night, instead of at deploy time when
 * someone is watching. Render keeps the previous instance serving when a
 * deploy fails to boot, so failing closed here costs a failed deploy, not
 * downtime.
 *
 * Outside production it must not throw: local dev and CI have no secret and
 * should not need one to run a test suite, so they get the development key and
 * a loud warning, in the same shape as the unregistered-model warning.
 */
export function validateAuditMaskKey(
  warn: (message: string) => void = console.warn,
  env: NodeJS.ProcessEnv = process.env,
): AuditMaskKeyProblem | null {
  const { problem } = inspectAuditMaskKey(env);
  if (!problem) return null;
  if (isProduction(env)) throw auditMaskKeyError(problem);

  warn(
    [
      "",
      "  ┌───────────────────────────────────────────────────────────────────┐",
      "  │  AUDIT_MASK_KEY — running on the PUBLIC development mask key      │",
      "  └───────────────────────────────────────────────────────────────────┘",
      "",
      `  AUDIT_MASK_KEY ${PROBLEM_DESCRIPTION[problem]}, so the failed-login`,
      "  username mask is running under the development key committed to",
      "  web/src/core/audit/mask-key.ts. That key is public, so the digests in",
      "  audit_events are reversible by anyone who reads this repo.",
      "",
      "  Fine locally and in CI — this is why the app still boots. NOT fine",
      "  anywhere real: a production boot with this key throws instead of",
      "  warning. Set AUDIT_MASK_KEY (see web/.env.example) to silence this.",
      "",
    ].join("\n"),
  );
  return problem;
}
