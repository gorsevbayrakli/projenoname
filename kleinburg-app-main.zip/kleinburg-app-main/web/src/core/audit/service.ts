/**
 * The audit trail (T41): writing and reading the append-only record of who did
 * what.
 *
 * ═══ WHY THIS MODULE EXISTS ═══════════════════════════════════════════════
 * #40 drew a boundary: the super admin administers the DIRECTORY and cannot
 * read brand content by role. (T50 has since carved SPEND out of that — an
 * admin reads any brand's costs and project names by role alone, on purpose;
 * see `core/llm/admin-spend.ts`. The paragraph below is about everything
 * else.) The #40 review showed that claim was half true.
 * `revokeBrandAccess` is a hard DELETE and there was no audit table, so an
 * admin could grant themselves membership, read a brand, and revoke — leaving
 * a database byte-identical to one where nothing happened. The evidence
 * existed only while the grant was live.
 *
 * This module is what makes #40's claim true. `membership_grant` and
 * `membership_revoke` both leave a row that outlives the `user_brands` row,
 * so the round trip is now visible afterwards, permanently, to the one person
 * who can audit it. Everything else here is the same idea applied to the other
 * three categories Elif asked for.
 *
 * ═══ APPEND-ONLY: WHAT IS ENFORCED, AND WHAT THAT IS WORTH ════════════════
 * Two layers, and it is worth being precise about what each buys.
 *
 * 1. APPLICATION. This module exports `recordAuditEvent`, its transactional
 *    and coalescing variants, and two read functions. There is no update path
 *    and no delete path, anywhere, and no retention job — Elif's call is
 *    unlimited retention until volume is measured, and an early purge policy
 *    contradicts the reason the table exists. This layer is what stops the
 *    ordinary accident: a well-meaning "clean up old rows" helper.
 *
 * 2. DATABASE. A `BEFORE UPDATE OR DELETE` trigger on `audit_events` that
 *    RAISEs, plus a statement-level one for TRUNCATE, added by hand to the
 *    migration because Drizzle does not model triggers. This layer is what
 *    stops the accident the application layer cannot see: a migration, a psql
 *    session, a future ORM call that bypasses this file. It fires for the
 *    table owner and for a superuser alike, and — since `drizzle/0007_*.sql`
 *    set both to ENABLE ALWAYS — regardless of `session_replication_role`.
 *    0006 shipped them as ENABLE ORIGIN and called that bypass unavoidable;
 *    it was not, and `service.test.ts` now pins the trigger state.
 *
 * What neither layer is: tamper-proof against someone with DDL rights, who can
 * `DROP TRIGGER` — or `DROP TABLE`, which takes the rows and the guards in one
 * statement and is available to exactly the same role, so do not over-read the
 * TRUNCATE guard. That is not a gap this repo can close — a genuinely
 * tamper-evident log needs append-only storage outside the database it audits
 * (WORM object storage, or a hash chain anchored somewhere the same operator
 * does not control). The trigger converts silent, casual erasure into an act
 * that requires deliberate DDL. Do not describe this table as tamper-proof.
 *
 * AND KNOW WHO HOLDS THAT DDL RIGHT TODAY. On Render — the previous host,
 * removed while a new one is chosen — the running application owned this
 * table: `render.yaml` handed the web service the database owner credential
 * because `startCommand` ran the migrations. So `DISABLE TRIGGER` was
 * reachable from application code, and the guards were a defence against
 * accident and against a careless admin, NOT against a compromised app
 * process. THIS IS A HOSTING CHOICE, NOT SOMETHING THIS CODE ENFORCES: the
 * next host inherits the same exposure unless it is deliberately set up with a
 * distinct low-privilege runtime role (INSERT/SELECT only) and migrations run
 * separately as the owner. That mitigation was written up for Render (now
 * deleted with the rest of that runbook) and was never applied there either —
 * whoever picks the new host should decide this before go-live, not rediscover
 * it after.
 *
 * ═══ RETENTION: UNLIMITED, AND WHAT THAT COSTS LATER ══════════════════════
 * Elif's call is unlimited retention until volume is measured, so there is no
 * purge job and no partitioning — and the second half of that has a
 * consequence worth writing down now rather than discovering later. Because
 * this is a plain unpartitioned table behind an append-only trigger, the day a
 * retention policy IS wanted, the only way to implement it is DISABLE TRIGGER
 * / DELETE / re-enable: a sequence indistinguishable from tampering, both in
 * the database and to anyone reading the migration history. Had the table been
 * created with monthly RANGE partitions on `occurred_at`, expiry would have
 * been `DETACH PARTITION` — routine, auditable, and never touching the guard.
 * That is the change to make if retention is ever adopted. Do not build
 * retention before then.
 *
 * ═══ THE DILEMMA: A FAILED AUDIT WRITE ON A SUCCESSFUL ACTION ═════════════
 * Hard rule 5 forbids swallowing an error. But an audit write that can fail
 * the action it records turns an audit-table outage into an application
 * outage. Both horns are real, and resolving it one way for everything is
 * wrong either way round, so it is resolved PER CATEGORY:
 *
 *   DIRECTORY ACTIONS ARE ATOMIC. `membership_grant`, `membership_revoke`,
 *   `brand_create`, `user_create`, `user_password_reset` write their audit row
 *   inside the SAME TRANSACTION as the action. If the row cannot be written,
 *   the action is rolled back and the admin gets a 500 with the real reason.
 *
 *   Why this way: an unaudited membership grant is precisely the thing T41
 *   exists to prevent. A grant that happened but was not recorded is strictly
 *   worse than a grant that did not happen — the first is an invisible
 *   privilege change, the second is a retry. These actions are low-volume,
 *   admin-initiated, synchronous and idempotent, so "it failed, do it again"
 *   costs one click. The cost of atomicity here is nearly zero and the benefit
 *   is the entire security claim, so atomicity wins outright.
 *
 *   EVERYTHING ELSE IS BEST-EFFORT, AND LOUD. Login, logout, failed login,
 *   generation triggers and content actions proceed even if their audit row
 *   fails to write. The failure is never swallowed: it goes to the server error
 *   log through `describeErrorForLog`, tagged `[audit] WRITE FAILED`, with the
 *   action and actor that were lost.
 *
 *   Why this way: the failure modes are asymmetric. Refusing a login because
 *   the audit table is unwritable locks every user out of the product,
 *   including the admin who would fix it — an audit dependency that becomes a
 *   self-inflicted denial of service, and one an attacker could trigger
 *   deliberately by filling the table. That last clause described a LIVE
 *   vulnerability for the whole of T41 and nobody followed it up: the login
 *   route was unauthenticated and unthrottled, so filling the table was a loop.
 *   See `core/audit/auth-failures.ts` for the two levers that close it, and
 *   note that they close the flood without touching the atomic guarantee above.
 *   Refusing an autosave loses a user's work. Neither trade is worth a log line about an action that is already
 *   constrained by `requireProjectAccess`.
 *
 *   "Best-effort" is NOT "silent". Hard rule 5 is about swallowing, not about
 *   propagating: an error that is logged with its real cause has not been
 *   swallowed. The one thing this module must never do is `catch {}`.
 *
 * ═══ WHAT IS DELIBERATELY NOT RECORDED ════════════════════════════════════
 *  - CONTENT BODIES. The row answers who and when; `step_contents` already
 *    holds what, and copying every draft into a table that can never be
 *    deleted would multiply both storage and exposure. `sanitizeAuditMetadata`
 *    enforces this with a length cap rather than trusting call sites.
 *  - SECRETS of any kind. See `events.ts`.
 *  - READS, WITH ONE EXCEPTION. Opening a project or viewing a step writes
 *    nothing. Elif asked for four categories and read-tracking is in none of
 *    them; it is also the category that would dwarf the others in volume
 *    (every page view) while answering the least. NOTE the consequence,
 *    because it bounds the security claim: the trail shows that an admin
 *    GRANTED themselves access to a brand and when they revoked it, not which
 *    projects they opened in between. That is enough to raise the question; it
 *    is not enough to answer "what exactly did they see".
 *
 *    THE EXCEPTION IS `spend_view_admin` (T50). It is a read, and it is
 *    recorded, because it is the one read that is NOT bounded by
 *    `requireProjectAccess` — an admin reaches it by role, across brands they
 *    have no membership in. The argument above ("reads are already constrained
 *    by the access gate, so a log line adds little") is precisely what fails
 *    for this one path, which is why this one path is the exception rather
 *    than the start of a slope. It is also why it COALESCES: a page view is
 *    not a mutation, and the volume objection above is real, so the row
 *    answers "did they look, at what, roughly when" rather than counting
 *    clicks. See `SPEND_VIEW_COALESCE_WINDOW_MS` in `events.ts`.
 *  - IP ADDRESSES. Not asked for, and three arguments against adding them
 *    uninvited: they are personal data under KVKK/GDPR in a table with
 *    deliberately unlimited retention; behind Render's proxy a naive read of
 *    `request.ip` records the proxy, and a naive read of `X-Forwarded-For`
 *    records whatever the client claims, so the plausible implementations are
 *    both wrong and a wrong IP in an audit log is worse than none.
 *    Flagged for Elif as a real decision, not an oversight.
 *
 *    A THIRD ARGUMENT USED TO STAND HERE AND WAS FALSE: that "the brute-force
 *    use case is already served by `core/auth/attempt-limiter.ts`". At the time
 *    it was written the limiter was wired to `/api/auth/change-password` and to
 *    nothing else — the login path, the one this bullet is about, had no limit
 *    at all. Corrected rather than deleted, because the claim is what let the
 *    unauthenticated login flood through review (#41 review, finding 1). The
 *    login route now has its own limiter and the failed-login row count has its
 *    own budget (`core/audit/auth-failures.ts`); neither of those depends on
 *    knowing an IP, so the conclusion survives, but the reasoning had to.
 *  - PROJECT CREATION. `projects.created_by` already records it and Elif's
 *    list names brand and user creation specifically. Add it if the four
 *    categories prove to have a hole.
 */

import { and, desc, eq, gt, sql, type SQL } from "drizzle-orm";

import { isSuperAdmin } from "../auth/roles";
import { getDb } from "../db/client";
import { describeErrorForLog } from "../errors/redact";
import {
  auditEvents,
  type AuditAction,
  type AuditEvent,
  type User,
  type WorkflowStep,
} from "../db/schema";
import {
  CONTENT_COALESCE_WINDOW_MS,
  SPEND_VIEW_COALESCE_WINDOW_MS,
  isCoalescedAction,
  sanitizeAuditMetadata,
  sanitizeAuditName,
} from "./events";

/** The acting user, as far as this module cares. */
export type AuditActor = Pick<User, "id" | "role">;

/**
 * What a caller supplies. Everything but `action` and `actorUsername` is
 * optional, because the four categories describe genuinely different things
 * and forcing a shared shape would mean nullable fields with invented values.
 */
export interface AuditEventInput {
  action: AuditAction;
  /** NULL only for a failed login against an unknown username. */
  actorUserId?: string | null;
  /**
   * The actor's name AS IT WAS. Required even when `actorUserId` is null, so
   * every row names somebody.
   *
   * `auth_login_failed` used to be the exception that made this column
   * sensitive: it stored the string typed into the username box, so a user who
   * typed their password one field early left it here permanently, and
   * `sanitizeAuditName` could not help because a bare password has no
   * recognisable shape. That path no longer calls this interface directly — it
   * goes through `recordFailedLoginAuditEvent`, which stores an unresolvable
   * username as a digest (#41 review, finding 4). Every remaining caller passes
   * a name it already holds in `users` or `brands`, so this column no longer
   * carries credential material. Keep it that way: do not add a call site that
   * puts unvalidated, user-typed text here.
   */
  actorUsername: string;
  targetUserId?: string | null;
  targetUsername?: string | null;
  brandId?: string | null;
  brandName?: string | null;
  projectId?: string | null;
  projectName?: string | null;
  step?: WorkflowStep | null;
  metadata?: Record<string, unknown>;
}

/**
 * The minimum a writer needs: `getDb()` and a Drizzle transaction both satisfy
 * it, which is what lets the atomic path pass its `tx` straight in.
 */
type AuditWriter = Pick<ReturnType<typeof getDb>, "insert" | "select">;

/** Turn caller input into the row, with every string sanitised. */
function toRow(input: AuditEventInput) {
  return {
    action: input.action,
    actorUserId: input.actorUserId ?? null,
    actorUsername: sanitizeAuditName(input.actorUsername),
    targetUserId: input.targetUserId ?? null,
    targetUsername: input.targetUsername
      ? sanitizeAuditName(input.targetUsername)
      : null,
    brandId: input.brandId ?? null,
    brandName: input.brandName ? sanitizeAuditName(input.brandName) : null,
    projectId: input.projectId ?? null,
    projectName: input.projectName
      ? sanitizeAuditName(input.projectName)
      : null,
    step: input.step ?? null,
    metadata: sanitizeAuditMetadata(input.metadata),
  };
}

/**
 * ATOMIC write. Throws on failure, so the caller's transaction rolls back and
 * the action does not happen.
 *
 * Takes the writer as its first argument precisely so it can be handed a `tx`.
 * `core/admin/service.ts` calls this INSIDE `db.transaction`, which is what
 * makes "the grant and its record land together or not at all" a database
 * guarantee rather than a hopeful ordering of two statements.
 */
export async function recordAuditEventTx(
  writer: AuditWriter,
  input: AuditEventInput,
): Promise<void> {
  await writer.insert(auditEvents).values(toRow(input));
}

/**
 * BEST-EFFORT write. Never throws; never silent.
 *
 * For the auth, generation and content categories. If the insert fails the
 * caller's action still succeeds and the operator gets a log line naming the
 * action and actor that were lost — which is the difference between a
 * best-effort write and a swallowed error.
 */
export async function recordAuditEvent(input: AuditEventInput): Promise<void> {
  try {
    await recordAuditEventTx(getDb(), input);
  } catch (e) {
    reportAuditFailure(input, e);
  }
}

/**
 * The one place an audit failure is reported. Uses `describeErrorForLog`, so a
 * driver error that quotes the failing statement cannot put a credential in
 * the log — the same helper and the same reasoning as `lib/api-errors.ts`.
 *
 * `actorUsername` is NOT included: on the `auth_login_failed` path it is
 * attacker-controlled, and the log line is the wrong place to relay it.
 */
function reportAuditFailure(input: AuditEventInput, e: unknown): void {
  console.error(
    `[audit] WRITE FAILED action=${input.action} actorUserId=${
      input.actorUserId ?? "anonymous"
    } -> ${describeErrorForLog(e)}`,
  );
}

/**
 * BEST-EFFORT write for category 4, collapsing an editing burst into one row.
 *
 * A conditional insert, not an upsert: the row is written only when no row
 * with the same (actor, project, action) exists inside
 * `CONTENT_COALESCE_WINDOW_MS`. The table is never updated, so append-only
 * survives; what is traded away is resolution, not integrity.
 *
 * The check and the insert are two statements, so two concurrent autosaves can
 * both decide to write. That race is left unguarded on purpose: its worst
 * outcome is a duplicate row, and a duplicate in an append-only log is
 * redundant, not wrong. Serialising every autosave behind a lock to prevent a
 * harmless duplicate would be the more expensive mistake.
 */
export async function recordContentAuditEvent(
  input: AuditEventInput,
): Promise<void> {
  try {
    if (isCoalescedAction(input.action) && input.actorUserId) {
      const since = new Date(Date.now() - CONTENT_COALESCE_WINDOW_MS);
      const [recent] = await getDb()
        .select({ id: auditEvents.id })
        .from(auditEvents)
        .where(
          and(
            eq(auditEvents.action, input.action),
            eq(auditEvents.actorUserId, input.actorUserId),
            input.projectId
              ? eq(auditEvents.projectId, input.projectId)
              : sql`${auditEvents.projectId} is null`,
            input.step
              ? eq(auditEvents.step, input.step)
              : sql`${auditEvents.step} is null`,
            gt(auditEvents.occurredAt, since),
          ),
        )
        .limit(1);
      if (recent) return;
    }
    await recordAuditEventTx(getDb(), input);
  } catch (e) {
    reportAuditFailure(input, e);
  }
}

/**
 * FAIL-CLOSED, COALESCING write for the super admin's cross-brand spend view
 * (T50). Returns true when a row was written, false when an equivalent row
 * already covers this window. THROWS if the write fails.
 *
 * ── WHY FAIL-CLOSED, WHEN EVERY OTHER READ-ADJACENT PATH IS BEST-EFFORT ──
 * The dilemma at the top of this file resolves per category, and this category
 * lands on the atomic side for the same reason `membership_grant` does: the
 * record is not a nice-to-have alongside the action, it is the entire
 * justification for permitting it. Elif accepted a real content exposure —
 * project names describe campaigns — specifically on the basis that crossing
 * the boundary leaves a trace. An untraced crossing is the thing that was not
 * agreed to, so if the trace cannot be written the data is not shown.
 *
 * And unlike the login path, failing closed here costs almost nothing and
 * cannot cascade. It refuses ONE view — an admin's spend page for a brand they
 * are not a member of. It does not touch their own brands (the member path
 * writes no row and calls nothing here), it locks nobody out of the product,
 * and it is not reachable by an unauthenticated party, so it cannot be used to
 * manufacture an outage. The self-inflicted-denial-of-service argument that
 * makes login best-effort simply does not apply.
 *
 * ── COALESCING ──────────────────────────────────────────────────────────
 * Conditional insert on (actor, brand, project) inside
 * `SPEND_VIEW_COALESCE_WINDOW_MS`, never an update, so append-only holds. The
 * full reasoning — including why a page view must not be recorded per click,
 * and why the project stays in the key — is in `events.ts` next to the window.
 *
 * The check and the insert are two statements, so two concurrent page loads
 * can both decide to write. Left unguarded exactly as in
 * `recordContentAuditEvent`: the worst outcome is a duplicate row, and a
 * duplicate in an append-only log is redundant rather than wrong. Note the
 * race can only ever produce MORE evidence, never less, which is the harmless
 * direction for this particular row to be wrong in.
 */
export async function recordSpendViewAuditEvent(
  input: AuditEventInput,
): Promise<boolean> {
  const since = new Date(Date.now() - SPEND_VIEW_COALESCE_WINDOW_MS);
  const [recent] = await getDb()
    .select({ id: auditEvents.id })
    .from(auditEvents)
    .where(
      and(
        eq(auditEvents.action, input.action),
        input.actorUserId
          ? eq(auditEvents.actorUserId, input.actorUserId)
          : sql`${auditEvents.actorUserId} is null`,
        input.brandId
          ? eq(auditEvents.brandId, input.brandId)
          : sql`${auditEvents.brandId} is null`,
        input.projectId
          ? eq(auditEvents.projectId, input.projectId)
          : sql`${auditEvents.projectId} is null`,
        gt(auditEvents.occurredAt, since),
      ),
    )
    .limit(1);

  if (recent) return false;

  await recordAuditEventTx(getDb(), input);
  return true;
}

// ── Reading ───────────────────────────────────────────────────────────────

/** Default page size for the log view. */
export const DEFAULT_AUDIT_PAGE_SIZE = 50;
/** Hard ceiling, so a crafted `limit` cannot pull the whole table. */
export const MAX_AUDIT_PAGE_SIZE = 200;

export interface ListAuditEventsOptions {
  limit?: number;
  offset?: number;
  /** Narrow to one action. Never widens the scope below. */
  action?: AuditAction;
  /**
   * Narrow to one actor. Honoured for the super admin; for anyone else it is
   * IGNORED, because their scope is already exactly themselves.
   */
  actorUserId?: string;
}

export interface AuditEventPage {
  events: AuditEvent[];
  /** True when more rows exist past this page. */
  hasMore: boolean;
}

/**
 * ═══ VISIBILITY ═══════════════════════════════════════════════════════════
 * Elif's decision: the super admin sees everything; an ordinary user sees
 * ONLY their own records, and nobody else's.
 *
 * "Their own" means `actor_user_id = me` — rows recording what I DID. It
 * pointedly does NOT include rows where I am the TARGET, and that is the
 * tenancy subtlety this function exists to get right.
 *
 * An audit row carries cross-brand information by nature: `membership_grant`
 * names an admin, a user, and a BRAND. If the scope were "rows that mention
 * me", then an ordinary user would read the brand names of every brand an
 * admin ever granted them or considered granting them — turning the "my own
 * records" view into a directory-enumeration oracle for brands the user cannot
 * access, through a page whose whole purpose is transparency. So the predicate
 * is on the actor column alone, and `audit.test.ts` proves it.
 *
 * Consequence Elif should know: a user therefore cannot see admin actions
 * taken UPON their account — their own password being reset, their own
 * membership being granted or revoked. That is a real product trade-off, taken
 * this way because the brief says "nobody else's records" and because the
 * alternative leaks brand names. If Elif would rather users saw actions
 * against their own account, the fix is a second, explicitly brand-redacted
 * query, not a widened predicate here.
 *
 * The scope is applied unconditionally and is ANDed with every caller filter,
 * so no combination of options can widen it. This is the authorization; the
 * UI hiding a link is not.
 */
export async function listAuditEvents(
  actor: AuditActor,
  options: ListAuditEventsOptions = {},
): Promise<AuditEventPage> {
  const limit = Math.min(
    Math.max(1, options.limit ?? DEFAULT_AUDIT_PAGE_SIZE),
    MAX_AUDIT_PAGE_SIZE,
  );
  const offset = Math.max(0, options.offset ?? 0);

  const filters: SQL[] = [];

  // THE SCOPE. Non-negotiable, applied before any caller filter is considered.
  if (!isSuperAdmin(actor)) {
    filters.push(eq(auditEvents.actorUserId, actor.id));
  } else if (options.actorUserId) {
    filters.push(eq(auditEvents.actorUserId, options.actorUserId));
  }

  if (options.action) {
    filters.push(eq(auditEvents.action, options.action));
  }

  // Fetch one extra row to answer `hasMore` without a second COUNT query.
  const rows = await getDb()
    .select()
    .from(auditEvents)
    .where(filters.length > 0 ? and(...filters) : undefined)
    .orderBy(desc(auditEvents.occurredAt), desc(auditEvents.id))
    .limit(limit + 1)
    .offset(offset);

  return {
    events: rows.slice(0, limit),
    hasMore: rows.length > limit,
  };
}
