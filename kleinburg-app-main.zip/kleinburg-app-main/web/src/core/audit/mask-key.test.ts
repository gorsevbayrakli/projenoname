/**
 * The missing-secret decision for AUDIT_MASK_KEY (#55), tested at the boundary
 * it is enforced on: boot.
 *
 * A config error must surface at DEPLOY time, not at 3am on the first failed
 * login, so production refuses to boot without the key. Silently falling back
 * to the public development key would reopen exactly the hole #55 closes, so
 * that fallback is deliberately unavailable in production — including for the
 * development key's own value, so a copy-pasted placeholder cannot quietly
 * become the production secret.
 */
import { afterEach, describe, expect, it } from "vitest";

import { maskUnknownUsername, UNKNOWN_USERNAME_PREFIX } from "./events";
import {
  DEVELOPMENT_AUDIT_MASK_KEY,
  MIN_AUDIT_MASK_KEY_LENGTH,
  validateAuditMaskKey,
} from "./mask-key";

/**
 * `process.env.NODE_ENV` is typed read-only, and these tests have to move it:
 * the whole decision under test is "what does production do differently".
 */
function setEnvVar(name: string, value: string | undefined): void {
  const env = process.env as Record<string, string | undefined>;
  if (value === undefined) delete env[name];
  else env[name] = value;
}

describe("validateAuditMaskKey (#55 boot check)", () => {
  const savedKey = process.env.AUDIT_MASK_KEY;
  const savedNodeEnv = process.env.NODE_ENV;

  afterEach(() => {
    setEnvVar("AUDIT_MASK_KEY", savedKey);
    setEnvVar("NODE_ENV", savedNodeEnv);
  });

  function productionEnv(key?: string): NodeJS.ProcessEnv {
    return key === undefined
      ? ({ NODE_ENV: "production" } as NodeJS.ProcessEnv)
      : ({ NODE_ENV: "production", AUDIT_MASK_KEY: key } as NodeJS.ProcessEnv);
  }

  it("FAILS THE BOOT in production when the key is missing", () => {
    const warnings: string[] = [];

    expect(() =>
      validateAuditMaskKey((m) => warnings.push(m), productionEnv()),
    ).toThrow(/AUDIT_MASK_KEY/);
    expect(warnings).toEqual([]);
  });

  it("names the variable and where to set it, so the failure is actionable", () => {
    let message = "";
    try {
      validateAuditMaskKey(() => {}, productionEnv());
    } catch (error) {
      message = (error as Error).message;
    }

    expect(message).toContain("AUDIT_MASK_KEY");
    expect(message).toContain("Render");
  });

  it("FAILS THE BOOT in production when the development key was copy-pasted in", () => {
    expect(() =>
      validateAuditMaskKey(() => {}, productionEnv(DEVELOPMENT_AUDIT_MASK_KEY)),
    ).toThrow(/AUDIT_MASK_KEY/);
  });

  it("FAILS THE BOOT in production when the key is too short to be a secret", () => {
    expect(() =>
      validateAuditMaskKey(() => {}, productionEnv("short")),
    ).toThrow(/AUDIT_MASK_KEY/);
  });

  it("boots silently in production once a real key is set", () => {
    const warnings: string[] = [];
    expect(
      validateAuditMaskKey(
        (m) => warnings.push(m),
        productionEnv("k".repeat(MIN_AUDIT_MASK_KEY_LENGTH)),
      ),
    ).toBe(null);
    expect(warnings).toEqual([]);
  });

  it("outside production WARNS instead of failing, and masking still works", () => {
    const warnings: string[] = [];

    expect(
      validateAuditMaskKey((m) => warnings.push(m), {
        NODE_ENV: "development",
      } as NodeJS.ProcessEnv),
    ).not.toBe(null);
    expect(warnings.length).toBe(1);
    expect(warnings[0]).toContain("AUDIT_MASK_KEY");

    setEnvVar("AUDIT_MASK_KEY", undefined);
    setEnvVar("NODE_ENV", "development");
    expect(maskUnknownUsername("root").startsWith(UNKNOWN_USERNAME_PREFIX)).toBe(
      true,
    );
  });
});
