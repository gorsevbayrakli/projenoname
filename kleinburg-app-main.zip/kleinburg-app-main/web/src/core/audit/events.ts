/**
 * The pure half of the audit trail (T41): what an action means, and what is
 * allowed to travel with it.
 *
 * No database, no next, no react (hard rule 1) — everything here is testable
 * without Postgres, which matters because this is the module that decides
 * whether a secret can reach the log.
 */

import { createHmac } from "node:crypto";

import { redactSecrets, REDACTED } from "../errors/redact";
import { resolveAuditMaskKey } from "./mask-key";
import { AUDIT_ACTIONS, type AuditAction } from "../db/schema";

export { AUDIT_ACTIONS };
export type { AuditAction };

/**
 * The categories an action can belong to. Used by the viewing UI to offer a
 * filter, and by `audit.test.ts` to assert that every action belongs to
 * exactly one — a new action that nobody classified is a bug, because it would
 * be invisible to a reader filtering by category.
 *
 * Four of these are Elif's 20 July categories. `spend` is the fifth, added by
 * T50, and it is deliberately its OWN category rather than folded into
 * `directory`: `directory` means "the admin changed the shape of the
 * directory", and every action in it is a mutation an admin performed. A
 * cross-brand spend view is neither — it is a READ, and the one read this
 * table records. Filing it under `directory` would make a reader filtering for
 * privilege changes wade through page views, and filing it under `content`
 * would put an admin's boundary crossing next to an ordinary user's autosave.
 * It is its own thing, so it gets its own name.
 */
export const AUDIT_CATEGORIES = {
  directory: [
    "brand_create",
    "user_create",
    "user_password_reset",
    "membership_grant",
    "membership_revoke",
    // T51. A mutation, by an admin, on brand configuration — the same shape as
    // the four above, so the same category and the same atomic write. It is
    // deliberately NOT filed under `spend`: that category is "an admin read
    // across a boundary", and putting a privilege-shaped change next to page
    // views would hide it from the reader most likely to be looking for it.
    "brand_cap_set",
    // #89. A privilege mutation performed by an admin on an existing account:
    // the same shape as `membership_grant`, and the one action in this file
    // that can lock every human out of the panel if it goes wrong. So it is
    // `directory`, and therefore atomic — a role change nobody can see is the
    // one this feature must never produce.
    "user_role_change",
  ],
  auth: [
    "auth_login",
    "auth_login_failed",
    "auth_logout",
    "user_password_change",
    // Not a login, but the same question a reader of this category asks: what
    // happened to the credentials and the recovery channel of this account.
    "user_email_change",
  ],
  generation: ["generation_start"],
  content: ["content_edit", "content_select", "content_download"],
  spend: ["spend_view_admin"],
} as const satisfies Record<string, readonly AuditAction[]>;

export type AuditCategory = keyof typeof AUDIT_CATEGORIES;

/** The category an action belongs to. */
export function categoryOf(action: AuditAction): AuditCategory {
  for (const [category, actions] of Object.entries(AUDIT_CATEGORIES)) {
    if ((actions as readonly string[]).includes(action)) {
      return category as AuditCategory;
    }
  }
  // Unreachable while the `satisfies` above holds and the test passes; throwing
  // beats returning a wrong category silently (hard rule 5).
  throw new Error(`audit action with no category: ${action}`);
}

/**
 * Actions whose audit write must be ATOMIC with the action itself — if the row
 * cannot be written, the action does not happen.
 *
 * Exactly the directory category. The reasoning is in `service.ts`; the short
 * version is that an unaudited membership grant is the precise thing T41
 * exists to prevent, so it is better not to grant at all. Everything else is
 * best-effort, because failing a login or an autosave over a log write turns
 * an audit outage into an application outage.
 */
export const ATOMIC_AUDIT_ACTIONS: readonly AuditAction[] =
  AUDIT_CATEGORIES.directory;

/** True if this action's write must succeed for the action to be allowed. */
export function isAtomicAuditAction(action: AuditAction): boolean {
  return ATOMIC_AUDIT_ACTIONS.includes(action);
}

// ── Volume control for category 4 ─────────────────────────────────────────

/**
 * How long one editing session's worth of the same content action collapses
 * into a single row.
 *
 * Category 4 is the high-volume one and the step UIs autosave: without this,
 * one person editing one step for ten minutes writes hundreds of rows that all
 * say the same thing. Five minutes is chosen to be long enough to swallow a
 * continuous editing burst and short enough that "came back after lunch and
 * edited again" is still a separate, visible event.
 *
 * Note what this is NOT: it is not an update-in-place. Coalescing an
 * append-only log by rewriting a row's timestamp would be an UPDATE, which the
 * table forbids. It is a conditional INSERT — the row is written only if no
 * matching row exists inside the window — so the log stays strictly append-only
 * and the cost is resolution, not integrity. A reader sees "edited this step
 * around 14:03", not every keystroke, which is the honest granularity anyway.
 */
export const CONTENT_COALESCE_WINDOW_MS = 5 * 60 * 1000;

/**
 * The actions that coalesce. Downloads deliberately do NOT: a download is a
 * discrete act of taking content out of the system, it happens a handful of
 * times rather than continuously, and "how many times was this exported" is a
 * question a security reader will actually ask.
 */
export const COALESCED_ACTIONS: readonly AuditAction[] = [
  "content_edit",
  "content_select",
];

export function isCoalescedAction(action: AuditAction): boolean {
  return COALESCED_ACTIONS.includes(action);
}

/**
 * How long one admin's cross-brand spend viewing collapses into a single row
 * per (admin, brand, project) — T50.
 *
 * ── WHY COALESCE AT ALL ──────────────────────────────────────────────────
 * The same reasoning as category 4, arriving from the other direction. A
 * mutation is a discrete fact and every one of them deserves a row. A page
 * VIEW is not: `/spend` re-runs its queries on every brand chip click, every
 * project drill-down, every back button and every refresh, so an admin
 * comparing six brands to find the outlier — the exact task this feature
 * exists for — would write dozens of rows in under a minute, all of them
 * saying the same thing. The table has no DELETE path, so that noise is
 * permanent and it would bury the directory mutations that are the reason a
 * human opens /activity at all.
 *
 * The question the trail has to answer is "did this admin look inside a brand
 * they are not a member of, and roughly when" — not "how many times did they
 * click". Coalescing answers the first exactly and gives up only the second.
 * As in category 4 this is a CONDITIONAL INSERT, never an update, so
 * append-only is untouched; what is traded is resolution, not integrity.
 *
 * ── WHY THE KEY INCLUDES THE PROJECT ─────────────────────────────────────
 * Keyed on (actor, brand, project) rather than (actor, brand). Keying on the
 * brand alone would be cheaper and would still record the crossing, but it
 * would silently swallow "which projects did they open", and project names are
 * precisely the content this decision knowingly exposed — so they are
 * precisely what the record should name. The row count stays bounded by the
 * number of projects in the brand, which is small.
 *
 * ── WHY THIRTY MINUTES ───────────────────────────────────────────────────
 * Longer than category 4's five, because a spend investigation is a slower
 * activity than a typing burst: an admin flips between brands, reads, comes
 * back. Thirty minutes covers one sitting while still making "looked again
 * that afternoon" a separate, visible event.
 */
export const SPEND_VIEW_COALESCE_WINDOW_MS = 30 * 60 * 1000;

// ── Metadata sanitisation ─────────────────────────────────────────────────

/**
 * Longest a single metadata string may be. Small on purpose: metadata is for
 * identifiers and counts, and anything longer is either a content body or a
 * mistake. Both get truncated rather than stored.
 */
export const MAX_METADATA_VALUE_LENGTH = 200;

/** Longest a username-ish snapshot may be (see `sanitizeAuditName`). */
export const MAX_NAME_LENGTH = 200;

/** Most keys one metadata object may carry. */
export const MAX_METADATA_KEYS = 20;

/** Marker appended when a value was cut short, so truncation is never silent. */
export const TRUNCATED = "…[truncated]";

/**
 * Key names that may never carry a value into the log, whatever the value is.
 *
 * `redactSecrets` masks secret-SHAPED text inside a string, which is the right
 * tool for a free-form error message. It is the wrong and only tool for a
 * structured object: `{ password: "hunter2" }` has nothing in the VALUE that
 * looks like a secret, so a value-only pass would store it verbatim. Here the
 * KEY is the signal, and it is available, so it is used first.
 */
const SECRET_KEY_PATTERN =
  /(password|passwd|secret|token|apikey|api_key|authorization|credential|hash|salt|cookie|session)/i;

/**
 * A log-safe metadata object.
 *
 * Four passes, each closing a different route a secret or a content body takes
 * into a permanent table:
 *  1. keys that name credential material are replaced with `[redacted]` —
 *     REPLACED, not dropped, so a reader can see that something was withheld
 *     rather than wondering whether it was ever recorded;
 *  2. every string value goes through `redactSecrets`, catching a secret that
 *     arrived under an innocent key (`{ note: "password=hunter2" }`);
 *  3. values are truncated to `MAX_METADATA_VALUE_LENGTH`, which is the
 *     mechanical version of "do not log content bodies" — a caller that passes
 *     a whole generated post stores 200 characters of it, not the post;
 *  4. only scalars survive. Nested objects and arrays become a type marker,
 *     because a nested shape is how an unbounded blob gets in past a per-value
 *     cap, and no legitimate caller needs one.
 *
 * This is deliberately paranoid about its own callers. Every call site today
 * passes something harmless; this function exists so that the one added next
 * year, in a hurry, cannot make the audit trail into a credential store.
 */
export function sanitizeAuditMetadata(
  metadata: Record<string, unknown> | undefined | null,
): Record<string, unknown> {
  if (!metadata || typeof metadata !== "object") return {};

  const out: Record<string, unknown> = {};
  let count = 0;

  for (const [key, value] of Object.entries(metadata)) {
    if (count >= MAX_METADATA_KEYS) {
      out["…"] = `${Object.keys(metadata).length - count} more keys dropped`;
      break;
    }
    count += 1;

    if (SECRET_KEY_PATTERN.test(key)) {
      out[key] = REDACTED;
      continue;
    }

    if (value === null || value === undefined) {
      out[key] = null;
    } else if (typeof value === "number" || typeof value === "boolean") {
      out[key] = value;
    } else if (typeof value === "string") {
      out[key] = truncate(redactSecrets(value), MAX_METADATA_VALUE_LENGTH);
    } else {
      // Objects, arrays, functions, symbols, bigints: not a scalar, not stored.
      out[key] = `[${Array.isArray(value) ? "array" : typeof value}]`;
    }
  }

  return out;
}

/**
 * A log-safe name snapshot (`actor_username`, `brand_name`, …).
 *
 * Runs `redactSecrets` and caps the length. Note what this does NOT do: it
 * only masks secret-SHAPED text (`password=hunter2`, an argon2 digest), so a
 * bare `hunter2` passes through untouched. Every caller of this function must
 * therefore already be passing a value it is willing to store forever. The one
 * caller that could not make that promise — the attempted username on a failed
 * login — does not use this function any more; see `maskUnknownUsername`.
 */
export function sanitizeAuditName(name: string): string {
  return truncate(redactSecrets(name), MAX_NAME_LENGTH);
}

/** Prefix marking an `actor_username` that was hashed rather than stored. */
export const UNKNOWN_USERNAME_PREFIX = "unknown:";

/** Hex characters of the digest kept. 48 bits: no realistic collision here. */
export const UNKNOWN_USERNAME_DIGEST_LENGTH = 12;

/**
 * The stand-in stored in `actor_username` for a failed login against a
 * username that does not exist (#41 review, finding 4).
 *
 * ── THE PROBLEM ──────────────────────────────────────────────────────────
 * The classic way `actor_username` acquires a password is a user typing their
 * password into the username box one field early. `sanitizeAuditName` cannot
 * help: it masks secret-SHAPED text, and a bare `hunter2` has no shape. The
 * column is permanent (the table forbids DELETE), unlimited-retention and
 * readable by the super admin, so a mistyped password landing there is a
 * credential disclosure with no expiry and no remedy short of DDL.
 *
 * ── WHY HASHING ONLY THE UNKNOWN HALF IS THE RIGHT CUT ───────────────────
 * Split the failed logins in two and the trade-off resolves cleanly:
 *
 *   KNOWN username — the string is, by definition, an identifier that already
 *   exists in `users`. It is not credential material, it names a real account
 *   under attack, and it is the row a security reader actually needs. Stored
 *   VERBATIM, and `recordFailedLoginAuditEvent` keeps it that way.
 *
 *   UNKNOWN username — no account exists, so there is nothing to defend and
 *   the investigative value of the exact string is close to nil. This is also
 *   exactly the bucket a mistyped password falls into, because a password is
 *   not a username. So the string is replaced by a digest.
 *
 * What survives the hash is the part worth keeping: the digest is stable, so
 * "the same unknown identifier was tried 400 times" and "300 distinct
 * identifiers were tried" both stay legible, which is the probing signal. What
 * is given up is "which names were tried" — and that is the half that could be
 * somebody's password.
 *
 * Case- and Unicode-normalised before hashing so that `Admin` and `admin`
 * correlate rather than looking like two attackers.
 *
 * ── WHY IT IS KEYED, AND WHAT THAT BUYS (#55) ────────────────────────────
 * The digest is an HMAC under `AUDIT_MASK_KEY`, not a bare hash. A bare
 * sha256 of a password is a lookup, not a mask: the input space this function
 * protects is exactly the space an attacker already has a wordlist for, so
 * whoever holds a dump hashes the list once, matches it against the column,
 * and reads the mistyped passwords straight out. Keying removes that, because
 * the wordlist cannot be hashed without the key, and the key is not in the
 * database. Every correlation property argued for above survives, since a
 * stable key keeps equal inputs equal.
 *
 * ── WHAT IT STILL DOES NOT PROTECT AGAINST ───────────────────────────────
 * An attacker holding BOTH the dump and the key is back to the unkeyed case:
 * they can hash a wordlist under the key and match it. Keying separates the
 * two secrets so that one breach is not enough, it does not make the digest
 * one-way against a small input space. Concretely this means the key must not
 * live where the data lives — not in the database, not in a backup of it, not
 * in the repo — and rotating it is a real remedy after a dump leaks, at the
 * cost of breaking correlation across the rotation (old and new rows never
 * match again). It also does not shorten retention: the row is still
 * permanent, and 48 bits is still narrow enough that someone with the key can
 * confirm a GUESSED input, so this reduces the blast radius of a dump rather
 * than making the column safe to publish.
 */
export function maskUnknownUsername(
  attempted: string,
  env: NodeJS.ProcessEnv = process.env,
): string {
  const digest = createHmac("sha256", resolveAuditMaskKey(env))
    .update(attempted.normalize("NFKC").toLowerCase())
    .digest("hex")
    .slice(0, UNKNOWN_USERNAME_DIGEST_LENGTH);
  return `${UNKNOWN_USERNAME_PREFIX}${digest}`;
}

function truncate(value: string, max: number): string {
  return value.length <= max ? value : value.slice(0, max) + TRUNCATED;
}
