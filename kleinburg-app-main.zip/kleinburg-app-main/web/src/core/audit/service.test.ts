/**
 * The audit trail against a real Postgres (T41).
 *
 * Four claims, in descending order of how much they matter:
 *
 *  1. APPEND-ONLY IS REAL. The database itself refuses UPDATE, DELETE and
 *     TRUNCATE. Not a convention, not "we just don't call it" — a trigger.
 *  2. A MEMBERSHIP ROUND TRIP LEAVES EVIDENCE. grant -> revoke destroys the
 *     `user_brands` row and leaves both audit rows behind. This is the whole
 *     reason the issue exists: #40's review found the database went
 *     byte-identical after an admin granted themselves access, read a brand
 *     and revoked. It no longer does.
 *  3. VISIBILITY IS SERVER-SIDE AND CANNOT BE WIDENED. A super admin sees
 *     everything; anybody else sees their own rows and nothing else — in
 *     particular not rows where they are the TARGET, because those name brands
 *     they may not be allowed to know exist.
 *  4. NO SECRET REACHES THE TABLE, on the paths that handle secrets.
 *
 * ── A NOTE ON CLEANUP ────────────────────────────────────────────────────
 * This file cannot clean up after itself, and that is not an oversight: the
 * table it tests forbids DELETE. Every assertion is therefore scoped to ids
 * this run created, and none may assume an empty table. That constraint is
 * itself a small proof that the trigger works.
 */
import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { and, eq, inArray, sql } from "drizzle-orm";

import {
  createBrand,
  createUser,
  grantBrandAccess,
  revokeBrandAccess,
  setTemporaryPassword,
  type Actor,
} from "../admin/service";
import { hashPassword } from "../auth/password";
import { authenticate } from "../auth/session";
import { closeDb, getDb } from "../db/client";
import { auditEvents, brands, userBrands, users } from "../db/schema";
import {
  listAuditEvents,
  recordAuditEvent,
  recordContentAuditEvent,
  MAX_AUDIT_PAGE_SIZE,
} from "./service";
import { CONTENT_COALESCE_WINDOW_MS, maskUnknownUsername } from "./events";
import {
  AUTH_FAILURE_AUDIT_MAX_PER_WINDOW,
  resetAuthFailureAuditBudget,
} from "./auth-failures";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

const TEMP = "gecici-sifre-2026";

async function makeUser(role: "admin" | "user" = "user") {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({
      username: `t41-${randomUUID()}`,
      passwordHash: await hashPassword(TEMP),
      role,
    })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

async function makeBrand() {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: `t41-brand-${randomUUID()}` })
    .returning();
  createdBrandIds.push(brand.id);
  return brand;
}

function actorOf(u: { id: string; role: "admin" | "user"; username: string }): Actor {
  return { id: u.id, role: u.role, username: u.username };
}

/** Audit rows this run wrote for a given actor, newest first. */
async function rowsForActor(actorUserId: string) {
  return getDb()
    .select()
    .from(auditEvents)
    .where(eq(auditEvents.actorUserId, actorUserId));
}

describe.skipIf(!hasDb)("audit trail", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    // Users and brands ARE cleaned up. audit_events deliberately is not, and
    // cannot be — which is also why these deletes are safe: the audit table
    // has no foreign keys, so removing a user neither cascades into the trail
    // nor is blocked by it.
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  // ── 1. Append-only, enforced by the database ────────────────────────────

  describe("is append-only at the DATABASE level", () => {
    /**
     * The application layer exports no update and no delete path, which is
     * necessary and not sufficient: it says nothing about a migration, a psql
     * session, or an ORM call written next year that does not go through
     * `service.ts`. These three tests are about the layer that covers those —
     * the trigger in `drizzle/0006_*.sql`.
     *
     * They go through raw SQL ON PURPOSE. Asserting that a function this
     * module does not export cannot be called would be circular; the point is
     * that the database refuses even when the application is bypassed
     * entirely.
     */
    /**
     * Drizzle wraps a driver error as `Failed query: …` and parks the real
     * one on `.cause`, so asserting on the top-level message would pass for
     * ANY failure — including the trigger not existing and the statement
     * failing for some unrelated reason. Unwrap, and assert on what Postgres
     * actually said.
     */
    async function rejectionCause(p: Promise<unknown>): Promise<string> {
      try {
        await p;
      } catch (e) {
        const cause = (e as { cause?: unknown }).cause;
        return cause instanceof Error ? cause.message : String(e);
      }
      throw new Error("expected the statement to be rejected, but it succeeded");
    }

    async function seedRow() {
      const [row] = await getDb()
        .insert(auditEvents)
        .values({
          action: "auth_login",
          actorUserId: randomUUID(),
          actorUsername: `t41-immutable-${randomUUID()}`,
        })
        .returning();
      return row;
    }

    it("refuses an UPDATE", async () => {
      const row = await seedRow();
      const message = await rejectionCause(
        getDb().execute(sql`update audit_events set actor_username = 'tampered' where id = ${row.id}`),
      );
      expect(message).toMatch(/append-only/i);
      expect(message).toContain("UPDATE");

      const [after] = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.id, row.id));
      expect(after.actorUsername).toBe(row.actorUsername);
    });

    it("refuses a DELETE", async () => {
      const row = await seedRow();
      const message = await rejectionCause(
        getDb().execute(sql`delete from audit_events where id = ${row.id}`),
      );
      expect(message).toMatch(/append-only/i);
      expect(message).toContain("DELETE");

      const [after] = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.id, row.id));
      expect(after).toBeDefined();
    });

    it("refuses a TRUNCATE", async () => {
      // TRUNCATE does not fire row-level triggers, so it needs its own
      // statement-level one. Without it, this is the cheapest way to erase the
      // entire trail in a single word.
      const row = await seedRow();
      const message = await rejectionCause(
        getDb().execute(sql`truncate audit_events`),
      );
      expect(message).toMatch(/append-only/i);
      expect(message).toContain("TRUNCATE");

      const [after] = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.id, row.id));
      expect(after).toBeDefined();
    });

    /**
     * #41 review, finding 2. `drizzle/0006_*.sql` created the triggers with the
     * default ENABLE ORIGIN and its comment called the resulting bypass
     * "unavoidable". It was not: `session_replication_role = replica` is a
     * session GUC, needs no DDL, and skips every ORIGIN trigger, so
     *
     *     SET session_replication_role = replica; DELETE FROM audit_events;
     *
     * emptied the table in two statements. `drizzle/0007_*.sql` sets both
     * triggers to ENABLE ALWAYS, which fires regardless of replication role.
     *
     * The state is asserted directly ('A', not 'O') because that is the fix
     * itself and the assertion does not depend on the test role's privileges.
     */
    it("keeps both triggers in the ENABLE ALWAYS state", async () => {
      const result = await getDb().execute<{
        tgname: string;
        tgenabled: string;
      }>(
        sql`select tgname, tgenabled from pg_trigger
            where tgrelid = 'audit_events'::regclass and not tgisinternal
            order by tgname`,
      );
      const states = Object.fromEntries(
        result.rows.map((r) => [r.tgname, r.tgenabled]),
      );
      expect(states).toEqual({
        audit_events_no_truncate: "A",
        audit_events_no_update_or_delete: "A",
      });
    });

    it("refuses a DELETE even under session_replication_role = replica", async () => {
      const row = await seedRow();

      // SET LOCAL inside a transaction, so the GUC and the DELETE are
      // guaranteed to land on the SAME pooled connection — a bare SET would be
      // free to go to a different one and the test would prove nothing.
      const message = await rejectionCause(
        getDb().transaction(async (tx) => {
          await tx.execute(sql`set local session_replication_role = replica`);
          await tx.execute(sql`delete from audit_events where id = ${row.id}`);
        }),
      );
      expect(message).toMatch(/append-only/i);
      expect(message).toContain("DELETE");

      const [after] = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.id, row.id));
      expect(after).toBeDefined();
    });
  });

  // ── 2. The claim T41 exists to make true ────────────────────────────────

  describe("makes an admin's brand round trip visible after the fact", () => {
    /**
     * #40's review, finding 12, in executable form.
     *
     * An admin grants themselves membership of a brand they are not in, reads
     * it, and revokes. Before T41 the database ended byte-identical to one
     * where nothing happened. Now the `user_brands` row is still destroyed —
     * revoke is still a hard DELETE, deliberately — but the two audit rows
     * survive it, and they are what turns "an admin cannot read brand content"
     * from a false claim into "an admin cannot read brand content QUIETLY".
     *
     * Since T50 even the narrowed claim needs its scope stated: spend is
     * readable by role, directly, without any of this round trip (see
     * core/llm/admin-spend.ts). What this test still proves is the round trip
     * for everything ELSE — documents, briefs, generated content — and that
     * it cannot be performed invisibly.
     */
    it("keeps grant and revoke after the membership row is destroyed", async () => {
      const admin = await makeUser("admin");
      const brand = await makeBrand();
      const actor = actorOf(admin);

      await grantBrandAccess(actor, admin.id, brand.id);
      await revokeBrandAccess(actor, admin.id, brand.id);

      // The membership itself is gone — revoke really did revoke.
      const membership = await getDb()
        .select()
        .from(userBrands)
        .where(
          and(
            eq(userBrands.userId, admin.id),
            eq(userBrands.brandId, brand.id),
          ),
        );
      expect(membership).toEqual([]);

      // The evidence is not.
      const rows = await rowsForActor(admin.id);
      const actions = rows.map((r) => r.action).sort();
      expect(actions).toEqual(["membership_grant", "membership_revoke"]);

      const grant = rows.find((r) => r.action === "membership_grant")!;
      expect(grant.brandId).toBe(brand.id);
      expect(grant.brandName).toBe(brand.name);
      expect(grant.targetUserId).toBe(admin.id);
      // The self-grant is flagged in the row, not left for a reader to spot by
      // comparing two uuids.
      expect(grant.metadata).toMatchObject({ selfGrant: true });

      const revoke = rows.find((r) => r.action === "membership_revoke")!;
      expect(revoke.metadata).toMatchObject({ removedMembership: true });
    });

    /**
     * The reason `audit_events` carries no foreign keys and snapshots names as
     * text. With `ON DELETE CASCADE`, deleting the user would delete their
     * trail — handing anyone who wants to erase their tracks a one-step way to
     * do it. The row must outlive its subject AND stay readable.
     */
    it("survives deletion of the user it names, still readable", async () => {
      const admin = await makeUser("admin");
      const brand = await makeBrand();
      const doomed = await makeUser("user");
      const doomedName = doomed.username;

      await grantBrandAccess(actorOf(admin), doomed.id, brand.id);
      await getDb().delete(users).where(eq(users.id, doomed.id));

      const [row] = await rowsForActor(admin.id);
      expect(row.targetUserId).toBe(doomed.id);
      // Not an anonymous uuid a year later: the name was snapshotted.
      expect(row.targetUsername).toBe(doomedName);
      expect(row.brandName).toBe(brand.name);
    });

    it("records a password reset, the OTHER route into a brand", async () => {
      // #40's second gap: reset a user's password and sign in as them,
      // reaching content with no membership row at any point.
      const admin = await makeUser("admin");
      const victim = await makeUser("user");

      await setTemporaryPassword(actorOf(admin), victim.id, TEMP);

      const [row] = await rowsForActor(admin.id);
      expect(row.action).toBe("user_password_reset");
      expect(row.targetUserId).toBe(victim.id);
      expect(row.targetUsername).toBe(victim.username);
    });

    it("records brand and user creation", async () => {
      const admin = await makeUser("admin");
      const actor = actorOf(admin);

      const brand = await createBrand(actor, `t41-created-${randomUUID()}`);
      createdBrandIds.push(brand.id);
      const created = await createUser(actor, `t41-${randomUUID()}`, TEMP);
      createdUserIds.push(created.id);

      const actions = (await rowsForActor(admin.id)).map((r) => r.action).sort();
      expect(actions).toEqual(["brand_create", "user_create"]);
    });
  });

  // ── 3. Visibility ───────────────────────────────────────────────────────

  describe("visibility", () => {
    it("shows a super admin everything, including other people's rows", async () => {
      const admin = await makeUser("admin");
      const other = await makeUser("user");
      await recordAuditEvent({
        action: "auth_login",
        actorUserId: other.id,
        actorUsername: other.username,
      });

      const { events } = await listAuditEvents(actorOf(admin), {
        actorUserId: other.id,
      });
      expect(events.length).toBeGreaterThan(0);
      expect(events.every((e) => e.actorUserId === other.id)).toBe(true);
    });

    it("shows an ordinary user their OWN rows", async () => {
      const me = await makeUser("user");
      await recordAuditEvent({
        action: "auth_login",
        actorUserId: me.id,
        actorUsername: me.username,
      });

      const { events } = await listAuditEvents(actorOf(me));
      expect(events).toHaveLength(1);
      expect(events[0].actorUserId).toBe(me.id);
    });

    it("hides every row an ordinary user did not cause", async () => {
      const me = await makeUser("user");
      const stranger = await makeUser("user");
      await recordAuditEvent({
        action: "auth_login",
        actorUserId: stranger.id,
        actorUsername: stranger.username,
      });

      const { events } = await listAuditEvents(actorOf(me));
      expect(events).toEqual([]);
    });

    /**
     * ── THE TENANCY SUBTLETY ──────────────────────────────────────────────
     * The test that stops the transparency page becoming a brand-enumeration
     * oracle.
     *
     * An audit row is cross-brand by nature: `membership_grant` names an
     * admin, a user, AND A BRAND. If "my own records" meant "rows that mention
     * me", an ordinary user would read the name of every brand an admin ever
     * granted them — including brands they were later revoked from and brands
     * they never actually accessed. The scope is therefore on the ACTOR column
     * alone.
     *
     * The visible cost, which Elif should know about: a user cannot see admin
     * actions taken upon their own account. That is the deliberate trade.
     */
    it("hides rows where the user is the TARGET, so brand names do not leak", async () => {
      const admin = await makeUser("admin");
      const subject = await makeUser("user");
      const secretBrand = await makeBrand();

      await grantBrandAccess(actorOf(admin), subject.id, secretBrand.id);
      await revokeBrandAccess(actorOf(admin), subject.id, secretBrand.id);

      const { events } = await listAuditEvents(actorOf(subject));

      expect(events).toEqual([]);
      // The brand's very NAME must not have travelled.
      expect(JSON.stringify(events)).not.toContain(secretBrand.name);
    });

    /**
     * Authorization is the query, not the caller's manners. A user who asks
     * for somebody else's rows must get their own, not an error and certainly
     * not the rows.
     */
    it("ignores an actorUserId filter aimed at somebody else", async () => {
      const me = await makeUser("user");
      const stranger = await makeUser("user");
      await recordAuditEvent({
        action: "auth_login",
        actorUserId: stranger.id,
        actorUsername: stranger.username,
      });
      await recordAuditEvent({
        action: "auth_login",
        actorUserId: me.id,
        actorUsername: me.username,
      });

      const { events } = await listAuditEvents(actorOf(me), {
        actorUserId: stranger.id,
      });

      expect(events).toHaveLength(1);
      expect(events[0].actorUserId).toBe(me.id);
    });

    it("keeps the scope when an action filter is combined with it", async () => {
      const me = await makeUser("user");
      const stranger = await makeUser("user");
      for (const u of [me, stranger]) {
        await recordAuditEvent({
          action: "auth_login",
          actorUserId: u.id,
          actorUsername: u.username,
        });
      }

      const { events } = await listAuditEvents(actorOf(me), {
        action: "auth_login",
      });
      expect(events.every((e) => e.actorUserId === me.id)).toBe(true);
    });

    it("caps a crafted page size so one request cannot pull the table", async () => {
      const admin = await makeUser("admin");
      const { events } = await listAuditEvents(actorOf(admin), {
        limit: 10_000,
      });
      expect(events.length).toBeLessThanOrEqual(MAX_AUDIT_PAGE_SIZE);
    });
  });

  // ── 4. Write paths ──────────────────────────────────────────────────────

  describe("write behaviour", () => {
    it("records both outcomes of a login attempt", async () => {
      const user = await makeUser("user");

      await authenticate(user.username, TEMP);
      await authenticate(user.username, "kesinlikle-yanlis");

      const actions = (await rowsForActor(user.id)).map((r) => r.action).sort();
      expect(actions).toEqual(["auth_login", "auth_login_failed"]);
    });

    it("records a failed login for a username that does not exist", async () => {
      // No user row, so no actor id — but a row is still written, and
      // `actor_username` is notNull for exactly this case.
      //
      // This test USED to look the name up verbatim. It no longer can, and the
      // change is the point of #41 review finding 4: an unresolvable username
      // is stored as a digest, because that is the bucket a password typed into
      // the username box falls into. The row, and the fact that somebody probed
      // for an account that does not exist, both survive.
      resetAuthFailureAuditBudget();
      const ghost = `t41-ghost-${randomUUID()}`;
      await authenticate(ghost, "whatever");

      const [row] = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.actorUsername, maskUnknownUsername(ghost)));

      expect(row.action).toBe("auth_login_failed");
      expect(row.actorUserId).toBeNull();
    });

    /**
     * BEST-EFFORT, NOT SILENT. The resolution of the audit-write dilemma for
     * the non-directory categories: the action survives an unwritable audit
     * table, but the operator is told. A `catch {}` here would be the exact
     * silent swallow CLAUDE.md hard rule 5 forbids.
     */
    it("does not throw when the write fails, and reports it loudly", async () => {
      const spy = vi.spyOn(console, "error").mockImplementation(() => {});
      try {
        await expect(
          recordAuditEvent({
            // Not a member of the pg enum: the insert fails in the driver.
            action: "not.a.real.action" as never,
            actorUserId: randomUUID(),
            actorUsername: "t41-loud",
          }),
        ).resolves.toBeUndefined();

        expect(spy).toHaveBeenCalledTimes(1);
        expect(String(spy.mock.calls[0][0])).toContain("[audit] WRITE FAILED");
      } finally {
        spy.mockRestore();
      }
    });

    it("collapses an editing burst into one row", async () => {
      const me = await makeUser("user");
      const projectId = randomUUID();

      // Ten autosaves, as a debounced editor would fire them.
      for (let i = 0; i < 10; i += 1) {
        await recordContentAuditEvent({
          action: "content_edit",
          actorUserId: me.id,
          actorUsername: me.username,
          projectId,
          step: "sm_posts",
        });
      }

      const rows = await rowsForActor(me.id);
      expect(rows).toHaveLength(1);
    });

    it("keeps a later editing session separate from an earlier one", async () => {
      const me = await makeUser("user");
      const projectId = randomUUID();

      await recordContentAuditEvent({
        action: "content_edit",
        actorUserId: me.id,
        actorUsername: me.username,
        projectId,
        step: "sm_posts",
      });

      // "Came back after lunch": simulated by ageing the clock past the window
      // rather than by writing a row with a doctored timestamp, since the
      // table would not let us correct one afterwards.
      const realNow = Date.now;
      Date.now = () => realNow() + CONTENT_COALESCE_WINDOW_MS + 1_000;
      try {
        await recordContentAuditEvent({
          action: "content_edit",
          actorUserId: me.id,
          actorUsername: me.username,
          projectId,
          step: "sm_posts",
        });
      } finally {
        Date.now = realNow;
      }

      expect(await rowsForActor(me.id)).toHaveLength(2);
    });

    it("keeps different steps and different actions apart while coalescing", async () => {
      const me = await makeUser("user");
      const projectId = randomUUID();

      await recordContentAuditEvent({
        action: "content_edit",
        actorUserId: me.id,
        actorUsername: me.username,
        projectId,
        step: "sm_posts",
      });
      await recordContentAuditEvent({
        action: "content_edit",
        actorUserId: me.id,
        actorUsername: me.username,
        projectId,
        step: "sm_pillars",
      });
      await recordContentAuditEvent({
        action: "content_select",
        actorUserId: me.id,
        actorUsername: me.username,
        projectId,
        step: "sm_posts",
      });

      expect(await rowsForActor(me.id)).toHaveLength(3);
    });

    it("never coalesces a download", async () => {
      const me = await makeUser("user");
      const projectId = randomUUID();

      for (let i = 0; i < 3; i += 1) {
        await recordContentAuditEvent({
          action: "content_download",
          actorUserId: me.id,
          actorUsername: me.username,
          projectId,
          step: "content_calendar",
          metadata: { format: "xlsx" },
        });
      }

      expect(await rowsForActor(me.id)).toHaveLength(3);
    });
  });

  // ── 5. No secrets in a table that can never be cleaned ──────────────────

  describe("never stores credential material", () => {
    it("keeps the temporary password out of a password-reset row", async () => {
      const admin = await makeUser("admin");
      const victim = await makeUser("user");
      const secret = "cok-gizli-parola-123";

      await setTemporaryPassword(actorOf(admin), victim.id, secret);

      const rows = await rowsForActor(admin.id);
      expect(JSON.stringify(rows)).not.toContain(secret);
    });

    it("keeps the attempted password out of a failed-login row", async () => {
      const user = await makeUser("user");
      const attempted = "yanlis-parola-denemesi-999";

      await authenticate(user.username, attempted);

      const rows = await rowsForActor(user.id);
      expect(JSON.stringify(rows)).not.toContain(attempted);
    });

    /**
     * #41 review, finding 4. The test above passes the secret as the PASSWORD
     * argument, which was never at risk — `authenticate` does not put the
     * password anywhere near the row, so that test stayed green under the real
     * failure. It is kept as a regression guard and this one tests the hazard
     * that was actually documented:
     *
     *   a user types their password into the USERNAME box one field early, it
     *   lands in `actor_username`, and that column lives in a table with no
     *   DELETE path, unlimited retention, and a super admin reading it.
     *
     * `sanitizeAuditName` cannot catch this: `redactSecrets` masks secret-
     * SHAPED text and a bare password has no shape. The fix is
     * `maskUnknownUsername` — a username that resolves to no user is stored as
     * a stable digest instead of verbatim.
     */
    it("never stores a bare password typed into the username box", async () => {
      resetAuthFailureAuditBudget();
      // Deliberately shapeless: no `password=` prefix, no `$argon2`, nothing
      // any mask could recognise. This is what defeats redactSecrets.
      const secret = `hunter2-${randomUUID()}`;

      await authenticate(secret, "bu-parola-onemsiz");

      const leaked = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.actorUsername, secret));
      expect(leaked).toHaveLength(0);

      // The row still exists — the signal is kept, the string is not.
      const masked = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.actorUsername, maskUnknownUsername(secret)));
      expect(masked).toHaveLength(1);
      expect(masked[0].actorUserId).toBeNull();
      expect(masked[0].action).toBe("auth_login_failed");
    });

    it("still records a KNOWN username verbatim on a failed login", async () => {
      // The other half of the cut. A username that exists is an identifier,
      // not credential material, and it names the account under attack — so it
      // must NOT be hashed, or the trail loses the row worth reading.
      resetAuthFailureAuditBudget();
      const user = await makeUser("user");

      await authenticate(user.username, "kesinlikle-yanlis-parola");

      const rows = await rowsForActor(user.id);
      const failed = rows.filter((r) => r.action === "auth_login_failed");
      expect(failed).toHaveLength(1);
      expect(failed[0].actorUsername).toBe(user.username);
    });

    /**
     * #41 review, finding 1 — the denial of service, in executable form.
     *
     * Before this, an unauthenticated attacker could POST garbage credentials
     * in a loop and each one wrote a permanent row into a table with no DELETE
     * path. Because directory actions are ATOMIC on their audit row, filling
     * that table eventually rolls back every `grantBrandAccess`,
     * `createBrand`, `createUser` and `setTemporaryPassword` — an
     * unauthenticated party locking the super admin out of the admin panel,
     * remediable only by the DDL the design calls tampering.
     *
     * The cap is what makes the growth bounded. Note what the test asserts
     * about the LOGIN: it still fails, identically, past the cap. The budget
     * drops the ROW, never the authentication decision — so this fix cannot
     * itself be turned into a way to log in, and cannot refuse service to a
     * legitimate user either.
     */
    it("caps how many failed-login rows an unauthenticated flood can write", async () => {
      resetAuthFailureAuditBudget();
      const overshoot = 5;
      const attempts = AUTH_FAILURE_AUDIT_MAX_PER_WINDOW + overshoot;
      const tag = `t41-flood-${randomUUID()}`;
      const names: string[] = [];

      for (let i = 0; i < attempts; i += 1) {
        const name = `${tag}-${i}`;
        names.push(name);
        // Every attempt still returns null: the login is refused exactly as
        // before, whether or not its row was written.
        expect(await authenticate(name, "yanlis")).toBeNull();
      }

      const written = await getDb()
        .select()
        .from(auditEvents)
        .where(
          inArray(
            auditEvents.actorUsername,
            names.map((n) => maskUnknownUsername(n)),
          ),
        );
      expect(written).toHaveLength(AUTH_FAILURE_AUDIT_MAX_PER_WINDOW);
    });

    it("does not let an unknown-name flood suppress rows for a real account", async () => {
      // The reason there are two budgets rather than one. With a shared
      // window, spraying random names would exhaust it and thereby HIDE the
      // rows recording an attack on a real account — turning the flood into a
      // tool for erasing the very signal the trail exists to show.
      resetAuthFailureAuditBudget();
      const victim = await makeUser("user");
      const tag = `t41-starve-${randomUUID()}`;

      for (let i = 0; i < AUTH_FAILURE_AUDIT_MAX_PER_WINDOW + 5; i += 1) {
        await authenticate(`${tag}-${i}`, "yanlis");
      }

      await authenticate(victim.username, "yanlis");

      const rows = await rowsForActor(victim.id);
      expect(rows.filter((r) => r.action === "auth_login_failed")).toHaveLength(1);
    });

    it("gives the same unknown identifier the same digest, so probing stays legible", async () => {
      // What the hash preserves: an admin can still see that one identifier was
      // tried repeatedly, and count distinct identifiers. That is the probing
      // signal; only "which names" is given up.
      resetAuthFailureAuditBudget();
      const probe = `t41-probe-${randomUUID()}`;

      await authenticate(probe, "a");
      await authenticate(probe.toUpperCase(), "b");

      const rows = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.actorUsername, maskUnknownUsername(probe)));
      expect(rows).toHaveLength(2);
    });

    it("keeps the password hash out of a user-creation row", async () => {
      const admin = await makeUser("admin");
      const created = await createUser(
        actorOf(admin),
        `t41-${randomUUID()}`,
        TEMP,
      );
      createdUserIds.push(created.id);

      const rows = await rowsForActor(admin.id);
      const serialized = JSON.stringify(rows);
      expect(serialized).not.toContain(TEMP);
      expect(serialized).not.toContain("$argon2");
    });
  });
});
