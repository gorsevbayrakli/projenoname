/**
 * The pure half of the audit trail (T41).
 *
 * These tests carry most of the weight of one promise: NOTHING SECRET AND NO
 * CONTENT BODY REACHES A TABLE THAT CAN NEVER BE DELETED. Because
 * `audit_events` is append-only by design, a leak here is not a bug that can
 * be fixed by deleting the rows — the rows cannot be deleted. That asymmetry
 * is why this file is as suspicious of its own callers as it is.
 */
import { afterEach, describe, expect, it } from "vitest";

import { REDACTED } from "../errors/redact";
import { AUDIT_ACTIONS } from "../db/schema";
import {
  ATOMIC_AUDIT_ACTIONS,
  AUDIT_CATEGORIES,
  categoryOf,
  isAtomicAuditAction,
  isCoalescedAction,
  MAX_METADATA_KEYS,
  MAX_METADATA_VALUE_LENGTH,
  MAX_NAME_LENGTH,
  sanitizeAuditMetadata,
  sanitizeAuditName,
  maskUnknownUsername,
  UNKNOWN_USERNAME_PREFIX,
  UNKNOWN_USERNAME_DIGEST_LENGTH,
  TRUNCATED,
} from "./events";
import { MIN_AUDIT_MASK_KEY_LENGTH } from "./mask-key";

describe("audit action catalog", () => {
  /**
   * Elif asked for four categories and the viewing UI filters by them. An
   * action in none of them would be recorded but unreachable through the
   * filter — present in the table, absent from the page that exists to show
   * it, which is the worst of both.
   */
  it("puts every action in exactly one category", () => {
    const assignments = AUDIT_ACTIONS.map((action) => ({
      action,
      categories: Object.entries(AUDIT_CATEGORIES)
        .filter(([, actions]) => (actions as readonly string[]).includes(action))
        .map(([name]) => name),
    }));

    const misfiled = assignments.filter((a) => a.categories.length !== 1);
    expect(misfiled).toEqual([]);
  });

  it("categorises the four kinds Elif asked for", () => {
    expect(categoryOf("membership_revoke")).toBe("directory");
    expect(categoryOf("auth_login_failed")).toBe("auth");
    expect(categoryOf("generation_start")).toBe("generation");
    expect(categoryOf("content_download")).toBe("content");
  });

  /**
   * The atomic/best-effort split is the resolution of the "a failed audit
   * write on a successful action" dilemma, and it is only defensible if the
   * atomic set is exactly the directory actions — the ones where an unrecorded
   * action is worse than no action. Anything else creeping in would mean a
   * login or an autosave can now be failed by a log write.
   */
  it("makes the directory actions, and ONLY those, atomic", () => {
    expect([...ATOMIC_AUDIT_ACTIONS].sort()).toEqual(
      [...AUDIT_CATEGORIES.directory].sort(),
    );
    expect(isAtomicAuditAction("membership_grant")).toBe(true);
    expect(isAtomicAuditAction("auth_login")).toBe(false);
    expect(isAtomicAuditAction("content_edit")).toBe(false);
  });

  it("coalesces edits and selections but never downloads", () => {
    expect(isCoalescedAction("content_edit")).toBe(true);
    expect(isCoalescedAction("content_select")).toBe(true);
    // A download is a discrete act of taking content out; "how many times"
    // is a question a security reader will actually ask.
    expect(isCoalescedAction("content_download")).toBe(false);
  });

  it("records both halves of a membership round trip", () => {
    // The specific pair that makes #40's claim true. If either disappeared,
    // grant -> read -> revoke would go back to leaving no trace.
    expect(AUDIT_ACTIONS).toContain("membership_grant");
    expect(AUDIT_ACTIONS).toContain("membership_revoke");
  });
});

describe("sanitizeAuditMetadata", () => {
  it("redacts a value whose KEY names credential material", () => {
    // The case `redactSecrets` alone cannot catch: "hunter2" contains nothing
    // secret-shaped, so only the key betrays it.
    const out = sanitizeAuditMetadata({
      password: "hunter2",
      temporaryPassword: "hunter2",
      apiKey: "sk-live-abc",
      sessionToken: "deadbeef",
      passwordHash: "$argon2id$v=19$m=1$x$y",
    });

    expect(Object.values(out)).toEqual([
      REDACTED,
      REDACTED,
      REDACTED,
      REDACTED,
      REDACTED,
    ]);
  });

  it("keeps the key when it redacts, so a reader sees something was withheld", () => {
    // Dropping the key silently would leave a reader unable to tell "nothing
    // was passed" from "something was withheld" (hard rule 5 in miniature).
    const out = sanitizeAuditMetadata({ password: "hunter2" });
    expect(Object.keys(out)).toEqual(["password"]);
  });

  it("masks a secret that arrived under an innocent key", () => {
    const out = sanitizeAuditMetadata({ note: "used password=hunter2 to log in" });
    expect(out.note).not.toContain("hunter2");
    expect(out.note).toContain(REDACTED);
  });

  it("masks an argon2 hash appearing in free text", () => {
    const out = sanitizeAuditMetadata({
      detail: "row had $argon2id$v=19$m=65536,t=3,p=4$c2FsdA$ZGlnZXN0 stored",
    });
    expect(out.detail).not.toContain("ZGlnZXN0");
    expect(out.detail).not.toContain("c2FsdA");
  });

  /**
   * The mechanical form of "do not log content bodies wholesale". A caller
   * that passes a generated post stores 200 characters of it, not the post —
   * and the marker makes the truncation visible instead of silent.
   */
  it("truncates a long value rather than storing a content body", () => {
    const body = "a".repeat(5_000);
    const out = sanitizeAuditMetadata({ caption: body });
    const stored = out.caption as string;

    expect(stored.length).toBe(MAX_METADATA_VALUE_LENGTH + TRUNCATED.length);
    expect(stored.endsWith(TRUNCATED)).toBe(true);
  });

  /**
   * The per-value cap is defeated by nesting: `{ rows: [...200 posts] }` has
   * no long STRING in it at the top level. Only scalars survive, so the whole
   * shape collapses to a type marker.
   */
  it("refuses nested objects and arrays, which is how a blob gets past the cap", () => {
    const out = sanitizeAuditMetadata({
      rows: [{ caption: "x".repeat(5_000) }, { caption: "y".repeat(5_000) }],
      nested: { deeply: { hidden: "x".repeat(5_000) } },
    });

    expect(out.rows).toBe("[array]");
    expect(out.nested).toBe("[object]");
    expect(JSON.stringify(out)).not.toContain("xxxxx");
  });

  it("keeps scalars, which is what metadata is actually for", () => {
    const out = sanitizeAuditMetadata({
      jobId: "d1f0c2a4",
      selectedCount: 3,
      selfGrant: true,
      brandName: null,
    });
    expect(out).toEqual({
      jobId: "d1f0c2a4",
      selectedCount: 3,
      selfGrant: true,
      brandName: null,
    });
  });

  it("caps the number of keys and says how many it dropped", () => {
    const wide: Record<string, unknown> = {};
    for (let i = 0; i < MAX_METADATA_KEYS + 5; i += 1) wide[`k${i}`] = i;

    const out = sanitizeAuditMetadata(wide);
    expect(Object.keys(out)).toHaveLength(MAX_METADATA_KEYS + 1);
    expect(out["…"]).toBe("5 more keys dropped");
  });

  it("treats missing metadata as empty, not as a crash", () => {
    expect(sanitizeAuditMetadata(undefined)).toEqual({});
    expect(sanitizeAuditMetadata(null)).toEqual({});
  });
});

describe("sanitizeAuditName", () => {
  it("passes an ordinary username through untouched", () => {
    expect(sanitizeAuditName("elif")).toBe("elif");
  });

  /**
   * This function catches the LABELLED shapes only. The bare-password case it
   * cannot catch is no longer routed through here at all — `auth_login_failed`
   * hashes an unresolvable username instead (see `maskUnknownUsername` below,
   * and #41 review, finding 4).
   */
  it("masks a secret-shaped string typed into the username box", () => {
    const out = sanitizeAuditName("password=hunter2");
    expect(out).not.toContain("hunter2");
  });

  it("caps a hostile length so one attempt cannot bloat the table", () => {
    const out = sanitizeAuditName("z".repeat(10_000));
    expect(out.length).toBe(MAX_NAME_LENGTH + TRUNCATED.length);
  });
});

/**
 * #41 review, finding 4. `sanitizeAuditName` cannot help with a BARE password
 * — `hunter2` has no secret shape — and `actor_username` lives in a table with
 * no DELETE path that the super admin reads. So a failed login against a
 * username that does not resolve stores a digest instead of the typed string.
 */
describe("maskUnknownUsername", () => {
  it("does not contain the input", () => {
    const secret = "hunter2";
    expect(maskUnknownUsername(secret)).not.toContain(secret);
  });

  it("is stable, so repeated probing of one identifier stays countable", () => {
    expect(maskUnknownUsername("root")).toBe(maskUnknownUsername("root"));
  });

  it("separates distinct identifiers, so probe BREADTH stays countable", () => {
    expect(maskUnknownUsername("root")).not.toBe(maskUnknownUsername("admin"));
  });

  it("correlates case and Unicode variants rather than showing two attackers", () => {
    expect(maskUnknownUsername("Admin")).toBe(maskUnknownUsername("admin"));
  });

  it("is bounded in length whatever the input", () => {
    const out = maskUnknownUsername("z".repeat(10_000));
    expect(out.length).toBe(
      UNKNOWN_USERNAME_PREFIX.length + UNKNOWN_USERNAME_DIGEST_LENGTH,
    );
  });

  it("is recognisable as a mask, so a reader is never misled into thinking it was the typed name", () => {
    expect(maskUnknownUsername("root").startsWith(UNKNOWN_USERNAME_PREFIX)).toBe(
      true,
    );
  });
});

/**
 * #55. The mask above defeats a casual reader of the table; an UNKEYED digest
 * does not defeat the attack that matters, which is someone holding a dump
 * hashing a password wordlist once and matching it against the column. The
 * digest is therefore an HMAC under a server-side secret.
 *
 * Two properties are in tension and both are tested here, because a change
 * that satisfies one alone is a regression:
 *   - KEYED: a different key must produce a different digest for one input.
 *     This is the only test that can tell an HMAC from a bare hash.
 *   - STABLE: the same key and input must produce the same digest forever,
 *     across processes, or the whole point of the mask — counting repeats and
 *     counting distinct identifiers — is lost. That is why the key is an env
 *     var and not a per-process random value.
 */
/**
 * `process.env.NODE_ENV` is typed read-only, and these tests have to move it:
 * the whole decision under test is "what does production do differently".
 */
function setEnvVar(name: string, value: string | undefined): void {
  const env = process.env as Record<string, string | undefined>;
  if (value === undefined) delete env[name];
  else env[name] = value;
}

describe("maskUnknownUsername keying (#55)", () => {
  const savedKey = process.env.AUDIT_MASK_KEY;
  const savedNodeEnv = process.env.NODE_ENV;

  afterEach(() => {
    setEnvVar("AUDIT_MASK_KEY", savedKey);
    setEnvVar("NODE_ENV", savedNodeEnv);
  });

  const keyA = "a".repeat(MIN_AUDIT_MASK_KEY_LENGTH);
  const keyB = "b".repeat(MIN_AUDIT_MASK_KEY_LENGTH);

  it("produces a DIFFERENT digest under a different key, which is what proves it is keyed", () => {
    process.env.AUDIT_MASK_KEY = keyA;
    const underA = maskUnknownUsername("hunter2");
    process.env.AUDIT_MASK_KEY = keyB;
    const underB = maskUnknownUsername("hunter2");

    expect(underA).not.toBe(underB);
  });

  it("is stable for the same key and input, so correlation survives a restart", () => {
    process.env.AUDIT_MASK_KEY = keyA;
    const first = maskUnknownUsername("hunter2");
    process.env.AUDIT_MASK_KEY = keyB;
    maskUnknownUsername("hunter2");
    process.env.AUDIT_MASK_KEY = keyA;

    expect(maskUnknownUsername("hunter2")).toBe(first);
  });

  it("still correlates case and Unicode variants under a key", () => {
    process.env.AUDIT_MASK_KEY = keyA;

    expect(maskUnknownUsername("Admin")).toBe(maskUnknownUsername("admin"));
    expect(maskUnknownUsername("ADMİN".toLowerCase())).toBe(
      maskUnknownUsername("admi̇n".normalize("NFKC")),
    );
  });

  it("keeps the returned shape, so existing callers and readers are unaffected", () => {
    process.env.AUDIT_MASK_KEY = keyA;
    const masked = maskUnknownUsername("hunter2");

    expect(masked.startsWith(UNKNOWN_USERNAME_PREFIX)).toBe(true);
    expect(masked.length).toBe(
      UNKNOWN_USERNAME_PREFIX.length + UNKNOWN_USERNAME_DIGEST_LENGTH,
    );
    expect(masked).not.toContain("hunter2");
  });

  /**
   * The other half of failing closed: if the boot check were ever bypassed,
   * the masking path itself must not quietly degrade to the unkeyed digest
   * this change exists to remove.
   */
  it("refuses to mask at all in production without a key, rather than degrading", () => {
    setEnvVar("NODE_ENV", "production");
    setEnvVar("AUDIT_MASK_KEY", undefined);

    expect(() => maskUnknownUsername("hunter2")).toThrow(/AUDIT_MASK_KEY/);
  });
});
