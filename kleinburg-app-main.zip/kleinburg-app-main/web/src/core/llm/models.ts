import type { WorkflowStep } from "../db/schema";

/**
 * Model resolution for LLM calls. Framework-neutral (no react/next).
 *
 * DEFAULT_MODEL is read lazily from the environment at call time (never cached
 * at module load) so tests can set OPENROUTER_MODEL before resolving.
 */

/**
 * The default model, read from OPENROUTER_MODEL at call time.
 *
 * Anthropic on purpose. This app uploads client brand documents, so the
 * OpenRouter account keeps "paid endpoints that may train on request data"
 * OFF — its default. Under that policy every endpoint serving Gemini 2.5 Pro
 * was filtered out and OpenRouter answered "404 no endpoints available", which
 * is what the first live run hit. Anthropic's endpoints do not train on
 * request data, so they survive the filter.
 */
export const DEFAULT_MODEL = "anthropic/claude-sonnet-5";

export function defaultModel(): string {
  return process.env.OPENROUTER_MODEL ?? DEFAULT_MODEL;
}

/**
 * The search-backed model that RETRIEVES for secondary_data (#47, re-aimed by
 * #52, re-chosen on evidence 2026-07-20).
 *
 * It does not write anything the user reads. secondary_data is two calls: this
 * model searches and reports what it retrieved, and the step's own model
 * (`resolveModel("secondary_data")`, i.e. the default) writes the entries from
 * that material. Its notes are requested in English and never shown to anyone.
 *
 * WHY NOT `perplexity/sonar`, which this used to be. Measured live against the
 * step's real prompt and schema (scripts/probe-research-model.ts, two runs):
 *
 *   perplexity/sonar               6 citations,  0 findings   (2.5s)
 *   perplexity/sonar-reasoning-pro 11 citations, 21 findings  (49.7s)
 *
 * Sonar SEARCHED and returned citations, then wrote an empty `findings` array
 * both times. A retrieval call that retrieves nothing leaves the writing call
 * with no material, which is the quiet version of a broken step — the failure
 * this app is least allowed to have (hard rule 5). That is not a defect the
 * split can work around, unlike the Turkish one below.
 *
 * Sonar's non-ASCII mangling is real and was re-confirmed the same day
 * (scripts/probe-models.ts): asked to reproduce nine Turkish words verbatim it
 * returned four, emitting "Doşana ışχώ … çiχω … gön̏l" — Greek letters and
 * combining marks inside Turkish words. sonar-reasoning-pro returned all nine
 * intact. So the reason the two calls were split no longer applies to the
 * retrieval model at all; the split is kept anyway, because the writing call
 * also localises and the boundary is worth having on its own.
 *
 * COST: $2/$8 per M against sonar's $1/$1, and ~50s against ~2.5s. A step that
 * returns nothing is not cheaper.
 *
 * A CORRECTION WORTH RECORDING, because it was believed and written down here:
 * sonar-reasoning-pro was previously thought to be blocked by the account's
 * "no training on request data" guardrail, on the strength of a 404 reading
 * "No endpoints available matching your guardrail restrictions and data
 * policy". It was not. Adding it to the account's ALLOWED MODELS list made it
 * work with the guardrail untouched. That message names both gates and does not
 * say which one refused, so a 404 here is not evidence about the data policy —
 * check the allowlist first. `perplexity/sonar-pro` and `google/gemini-2.5-pro`
 * were both diagnosed off the same message and both deserve re-probing before
 * anyone repeats the claim that the guardrail is what excluded them.
 *
 * ONE PLACE, so swapping the retrieval provider stays a one-line change: this
 * constant is the only mention of it outside its registry entry, and
 * `configuredModels()` below counts it as a config site so it cannot fall out
 * of the startup check by being routed differently from a step override.
 */
export const RESEARCH_MODEL = "perplexity/sonar-reasoning-pro";

/**
 * Per-step model overrides. An entry here wins over DEFAULT_MODEL.
 *
 * EMPTY TODAY, and that is a real state rather than a leftover. #47 put
 * secondary_data on RESEARCH_MODEL here, because the step was one call and that
 * call had to search. #52 split the step into a retrieval call and a writing
 * call, so "the model the step runs on" stopped being a single answer: the
 * retrieval model is named directly by run-step.ts (it is not a preference and
 * not overridable), and the WRITING call wants exactly what every other step
 * uses — the default — because the whole point of the split was to get the
 * entries written by the model whose Turkish is sound.
 *
 * Per-brand / per-step model CONFIG remains a Faz 5+ concern. Keeping the map
 * (rather than deleting it) keeps `resolveModel` honest about what it does and
 * leaves the mechanism in place for a step that genuinely needs a capability
 * the default lacks.
 */
export const STEP_MODEL_OVERRIDES: Partial<Record<WorkflowStep, string>> = {};

/** Resolve the model for a workflow step: step override, else the default. */
export function resolveModel(step: WorkflowStep): string {
  return STEP_MODEL_OVERRIDES[step] ?? defaultModel();
}

/**
 * Every model this app is configured to call, mapped to ALL the config sites
 * that name it.
 *
 * Exists so "which models does this app actually use?" has one answer that both
 * the startup check and the tests read. Before #52 that question was answerable
 * as `Object.values(STEP_MODEL_OVERRIDES)` plus the default; once the retrieval
 * model moved out of that map, any check written against it would have gone
 * quietly vacuous — including the one asserting we never route to the
 * guardrail-blocked sonar-pro.
 *
 * A Map of ARRAYS, not of single sources: `OPENROUTER_MODEL=perplexity/sonar`
 * is also the retrieval model, and a last-write-wins map blamed one config site
 * while pointing the operator away from the other.
 */
export function configuredModels(): Map<string, string[]> {
  const configured = new Map<string, string[]>();
  const addSource = (model: string, source: string) => {
    const sources = configured.get(model);
    if (sources) sources.push(source);
    else configured.set(model, [source]);
  };
  addSource(defaultModel(), "OPENROUTER_MODEL / DEFAULT_MODEL");
  addSource(RESEARCH_MODEL, "RESEARCH_MODEL (secondary_data retrieval)");
  for (const [step, model] of Object.entries(STEP_MODEL_OVERRIDES)) {
    if (model) addSource(model, `STEP_MODEL_OVERRIDES.${step}`);
  }
  return configured;
}

// ── Output limits ──────────────────────────────────────────────────────────
// A completion ceiling (`max_tokens`) above the model's own limit is not
// silently trimmed by OpenRouter — the request is REJECTED, which fails the
// whole step. So anything that computes a ceiling has to clamp against a real
// number, and this table is where that number would come from.
//
// ADVISORY TODAY — NOTHING DERIVES A CEILING FROM IT. Its one consumer was the
// content_calendar step, and the calendar is now built in code rather than
// generated (run-step.ts returns to runContentCalendar before any model setup),
// so `maxOutputFor` has no production caller. The steps that DO still call a
// model pass no `maxTokens` at all except cadence.ts, which caps itself with
// its own constant — see the KNOWN GAP note in run-step.ts, which is the live
// version of this problem and is NOT covered by this table.
//
// The table is kept, not deleted, because that gap is still open and this is
// the data a fix would clamp against. Read it as documentation of what each
// model allows, not as something the pipeline enforces.
//
// This table exists because that clamp used to be a bare literal justified only
// by a prose comment ("the model's max output is 128000") that no code could
// check. Registering the limit makes the safety argument rest on data the code
// actually holds.
//
// HISTORY, so nobody re-derives it a third time: the first version of this table
// registered the default model at 64000, on the theory that the old 128000
// comment had confused the context window with the output limit. That theory was
// WRONG and the original comment was right. Claude Sonnet 5 has a 1M context
// window AND a 128K max output; they are different numbers, and 128000 is
// genuinely the output limit. Every value below is the DOCUMENTED max output,
// cited inline. Check the citation before "correcting" one of them.

/** What the registry knows about a model. Only the output limit, for now. */
export interface ModelDef {
  /**
   * Maximum completion tokens the provider accepts for this model. NOT the
   * context window — on the Anthropic models here the window is 1M while the
   * output limit is 128K, so a value at or near seven figures in this table is
   * a context window that wandered into the wrong field.
   */
  maxOutput: number;
}

/**
 * Models this app is known to run against, with their documented completion
 * limits. Deliberately small: it lists what we actually use, not a mirror of
 * OpenRouter's catalogue, which would rot.
 *
 * Adding a model is a one-line edit. Not adding it is not a failure — an
 * unregistered model falls back to UNREGISTERED_MODEL_MAX_OUTPUT below.
 */
export const MODEL_REGISTRY: Record<string, ModelDef> = {
  // The default (see defaultModel above). Anthropic documents Claude Sonnet 5
  // as 1M context window / 128K max output. 128000 is the OUTPUT figure.
  "anthropic/claude-sonnet-5": { maxOutput: 128_000 },
  // Anthropic documents Claude 3.5 Sonnet as 200K context / 8192 max output.
  // The small number here is correct and is NOT the same mistake as above: the
  // 3.5 generation really did cap output at 8192.
  "anthropic/claude-3.5-sonnet": { maxOutput: 8192 },
  // The old default, kept because OPENROUTER_MODEL may still point at it.
  // Google documents Gemini 2.5 Pro as 1M context / 65536 max output.
  "google/gemini-2.5-pro": { maxOutput: 65_536 },
  // The secondary_data RETRIEVAL model (RESEARCH_MODEL above). It writes only
  // the internal English notes the writing call consumes, never step output.
  //
  // 8000 IS A CONSERVATIVE CHOICE, NOT A CITED FIGURE, and saying so plainly is
  // better than a confident-looking number nobody can check. What IS documented:
  // OpenRouter lists perplexity/sonar at a 127K CONTEXT window and publishes no
  // max-output figure for it, and Perplexity documents Sonar Pro — the larger
  // sibling — at 8,000 max output. 8000 assumes the base model does not exceed
  // what the bigger one is documented at, which is the safe direction to be
  // wrong in (see UNREGISTERED_MODEL_MAX_OUTPUT below: guessing low degrades,
  // guessing high breaks the request outright).
  //
  // Nothing currently depends on the value being exact: only content_calendar
  // derives a ceiling from the registry, and content_calendar does not run on
  // this model. Registering it at all is what matters — an unregistered model
  // makes maxOutputFor warn on every run of the step.
  "perplexity/sonar": { maxOutput: 8000 },
  // The secondary_data RETRIEVAL model (RESEARCH_MODEL above). Like sonar, this
  // is a CONSERVATIVE CHOICE rather than a cited figure: OpenRouter publishes no
  // max-output number for it, and Perplexity documents Sonar Pro at 8,000. The
  // reasoning variant also spends tokens on a think block, so the completion it
  // has left is not larger than its sibling's. Nothing derives a ceiling from
  // this today — only content_calendar did, and content_calendar no longer runs
  // on a model at all — but registering it keeps maxOutputFor quiet.
  "perplexity/sonar-reasoning-pro": { maxOutput: 8000 },
};

/**
 * Assumed output limit for a model that is NOT in the registry.
 *
 * `defaultModel()` accepts any OPENROUTER_MODEL string unvalidated — an
 * operator can point the app at anything — so this is the honest answer to "how
 * much output will that model take?": we do not know.
 *
 * 16000 rather than something generous, because the two failure modes are not
 * symmetric. Guessing LOW costs headroom (a big calendar may truncate, and the
 * error names the ceiling). Guessing HIGH produces a request the provider
 * rejects outright, so EVERY calendar run fails and the message is about
 * max_tokens rather than about the unregistered model. Under-guessing degrades;
 * over-guessing breaks. The fix in both cases is the same one-line registry
 * entry above.
 *
 * That reasoning survives the 128000 correction unchanged — it never depended on
 * what the default model's real limit was. What DID need fixing is that the
 * degradation was SILENT: an operator who pointed OPENROUTER_MODEL at an
 * unregistered model got calendars capped low with nothing anywhere saying why.
 * `maxOutputFor` warns (see below).
 *
 * ALL OF THAT IS HISTORY, not current behaviour: no caller asks this constant
 * for a ceiling any more (see the section header above). It is the fallback
 * `maxOutputFor` would return if something did.
 */
export const UNREGISTERED_MODEL_MAX_OUTPUT = 16000;

/**
 * Models already warned about, so a long-running process logs once per unknown
 * model rather than once per call.
 */
const warnedUnregisteredModels = new Set<string>();

/**
 * The completion-token limit to size requests against for `model`.
 *
 * NO PRODUCTION CALLER TODAY — only models.test.ts. Its consumer was the
 * content_calendar step, which no longer calls a model, and no step has taken
 * its place: see the section header above and the KNOWN GAP note in
 * run-step.ts. Calling this changes nothing on its own; it is the number a
 * future clamp would ask for.
 *
 * An unregistered model WARNS rather than throwing, and the asymmetry above is
 * why. Throwing would make an unknown OPENROUTER_MODEL fail a step outright —
 * a hard stop on a config that is otherwise working, deep inside a pipeline
 * run, for a model the provider may well accept. The fallback is a deliberate
 * conservative assumption, not a failure, so the honest report is a loud
 * warning naming the model, the assumed ceiling and the one-line fix (CLAUDE.md
 * hard rule 5 forbids the SILENT version of this, not the degraded one). A
 * genuinely unusable model still fails loudly where it should: at the
 * OpenRouter call, with the provider's own error.
 */
export function maxOutputFor(model: string): number {
  const registered = MODEL_REGISTRY[model];
  if (registered) return registered.maxOutput;

  if (!warnedUnregisteredModels.has(model)) {
    warnedUnregisteredModels.add(model);
    console.warn(
      `[models] "${model}" is not in MODEL_REGISTRY (core/llm/models.ts). ` +
        `Returning the conservative assumption of ${UNREGISTERED_MODEL_MAX_OUTPUT} ` +
        `tokens, well below what a registered model allows (the default model ` +
        `allows ${MODEL_REGISTRY[DEFAULT_MODEL]?.maxOutput}). Whether that ` +
        `degrades anything depends on the caller — today nothing clamps against ` +
        `it. Fix: add "${model}" to MODEL_REGISTRY with its documented max output.`,
    );
  }
  return UNREGISTERED_MODEL_MAX_OUTPUT;
}

// ── Startup validation of the configured model ─────────────────────────────
//
// WHY THIS EXISTS SEPARATELY FROM THE maxOutputFor WARNING ABOVE.
//
// `defaultModel()` returns whatever OPENROUTER_MODEL says, unvalidated. The
// maxOutputFor warning does report an unregistered model, but only when
// something asks for an output limit — and since the calendar stopped calling a
// model, NOTHING does. maxOutputFor therefore never fires in production at all,
// which makes this boot check the ONLY thing that reports an unregistered model.
//
// It was written to close a narrower hole, back when content_calendar was the
// one caller and the fallback really did cap it (a large project truncated and
// found out; a small one fit under the ceiling, succeeded, and never learned it
// was degraded). That specific asymmetry is gone with the caller. The reason to
// keep the check at boot is unchanged and does not depend on it: it is (a)
// unconditional — it does not wait for a step that may never run, (b) early —
// next to the rest of the startup output an operator watches during a deploy,
// and (c) attributable to the config change that caused it rather than to a
// pipeline run hours later.
//
// What it reports today is narrower and it says so: we do not know this model's
// output limit. It does not claim anything is being capped, because nothing is.
//
// WARN, NOT THROW — and this is NOT the same reasoning as maxOutputFor's, so it
// is argued from scratch rather than inherited:
//
//   - MODEL_REGISTRY is a hand-maintained list of models we happen to have
//     registered, NOT a list of models OpenRouter serves. It lags the catalogue
//     by construction. Throwing would let a stale local list refuse to boot an
//     app whose configuration the provider would have accepted, and the operator
//     has no way to run at all until they edit source. That is a worse failure
//     than the one being fixed.
//   - The fallback is a deliberate conservative assumption, not a broken state.
//     Every step still runs — today nothing even consults it. There is nothing
//     here that is unsafe to proceed with.
//   - A model that genuinely does not exist still fails loudly, at the
//     OpenRouter call, with the provider's own error naming the model. Startup
//     is not the last line of defence.
//   - CLAUDE.md hard rule 5 forbids SILENT failure, not degraded operation. The
//     rule is satisfied by making the degradation loud, early and attributable,
//     which is exactly what is missing today. Escalating to a hard error would
//     go beyond the rule and trade a silent degradation for a hard outage.
//
// The warning is therefore made unmissable instead: a multi-line block, its own
// banner, the assumed ceiling, and the one-line fix.

/**
 * Report at startup if the app is configured to run a model the registry does
 * not know. Called from `src/instrumentation.ts`, once per server boot.
 *
 * Covers every entry of `configuredModels()`: OPENROUTER_MODEL (the
 * operator-settable one, and the finding that prompted this), RESEARCH_MODEL,
 * and STEP_MODEL_OVERRIDES (in-source, but a step routed to an unregistered
 * model has the same consequence).
 *
 * Returns the unregistered model ids it found, so a test can assert on the
 * outcome rather than on console output. Never throws — see the block above.
 */
export function validateConfiguredModels(
  warn: (message: string) => void = console.warn,
): string[] {
  const unregistered = [...configuredModels()].filter(
    ([model]) => !MODEL_REGISTRY[model],
  );
  if (unregistered.length === 0) return [];

  const lines = [
    "",
    "  ┌───────────────────────────────────────────────────────────────────┐",
    "  │  UNREGISTERED MODEL — its output limit is unknown to this app     │",
    "  └───────────────────────────────────────────────────────────────────┘",
    "",
  ];
  for (const [model, sources] of unregistered) {
    lines.push(
      `  "${model}" (from ${sources.join(", ")}) is not in MODEL_REGISTRY`,
      `  (web/src/core/llm/models.ts). Its max output is unknown, so the app`,
      `  would assume ${UNREGISTERED_MODEL_MAX_OUTPUT} tokens — against ` +
        `${MODEL_REGISTRY[DEFAULT_MODEL]?.maxOutput} for the default model.`,
      "",
      "  Effect today: NONE at runtime. No step derives a completion ceiling",
      "  from the registry any more — content_calendar, its only consumer, is",
      "  built in code and makes no model call, and the steps that do call a",
      "  model send no max_tokens (platform_cadence caps itself with its own",
      "  constant). The registry is advisory: this warns that we cannot say",
      "  what this model's limit is, not that anything is being capped.",
      "",
      `  Fix (one line): add "${model}" to MODEL_REGISTRY with its documented`,
      "  max output. Not a fatal error — the app runs.",
      "",
    );
  }
  warn(lines.join("\n"));
  return unregistered.map(([model]) => model);
}
