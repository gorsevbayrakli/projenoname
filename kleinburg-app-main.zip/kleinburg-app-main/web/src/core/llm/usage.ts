import { getDb } from "../db/client";
import { llmCalls } from "../db/schema";

/**
 * Usage/cost recording for LLM calls. Framework-neutral (no react/next).
 * numeric columns are stored as strings by drizzle, so costUsd is converted
 * here; a null cost (OpenRouter didn't report one) is stored as null.
 */
export async function recordLlmCall(args: {
  jobId: string;
  model: string;
  promptTokens: number;
  completionTokens: number;
  costUsd: number | null;
  durationMs: number;
}): Promise<void> {
  const db = getDb();
  await db.insert(llmCalls).values({
    jobId: args.jobId,
    model: args.model,
    promptTokens: args.promptTokens,
    completionTokens: args.completionTokens,
    costUsd: args.costUsd === null ? null : String(args.costUsd),
    durationMs: args.durationMs,
  });
}
