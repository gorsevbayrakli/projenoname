/**
 * LLM error taxonomy. Two kinds only, so callers (and the retry loop) never have
 * to guess: transient = worth retrying, permanent = give up immediately.
 * Framework-neutral (no react/next).
 */

/** Retryable failure: 429 rate limit, 5xx, network/timeout. */
export class LlmTransientError extends Error {
  constructor(message: string, options?: { cause?: unknown }) {
    super(message, options);
    this.name = "LlmTransientError";
  }
}

/** Non-retryable failure: 400/401/403, invalid output schema, bad request. */
export class LlmPermanentError extends Error {
  constructor(message: string, options?: { cause?: unknown }) {
    super(message, options);
    this.name = "LlmPermanentError";
  }
}

/**
 * Map an HTTP status to a retry disposition. 429 (rate limit) and any 5xx are
 * transient; everything else (4xx client errors) is permanent.
 */
export function classifyHttpError(status: number): "transient" | "permanent" {
  if (status === 429 || status >= 500) return "transient";
  return "permanent";
}
