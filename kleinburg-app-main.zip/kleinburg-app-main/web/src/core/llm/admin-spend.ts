/**
 * The super admin's cross-brand spend view (T50).
 *
 * ═══ WHAT THIS MODULE IS ══════════════════════════════════════════════════
 * This is the ONE place in the codebase where a ROLE, rather than a
 * `user_brands` row, opens a brand. Everything about its shape follows from
 * wanting that fact to be impossible to miss.
 *
 * Elif's decision, 20 July: the super admin gets full spend visibility — every
 * brand, with project names, including the step and model breakdowns, exactly
 * as if it were their own brand. She was shown the narrower options
 * (brand-level totals only; project-level with names) together with the
 * trade-off, and chose full visibility. The reason is that the question an
 * admin has to answer — "which brand or project is the outlier, is a cap
 * warranted" — cannot be answered without seeing brands they are not a member
 * of, and a total with no name attached does not identify an outlier.
 *
 * ═══ WHAT IT CHANGES, STATED PLAINLY ══════════════════════════════════════
 * #40 drew the boundary as: the super admin administers the DIRECTORY and
 * cannot read brand CONTENT; to reach a brand they must grant themselves a
 * visible, revocable membership. #41 narrowed the true version of that to
 * "cannot read it QUIETLY".
 *
 * This module removes that boundary FOR SPEND, and project names are content —
 * they describe campaigns. That is a genuine content exposure and it was
 * accepted knowingly rather than reasoned away. It is bounded to exactly three
 * functions, and it is loud: every crossing writes to the audit trail and the
 * UI tells the admin which brands are not theirs.
 *
 * What it does NOT open: documents, briefs, generated posts, step contents,
 * calendars, project settings. An admin who wants any of those still has to
 * grant themselves membership, still writes a `user_brands` row, and still
 * shows up in `/activity` as `membership_grant`. The hole is spend-shaped.
 *
 * ═══ WHY THE EXCEPTION IS *HERE* AND NOT IN `core/tenancy/access.ts` ══════
 * Because `access.ts` is the common door for every project-scoped read in the
 * product. An `if (role === "admin")` inside `requireProjectAccess` would have
 * been three lines and would have granted, in one stroke, admin access to
 * every current and future caller of that gate — a permission Elif granted for
 * COST becoming a permission over CONTENT, silently, by inheritance. Nobody
 * reading a call site would see it happen.
 *
 * So `access.ts` still contains zero role exceptions (`admin-spend.test.ts`
 * asserts it against the source text, and `core/admin/service.test.ts` asserts
 * it behaviourally), and the exception lives in a module whose name, whose
 * function names and whose import line all say "admin". The page calls
 * `getBrandSpendAsSuperAdmin` inside a visible `isSuperAdmin(user)` branch
 * rather than through a polymorphic helper, deliberately: the branch is the
 * documentation.
 */

import { and, asc, eq } from "drizzle-orm";

import { recordSpendViewAuditEvent } from "../audit/service";
import { requireSuperAdmin } from "../auth/roles";
import { getDb } from "../db/client";
import {
  brands,
  projects,
  userBrands,
  type Brand,
  type Project,
  type User,
} from "../db/schema";
import { AccessError, NotFoundError } from "../tenancy/errors";
import {
  readBrandSpendUnscoped,
  readProjectSpendUnscoped,
  type BrandSpend,
  type ProjectSpend,
} from "./spend";

/** What the admin path needs of the actor. `username` is for the audit row. */
export type SpendAdminActor = Pick<User, "id" | "role" | "username">;

/**
 * One brand in the admin's brand picker.
 *
 * `viewerIsMember` is the flag the UI turns into a visible marker. It is
 * computed server-side and travels with the data rather than being recomputed
 * in the component, so the badge cannot drift out of agreement with the thing
 * that decided whether to write an audit row.
 */
export interface AdminSpendBrand {
  id: string;
  name: string;
  viewerIsMember: boolean;
}

export interface AdminBrandSpend extends BrandSpend {
  /** False = the admin is looking at a brand they do not belong to. */
  viewerIsMember: boolean;
}

export interface AdminProjectSpend extends ProjectSpend {
  viewerIsMember: boolean;
}

/**
 * Every active brand, each flagged with whether this admin is a member.
 *
 * Ordered by name like `listAccessibleBrands`, and inactive brands are omitted
 * for the same reason they are omitted there: a deactivated brand is not part
 * of the product's present, and its spend is not a number anyone is deciding a
 * cap from.
 *
 * Listing brand NAMES is not itself the boundary crossing — `/admin` already
 * shows an admin every brand name (`listAllBrands`), which is directory
 * administration and always was. So no audit row is written here. The crossing
 * is opening a brand's spend, and that is where the row is written.
 */
export async function listAllBrandsForSpendAsSuperAdmin(
  actor: SpendAdminActor,
): Promise<AdminSpendBrand[]> {
  requireSuperAdmin(actor);

  const db = getDb();
  const rows = await db
    .select({
      id: brands.id,
      name: brands.name,
      memberBrandId: userBrands.brandId,
    })
    .from(brands)
    .leftJoin(
      userBrands,
      and(
        eq(userBrands.brandId, brands.id),
        eq(userBrands.userId, actor.id),
      ),
    )
    .where(eq(brands.isActive, true))
    .orderBy(asc(brands.name));

  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    viewerIsMember: r.memberBrandId !== null,
  }));
}

/**
 * Spend for ANY brand, member or not.
 *
 * Order of operations is load-bearing and is the same in both read functions
 * below: authorise the role, resolve the subject, decide membership, WRITE THE
 * AUDIT ROW, and only then read the numbers. The audit write comes before the
 * read so that a failure to record the crossing means the crossing does not
 * happen — see `recordSpendViewAuditEvent` for why this category fails closed
 * where logins do not.
 */
export async function getBrandSpendAsSuperAdmin(
  actor: SpendAdminActor,
  brandId: string,
): Promise<AdminBrandSpend> {
  requireSuperAdmin(actor);

  const brand = await loadActiveBrand(brandId);
  const viewerIsMember = await isMemberOf(actor.id, brand.id);

  if (!viewerIsMember) {
    await auditCrossing(actor, brand, null);
  }

  const spend = await readBrandSpendUnscoped(brand);
  return { ...spend, viewerIsMember };
}

/**
 * Spend for ANY project, in any brand. Same order of operations as above.
 *
 * The audit row names the project as well as the brand, because the project
 * name is the part of this that is content, and a record of a content exposure
 * that omits which content was exposed is not much of a record.
 */
export async function getProjectSpendAsSuperAdmin(
  actor: SpendAdminActor,
  projectId: string,
): Promise<AdminProjectSpend> {
  requireSuperAdmin(actor);

  const db = getDb();
  const [row] = await db
    .select({ project: projects, brand: brands })
    .from(projects)
    .innerJoin(brands, eq(projects.brandId, brands.id))
    .where(eq(projects.id, projectId))
    .limit(1);

  if (!row) throw new NotFoundError("Proje bulunamadı", "PROJECT_NOT_FOUND");
  // An inactive brand is closed to the admin too. The spend view is a tool for
  // deciding a cap on live work, and T50 did not ask to reopen archived
  // brands — so this path stays exactly as narrow as the brand list above.
  if (!row.brand.isActive) throw new AccessError();

  const viewerIsMember = await isMemberOf(actor.id, row.brand.id);

  if (!viewerIsMember) {
    await auditCrossing(actor, row.brand, row.project);
  }

  const spend = await readProjectSpendUnscoped(row.project, row.brand);
  return { ...spend, viewerIsMember };
}

/* ── internals ─────────────────────────────────────────────────────────── */

async function loadActiveBrand(brandId: string): Promise<Brand> {
  const db = getDb();
  const [brand] = await db
    .select()
    .from(brands)
    .where(and(eq(brands.id, brandId), eq(brands.isActive, true)))
    .limit(1);
  if (!brand) throw new AccessError();
  return brand;
}

/**
 * Membership, asked directly rather than through `userCanAccessBrand`.
 *
 * Not a duplication worth collapsing: `userCanAccessBrand` is a component of
 * the AUTHORIZATION gate, and this call is not authorising anything — by the
 * time it runs, the role has already decided the answer. It is asking a
 * question about presentation and about whether a row is owed. Routing a
 * non-authorization question through the authorization primitive is how the
 * two get confused later.
 */
async function isMemberOf(userId: string, brandId: string): Promise<boolean> {
  const db = getDb();
  const [row] = await db
    .select({ brandId: userBrands.brandId })
    .from(userBrands)
    .where(
      and(eq(userBrands.userId, userId), eq(userBrands.brandId, brandId)),
    )
    .limit(1);
  return Boolean(row);
}

/** The trace. Throws if it cannot be written, which refuses the view. */
async function auditCrossing(
  actor: SpendAdminActor,
  brand: Brand,
  project: Project | null,
): Promise<void> {
  await recordSpendViewAuditEvent({
    action: "spend_view_admin",
    actorUserId: actor.id,
    actorUsername: actor.username,
    brandId: brand.id,
    brandName: brand.name,
    projectId: project?.id ?? null,
    projectName: project?.name ?? null,
    metadata: {
      // What the admin saw, in the two words that matter to a reader deciding
      // whether to ask about it: the whole brand, or one project inside it.
      scope: project ? "project" : "brand",
      viaRole: "admin",
    },
  });
}
