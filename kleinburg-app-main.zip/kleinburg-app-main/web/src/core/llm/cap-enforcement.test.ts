import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import {
  auditEvents,
  brands,
  generationJobs,
  llmCalls,
  projects,
  userBrands,
  users,
  type WorkflowStep,
} from "../db/schema";
import { setBrandMonthlyCap } from "../admin/service";
import { deleteProject } from "../tenancy/projects";
import {
  SpendCapExceededError,
  assertBrandWithinCap,
  getBrandCapStatus,
  spendMonthOf,
} from "./cap";

import { hasDb } from "@/test/db-gate";

/**
 * The monthly cap against a real database (T51): that the count comes from
 * #42's aggregation over the right window, that unpriced calls move the
 * decision, that the refusal fires before anything is written, and that a cap
 * change leaves an audit row.
 *
 * ── HOW THESE TESTS PIN TIME ─────────────────────────────────────────────
 * `llm_calls.created_at` defaults to now(), so a fixture that relied on the
 * default could only ever test "this month" and would prove nothing about the
 * boundary. Every call here is inserted with an EXPLICIT `createdAt`, and
 * every assertion passes an explicit `now`. No test reads the system clock, so
 * none of them behave differently on the 1st of the month.
 */

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

/** The instant every test calls "now": mid-August 2026, Istanbul afternoon. */
const NOW = new Date("2026-08-15T12:00:00.000Z");
const AUGUST = spendMonthOf(NOW);

async function makeUser(role: "admin" | "user" = "admin") {
  const [user] = await getDb()
    .insert(users)
    .values({ username: `t51-${randomUUID()}`, passwordHash: "x", role })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

async function makeBrand(monthlyCapUsd: string | null = null) {
  const [brand] = await getDb()
    .insert(brands)
    .values({ name: `brand-${randomUUID()}`, isActive: true, monthlyCapUsd })
    .returning();
  createdBrandIds.push(brand.id);
  return brand;
}

/** An ordinary membership grant — the only thing `deleteProject` asks for. */
async function grantBrand(userId: string, brandId: string) {
  await getDb().insert(userBrands).values({ userId, brandId });
}

async function makeProject(brandId: string, createdBy: string) {
  const [project] = await getDb()
    .insert(projects)
    .values({ brandId, name: `proj-${randomUUID()}`, createdBy })
    .returning();
  return project;
}

async function makeJob(projectId: string, step: WorkflowStep = "sm_pillars") {
  const [job] = await getDb()
    .insert(generationJobs)
    .values({ projectId, step, status: "succeeded", input: {} })
    .returning();
  return job;
}

async function makeCall(
  jobId: string,
  opts: {
    costUsd: number | null;
    createdAt: Date;
    model?: string;
    promptTokens?: number;
    completionTokens?: number;
  },
) {
  await getDb()
    .insert(llmCalls)
    .values({
      jobId,
      model: opts.model ?? "anthropic/claude-sonnet-5",
      promptTokens: opts.promptTokens ?? 1000,
      completionTokens: opts.completionTokens ?? 0,
      costUsd: opts.costUsd === null ? null : String(opts.costUsd),
      durationMs: 10,
      createdAt: opts.createdAt,
    });
}

/** A brand with a project, ready to have calls hung off it. */
async function scenario(cap: string | null) {
  const user = await makeUser();
  const brand = await makeBrand(cap);
  const project = await makeProject(brand.id, user.id);
  const job = await makeJob(project.id);
  return { user, brand, project, job };
}

describe.skipIf(!hasDb)("llm/cap enforcement", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdBrandIds.length > 0) {
      // Cascades to projects, generation_jobs, llm_calls. `audit_events` rows
      // deliberately survive: the table has no DELETE path, by design (T41).
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    await closeDb();
  });

  describe("what counts towards the cap", () => {
    it("counts only calls inside the current month", async () => {
      const { brand, job } = await scenario("100.00");

      // $40 in July, $10 in August. A window-blind implementation would total
      // $50 and warn; the correct one sees $10 and is calm. The July figure is
      // deliberately large enough to cross both thresholds on its own.
      await makeCall(job.id, {
        costUsd: 40,
        createdAt: new Date("2026-07-20T10:00:00.000Z"),
      });
      await makeCall(job.id, { costUsd: 10, createdAt: NOW });

      const status = await getBrandCapStatus(brand, NOW);
      expect(status.measuredUsd).toBe(10);
      expect(status.state).toBe("ok");
    });

    it("counts a call by WHEN IT WAS MADE, across the local midnight", async () => {
      const { brand, job } = await scenario("100.00");

      // 31 July 22:00 UTC is 1 August 01:00 in Istanbul: this call belongs to
      // AUGUST. A UTC-boundary implementation would file it under July and
      // report $0 for August. This is the fixture that separates the two.
      await makeCall(job.id, {
        costUsd: 33,
        createdAt: new Date("2026-07-31T22:00:00.000Z"),
      });
      // And one an hour earlier, which is 31 July 23:00 local: still July.
      await makeCall(job.id, {
        costUsd: 44,
        createdAt: new Date("2026-07-31T20:00:00.000Z"),
      });

      const status = await getBrandCapStatus(brand, NOW);
      expect(status.measuredUsd).toBe(33);
    });

    it("is the SAME arithmetic the /spend page uses", async () => {
      // The window bounds come from `spendMonthOf` and the aggregation from
      // spend.ts, so this asserts the join chain reaches llm_calls the same
      // way: through generation_jobs -> projects -> brand.
      const { brand, job } = await scenario("100.00");
      await makeCall(job.id, { costUsd: 1.63, createdAt: NOW });

      const status = await getBrandCapStatus(brand, NOW);
      expect(status.measuredUsd).toBe(1.63);
      expect(status.month.since.getTime()).toBe(AUGUST.since.getTime());
      expect(status.month.until.getTime()).toBe(AUGUST.until.getTime());
    });
  });

  describe("unpriced calls move the decision", () => {
    it("BLOCKS a brand that is only over the cap once unpriced calls are counted", async () => {
      // THE FIXTURE THIS FEATURE LIVES OR DIES BY.
      //
      // Cap $10. Measured spend $8 — under the cap, and under the 80% warning
      // threshold of... no: $8/$10 is exactly 80%, so pick numbers that make
      // the two implementations land in DIFFERENT states, not merely different
      // numbers.
      //
      // Priced:   4,000,000 tokens, $6.00 -> $0.0000015/token, 60% of a $10 cap.
      // Unpriced: 4,000,000 tokens        -> $6.00 imputed, total $12.00.
      //
      // Counting unknown as zero  -> $6.00,  60% -> "ok", generation allowed.
      // Counting it honestly      -> $12.00, 120% -> "blocked", refused.
      //
      // There is no reading of these numbers under which both implementations
      // agree, which is the point: a fixture that passed either way would be
      // worthless here.
      //
      // The counts are in millions rather than thousands so that the implied
      // rate is a realistic one. At 4000 tokens for $6 the fixture implied
      // $0.0015/token, which the estimator's absurdity ceiling now clamps —
      // it would still have gone green, but for the wrong reason.
      const { brand, job } = await scenario("10.00");
      await makeCall(job.id, {
        costUsd: 6,
        promptTokens: 4_000_000,
        createdAt: NOW,
      });
      await makeCall(job.id, {
        costUsd: null,
        promptTokens: 4_000_000,
        createdAt: NOW,
      });

      const status = await getBrandCapStatus(brand, NOW);

      expect(status.measuredUsd).toBe(6);
      expect(status.estimatedUnpricedUsd).toBe(6);
      expect(status.chargeableUsd).toBe(12);
      expect(status.state).toBe("blocked");
      expect(status.unpricedCallCount).toBe(1);
    });

    it("keeps the measured and the estimated halves apart", async () => {
      // The operator is entitled to know which part is a fact. If these were
      // pre-added there would be no way to tell them apart on screen.
      const { brand, job } = await scenario("100.00");
      await makeCall(job.id, {
        costUsd: 2,
        promptTokens: 1_000_000,
        createdAt: NOW,
      });
      await makeCall(job.id, {
        costUsd: null,
        promptTokens: 500_000,
        createdAt: NOW,
      });

      const status = await getBrandCapStatus(brand, NOW);
      expect(status.measuredUsd).toBe(2);
      expect(status.estimatedUnpricedUsd).toBe(1);
      expect(status.chargeableUsd).toBe(3);
    });

    it("REFUSES when even the most generous bound does not fit", async () => {
      // Every call this brand ever made was unpriced, so no rate exists
      // anywhere in its history and these tokens cannot be priced from this
      // brand's data at all.
      //
      // They are still BOUNDED: 200,000 tokens at the absurdity ceiling of
      // $0.001/token is at most $200, and $200 does not fit under a $100 cap.
      // So the cap cannot be shown to hold, and it refuses.
      const { brand, job } = await scenario("100.00");
      await makeCall(job.id, {
        costUsd: null,
        promptTokens: 200_000,
        createdAt: NOW,
      });

      const status = await getBrandCapStatus(brand, NOW);
      expect(status.state).toBe("unmeasurable");
      expect(status.unpriceableTokens).toBe(200_000);
      expect(status.worstCaseUsd).toBe(200);
      await expect(assertBrandWithinCap(brand, NOW)).rejects.toThrow(
        SpendCapExceededError,
      );
    });

    it("PERMITS the same brand when the generous bound does fit", async () => {
      // The other half of the pair, and the whole of finding 4.
      //
      // Identical shape to the test above — unpriced calls, not one priced
      // call anywhere in the brand's history, nothing to derive a rate from —
      // differing only in whether the worst case leaves room under the cap.
      //
      //   20,000 unpriceable tokens x $0.001 = $20 worst case, cap $100.
      //
      // The old rule refused on the mere PRESENCE of unpriceable tokens, so it
      // refused here too, and that is what made a whole-brand outage reachable
      // by an ordinary project delete. The two rules land in different states
      // on this fixture: "unmeasurable" versus "ok".
      const { brand, job } = await scenario("100.00");
      await makeCall(job.id, {
        costUsd: null,
        promptTokens: 20_000,
        createdAt: NOW,
      });

      const status = await getBrandCapStatus(brand, NOW);
      expect(status.state).toBe("ok");
      expect(status.unpriceableTokens).toBe(20_000);
      expect(status.worstCaseUsd).toBe(20);
      // And it must not have invented a cost for them along the way: the
      // estimate stays zero, because zero is what could actually be observed.
      expect(status.estimatedUnpricedUsd).toBe(0);
      expect(status.chargeableUsd).toBe(0);
      await expect(assertBrandWithinCap(brand, NOW)).resolves.toBeDefined();
    });

    it("still calls a brand over its cap BLOCKED, not unmeasurable", async () => {
      // Both conditions at once: real measured spend past the ceiling AND
      // tokens nothing can price. `blocked` wins, because it is the claim
      // supported by evidence and "we could not work out your spend" would be
      // the weaker and less true of the two sentences available.
      const { brand, job } = await scenario("10.00");
      // 100 priced tokens is under the evidence floor, so this call's $12 is
      // counted as spend (it is measured) but yields no rate anyone can use.
      await makeCall(job.id, {
        costUsd: 12,
        model: "priced",
        promptTokens: 100,
        createdAt: NOW,
      });
      await makeCall(job.id, {
        costUsd: null,
        model: "never-priced",
        promptTokens: 5_000,
        createdAt: NOW,
      });

      const status = await getBrandCapStatus(brand, NOW);
      expect(status.state).toBe("blocked");
    });

    it("does not fire `unmeasurable` for a brand that has simply done nothing", async () => {
      // A fresh capped brand has no unpriced calls, so the narrow door above
      // must not catch it. If it did, setting a cap would block a brand before
      // it had spent a cent.
      const { brand } = await scenario("50.00");
      const status = await getBrandCapStatus(brand, NOW);
      expect(status.state).toBe("ok");
      await expect(assertBrandWithinCap(brand, NOW)).resolves.toBeDefined();
    });
  });

  describe("an ordinary project delete cannot black out the brand", () => {
    it("keeps the OTHER projects working after the priced one is deleted", async () => {
      // FINDING 4, END TO END, with the real `deleteProject`.
      //
      // The brand has priced calls in project A and unpriced ones in project
      // B. An ordinary member deletes project A — which needs nothing but
      // `requireProjectAccess`, i.e. any member — and the cascade
      // projects -> generation_jobs -> llm_calls takes every priced call the
      // brand has ever had with it. The brand is left with unpriced calls and
      // no rate anywhere in its history.
      //
      // Under the old rule that refused on the mere presence of unpriceable
      // tokens, EVERY project in the brand was refused from that moment,
      // clearable only by a super admin. One ordinary user, one ordinary
      // delete, whole-brand outage. Now the unpriceable tokens are bounded
      // ($0.001 x 20,000 = $20) and $20 fits under the $100 cap, so the brand
      // keeps working.
      const user = await makeUser("user");
      const brand = await makeBrand("100.00");

      const projectA = await makeProject(brand.id, user.id);
      const jobA = await makeJob(projectA.id);
      await makeCall(jobA.id, {
        costUsd: 3,
        promptTokens: 1_000_000,
        createdAt: NOW,
      });

      const projectB = await makeProject(brand.id, user.id);
      const jobB = await makeJob(projectB.id);
      await makeCall(jobB.id, {
        costUsd: null,
        promptTokens: 20_000,
        createdAt: NOW,
      });

      // Before the delete: the brand can price B's calls from A's, and is calm.
      expect((await getBrandCapStatus(brand, NOW)).state).toBe("ok");

      await grantBrand(user.id, brand.id);
      await deleteProject(user.id, projectA.id);

      const after = await getBrandCapStatus(brand, NOW);

      // The evidence really is gone — this is what makes the test meaningful
      // rather than a delete that quietly failed.
      expect(after.measuredUsd).toBe(0);
      expect(after.unpriceableTokens).toBe(20_000);
      // And the brand is still open for business.
      expect(after.state).toBe("ok");
      await expect(assertBrandWithinCap(brand, NOW)).resolves.toBeDefined();
    });
  });

  describe("warn first, then stop", () => {
    it("warns at 80% without refusing", async () => {
      const { brand, job } = await scenario("100.00");
      await makeCall(job.id, { costUsd: 80, createdAt: NOW });

      const status = await getBrandCapStatus(brand, NOW);
      expect(status.state).toBe("warning");
      // Elif's decision is warn FIRST, then stop. A warning that refused would
      // move the ceiling from 100% to 80% without anyone deciding to.
      await expect(assertBrandWithinCap(brand, NOW)).resolves.toBeDefined();
    });

    it("is still calm one cent below the warning threshold", async () => {
      const { brand, job } = await scenario("100.00");
      await makeCall(job.id, { costUsd: 79.99, createdAt: NOW });
      expect((await getBrandCapStatus(brand, NOW)).state).toBe("ok");
    });

    it("refuses at exactly 100%, not only past it", async () => {
      const { brand, job } = await scenario("100.00");
      await makeCall(job.id, { costUsd: 100, createdAt: NOW });
      expect((await getBrandCapStatus(brand, NOW)).state).toBe("blocked");
    });

    it("measures nothing at all for an uncapped brand", async () => {
      // The default. Shipping this feature must change nothing for a brand
      // whose cap nobody set — including not spending a query on it.
      const { brand, job } = await scenario(null);
      await makeCall(job.id, { costUsd: 9999, createdAt: NOW });

      const status = await getBrandCapStatus(brand, NOW);
      expect(status.state).toBe("unlimited");
      expect(status.capUsd).toBeNull();
      expect(status.ratio).toBeNull();
      await expect(assertBrandWithinCap(brand, NOW)).resolves.toBeDefined();
    });

    it("treats a cap of 0 as a real ceiling, not as unlimited", async () => {
      const { brand } = await scenario("0.00");
      const status = await getBrandCapStatus(brand, NOW);
      expect(status.capUsd).toBe(0);
      expect(status.state).toBe("blocked");
    });
  });

  describe("the refusal", () => {
    it("carries the brand, the cap, the spend and the reset date", async () => {
      const { brand, job } = await scenario("10.00");
      await makeCall(job.id, { costUsd: 12, createdAt: NOW });

      const error = await assertBrandWithinCap(brand, NOW).catch((e) => e);
      expect(error).toBeInstanceOf(SpendCapExceededError);
      expect(error.code).toBe("SPEND_CAP_EXCEEDED");
      expect(error.status.brandName).toBe(brand.name);
      expect(error.status.capUsd).toBe(10);
      expect(error.status.chargeableUsd).toBe(12);
      expect(error.message).toContain(brand.name);
      expect(error.message).toContain("$10.00");
      // The reset date, on the operator's calendar.
      expect(error.message).toContain("1 Eylül 2026");
    });
  });

  describe("changing a cap is audited", () => {
    it("records the raise AND the lowering, with both values", async () => {
      // The round trip #51 item 5 is about: raise, spend, put it back. After
      // it, `brands` looks untouched — these rows are the only evidence.
      const actor = await makeUser("admin");
      const brand = await makeBrand("100.00");

      await setBrandMonthlyCap(actor, brand.id, 500);
      await setBrandMonthlyCap(actor, brand.id, 100);

      const rows = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.brandId, brand.id));

      const capRows = rows.filter((r) => r.action === "brand_cap_set");
      expect(capRows).toHaveLength(2);

      const directions = capRows.map(
        (r) => (r.metadata as Record<string, unknown>).direction,
      );
      expect(directions).toContain("raised");
      expect(directions).toContain("lowered");

      const raised = capRows.find(
        (r) => (r.metadata as Record<string, unknown>).direction === "raised",
      )!;
      // Both values on the row, so it is legible without the neighbouring one.
      expect((raised.metadata as Record<string, unknown>).previousCapUsd).toBe(
        100,
      );
      expect((raised.metadata as Record<string, unknown>).capUsd).toBe(500);
    });

    it("distinguishes removing a cap from setting it to zero", async () => {
      const actor = await makeUser("admin");
      const brand = await makeBrand("50.00");

      const cleared = await setBrandMonthlyCap(actor, brand.id, null);
      expect(cleared.monthlyCapUsd).toBeNull();

      const zeroed = await setBrandMonthlyCap(actor, brand.id, 0);
      expect(zeroed.monthlyCapUsd).toBe("0.00");

      const rows = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.brandId, brand.id));
      const directions = rows
        .filter((r) => r.action === "brand_cap_set")
        .map((r) => (r.metadata as Record<string, unknown>).direction);
      expect(directions).toContain("removed");
      expect(directions).toContain("set");
    });

    it("records the STORED value, not the one that was typed", async () => {
      // #51 review, finding 5. The column is numeric(12,2) and the service
      // rounds to it with toFixed(2) precisely so the rounding is visible
      // rather than happening inside the driver — and then the audit row took
      // the raw input, which is where the visibility was being lost.
      //
      // 50.004 against a stored "50.00" rounds to "50.00": a write that
      // changed nothing. The trail used to call it `raised` at `50.004`, which
      // is a claim about a change that did not happen, recorded on the only
      // evidence there is that anything happened at all.
      const actor = await makeUser("admin");
      const brand = await makeBrand("50.00");

      const updated = await setBrandMonthlyCap(actor, brand.id, 50.004);
      expect(updated.monthlyCapUsd).toBe("50.00");

      const [row] = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.brandId, brand.id));
      const metadata = row.metadata as Record<string, unknown>;

      expect(metadata.capUsd).toBe(50);
      expect(metadata.direction).toBe("unchanged");
    });

    it("still records a rounding that DID move the stored value", async () => {
      // The other side of it: 50.005 rounds up to "50.01", which is a real
      // change, and the trail must say so at the rounded figure.
      const actor = await makeUser("admin");
      const brand = await makeBrand("50.00");

      const updated = await setBrandMonthlyCap(actor, brand.id, 50.005);
      expect(updated.monthlyCapUsd).toBe("50.01");

      const [row] = await getDb()
        .select()
        .from(auditEvents)
        .where(eq(auditEvents.brandId, brand.id));
      const metadata = row.metadata as Record<string, unknown>;

      expect(metadata.capUsd).toBe(50.01);
      expect(metadata.direction).toBe("raised");
    });

    it("refuses a non-admin, before touching the brand", async () => {
      const ordinary = await makeUser("user");
      const brand = await makeBrand("50.00");

      await expect(
        setBrandMonthlyCap(ordinary, brand.id, 999),
      ).rejects.toThrow();

      const [after] = await getDb()
        .select()
        .from(brands)
        .where(eq(brands.id, brand.id));
      expect(after.monthlyCapUsd).toBe("50.00");
    });

    it("rejects a negative cap without writing anything", async () => {
      const actor = await makeUser("admin");
      const brand = await makeBrand(null);

      await expect(setBrandMonthlyCap(actor, brand.id, -5)).rejects.toThrow();

      const [after] = await getDb()
        .select()
        .from(brands)
        .where(eq(brands.id, brand.id));
      expect(after.monthlyCapUsd).toBeNull();
    });
  });
});
