import { readdirSync, readFileSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";

import { describe, expect, it } from "vitest";

/**
 * The structural guard behind #42's C1.
 *
 * `generateStructured` records usage only when it is given a `jobId`
 * (`if (!opts.jobId) return`), and `llm_calls.job_id` is NOT NULL, so a caller
 * that omits it produces a billed call with NO ledger row at all. That is worse
 * than an unpriced call: an unpriced call is at least counted in
 * `unpricedCallCount`, which is the blind-spot accounting the /spend page's
 * honesty rests on. An unrecorded one is invisible, and /spend goes on
 * reporting `complete: true` over a total that is missing money.
 *
 * `jobId` is optional in the signature because the tests in openrouter.test.ts
 * exercise the no-jobId path deliberately. Optional means forgettable, and it
 * WAS forgotten — cadence.ts shipped that way and was reachable from the UI.
 * TypeScript cannot catch an omitted optional field, so the source is checked
 * instead, in the same spirit as the DB-gate registry test.
 *
 * THE SCAN IS NO LONGER THE ONLY ENFORCEMENT, and must not be relied on as if
 * it were. It reads text: it accepts the shorthand `jobId,` whatever the value
 * is, so a caller that forwards its own optional parameter satisfies it while
 * passing `undefined` (runStep did exactly that). `generateStructured` now
 * throws when the id is absent or blank, before the request is sent, and
 * `unrecorded: true` is the one documented way out. What survives here is the
 * cheap part the runtime cannot give: naming the call sites that opted out, in
 * one list, so the exceptions stay visible and countable.
 *
 * IT SCANS `scripts/` AS WELL AS `src/`. It did not, and the three probe/smoke
 * scripts under `scripts/` were calling generateStructured with no jobId at
 * all — the exact forbidden pattern, simply parked in the one directory the
 * guard could not see. They are legitimate (no job row exists to bill against),
 * so they now say so with `unrecorded: true` rather than being invisible.
 *
 * If a future call genuinely must not be recorded, this test is the place to
 * say so out loud and explain why — not the call site to quietly omit a field.
 */

const WEB_ROOT = fileURLToPath(new URL("../../../", import.meta.url));

/** This file quotes the call syntax it searches for, so it never scans itself. */
const SELF = fileURLToPath(import.meta.url);

/** The directories a billable call can be written in. */
const SCANNED_DIRS = ["src", "scripts"] as const;

/** Every non-test `.ts`/`.tsx` under one of SCANNED_DIRS. */
function sourceFiles(dir: string): string[] {
  const out: string[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...sourceFiles(full));
    else if (/\.tsx?$/.test(entry.name) && !/\.test\.tsx?$/.test(entry.name)) {
      out.push(full);
    }
  }
  return out;
}

/**
 * Call sites of `generateStructured({ ... })` — including `deps.` /
 * `opts.`-prefixed ones — paired with their argument object.
 *
 * The object is taken by brace matching rather than by regex, because the
 * argument spans many lines and contains nested objects.
 */
function callSites(): Array<{ file: string; args: string }> {
  const out: Array<{ file: string; args: string }> = [];
  const callRe = /(?:\w+\.)?generateStructured\s*\(\s*\{/g;

  const files = SCANNED_DIRS.flatMap((dir) =>
    sourceFiles(join(WEB_ROOT, dir)),
  );
  for (const file of files) {
    if (file === SELF) continue;
    const source = readFileSync(file, "utf8");
    const rel = relative(WEB_ROOT, file).replaceAll("\\", "/");
    // The definition itself declares the parameter; it is not a call.
    if (rel === "src/core/llm/openrouter.ts") continue;

    for (const match of source.matchAll(callRe)) {
      let depth = 1;
      let i = match.index + match[0].length;
      while (i < source.length && depth > 0) {
        if (source[i] === "{") depth++;
        else if (source[i] === "}") depth--;
        i++;
      }
      out.push({ file: rel, args: source.slice(match.index, i) });
    }
  }
  return out;
}

describe("every billed LLM call is recorded", () => {
  it("finds the call sites at all, so a green run cannot be vacuous", () => {
    // Without this the whole file passes trivially if the regex ever stops
    // matching — the failure mode that let M2 ship.
    const sites = callSites();
    expect(sites.length).toBeGreaterThanOrEqual(2);
    expect(sites.map((s) => s.file)).toContain("src/core/pipeline/cadence.ts");
    // And that `scripts/` is genuinely in view — this file's whole second
    // failure was a scan that looked complete while missing a directory.
    expect(sites.map((s) => s.file)).toContain("scripts/llm-smoke.ts");
  });

  it("passes a jobId at every generateStructured call site", () => {
    // Accepts both `jobId: x` and the shorthand `jobId,` — run-step.ts uses
    // the latter, and a matcher that missed it would report a false positive
    // there while still catching a genuinely absent field.
    const missing = callSites()
      .filter(
        (site) =>
          !/\bjobId\s*[:,}]/.test(site.args) &&
          !/\bunrecorded\s*:\s*true/.test(site.args),
      )
      .map((site) => site.file);

    expect(
      missing,
      "these calls are billed but write no llm_calls row, so /spend under-reports them silently",
    ).toEqual([]);
  });

  /**
   * The opt-out, listed by name. `unrecorded: true` is the only way past the
   * runtime check in generateStructured, so an app module reaching for it would
   * reopen the whole hole — quietly, and with the source scan above still
   * green. Written as an exact list rather than a rule about paths so that
   * adding one is a deliberate edit to this file with a reason attached.
   */
  it("only the probe/smoke scripts opt out of recording", () => {
    const optedOut = callSites()
      .filter((site) => /\bunrecorded\s*:\s*true/.test(site.args))
      .map((site) => site.file)
      .sort();

    expect(optedOut).toEqual([
      // No job row exists for any of these: they are operator tools run from a
      // terminal, not generation the product bills a project for.
      "scripts/llm-smoke.ts",
      "scripts/probe-models.ts",
      "scripts/probe-research-model.ts",
    ]);
  });
});
