import { afterEach, describe, expect, it, vi } from "vitest";

import {
  configuredModels,
  defaultModel,
  maxOutputFor,
  MODEL_REGISTRY,
  RESEARCH_MODEL,
  resolveModel,
  UNREGISTERED_MODEL_MAX_OUTPUT,
  validateConfiguredModels,
} from "./models";

describe("model resolution", () => {
  const original = process.env.OPENROUTER_MODEL;

  afterEach(() => {
    if (original === undefined) delete process.env.OPENROUTER_MODEL;
    else process.env.OPENROUTER_MODEL = original;
  });

  it("defaults to a model whose endpoints do not train on request data", () => {
    // Gemini 2.5 Pro was the old default; under the account's data policy
    // OpenRouter had no endpoint left to route to and returned a 404.
    delete process.env.OPENROUTER_MODEL;
    expect(defaultModel()).toBe("anthropic/claude-sonnet-5");
    expect(resolveModel("brand_context")).toBe("anthropic/claude-sonnet-5");
  });

  it("respects OPENROUTER_MODEL read lazily at call time", () => {
    process.env.OPENROUTER_MODEL = "anthropic/claude-3.5-sonnet";
    expect(defaultModel()).toBe("anthropic/claude-3.5-sonnet");
    expect(resolveModel("sm_posts")).toBe("anthropic/claude-3.5-sonnet");
  });
});

/**
 * The output-limit registry exists so that code sizing a `max_tokens` request
 * (today: the content_calendar ceiling in pipeline/run-step.ts) can clamp
 * against DATA rather than a literal justified in prose. A request above the
 * model's real limit is rejected outright, failing the whole step.
 */
describe("model output limits", () => {
  const original = process.env.OPENROUTER_MODEL;

  afterEach(() => {
    if (original === undefined) delete process.env.OPENROUTER_MODEL;
    else process.env.OPENROUTER_MODEL = original;
  });

  it("knows the default model's limit", () => {
    delete process.env.OPENROUTER_MODEL;
    // The registry must actually cover the model the app runs by default,
    // otherwise every calendar silently falls back to the conservative
    // assumption and big projects truncate for no visible reason.
    expect(MODEL_REGISTRY[defaultModel()]).toBeDefined();
    // 128000 is Anthropic's documented max OUTPUT for Claude Sonnet 5. Its
    // context window is 1M — a different number, not this one. This assertion
    // read 64000 for one commit, on the mistaken theory that 128000 had to be a
    // context window because it looked too big to be an output limit.
    expect(maxOutputFor(defaultModel())).toBe(128_000);
  });

  it("falls back conservatively for an unregistered model", () => {
    // defaultModel() accepts any OPENROUTER_MODEL string unvalidated, so this
    // path is reachable in production by an env change alone.
    expect(maxOutputFor("some/model-we-have-never-heard-of")).toBe(
      UNREGISTERED_MODEL_MAX_OUTPUT,
    );
    // Conservative RELATIVE TO THE DEFAULT: an unknown model must never be
    // assumed to take as much as the model we actually run, or an env change
    // alone starts producing requests the provider rejects.
    //
    // Deliberately NOT "below every registered model" — claude-3.5-sonnet is
    // registered at 8192, under this fallback. That is not a contradiction: a
    // registered model's real limit is known and used directly, so the fallback
    // only ever applies to models absent from the table.
    delete process.env.OPENROUTER_MODEL;
    expect(UNREGISTERED_MODEL_MAX_OUTPUT).toBeLessThan(
      maxOutputFor(defaultModel()),
    );
  });

  it("warns rather than degrading silently for an unregistered model", () => {
    // CLAUDE.md hard rule 5: no silent failure. The fallback is a deliberate
    // conservative assumption, but an operator who points OPENROUTER_MODEL at
    // an unregistered model must be told their calendars are being capped low.
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      // A name unique to this test: the warning fires once per model per
      // process, so a name any other test touches would already be spent.
      const unknown = "acme/model-that-does-not-exist-warn-test";
      expect(maxOutputFor(unknown)).toBe(UNREGISTERED_MODEL_MAX_OUTPUT);

      expect(warn).toHaveBeenCalledTimes(1);
      const message = String(warn.mock.calls[0]?.[0]);
      // The message has to name the model and the fix, or it is noise.
      expect(message).toContain(unknown);
      expect(message).toContain(String(UNREGISTERED_MODEL_MAX_OUTPUT));
      expect(message).toContain("MODEL_REGISTRY");

      // Once per model, not once per calendar run: a repeat is silent.
      expect(maxOutputFor(unknown)).toBe(UNREGISTERED_MODEL_MAX_OUTPUT);
      expect(warn).toHaveBeenCalledTimes(1);
    } finally {
      warn.mockRestore();
    }
  });

  it("does not warn for a registered model", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    try {
      expect(maxOutputFor("anthropic/claude-sonnet-5")).toBe(128_000);
      expect(warn).not.toHaveBeenCalled();
    } finally {
      warn.mockRestore();
    }
  });

  it("registers an output limit, not a context window, for every entry", () => {
    // This test used to say "a six-figure value in this table is the tell" and
    // guarded against one. That guard encoded a factual error: 128000 IS the
    // documented max output for the default model, and the six-figure rule
    // would have blocked the correct value. It is inverted here.
    //
    // What actually needs guarding is a CONTEXT WINDOW landing in this field.
    // Those are 1M on the current Anthropic and Google models, so the band
    // below admits every real output limit we might register (8192 through
    // 128000) while still rejecting a stray 1_000_000.
    const LARGEST_DOCUMENTED_MAX_OUTPUT = 128_000;
    for (const [model, def] of Object.entries(MODEL_REGISTRY)) {
      expect(def.maxOutput, model).toBeGreaterThan(0);
      expect(Number.isInteger(def.maxOutput), model).toBe(true);
      expect(def.maxOutput, model).toBeLessThanOrEqual(
        LARGEST_DOCUMENTED_MAX_OUTPUT,
      );
    }
    // The band is a real constraint, not one so wide it can never fail: a 1M
    // context window mistaken for an output limit sits above it. That used to
    // be asserted as `expect(1_000_000).toBeGreaterThan(LARGEST_...)`, which
    // compared two literals — arithmetic, not code, and unfalsifiable by any
    // state of the registry. It is a comment now, because that is what it was.
  });

  it("rejects a context window that lands in the maxOutput field", () => {
    // Exercises the guard the band above encodes, against the actual shape of
    // the mistake: MODEL_REGISTRY entries are checked by the same predicate
    // with a 1M value spliced in, and it must fail.
    const LARGEST_DOCUMENTED_MAX_OUTPUT = 128_000;
    const withContextWindow = {
      ...MODEL_REGISTRY,
      "anthropic/claude-sonnet-5": { maxOutput: 1_000_000 },
    };
    const offenders = Object.entries(withContextWindow).filter(
      ([, def]) => def.maxOutput > LARGEST_DOCUMENTED_MAX_OUTPUT,
    );
    expect(offenders.map(([model]) => model)).toEqual([
      "anthropic/claude-sonnet-5",
    ]);
  });
});

/**
 * Startup validation (see validateConfiguredModels in models.ts).
 *
 * The gap it closes: maxOutputFor only warns when something asks for an output
 * limit, and since the calendar became deterministic NOTHING does — so that
 * warning never fires in production and this boot check is the only report an
 * operator gets. Boot-time is unconditional; it does not wait for a step.
 */
describe("startup model validation", () => {
  const original = process.env.OPENROUTER_MODEL;

  afterEach(() => {
    if (original === undefined) delete process.env.OPENROUTER_MODEL;
    else process.env.OPENROUTER_MODEL = original;
  });

  it("stays silent when every configured model is registered", () => {
    delete process.env.OPENROUTER_MODEL;
    const warn = vi.fn();
    expect(validateConfiguredModels(warn)).toEqual([]);
    expect(warn).not.toHaveBeenCalled();
  });

  it("names an unregistered OPENROUTER_MODEL and the assumed ceiling", () => {
    process.env.OPENROUTER_MODEL = "some/unreleased-model";
    const warn = vi.fn();

    expect(validateConfiguredModels(warn)).toEqual(["some/unreleased-model"]);
    expect(warn).toHaveBeenCalledTimes(1);

    const message = warn.mock.calls[0]![0] as string;
    // The operator has to be able to act on this without reading the source:
    // which model, where it came from, what is assumed, and the fix.
    expect(message).toContain("some/unreleased-model");
    expect(message).toContain("OPENROUTER_MODEL");
    expect(message).toContain(String(UNREGISTERED_MODEL_MAX_OUTPUT));
    expect(message).toContain("MODEL_REGISTRY");
  });

  /**
   * #47 review. The configured-model map was keyed by MODEL ID, so when one
   * model is named by two config sites the later write erased the earlier
   * label. Setting OPENROUTER_MODEL to the same value a step override uses is
   * exactly that collision: the warning then blamed one site and pointed the
   * operator away from the other.
   */
  it("attributes a model named by two config sites to both of them", () => {
    // Reaching the collision needs a model that is BOTH the default and named
    // by another config site AND unregistered. The first two are set here; the
    // third is arranged by lifting the model out of the registry for this test
    // and putting it back, rather than inventing a parallel fake registry.
    //
    // The second site is RESEARCH_MODEL since #52 (it was
    // STEP_MODEL_OVERRIDES.secondary_data, which no longer exists — the step's
    // retrieval call names the model directly instead of overriding the step).
    const model = RESEARCH_MODEL;
    process.env.OPENROUTER_MODEL = model;
    const saved = MODEL_REGISTRY[model];
    delete MODEL_REGISTRY[model];
    try {
      const warn = vi.fn();

      expect(validateConfiguredModels(warn)).toEqual([model]);
      // ONE entry, not two — it is one model — carrying BOTH config sites.
      expect(warn).toHaveBeenCalledTimes(1);
      const message = warn.mock.calls[0]![0] as string;
      expect(message).toContain("OPENROUTER_MODEL / DEFAULT_MODEL");
      expect(message).toContain("RESEARCH_MODEL (secondary_data retrieval)");
    } finally {
      MODEL_REGISTRY[model] = saved;
    }
  });

  it("warns instead of throwing, so a stale registry cannot block boot", () => {
    // MODEL_REGISTRY is a hand-maintained subset of OpenRouter's catalogue, not
    // a mirror of it. Throwing would let a lagging local list refuse to start an
    // app whose config the provider would accept. Degraded, loud and running
    // beats a hard outage; CLAUDE.md rule 5 forbids the SILENT version.
    process.env.OPENROUTER_MODEL = "some/unreleased-model";
    expect(() => validateConfiguredModels(() => {})).not.toThrow();
  });

  it("also covers the non-default models, not just OPENROUTER_MODEL", () => {
    delete process.env.OPENROUTER_MODEL;
    // Every model this app calls must be registered — a call routed to an
    // unknown model degrades exactly the same way as an unknown default.
    const models = [...configuredModels().keys()];
    // Guard the guard: an empty map would make the loop below vacuous. The
    // default and the retrieval model are two distinct entries, always.
    expect(models.length).toBeGreaterThanOrEqual(2);
    for (const model of models) {
      expect(MODEL_REGISTRY[model], model).toBeDefined();
    }
    expect(validateConfiguredModels(() => {})).toEqual([]);
  });
});

/**
 * #47, re-aimed by #52. secondary_data is presented to the user as research,
 * and its output is handed to the post prompts as fact. On a single-model
 * pipeline it had no search behind it, so it invented a "studies show…" claim
 * that a published post repeated. #47 wired the search capability in by routing
 * the whole step to Sonar; #52 kept the capability and moved it to a dedicated
 * RETRIEVAL call, because Sonar's prose mangles every non-ASCII letter and the
 * app's main market writes Turkish.
 *
 * So the guarantee under test changed shape: it is no longer "the step runs on
 * a search model" but "a search model is still what does the searching, and it
 * is still never sonar-pro".
 */
describe("the research step still has a search-backed model behind it", () => {
  const original = process.env.OPENROUTER_MODEL;

  afterEach(() => {
    if (original === undefined) delete process.env.OPENROUTER_MODEL;
    else process.env.OPENROUTER_MODEL = original;
  });

  it("retrieves with perplexity/sonar-reasoning-pro", () => {
    expect(RESEARCH_MODEL).toBe("perplexity/sonar-reasoning-pro");
    expect(configuredModels().get("perplexity/sonar-reasoning-pro")).toContain(
      "RESEARCH_MODEL (secondary_data retrieval)",
    );
  });

  // The WRITING call is the one that changed hands (#52): the entries are
  // written by the model that spells the project's language correctly, which
  // is the same one the other seven steps use.
  it("writes the entries with the default model, not the search model", () => {
    delete process.env.OPENROUTER_MODEL;
    expect(resolveModel("secondary_data")).toBe("anthropic/claude-sonnet-5");
    expect(resolveModel("secondary_data")).not.toBe(RESEARCH_MODEL);
  });

  // Never sonar-pro: the account's "no training on request data" guardrail
  // filters out every endpoint serving it and the request 404s. The guardrail
  // protects client brand documents and is not the thing to relax.
  //
  // Asserted over configuredModels(), NOT over STEP_MODEL_OVERRIDES: that map
  // is empty since #52, so the old assertion would have passed vacuously while
  // the retrieval model it was written to police moved out from under it.
  it("never routes to the guardrail-blocked sonar-pro", () => {
    expect([...configuredModels().keys()]).not.toContain("perplexity/sonar-pro");
  });

  // Retrieval is a capability requirement, not an operator preference —
  // OPENROUTER_MODEL must not silently take search away again, which is
  // precisely how the capability was lost the first time.
  it("keeps retrieval on a search model even when OPENROUTER_MODEL is set", () => {
    process.env.OPENROUTER_MODEL = "anthropic/claude-3.5-sonnet";
    expect(configuredModels().get(RESEARCH_MODEL)).toContain(
      "RESEARCH_MODEL (secondary_data retrieval)",
    );
    expect(resolveModel("sm_posts")).toBe("anthropic/claude-3.5-sonnet");
  });

  // Registered, so maxOutputFor would not warn if anything asked it for a
  // ceiling. Nothing does today; the registration also keeps the boot banner
  // quiet, which is what actually reports an unregistered model now.
  it("is registered, so the step does not run under the unregistered warning", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    expect(maxOutputFor("perplexity/sonar")).toBe(
      MODEL_REGISTRY["perplexity/sonar"].maxOutput,
    );
    expect(maxOutputFor("perplexity/sonar")).not.toBe(
      UNREGISTERED_MODEL_MAX_OUTPUT,
    );
    expect(warn).not.toHaveBeenCalled();
    warn.mockRestore();
  });
});
