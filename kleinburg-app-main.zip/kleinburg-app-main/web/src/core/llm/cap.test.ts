import { describe, expect, it } from "vitest";

import {
  CAP_WARNING_RATIO,
  MAX_PLAUSIBLE_RATE_USD_PER_TOKEN,
  MIN_RATE_EVIDENCE_TOKENS,
  SPEND_MONTH_TIMEZONE,
  describeRefusal,
  estimateUnpricedUsd,
  formatMonthReset,
  parseCap,
  refusesGeneration,
  spendMonthOf,
  warnsAboutSpend,
  type BrandCapStatus,
} from "./cap";
import type { ModelSpend } from "./spend";

/**
 * The PURE half of the monthly cap (T51): which instants bound a month, what
 * an unpriced call is charged, and what a refused operator reads.
 *
 * These need no database on purpose. The month boundary and the imputation of
 * unpriced calls are the two pieces of this feature most likely to be quietly
 * wrong, and both are arithmetic — pinning them through Postgres would make
 * them slower to run and harder to read without making them better tested.
 *
 * NOTHING HERE READS THE CLOCK. Every function under test takes its instant as
 * an argument, so a suite that happens to run at 00:30 on the 1st behaves
 * exactly like one that runs at noon on the 12th.
 */

/** A `ModelSpend` row with only the fields the estimator looks at. */
function modelRow(over: Partial<ModelSpend> & { model: string }): ModelSpend {
  return {
    model: over.model,
    costUsd: over.costUsd ?? 0,
    callCount: over.callCount ?? 0,
    pricedCallCount: over.pricedCallCount ?? 0,
    unpricedCallCount: over.unpricedCallCount ?? 0,
    promptTokens: over.promptTokens ?? 0,
    completionTokens: over.completionTokens ?? 0,
    unpricedPromptTokens: over.unpricedPromptTokens ?? 0,
    unpricedCompletionTokens: over.unpricedCompletionTokens ?? 0,
    complete: over.complete ?? true,
  };
}

describe("llm/cap: the month window", () => {
  it("draws the boundary on the OPERATOR'S calendar, not UTC", () => {
    // 31 July 2026, 22:00 UTC. In Istanbul (UTC+3) that is already 01:00 on
    // 1 August, so this instant belongs to AUGUST.
    //
    // This is the fixture the whole timezone decision rests on: it is inside
    // the three-hour window where UTC and Istanbul disagree about the month,
    // which is the only window where a UTC implementation and this one give
    // different answers. A fixture at noon would pass under either and would
    // therefore prove nothing.
    const month = spendMonthOf(new Date("2026-07-31T22:00:00.000Z"));

    expect(month.year).toBe(2026);
    expect(month.month).toBe(8);
    // Local midnight on 1 August in Istanbul = 21:00 UTC on 31 July.
    expect(month.since.toISOString()).toBe("2026-07-31T21:00:00.000Z");
    expect(month.until.toISOString()).toBe("2026-08-31T21:00:00.000Z");
  });

  it("puts the last instant before local midnight in the OLD month", () => {
    // One millisecond earlier than the previous test's instant boundary.
    const month = spendMonthOf(new Date("2026-07-31T20:59:59.999Z"));
    expect(month.month).toBe(7);
    expect(month.since.toISOString()).toBe("2026-06-30T21:00:00.000Z");
  });

  it("tiles the timeline: one month's `until` is the next month's `since`", () => {
    // The half-open window is what stops a call landing exactly on the
    // boundary from being counted in both months or in neither.
    const july = spendMonthOf(new Date("2026-07-15T09:00:00.000Z"));
    const august = spendMonthOf(july.until);

    expect(august.month).toBe(8);
    expect(august.since.getTime()).toBe(july.until.getTime());
  });

  it("rolls December into the following January", () => {
    const december = spendMonthOf(new Date("2026-12-20T12:00:00.000Z"));
    expect(december.month).toBe(12);
    const next = spendMonthOf(december.until);
    expect(next.year).toBe(2027);
    expect(next.month).toBe(1);
  });

  it("names the reset date in the same zone the boundary was drawn in", () => {
    // `until` is 21:00 UTC on 31 August — which in Istanbul is 1 September.
    // If this ever prints "31 Ağustos" the message is telling the operator a
    // date one day before the cap actually resets, which is the exact
    // confusion the local-calendar decision exists to prevent.
    const month = spendMonthOf(new Date("2026-08-15T12:00:00.000Z"));
    expect(formatMonthReset(month.until)).toBe("1 Eylül 2026");
  });

  it("uses Istanbul, stated once, so the decision has one home", () => {
    expect(SPEND_MONTH_TIMEZONE).toBe("Europe/Istanbul");
  });
});

describe("llm/cap: pricing the calls OpenRouter did not price", () => {
  it("charges an unpriced call at its own model's observed rate", () => {
    // 1,000,000 priced tokens cost $2 -> $0.000002/token. 500,000 unpriced
    // tokens must therefore be charged $1, NOT $0.
    //
    // Token counts are at the magnitude a real wizard step burns, not the
    // toy 1000 this fixture used to carry. That mattered once the estimator
    // grew an evidence floor and an absurdity ceiling: at 1000 tokens for $2
    // the fixture implied $0.002/token, twenty-six times the dearest rate on
    // the market, so it would have been exercising the clamp rather than the
    // fallback it is named after.
    const window = [
      modelRow({
        model: "anthropic/claude-sonnet-5",
        costUsd: 2,
        promptTokens: 1_000_000,
        completionTokens: 500_000,
        unpricedPromptTokens: 300_000,
        unpricedCompletionTokens: 200_000,
      }),
    ];
    // priced tokens = 1,500,000 - 500,000 = 1,000,000; unpriced = 500,000.
    const { usd, unmeasurable } = estimateUnpricedUsd(window, []);
    expect(usd).toBeCloseTo(1, 9);
    expect(unmeasurable).toBe(false);
  });

  it("NEVER treats an unpriced call as free", () => {
    // The single assertion this whole module exists for. A zero here is the
    // silent overspend #51 item 2 forbids.
    const window = [
      modelRow({
        model: "m",
        costUsd: 5,
        promptTokens: 2000,
        completionTokens: 0,
        unpricedPromptTokens: 1000,
      }),
    ];
    const { usd } = estimateUnpricedUsd(window, []);
    expect(usd).toBeGreaterThan(0);
  });

  it("prices each model at ITS OWN rate, not a blend of all of them", () => {
    // Sonnet at $0.01/token and a cheap model at $0.0001/token, with the
    // unpriced tokens ALL on the cheap model. A single blended rate would
    // charge them at roughly the average and come out ~50x too high, so the
    // two rates are deliberately orders of magnitude apart: a per-model
    // implementation and a blended one cannot both satisfy this.
    const window = [
      modelRow({
        model: "expensive",
        costUsd: 10,
        promptTokens: 1000,
        completionTokens: 0,
      }),
      modelRow({
        model: "cheap",
        costUsd: 0.1,
        promptTokens: 2000,
        completionTokens: 0,
        unpricedPromptTokens: 1000,
      }),
    ];
    // cheap: priced tokens 1000, cost 0.1 -> 0.0001/token. 1000 unpriced = $0.10.
    const { usd } = estimateUnpricedUsd(window, []);
    expect(usd).toBeCloseTo(0.1, 9);
  });

  it("falls back to the brand's history when this month priced nothing", () => {
    // Every call of this model this month was unpriced, so the window carries
    // no rate at all. The brand's own history does.
    const window = [
      modelRow({
        model: "m",
        costUsd: 0,
        promptTokens: 1_000_000,
        completionTokens: 0,
        unpricedPromptTokens: 1_000_000,
      }),
    ];
    const history = [
      modelRow({
        model: "m",
        costUsd: 4,
        promptTokens: 1_000_000,
        completionTokens: 0,
      }),
    ];
    // history rate = 4 / 1,000,000 = $0.000004/token; 1,000,000 unpriced -> $4.
    const { usd, unmeasurable } = estimateUnpricedUsd(window, history);
    expect(usd).toBeCloseTo(4, 9);
    expect(unmeasurable).toBe(false);
  });

  it("falls back to the brand's dearest observed rate for a never-priced MODEL", () => {
    // A model this brand has never been quoted a price for at all. The brand
    // has been quoted prices for a DIFFERENT model, so a rate exists.
    const window = [
      modelRow({
        model: "brand-new-model",
        costUsd: 0,
        promptTokens: 500_000,
        completionTokens: 0,
        unpricedPromptTokens: 500_000,
      }),
    ];
    const history = [
      modelRow({
        model: "some-other-model",
        costUsd: 3,
        promptTokens: 1_000_000,
        completionTokens: 500_000,
      }),
    ];
    // the one observed rate: 3 / 1,500,000 = $0.000002/token; 500,000 -> $1.
    const { usd, unmeasurable } = estimateUnpricedUsd(window, history);
    expect(usd).toBeCloseTo(1, 9);
    expect(unmeasurable).toBe(false);
  });

  it("reports UNMEASURABLE rather than guessing when no price was ever seen", () => {
    // Unpriced calls exist and the brand has never had a single priced call.
    // Nothing can be estimated, so nothing is: the caller fails closed.
    const window = [
      modelRow({
        model: "m",
        costUsd: 0,
        promptTokens: 1000,
        completionTokens: 0,
        unpricedPromptTokens: 1000,
      }),
    ];
    const { usd, unmeasurable } = estimateUnpricedUsd(window, []);
    expect(usd).toBe(0);
    expect(unmeasurable).toBe(true);
  });

  it("is not confused by a priced call that burned no tokens", () => {
    // A zero-token priced row would make cost/tokens divide by zero and yield
    // Infinity, which would then be added to the cap comparison and block a
    // brand forever.
    const window = [
      modelRow({
        model: "m",
        costUsd: 1,
        promptTokens: 400,
        completionTokens: 0,
        unpricedPromptTokens: 400,
      }),
    ];
    const { usd, unmeasurable } = estimateUnpricedUsd(window, []);
    expect(Number.isFinite(usd)).toBe(true);
    // No priced tokens at all in this row, and no history -> unmeasurable.
    expect(unmeasurable).toBe(true);
  });

  it("charges nothing when every call was priced", () => {
    const window = [
      modelRow({
        model: "m",
        costUsd: 7,
        promptTokens: 1000,
        completionTokens: 1000,
      }),
    ];
    expect(estimateUnpricedUsd(window, [])).toEqual({
      usd: 0,
      unmeasurable: false,
      unpriceableTokens: 0,
      unpriceableCeilingUsd: 0,
    });
  });
});

/* ── The two bounds the imputation actually has (#51 review, 1 and 2) ────── */

describe("llm/cap: the last-resort rate cannot under-price by an order of magnitude", () => {
  it("uses the brand's HIGHEST observed model rate, not its blend", () => {
    // THE FIXTURE FINDING 1 WAS REPRODUCED WITH, arranged so the two
    // implementations land in DIFFERENT STATES rather than merely different
    // numbers.
    //
    // History: a cheap model with a huge token count, and a dearer one with a
    // small count. A token-weighted BLEND is dragged almost all the way down
    // to the cheap rate, because the cheap model dominates the denominator —
    // which is exactly the "average of Sonnet and Perplexity" the module
    // header rejects, arriving through the back door.
    //
    //   cheap: 1,000,000 priced tokens, $1.00   -> $0.000001/token
    //   dear:    100,000 priced tokens, $1.20   -> $0.000012/token
    //   blended = 2.20 / 1,100,000              -> $0.000002/token
    //   highest                                 -> $0.000012/token
    //
    // 50,000 unpriced tokens of a model never priced at all:
    //   blended -> $0.10   (and $49.50 + $0.10 = $49.60, UNDER a $50 cap)
    //   highest -> $0.60   (and $49.50 + $0.60 = $50.10, OVER it)
    //
    // A blend under-prices by 6x here and by 12.6x in the reviewer's own
    // fixture. There is no reading of these numbers under which both
    // implementations agree.
    const window = [
      modelRow({
        model: "never-priced-model",
        costUsd: 0,
        promptTokens: 50_000,
        completionTokens: 0,
        unpricedPromptTokens: 50_000,
      }),
    ];
    const history = [
      modelRow({
        model: "perplexity/sonar",
        costUsd: 1,
        promptTokens: 1_000_000,
        completionTokens: 0,
      }),
      modelRow({
        model: "anthropic/claude-sonnet-5",
        costUsd: 1.2,
        promptTokens: 100_000,
        completionTokens: 0,
      }),
    ];

    const { usd, unmeasurable } = estimateUnpricedUsd(window, history);

    expect(usd).toBeCloseTo(0.6, 9);
    expect(unmeasurable).toBe(false);
  });

  it("does not let one cheap model drag an expensive one's own rate down", () => {
    // Fallback 3 only ever applies to a model with no rate of its own. A model
    // that HAS one keeps it, so widening the last resort must not widen this.
    const window = [
      modelRow({
        model: "cheap",
        costUsd: 0,
        promptTokens: 10_000,
        completionTokens: 0,
        unpricedPromptTokens: 10_000,
      }),
    ];
    const history = [
      modelRow({
        model: "cheap",
        costUsd: 0.01,
        promptTokens: 10_000,
        completionTokens: 0,
      }),
      modelRow({ model: "dear", costUsd: 100, promptTokens: 10_000 }),
    ];
    // The model's OWN historical rate is $0.000001/token -> $0.01, not the
    // $100 the highest-rate fallback would have charged.
    expect(estimateUnpricedUsd(window, history).usd).toBeCloseTo(0.01, 9);
  });
});

describe("llm/cap: a derived rate needs evidence before it is trusted", () => {
  it("IGNORES a rate derived from a handful of tokens", () => {
    // THE FIXTURE FINDING 2 WAS REPRODUCED WITH, again as a state change.
    //
    // One priced call of 10 tokens costing $0.30 — a supplier minimum charge,
    // or a numeric(12,6) rounding artifact — implies $0.03/token, which is
    // four hundred times the dearest rate any model on the market charges.
    // Trusting it prices a 50,000-token unpriced call at $1,500 and blocks the
    // brand for the rest of the month on one bad row, with no recourse but
    // raising the cap past a number that is pure noise.
    //
    //   trusting it  -> 50,000 x $0.03      = $1,500.00  -> blocked
    //   ignoring it  -> 50,000 x $0.000001  =     $0.05  -> ok
    const window = [
      modelRow({
        model: "noisy",
        costUsd: 0.3,
        promptTokens: 50_010,
        completionTokens: 0,
        unpricedPromptTokens: 50_000,
      }),
    ];
    const history = [
      modelRow({ model: "solid", costUsd: 1, promptTokens: 1_000_000 }),
    ];

    const { usd } = estimateUnpricedUsd(window, history);

    expect(usd).toBeCloseTo(0.05, 9);
    expect(usd).toBeLessThan(1);
  });

  it("states the evidence floor once, so a test cannot restate it", () => {
    expect(MIN_RATE_EVIDENCE_TOKENS).toBe(1000);
  });

  it("clamps any surviving rate to the absurdity ceiling", () => {
    // Belt and braces: a row with enough tokens to clear the floor can still
    // carry a nonsense cost. $500 for 1,000 tokens is $0.50/token; the ceiling
    // is what stops that reaching the cap comparison as a five-figure sum.
    const window = [
      modelRow({
        model: "m",
        costUsd: 500,
        promptTokens: 2000,
        completionTokens: 0,
        unpricedPromptTokens: 1000,
      }),
    ];
    const { usd } = estimateUnpricedUsd(window, []);
    expect(usd).toBe(1000 * MAX_PLAUSIBLE_RATE_USD_PER_TOKEN);
  });

  it("keeps the ceiling comfortably above every real price", () => {
    // The dearest published output token on the market is around $75 per
    // million, i.e. $0.000075. The ceiling is more than an order of magnitude
    // above that on purpose: it is an absurdity bound, not a price.
    expect(MAX_PLAUSIBLE_RATE_USD_PER_TOKEN).toBeGreaterThan(0.000075 * 10);
  });
});

describe("llm/cap: tokens no rate can price at all", () => {
  it("reports them as a WORST CASE rather than only as a refusal", () => {
    // Finding 4. Unpriceable tokens used to mean "refuse, full stop", which
    // made a brand-wide outage reachable by an ordinary project delete. They
    // are now also bounded, so a brand with room under its cap keeps working.
    const window = [
      modelRow({
        model: "m",
        costUsd: 0,
        promptTokens: 50_000,
        completionTokens: 0,
        unpricedPromptTokens: 50_000,
      }),
    ];

    const estimate = estimateUnpricedUsd(window, []);

    expect(estimate.usd).toBe(0);
    expect(estimate.unmeasurable).toBe(true);
    expect(estimate.unpriceableTokens).toBe(50_000);
    expect(estimate.unpriceableCeilingUsd).toBe(
      50_000 * MAX_PLAUSIBLE_RATE_USD_PER_TOKEN,
    );
  });
});

describe("llm/cap: reading the stored cap", () => {
  it("treats NULL as unlimited and 0 as a real ceiling", () => {
    // These must never collapse into each other: one means "do not measure
    // this brand", the other means "this brand may spend nothing".
    expect(parseCap(null)).toBeNull();
    expect(parseCap(undefined)).toBeNull();
    expect(parseCap("0.00")).toBe(0);
  });

  it("reads the numeric string the driver returns without losing precision", () => {
    expect(parseCap("50.00")).toBe(50);
    expect(parseCap("1234.56")).toBe(1234.56);
  });

  it("THROWS on a corrupt value instead of degrading to unlimited", () => {
    // Quietly reading a broken cap as "no cap" would turn a data problem into
    // unmetered spend — the one outcome this feature exists to prevent.
    expect(() => parseCap("not-a-number")).toThrow();
    expect(() => parseCap("-1")).toThrow();
  });
});

describe("llm/cap: what a refused operator is told", () => {
  const status: BrandCapStatus = {
    brandId: "b",
    brandName: "Kleinburg",
    capUsd: 50,
    month: spendMonthOf(new Date("2026-08-15T12:00:00.000Z")),
    measuredUsd: 41.03,
    estimatedUnpricedUsd: 9.09,
    chargeableUsd: 50.12,
    unpricedCallCount: 3,
    unpriceableTokens: 0,
    worstCaseUsd: 50.12,
    ratio: 50.12 / 50,
    state: "blocked",
  };

  it("names the brand, the cap, the spend and the reset date", () => {
    // #51 item 4, asserted one clause at a time so a message that drops any
    // single fact fails rather than merely reading differently.
    const message = describeRefusal(status);
    expect(message).toContain("Kleinburg");
    expect(message).toContain("$50.00");
    expect(message).toContain("$50.12");
    expect(message).toContain("1 Eylül 2026");
  });

  it("says which part of the spend is measured and which is estimated", () => {
    // "You spent $50.12" and "you spent $41.03 plus about $9.09 we worked out"
    // are different claims, and the operator is owed the second.
    const message = describeRefusal(status);
    expect(message).toContain("$41.03");
    expect(message).toContain("$9.09");
    expect(message).toContain("3");
  });

  it("does not invent an estimate clause when everything was priced", () => {
    const message = describeRefusal({
      ...status,
      measuredUsd: 51,
      estimatedUnpricedUsd: 0,
      chargeableUsd: 51,
      unpricedCallCount: 0,
    });
    expect(message).toContain("$51.00");
    expect(message).not.toContain("tahmin");
  });

  it("explains an UNMEASURABLE refusal as its own thing", () => {
    // A brand blocked because its spend could not be bounded is not a brand
    // that overspent, and telling the operator it hit its cap would be a lie.
    const message = describeRefusal({
      ...status,
      state: "unmeasurable",
      unpriceableTokens: 90_000,
      worstCaseUsd: 90,
    });
    expect(message).toContain("hesaplanamıyor");
    expect(message).toContain("Kleinburg");
    // It must not read as "you hit your cap": the refusal is that even the
    // most generous bound on the unpriceable calls does not fit under it, and
    // the operator is owed that number so the sentence can be argued with.
    expect(message).toContain("$90.00");
    expect(message).toContain("$50.00");
    expect(message).toContain("1 Eylül 2026");
  });
});

describe("llm/cap: which states stop work", () => {
  it("refuses only at the cap and when spend cannot be bounded", () => {
    expect(refusesGeneration("blocked")).toBe(true);
    expect(refusesGeneration("unmeasurable")).toBe(true);
    // The warning WARNS. It must not stop anything: Elif's decision is warn
    // first, then stop, and a warning that blocked would collapse the two.
    expect(refusesGeneration("warning")).toBe(false);
    expect(refusesGeneration("ok")).toBe(false);
    expect(refusesGeneration("unlimited")).toBe(false);
  });

  it("warns from the warning state onwards", () => {
    expect(warnsAboutSpend("warning")).toBe(true);
    expect(warnsAboutSpend("blocked")).toBe(true);
    expect(warnsAboutSpend("ok")).toBe(false);
    expect(warnsAboutSpend("unlimited")).toBe(false);
  });

  it("warns at 80%, which is Elif's number", () => {
    expect(CAP_WARNING_RATIO).toBe(0.8);
  });
});
