import { randomUUID } from "node:crypto";
import { afterAll, describe, expect, it, vi } from "vitest";
import { inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import {
  brands,
  generationJobs,
  llmCalls,
  projects,
  users,
} from "../db/schema";

import { hasDb } from "@/test/db-gate";

/**
 * T50 — the one contract that cannot be observed from the outside: if the
 * crossing cannot be RECORDED, it does not HAPPEN.
 *
 * This lives in its own file because proving it needs the audit writer to
 * fail, and the only honest way to make a healthy Postgres refuse one insert
 * is to mock the writer — which `vi.mock` applies to a whole module graph for
 * a whole file. `admin-spend.test.ts` reads real audit rows, so the two cannot
 * share a file.
 *
 * Why bother at all: this is exactly the kind of guarantee that decays
 * silently. Someone adds a `try/catch` around the audit call "so the page does
 * not 500", the feature keeps working, every other test stays green, and the
 * boundary quietly becomes untraced — which is the one thing Elif's decision
 * was conditional on. The test also pins the ORDERING: it asserts no spend
 * query ran, so an implementation that read the numbers first and audited
 * afterwards fails here even though it would look identical in production
 * until the day the audit table broke.
 */
vi.mock("../audit/service", () => ({
  recordSpendViewAuditEvent: vi.fn(async () => {
    throw new Error("audit table unavailable");
  }),
}));

const readBrandSpendUnscoped = vi.fn();
const readProjectSpendUnscoped = vi.fn();

vi.mock("./spend", async (importOriginal) => {
  const actual = await importOriginal<typeof import("./spend")>();
  return {
    ...actual,
    readBrandSpendUnscoped: (...args: unknown[]) => {
      readBrandSpendUnscoped(...args);
      throw new Error("spend must not be read when the crossing is unrecorded");
    },
    readProjectSpendUnscoped: (...args: unknown[]) => {
      readProjectSpendUnscoped(...args);
      throw new Error("spend must not be read when the crossing is unrecorded");
    },
  };
});

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

afterAll(async () => {
  if (!hasDb) return;
  const db = getDb();
  if (createdBrandIds.length > 0) {
    await db.delete(brands).where(inArray(brands.id, createdBrandIds));
  }
  if (createdUserIds.length > 0) {
    await db.delete(users).where(inArray(users.id, createdUserIds));
  }
  await closeDb();
});

describe.skipIf(!hasDb)("llm/admin-spend fails closed", () => {
  async function fixture() {
    const db = getDb();
    const [admin] = await db
      .insert(users)
      .values({
        username: `t50fc-${randomUUID()}`,
        passwordHash: "x",
        role: "admin",
      })
      .returning();
    createdUserIds.push(admin.id);

    const [brand] = await db
      .insert(brands)
      .values({ name: `t50fc-${randomUUID()}`, isActive: true })
      .returning();
    createdBrandIds.push(brand.id);

    const [project] = await db
      .insert(projects)
      .values({ brandId: brand.id, name: "gizli-proje", createdBy: admin.id })
      .returning();

    const [job] = await db
      .insert(generationJobs)
      .values({
        projectId: project.id,
        step: "brand_context",
        status: "succeeded",
        input: {},
      })
      .returning();
    await db.insert(llmCalls).values({
      jobId: job.id,
      model: "test/model-a",
      promptTokens: 10,
      completionTokens: 5,
      durationMs: 100,
      costUsd: "1.000000",
    });

    return {
      actor: { id: admin.id, role: admin.role, username: admin.username },
      brand,
      project,
    };
  }

  it("refuses the brand view rather than showing unrecorded spend", async () => {
    const { getBrandSpendAsSuperAdmin } = await import("./admin-spend");
    const { actor, brand } = await fixture();

    await expect(
      getBrandSpendAsSuperAdmin(actor, brand.id),
    ).rejects.toThrow("audit table unavailable");

    // The ordering assertion: the numbers were never even fetched.
    expect(readBrandSpendUnscoped).not.toHaveBeenCalled();
  });

  it("refuses the project view rather than showing unrecorded spend", async () => {
    const { getProjectSpendAsSuperAdmin } = await import("./admin-spend");
    const { actor, project } = await fixture();

    await expect(
      getProjectSpendAsSuperAdmin(actor, project.id),
    ).rejects.toThrow("audit table unavailable");

    expect(readProjectSpendUnscoped).not.toHaveBeenCalled();
  });
});
