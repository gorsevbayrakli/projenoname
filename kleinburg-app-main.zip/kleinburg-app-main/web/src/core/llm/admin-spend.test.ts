import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { and, eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import {
  auditEvents,
  brands,
  generationJobs,
  llmCalls,
  projects,
  userBrands,
  users,
  type WorkflowStep,
} from "../db/schema";
import { AccessError } from "../tenancy/errors";
import { getBrandSpend, getProjectSpend } from "./spend";
import {
  getBrandSpendAsSuperAdmin,
  getProjectSpendAsSuperAdmin,
  listAllBrandsForSpendAsSuperAdmin,
} from "./admin-spend";

import { hasDb } from "@/test/db-gate";

/**
 * T50 — the super admin's cross-brand spend view.
 *
 * ── HOW THESE FIXTURES ARE BUILT, AND WHY IT MATTERS ─────────────────────
 * Three agents this session shipped tests that passed against deliberately
 * broken implementations, and the shared cause was a fixture that looked the
 * same whether the code was right or wrong. An isolation test where the
 * "forbidden" brand has no data in it proves nothing: an implementation that
 * leaks everything returns the same empty list as one that leaks nothing.
 *
 * So every brand here carries REAL, DISTINCT, ASSERTED spend, and every
 * assertion is on a value only the correct implementation can produce:
 *  - the foreign brand's project has a name and a cost that are checked by
 *    equality, so "the admin sees it" and "the admin does not" cannot both
 *    pass;
 *  - the member/non-member audit tests are a matched pair over two brands that
 *    differ ONLY in membership, so an implementation that audits always, or
 *    never, fails one of them;
 *  - the coalescing test asserts one row for a repeat AND two rows for a
 *    drill-down, so neither "no coalescing" nor "coalescing too coarsely"
 *    passes.
 */

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

async function makeUser(role: "admin" | "user") {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({ username: `t50-${randomUUID()}`, passwordHash: "x", role })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

async function makeBrand(name?: string) {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: name ?? `t50-brand-${randomUUID()}`, isActive: true })
    .returning();
  createdBrandIds.push(brand.id);
  return brand;
}

async function grant(userId: string, brandId: string) {
  await getDb().insert(userBrands).values({ userId, brandId });
}

async function makeProject(brandId: string, createdBy: string, name?: string) {
  const db = getDb();
  const [project] = await db
    .insert(projects)
    .values({
      brandId,
      name: name ?? `t50-proj-${randomUUID()}`,
      createdBy,
    })
    .returning();
  return project;
}

/** A project with one priced call on it, so every brand has a real number. */
async function makeSpend(
  projectId: string,
  costUsd: number,
  step: WorkflowStep = "brand_context",
  model = "test/model-a",
) {
  const db = getDb();
  const [job] = await db
    .insert(generationJobs)
    .values({ projectId, step, status: "succeeded", input: {} })
    .returning();
  await db.insert(llmCalls).values({
    jobId: job.id,
    model,
    promptTokens: 1000,
    completionTokens: 500,
    durationMs: 100,
    costUsd: String(costUsd),
  });
  return job;
}

/** The audit rows this feature writes, for one admin. */
async function spendViewRows(actorUserId: string) {
  return getDb()
    .select()
    .from(auditEvents)
    .where(
      and(
        eq(auditEvents.action, "spend_view_admin"),
        eq(auditEvents.actorUserId, actorUserId),
      ),
    );
}

beforeAll(() => {
  if (!hasDb) return;
});

afterAll(async () => {
  if (!hasDb) return;
  const db = getDb();
  // Brands cascade to projects -> generation_jobs -> llm_calls, and to
  // user_brands. `audit_events` has NO foreign keys and an append-only
  // trigger, so the rows this suite wrote stay behind on purpose — defeating
  // the trigger to tidy up would be defeating the point of the table.
  if (createdBrandIds.length > 0) {
    await db.delete(brands).where(inArray(brands.id, createdBrandIds));
  }
  if (createdUserIds.length > 0) {
    await db.delete(users).where(inArray(users.id, createdUserIds));
  }
  await closeDb();
});

describe.skipIf(!hasDb)("llm/admin-spend", () => {
  // ── 1. Nothing changed for ordinary users ────────────────────────────

  /**
   * The requirement Elif was most explicit about. The fixture is two brands
   * that BOTH have spend and differ only in membership, so an implementation
   * that widened the ordinary path cannot pass by returning nothing.
   */
  it("an ordinary user still sees only the brands they are a member of", async () => {
    const user = await makeUser("user");
    const mine = await makeBrand();
    const theirs = await makeBrand();
    await grant(user.id, mine.id);

    const myProject = await makeProject(mine.id, user.id, "kampanya-benim");
    await makeSpend(myProject.id, 1.5);
    const theirProject = await makeProject(theirs.id, user.id, "kampanya-onlarin");
    await makeSpend(theirProject.id, 99);

    // Their own brand: real numbers, and ONLY their own project in it.
    const own = await getBrandSpend(user.id, mine.id);
    expect(own.total.costUsd).toBe(1.5);
    expect(own.byProject.map((p) => p.projectName)).toEqual(["kampanya-benim"]);

    // The other brand: refused, at both grains.
    await expect(getBrandSpend(user.id, theirs.id)).rejects.toBeInstanceOf(
      AccessError,
    );
    await expect(
      getProjectSpend(user.id, theirProject.id),
    ).rejects.toBeInstanceOf(AccessError);
  });

  /**
   * The other half of "nothing changed": the admin path itself must be closed
   * to them. If `requireSuperAdmin` were ever dropped from these functions,
   * this is what catches it — and the foreign brand has $99 of spend in it, so
   * a leak is a concrete wrong value rather than an empty result.
   */
  it("an ordinary user cannot reach the admin path, and no audit row is written", async () => {
    const user = await makeUser("user");
    const foreign = await makeBrand();
    const foreignProject = await makeProject(foreign.id, user.id, "gizli-kampanya");
    await makeSpend(foreignProject.id, 99);

    const actor = { id: user.id, role: user.role, username: user.username };

    await expect(
      listAllBrandsForSpendAsSuperAdmin(actor),
    ).rejects.toBeInstanceOf(AccessError);
    await expect(
      getBrandSpendAsSuperAdmin(actor, foreign.id),
    ).rejects.toBeInstanceOf(AccessError);
    await expect(
      getProjectSpendAsSuperAdmin(actor, foreignProject.id),
    ).rejects.toBeInstanceOf(AccessError);

    // A refused attempt is not a crossing, so it leaves no spend_view row.
    expect(await spendViewRows(user.id)).toHaveLength(0);
  });

  it("the refusal carries ADMIN_REQUIRED, not a bare access error", async () => {
    const user = await makeUser("user");
    const foreign = await makeBrand();
    try {
      await getBrandSpendAsSuperAdmin(
        { id: user.id, role: user.role, username: user.username },
        foreign.id,
      );
      throw new Error("expected getBrandSpendAsSuperAdmin to throw");
    } catch (e) {
      expect(e).toBeInstanceOf(AccessError);
      expect((e as AccessError).code).toBe("ADMIN_REQUIRED");
    }
  });

  // ── 2. What the admin now sees ───────────────────────────────────────

  /**
   * Elif chose FULL visibility over the two narrower options, so the assertion
   * is on the project NAME and the exact cost — the things the narrower
   * options would have withheld. A brand-totals-only implementation fails on
   * the name; a redacted-names implementation fails on the same line.
   */
  it("the admin sees a non-member brand's spend, with project names and breakdowns", async () => {
    const admin = await makeUser("admin");
    const owner = await makeUser("user");
    const brand = await makeBrand();
    await grant(owner.id, brand.id);
    const project = await makeProject(brand.id, owner.id, "yaz-kampanyasi-2026");
    await makeSpend(project.id, 2.25, "brand_context", "test/model-a");
    await makeSpend(project.id, 0.75, "sm_pillars", "test/model-b");

    const actor = { id: admin.id, role: admin.role, username: admin.username };

    // The admin holds no user_brands row on this brand...
    await expect(getBrandSpend(admin.id, brand.id)).rejects.toBeInstanceOf(
      AccessError,
    );

    // ...and the admin path still shows everything.
    const spend = await getBrandSpendAsSuperAdmin(actor, brand.id);
    expect(spend.viewerIsMember).toBe(false);
    expect(spend.total.costUsd).toBe(3);
    expect(spend.byProject.map((p) => p.projectName)).toEqual([
      "yaz-kampanyasi-2026",
    ]);
    expect(spend.byModel.map((m) => m.model).sort()).toEqual([
      "test/model-a",
      "test/model-b",
    ]);

    // Drill-down: the step breakdown, which is the deepest grain Elif chose.
    const projectSpend = await getProjectSpendAsSuperAdmin(actor, project.id);
    expect(projectSpend.viewerIsMember).toBe(false);
    expect(projectSpend.projectName).toBe("yaz-kampanyasi-2026");
    expect(
      projectSpend.byStep.map((s) => [s.step, s.costUsd]),
    ).toEqual([
      ["brand_context", 2.25],
      ["sm_pillars", 0.75],
    ]);
  });

  it("the admin's brand list covers brands they do not belong to, flagged", async () => {
    const admin = await makeUser("admin");
    const mine = await makeBrand();
    const theirs = await makeBrand();
    await grant(admin.id, mine.id);

    const list = await listAllBrandsForSpendAsSuperAdmin({
      id: admin.id,
      role: admin.role,
      username: admin.username,
    });

    const byId = new Map(list.map((b) => [b.id, b]));
    expect(byId.get(mine.id)?.viewerIsMember).toBe(true);
    expect(byId.get(theirs.id)?.viewerIsMember).toBe(false);
  });

  it("a deactivated brand stays closed to the admin spend path", async () => {
    const admin = await makeUser("admin");
    const brand = await makeBrand();
    await getDb()
      .update(brands)
      .set({ isActive: false })
      .where(eq(brands.id, brand.id));

    await expect(
      getBrandSpendAsSuperAdmin(
        { id: admin.id, role: admin.role, username: admin.username },
        brand.id,
      ),
    ).rejects.toBeInstanceOf(AccessError);
  });

  // ── 3. The crossing leaves a trace ───────────────────────────────────

  /**
   * A matched pair: two brands identical but for membership. An
   * implementation that writes a row unconditionally fails the second half;
   * one that never writes fails the first. Neither can be passed by accident.
   */
  it("writes an audit row for a NON-member brand and none for a member brand", async () => {
    const admin = await makeUser("admin");
    const foreign = await makeBrand();
    const mine = await makeBrand();
    await grant(admin.id, mine.id);
    const actor = { id: admin.id, role: admin.role, username: admin.username };

    await getBrandSpendAsSuperAdmin(actor, foreign.id);
    await getBrandSpendAsSuperAdmin(actor, mine.id);

    const rows = await spendViewRows(admin.id);
    expect(rows.map((r) => r.brandId)).toEqual([foreign.id]);

    const [row] = rows;
    expect(row.actorUsername).toBe(admin.username);
    expect(row.brandName).toBe(foreign.name);
    expect(row.projectId).toBeNull();
    expect(row.metadata).toMatchObject({ scope: "brand", viaRole: "admin" });
  });

  it("names the project when the admin drills into one", async () => {
    const admin = await makeUser("admin");
    const owner = await makeUser("user");
    const brand = await makeBrand();
    await grant(owner.id, brand.id);
    const project = await makeProject(brand.id, owner.id, "sonbahar-lansmani");

    await getProjectSpendAsSuperAdmin(
      { id: admin.id, role: admin.role, username: admin.username },
      project.id,
    );

    const [row] = await spendViewRows(admin.id);
    expect(row.projectId).toBe(project.id);
    expect(row.projectName).toBe("sonbahar-lansmani");
    expect(row.metadata).toMatchObject({ scope: "project" });
  });

  /**
   * Coalescing, pinned from BOTH sides. The repeat must collapse (or /activity
   * drowns in page views) and the drill-down must NOT (or the record stops
   * naming which content was exposed, which is the half Elif accepted the risk
   * on). A key of (actor, brand) alone passes the first and fails the second.
   */
  it("collapses a repeated view but keeps a separate row per project", async () => {
    const admin = await makeUser("admin");
    const owner = await makeUser("user");
    const brand = await makeBrand();
    await grant(owner.id, brand.id);
    const projectA = await makeProject(brand.id, owner.id, "proje-a");
    const projectB = await makeProject(brand.id, owner.id, "proje-b");
    const actor = { id: admin.id, role: admin.role, username: admin.username };

    // Four brand-level views in a row: one row.
    await getBrandSpendAsSuperAdmin(actor, brand.id);
    await getBrandSpendAsSuperAdmin(actor, brand.id);
    await getBrandSpendAsSuperAdmin(actor, brand.id);
    await getBrandSpendAsSuperAdmin(actor, brand.id);
    expect(await spendViewRows(admin.id)).toHaveLength(1);

    // Two distinct projects, each viewed twice: two more rows, not four.
    await getProjectSpendAsSuperAdmin(actor, projectA.id);
    await getProjectSpendAsSuperAdmin(actor, projectA.id);
    await getProjectSpendAsSuperAdmin(actor, projectB.id);
    await getProjectSpendAsSuperAdmin(actor, projectB.id);

    const rows = await spendViewRows(admin.id);
    expect(rows).toHaveLength(3);
    expect(
      rows
        .map((r) => r.projectName)
        .sort((a, b) => String(a).localeCompare(String(b))),
    ).toEqual(["proje-a", "proje-b", null].sort((a, b) =>
      String(a).localeCompare(String(b)),
    ));
  });

  // ── 4. The door itself is untouched ──────────────────────────────────

  // The "access.ts still contains zero role exceptions" source scan used to
  // live here. It reads one file off disk and needs no database, so the gate
  // above was silently switching off a structural guard for anyone without
  // Postgres running. It now runs on every invocation from
  // `core/tenancy/access-role-blind.test.ts`.
});
