import { beforeEach, describe, expect, it, vi } from "vitest";
import { z } from "zod";

import { classifyHttpError, LlmPermanentError } from "./errors";
import {
  generateStructured,
  parseCitations,
  type OpenAILike,
} from "./openrouter";
import { recordLlmCall } from "./usage";

// recordLlmCall writes to Postgres; these tests are about WHETHER it is called,
// on which paths, so the write itself is mocked and the file needs no DB gate.
vi.mock("./usage", () => ({ recordLlmCall: vi.fn(async () => {}) }));

const recorded = vi.mocked(recordLlmCall);

// Every test now passes a jobId — an unrecorded billed call is forbidden and
// generateStructured refuses one — so recordLlmCall is reached from every
// describe in this file, and the one test that makes it REJECT would otherwise
// leak that rejection into every test declared after it.
beforeEach(() => {
  recorded.mockReset();
  recorded.mockResolvedValue(undefined);
});

const schema = z.object({ answer: z.number() });
const noopSleep = async () => {};

/** A fake OpenAI-like client whose create() returns a canned response. */
function fakeClient(content: unknown, usage?: unknown): OpenAILike {
  return {
    chat: {
      completions: {
        create: vi.fn(async () => ({
          choices: [{ message: { content: JSON.stringify(content) } }],
          usage: usage ?? null,
        })),
      },
    },
  } as unknown as OpenAILike;
}

/** An error carrying an HTTP status, like the openai SDK's APIError. */
class ApiError extends Error {
  status: number;
  constructor(status: number) {
    super(`status ${status}`);
    this.status = status;
  }
}

describe("classifyHttpError", () => {
  it("treats 429 and 5xx as transient", () => {
    expect(classifyHttpError(429)).toBe("transient");
    expect(classifyHttpError(500)).toBe("transient");
    expect(classifyHttpError(503)).toBe("transient");
  });

  it("treats 4xx client errors as permanent", () => {
    expect(classifyHttpError(400)).toBe("permanent");
    expect(classifyHttpError(401)).toBe("permanent");
    expect(classifyHttpError(403)).toBe("permanent");
    expect(classifyHttpError(404)).toBe("permanent");
  });
});

describe("generateStructured", () => {
  it("returns the zod-validated object for a well-formed response", async () => {
    const client = fakeClient({ answer: 4 });
    const result = await generateStructured({
      prompt: "2+2?",
      schema,
      model: "test/model",
      jobId: "job-test",
      client,
      sleep: noopSleep,
    });
    expect(result).toEqual({ answer: 4 });
  });

  // maxTokens is opt-in: only content_calendar raises it (T26). Every other
  // step must keep the provider default, so the field is OMITTED, not sent as
  // undefined/null.
  it("sends max_tokens only when maxTokens is given", async () => {
    const withLimit = fakeClient({ answer: 4 });
    await generateStructured({
      prompt: "2+2?",
      schema,
      model: "test/model",
      jobId: "job-test",
      maxTokens: 16000,
      client: withLimit,
      sleep: noopSleep,
    });
    const sent = vi.mocked(withLimit.chat.completions.create).mock.calls[0][0];
    expect(sent.max_tokens).toBe(16000);

    const withoutLimit = fakeClient({ answer: 4 });
    await generateStructured({
      prompt: "2+2?",
      schema,
      model: "test/model",
      jobId: "job-test",
      client: withoutLimit,
      sleep: noopSleep,
    });
    const bare = vi.mocked(withoutLimit.chat.completions.create).mock.calls[0][0];
    expect("max_tokens" in bare).toBe(false);
  });

  it("throws LlmPermanentError when output violates the schema", async () => {
    const client = fakeClient({ answer: "not a number" });
    await expect(
      generateStructured({
        prompt: "2+2?",
        schema,
        model: "test/model",
        jobId: "job-test",
        client,
        sleep: noopSleep,
      }),
    ).rejects.toBeInstanceOf(LlmPermanentError);
  });

  // ── TRUNCATION (T38) ──────────────────────────────────────────────────────
  // A max_tokens cut on a json_schema completion returns half-written JSON.
  // Before finish_reason was read, the ONLY symptom was "geçerli JSON değil",
  // which sends the user hunting a malformed-model problem that does not exist.

  /** A client whose completion was cut off by the token ceiling. */
  function truncatedClient(partial: string): OpenAILike {
    return {
      chat: {
        completions: {
          create: vi.fn(async () => ({
            choices: [
              { message: { content: partial }, finish_reason: "length" },
            ],
            usage: null,
          })),
        },
      },
    } as unknown as OpenAILike;
  }

  it("names the TOKEN CEILING, not bad JSON, when finish_reason is 'length'", async () => {
    const create = vi.fn(async () => ({
      choices: [
        { message: { content: '{"answer": 4' }, finish_reason: "length" },
      ],
      usage: null,
    }));
    const client = { chat: { completions: { create } } } as unknown as OpenAILike;

    const err = await generateStructured({
      prompt: "2+2?",
      schema,
      model: "test/model",
      jobId: "job-test",
      maxTokens: 16000,
      client,
      sleep: noopSleep,
    }).then(
      () => null,
      (e: Error) => e,
    );

    expect(err).toBeInstanceOf(LlmPermanentError);
    expect(err!.message).toMatch(/yarıda kesildi/);
    expect(err!.message).toContain("16000 token");
    expect(err!.message).toContain("test/model");
    // The whole point: it must NOT read as a malformed-output failure.
    expect(err!.message).not.toMatch(/geçerli JSON değil/);
    // PERMANENT by the taxonomy: re-sending the same request hits the same
    // ceiling, so there is no retry to make. One call, no loop.
    expect(create).toHaveBeenCalledTimes(1);
  });

  it("reports the provider default when no maxTokens was requested", async () => {
    const err = await generateStructured({
      prompt: "2+2?",
      schema,
      model: "test/model",
      jobId: "job-test",
      client: truncatedClient('{"answer": 4'),
      sleep: noopSleep,
    }).then(
      () => null,
      (e: Error) => e,
    );

    expect(err!.message).toContain("sağlayıcı varsayılanı");
  });

  // The check fires even when the cut happens to land on parseable JSON: the
  // content is still short of what was asked for, so trusting it would persist
  // a partial result as a success (hard rule: no partial saves).
  it("fires even when the truncated content still parses and validates", async () => {
    const err = await generateStructured({
      prompt: "2+2?",
      schema,
      client: truncatedClient(JSON.stringify({ answer: 4 })),
      model: "test/model",
      jobId: "job-test",
      sleep: noopSleep,
    }).then(
      () => null,
      (e: Error) => e,
    );

    expect(err).toBeInstanceOf(LlmPermanentError);
    expect(err!.message).toMatch(/yarıda kesildi/);
  });

  it("a clean finish_reason ('stop') is untouched", async () => {
    const create = vi.fn(async () => ({
      choices: [
        { message: { content: JSON.stringify({ answer: 4 }) }, finish_reason: "stop" },
      ],
      usage: null,
    }));
    const client = { chat: { completions: { create } } } as unknown as OpenAILike;

    await expect(
      generateStructured({
        prompt: "2+2?",
        schema,
        model: "test/model",
        jobId: "job-test",
        client,
        sleep: noopSleep,
      }),
    ).resolves.toEqual({ answer: 4 });
  });

  it("retries a transient error (429) twice then succeeds (3 calls total)", async () => {
    const create = vi
      .fn()
      .mockRejectedValueOnce(new ApiError(429))
      .mockRejectedValueOnce(new ApiError(429))
      .mockResolvedValueOnce({
        choices: [{ message: { content: JSON.stringify({ answer: 4 }) } }],
        usage: null,
      });
    const client = {
      chat: { completions: { create } },
    } as unknown as OpenAILike;

    const result = await generateStructured({
      prompt: "2+2?",
      schema,
      model: "test/model",
      jobId: "job-test",
      client,
      sleep: noopSleep,
    });
    expect(result).toEqual({ answer: 4 });
    expect(create).toHaveBeenCalledTimes(3);
  });

  it("throws LlmPermanentError immediately on a permanent error (401), no retry", async () => {
    const create = vi.fn().mockRejectedValue(new ApiError(401));
    const client = {
      chat: { completions: { create } },
    } as unknown as OpenAILike;

    await expect(
      generateStructured({
        prompt: "2+2?",
        schema,
        model: "test/model",
        jobId: "job-test",
        client,
        sleep: noopSleep,
      }),
    ).rejects.toBeInstanceOf(LlmPermanentError);
    expect(create).toHaveBeenCalledTimes(1);
  });
});

// ── USAGE RECORDING ON FAILURE PATHS (T39) ───────────────────────────────────
// A response that came back was BILLED, even when nothing usable is in it. Only
// recording on the success path hid precisely the most expensive failures — a
// truncated content_calendar burns the entire completion ceiling — from the
// per-brand / per-project / per-platform spend records the API limits will be
// set from. Every post-response failure path now records, THEN throws.
describe("generateStructured usage recording", () => {
  beforeEach(() => {
    recorded.mockReset();
    recorded.mockResolvedValue(undefined);
  });

  const USAGE = { prompt_tokens: 1200, completion_tokens: 16000, cost: 0.42 };

  /** A client whose completion was cut off by the token ceiling, with usage. */
  function client(
    body: Partial<{ content: string | null; finish_reason: string }>,
    usage: unknown = USAGE,
  ): OpenAILike {
    return {
      chat: {
        completions: {
          create: vi.fn(async () => ({
            choices: [
              {
                message: { content: body.content ?? null },
                finish_reason: body.finish_reason ?? "stop",
              },
            ],
            usage,
          })),
        },
      },
    } as unknown as OpenAILike;
  }

  const run = (c: OpenAILike) =>
    generateStructured({
      prompt: "2+2?",
      schema,
      model: "test/model",
      jobId: "job-1",
      maxTokens: 16000,
      client: c,
      sleep: noopSleep,
    }).then(
      () => null,
      (e: Error) => e,
    );

  // THE ONE THE OWNER ASKED FOR: a truncated calendar is the most expensive
  // single call the pipeline makes, and it used to leave no trace in the spend
  // records at all.
  it("records the spend when the TRUNCATION guard fires", async () => {
    const err = await run(
      client({ content: '{"answer": 4', finish_reason: "length" }),
    );

    // Still fails, and still with the truncation message — recording must not
    // turn a failure into a success (hard rule 5).
    expect(err).toBeInstanceOf(LlmPermanentError);
    expect(err!.message).toMatch(/yarıda kesildi/);

    expect(recorded).toHaveBeenCalledTimes(1);
    expect(recorded.mock.calls[0][0]).toMatchObject({
      jobId: "job-1",
      model: "test/model",
      promptTokens: 1200,
      completionTokens: 16000,
      costUsd: 0.42,
    });
  });

  it("records the spend when the output is not valid JSON", async () => {
    const err = await run(client({ content: "not json at all" }));

    expect(err!.message).toMatch(/geçerli JSON değil/);
    expect(recorded).toHaveBeenCalledTimes(1);
  });

  it("records the spend when the output fails the schema", async () => {
    const err = await run(client({ content: '{"answer": "four"}' }));

    expect(err!.message).toMatch(/beklenen şemaya uymadı/);
    expect(recorded).toHaveBeenCalledTimes(1);
  });

  // The empty-content path got the same treatment: the prompt tokens were sent
  // and billed even though nothing came back.
  it("records the spend when the model returns empty content", async () => {
    const err = await run(client({ content: null }));

    expect(err!.message).toMatch(/boş içerik döndürdü/);
    expect(recorded).toHaveBeenCalledTimes(1);
  });

  it("still records exactly once on the success path", async () => {
    const ok = await generateStructured({
      prompt: "2+2?",
      schema,
      model: "test/model",
      jobId: "job-1",
      client: client({ content: '{"answer": 4}' }),
      sleep: noopSleep,
    });

    expect(ok).toEqual({ answer: 4 });
    expect(recorded).toHaveBeenCalledTimes(1);
  });

  // llm_calls.duration_ms means "how long the model took to answer", and it is
  // the only latency column there is. Timing the whole retry loop folded the
  // failed attempts and the backoff sleeps into it, so every latency reading
  // over that column was really "model speed plus our own retry overhead" with
  // no way to separate the two.
  it("records the answering attempt's duration, not the whole retry sequence", async () => {
    vi.useFakeTimers();
    try {
      const create = vi
        .fn()
        // A slow attempt that fails transiently: 1000ms burned, no answer.
        .mockImplementationOnce(async () => {
          vi.advanceTimersByTime(1000);
          throw new ApiError(429);
        })
        // The attempt that actually answered.
        .mockImplementationOnce(async () => {
          vi.advanceTimersByTime(200);
          return {
            choices: [{ message: { content: JSON.stringify({ answer: 4 }) } }],
            usage: USAGE,
          };
        });

      const ok = await generateStructured({
        prompt: "2+2?",
        schema,
        model: "test/model",
        jobId: "job-1",
        client: { chat: { completions: { create } } } as unknown as OpenAILike,
        // The real backoff, spending the same clock the code reads.
        sleep: async (ms: number) => {
          vi.advanceTimersByTime(ms);
        },
      });

      expect(ok).toEqual({ answer: 4 });
      expect(create).toHaveBeenCalledTimes(2);
      // 200 is the answering attempt alone. 1700 — 1000 failed + 500 backoff +
      // 200 — is what the loop-wide timer used to write.
      expect(recorded.mock.calls[0][0].durationMs).toBe(200);
    } finally {
      vi.useRealTimers();
    }
  });

  // Without a jobId there is no job to attribute the spend to, so there is
  // nothing to write — the failure path must not invent one. `unrecorded` is
  // what makes that case reachable at all now; see the guard test below.
  it("records nothing when recording is opted out of, and still fails", async () => {
    const err = await generateStructured({
      prompt: "2+2?",
      schema,
      model: "test/model",
      unrecorded: true,
      client: client({ content: '{"answer": 4', finish_reason: "length" }),
      sleep: noopSleep,
    }).then(
      () => null,
      (e: Error) => e,
    );

    expect(err).toBeInstanceOf(LlmPermanentError);
    expect(recorded).not.toHaveBeenCalled();
  });

  /**
   * THE GUARD ITSELF (#68). A billed call with no `llm_calls` row is invisible
   * to /spend, which then reports `complete: true` over a total that is missing
   * money. The source scan in every-call-recorded.test.ts could only see the
   * literal call site, so an optional `jobId` forwarded from one level up —
   * which is what runStep did — slipped past it. The refusal therefore lives in
   * the code the forwarded value actually reaches.
   *
   * The assertion that matters is `create` never being called: refusing AFTER
   * the request would still burn the money it exists to account for.
   */
  it.each([
    ["absent", undefined],
    ["empty", ""],
    ["blank", "   "],
  ])("refuses to send the request at all when the jobId is %s", async (
    _name,
    jobId,
  ) => {
    const create = vi.fn();
    const err = await generateStructured({
      prompt: "2+2?",
      schema,
      model: "test/model",
      jobId,
      client: {
        chat: { completions: { create } },
      } as unknown as OpenAILike,
      sleep: noopSleep,
    }).then(
      () => null,
      (e: Error) => e,
    );

    expect(err).toBeInstanceOf(Error);
    expect(err!.message).toMatch(/jobId olmadan/);
    expect(create).not.toHaveBeenCalled();
    expect(recorded).not.toHaveBeenCalled();
  });

  // A failed INSERT must not swallow, and must not mask: the generation failure
  // is the actionable one the worker writes onto the job, so it stays the
  // thrown error and the recording failure is appended to its message.
  it("surfaces BOTH errors when the usage write itself fails", async () => {
    recorded.mockRejectedValue(new Error("connection terminated"));

    const err = await run(
      client({ content: '{"answer": 4', finish_reason: "length" }),
    );

    expect(err).toBeInstanceOf(LlmPermanentError);
    expect(err!.message).toMatch(/yarıda kesildi/);
    expect(err!.message).toContain("connection terminated");
  });
});

/**
 * Citations (#47).
 *
 * secondary_data's retrieval call runs on a search-backed model (#52) and the
 * step shows the user the documents behind each item. Those documents arrive on
 * `choices[0].message.annotations`, which is provider-shaped, optional, and not
 * something a normal (non-search) model sends at all.
 *
 * The claim under test is therefore mostly about ROBUSTNESS: nothing about the
 * annotations may fail a generation that otherwise succeeded, because the
 * completion is already paid for and its content is valid. The one thing that
 * must NOT be quiet is a `url_citation` whose shape we no longer understand —
 * that would empty every source list in the product, and hard rule 5 says a
 * degradation like that gets said out loud.
 */
describe("parseCitations", () => {
  const good = {
    type: "url_citation",
    url_citation: {
      url: "https://pmc.ncbi.nlm.nih.gov/articles/PMC8295993/",
      title: "What Is Commensality? A Critical Discussion of an Expanding Field",
      start_index: 10,
      end_index: 42,
    },
  };

  it("reads url and title off a url_citation annotation", () => {
    expect(parseCitations({ annotations: [good] })).toEqual([
      {
        url: "https://pmc.ncbi.nlm.nih.gov/articles/PMC8295993/",
        title:
          "What Is Commensality? A Critical Discussion of an Expanding Field",
      },
    ]);
  });

  // The overwhelmingly common case: every model without search.
  it("returns nothing when the field is absent, null or the message is not an object", () => {
    expect(parseCitations({ content: "{}" })).toEqual([]);
    expect(parseCitations({ annotations: null })).toEqual([]);
    expect(parseCitations(undefined)).toEqual([]);
    expect(parseCitations("not a message")).toEqual([]);
  });

  /**
   * #47 review. `title: z.string().optional()` accepts an ABSENT title but
   * rejects an explicit `title: null` — and null is how providers most commonly
   * say "no title for this document". safeParse then failed and the whole entry
   * was dropped, URL and all, one line above where a missing title is defaulted
   * to "" anyway. Losing the link to save a label is the wrong trade.
   */
  it("keeps a citation whose title is null, defaulting the label to empty", () => {
    expect(
      parseCitations({
        annotations: [
          { type: "url_citation", url_citation: { url: "https://a.example/x", title: null } },
        ],
      }),
    ).toEqual([{ url: "https://a.example/x", title: "" }]);
  });

  it("keeps a citation with no title field at all", () => {
    expect(
      parseCitations({
        annotations: [
          { type: "url_citation", url_citation: { url: "https://a.example/y" } },
        ],
      }),
    ).toEqual([{ url: "https://a.example/y", title: "" }]);
  });

  it("returns nothing for an empty annotations array", () => {
    expect(parseCitations({ annotations: [] })).toEqual([]);
  });

  it("keeps the good entries when the array also holds junk", () => {
    const citations = parseCitations({
      annotations: [null, 42, "nope", { type: "file_citation" }, good],
    });
    expect(citations).toHaveLength(1);
    expect(citations[0].url).toBe(good.url_citation.url);
  });

  it("defaults a missing title to an empty string rather than dropping the source", () => {
    expect(
      parseCitations({
        annotations: [
          { type: "url_citation", url_citation: { url: "https://example.com" } },
        ],
      }),
    ).toEqual([{ url: "https://example.com", title: "" }]);
  });

  it("collapses the same document cited for several spans", () => {
    expect(
      parseCitations({ annotations: [good, { ...good }] }),
    ).toHaveLength(1);
  });

  // Model-adjacent output reaching an href. Rejected at this boundary, not only
  // at the render site.
  it("drops a citation whose URL is not http(s)", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    expect(
      parseCitations({
        annotations: [
          {
            type: "url_citation",
            url_citation: { url: "javascript:alert(1)", title: "x" },
          },
          { type: "url_citation", url_citation: { url: "/relative", title: "y" } },
        ],
      }),
    ).toEqual([]);
    expect(warn).toHaveBeenCalled();
    warn.mockRestore();
  });

  // The shape-drift case: said out loud, but never thrown.
  it("warns about a malformed url_citation instead of throwing", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    expect(() =>
      parseCitations({
        annotations: [{ type: "url_citation", url_citation: { url: 7 } }, good],
      }),
    ).not.toThrow();
    expect(parseCitations({ annotations: [{ type: "url_citation" }] })).toEqual(
      [],
    );
    expect(warn).toHaveBeenCalled();
    warn.mockRestore();
  });

  it("warns when annotations is present but not an array", () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    expect(parseCitations({ annotations: { url: "https://example.com" } })).toEqual(
      [],
    );
    expect(warn).toHaveBeenCalled();
    warn.mockRestore();
  });
});

describe("generateStructured reports citations", () => {
  function clientWith(message: Record<string, unknown>): OpenAILike {
    return {
      chat: {
        completions: {
          create: vi.fn(async () => ({
            choices: [{ message }],
            usage: null,
          })),
        },
      },
    } as unknown as OpenAILike;
  }

  it("hands the retrieved documents to onCitations on success", async () => {
    const seen: unknown[] = [];
    await generateStructured({
      prompt: "p",
      schema,
      model: "perplexity/sonar",
      jobId: "job-test",
      client: clientWith({
        content: '{"answer": 4}',
        annotations: [
          {
            type: "url_citation",
            url_citation: { url: "https://example.com/a", title: "A" },
          },
        ],
      }),
      sleep: noopSleep,
      onCitations: (c) => seen.push(...c),
    });

    expect(seen).toEqual([{ url: "https://example.com/a", title: "A" }]);
  });

  // "Nothing was retrieved" is a real, reportable answer — it is what makes an
  // all-unsourced run visible instead of looking like a step that was not asked.
  it("reports an empty list when the model returned no annotations", async () => {
    const seen: unknown[] = [];
    await generateStructured({
      prompt: "p",
      schema,
      model: "anthropic/claude-sonnet-5",
      jobId: "job-test",
      client: clientWith({ content: '{"answer": 4}' }),
      sleep: noopSleep,
      onCitations: (c) => seen.push(c),
    });

    expect(seen).toEqual([[]]);
  });

  it("never reports citations for a generation that failed", async () => {
    const onCitations = vi.fn();
    await expect(
      generateStructured({
        prompt: "p",
        schema,
        model: "perplexity/sonar",
        jobId: "job-test",
        client: clientWith({
          content: '{"answer": "not a number"}',
          annotations: [
            {
              type: "url_citation",
              url_citation: { url: "https://example.com/a", title: "A" },
            },
          ],
        }),
        sleep: noopSleep,
        onCitations,
      }),
    ).rejects.toBeInstanceOf(LlmPermanentError);

    expect(onCitations).not.toHaveBeenCalled();
  });

  it("is optional: a caller that does not ask is unaffected", async () => {
    await expect(
      generateStructured({
        prompt: "p",
        schema,
        model: "perplexity/sonar",
        jobId: "job-test",
        client: clientWith({ content: '{"answer": 4}', annotations: "garbage" }),
        sleep: noopSleep,
      }),
    ).resolves.toEqual({ answer: 4 });
  });
});
