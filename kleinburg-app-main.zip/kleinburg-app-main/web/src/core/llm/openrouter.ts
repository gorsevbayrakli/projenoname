import OpenAI from "openai";
import { z } from "zod";
import { zodToJsonSchema } from "zod-to-json-schema";

import { classifyHttpError, LlmPermanentError, LlmTransientError } from "./errors";
import { recordLlmCall } from "./usage";

/**
 * The single OpenRouter LLM client: structured output + usage/cost recording.
 * Framework-neutral (no react/next). All transport lives here; per-step prompts
 * and schemas (T11) and pipeline wiring (T12) live elsewhere.
 */

const OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1";

// ── Citations (#47) ────────────────────────────────────────────────────────
// A search-backed model (perplexity/sonar, which secondary_data's RETRIEVAL
// call runs on — see core/pipeline/run-step.ts runSecondaryData) returns the
// documents it actually retrieved alongside the completion. Those are the only URLs in this system that were RETRIEVED
// rather than WRITTEN, which is what makes them worth threading through: the
// bug this whole change exists to fix was a research-shaped sentence that no
// document stood behind.
//
// OpenRouter puts them on `choices[0].message.annotations`, NOT on a top-level
// `citations` field (measured against the live endpoint on 2026-07-20), shaped:
//   { type: "url_citation", url_citation: { url, title, start_index, end_index } }
//
// This is model-adjacent output, so hard rule 4 applies: it is validated with
// Zod, never sniffed with regex or trusted as-is.

/** One retrieved document behind a generation. */
export interface Citation {
  url: string;
  title: string;
}

/**
 * A URL we are willing to hand to a link. Model-adjacent output reaches an
 * `href`, so the scheme is checked HERE rather than only at the render site —
 * `javascript:` and `data:` URLs are rejected at the boundary, and the UI's own
 * check (components/wizard/source-links.tsx) is defence in depth, not the only
 * gate.
 */
function isSafeHttpUrl(value: string): boolean {
  try {
    const { protocol } = new URL(value);
    return protocol === "http:" || protocol === "https:";
  } catch {
    return false;
  }
}

/**
 * One annotation entry. Everything but `title` must be present and well-formed
 * or the entry is not a citation we can show.
 *
 * `title` is `.nullish()`, not `.optional()`. The difference is load-bearing:
 * `.optional()` accepts an ABSENT title but REJECTS an explicit `title: null`,
 * and null is how providers most commonly express "no title for this document".
 * That rejection failed the whole entry, so a perfectly good URL was dropped —
 * one line below the place where a missing title is defaulted to "" anyway. The
 * cost of a null title is a link labelled with its own URL; the cost of the
 * strictness was losing the source entirely.
 */
const urlCitationSchema = z.object({
  type: z.literal("url_citation"),
  url_citation: z.object({
    url: z.string().refine(isSafeHttpUrl, { message: "url is not http(s)" }),
    title: z.string().nullish(),
  }),
});

/**
 * Read the citations off a completion message.
 *
 * TOLERANT BY DESIGN, and that is not silent error swallowing (hard rule 5).
 * The failure modes here are all "this call produced fewer usable sources than
 * hoped", never "this generation is invalid": most models return no annotations
 * at all, a search model may return an empty array, and an unrecognised
 * annotation type is simply not a URL citation. Throwing on any of those would
 * fail an otherwise good, already-billed generation over metadata.
 *
 * What is NOT swallowed is a shape we expected to understand and could not: a
 * `url_citation` entry that fails the schema is dropped AND warned about, so a
 * provider changing the shape shows up in the logs instead of quietly emptying
 * every source list in the product.
 *
 * Duplicates are collapsed by URL — the same document is commonly cited for
 * several spans of one answer.
 */
export function parseCitations(message: unknown): Citation[] {
  if (!message || typeof message !== "object") return [];
  const raw = (message as { annotations?: unknown }).annotations;
  if (raw === undefined || raw === null) return [];
  if (!Array.isArray(raw)) {
    console.warn(
      "[openrouter] message.annotations was not an array; ignoring citations",
    );
    return [];
  }

  const byUrl = new Map<string, Citation>();
  for (const entry of raw) {
    // Not a url_citation at all (a future annotation type): not our concern.
    if (
      !entry ||
      typeof entry !== "object" ||
      (entry as { type?: unknown }).type !== "url_citation"
    ) {
      continue;
    }
    const parsed = urlCitationSchema.safeParse(entry);
    if (!parsed.success) {
      console.warn(
        `[openrouter] dropping a malformed url_citation annotation: ${parsed.error.issues
          .map((i) => `${i.path.join(".")}: ${i.message}`)
          .join("; ")}`,
      );
      continue;
    }
    const { url, title } = parsed.data.url_citation;
    if (!byUrl.has(url)) byUrl.set(url, { url, title: title ?? "" });
  }
  return [...byUrl.values()];
}

/**
 * The minimal slice of the OpenAI SDK we depend on. Declaring it lets tests
 * inject a fake client with no real SDK / no network.
 */
export interface OpenAILike {
  chat: {
    completions: {
      create(body: {
        model: string;
        messages: Array<{ role: "system" | "user"; content: string }>;
        response_format: unknown;
        max_tokens?: number;
      }): Promise<{
        choices: Array<{
          message: {
            content: string | null;
            /**
             * Retrieved-document citations on a search-backed model. `unknown`
             * on purpose: it is provider output, so it is validated by
             * parseCitations (Zod) rather than trusted through a type.
             */
            annotations?: unknown;
          };
          /**
           * Why the completion stopped. "length" means the token ceiling cut
           * it off; anything else ("stop", absent) means the model finished on
           * its own. Read below — a cut completion must not be reported as
           * malformed JSON.
           */
          finish_reason?: string | null;
        }>;
        usage?: {
          prompt_tokens?: number;
          completion_tokens?: number;
          cost?: number;
          total_cost?: number;
        } | null;
      }>;
    };
  };
}

/** Build a fresh OpenRouter-configured client. Lazy so env is read at call time. */
export function createOpenRouterClient(): OpenAILike {
  const apiKey = process.env.OPENROUTER_API_KEY;
  if (!apiKey) {
    // Fail with a clear, self-explaining error instead of the OpenAI SDK's
    // constructor error (which references OPENAI_API_KEY and is confusing here).
    throw new LlmPermanentError("OPENROUTER_API_KEY tanımlı değil");
  }
  return new OpenAI({
    baseURL: OPENROUTER_BASE_URL,
    apiKey,
  }) as unknown as OpenAILike;
}

let singleton: OpenAILike | null = null;

/** Shared default client (created on first use). */
export function getOpenRouterClient(): OpenAILike {
  if (!singleton) singleton = createOpenRouterClient();
  return singleton;
}

/** Sleep helper; injectable so tests can pass a no-op. */
export type SleepFn = (ms: number) => Promise<void>;
const defaultSleep: SleepFn = (ms) => new Promise((r) => setTimeout(r, ms));

const MAX_ATTEMPTS = 3;
const BACKOFF_MS = [500, 1500];

/**
 * Extract an HTTP status from an unknown thrown error, if it carries one
 * (openai SDK APIError shape). Returns null when there is no numeric status
 * (e.g. a bare network/timeout error).
 */
function statusOf(err: unknown): number | null {
  if (err && typeof err === "object" && "status" in err) {
    const status = (err as { status?: unknown }).status;
    if (typeof status === "number") return status;
  }
  return null;
}

/**
 * Decide whether a thrown API error is transient (retry) or permanent (give up).
 * A status maps via classifyHttpError; a status-less error (network/timeout) is
 * treated as transient.
 */
function isTransient(err: unknown): boolean {
  const status = statusOf(err);
  if (status === null) return true; // network/timeout: retry
  return classifyHttpError(status) === "transient";
}

/**
 * Generate a structured object validated against a zod schema.
 *
 * Retries transient failures (429/5xx/network) up to MAX_ATTEMPTS with
 * exponential backoff; permanent failures (4xx, invalid schema) throw at once.
 * Records usage/cost against `jobId` via recordLlmCall.
 *
 * `jobId` IS REQUIRED AT RUNTIME, and that is enforced here rather than by the
 * type. `llm_calls.job_id` is NOT NULL, so a call without one is billed and
 * writes no ledger row at all — invisible to /spend, which goes on reporting
 * `complete: true` over a total that is missing money. It was optional in the
 * signature once, and it WAS forgotten: cadence.ts shipped that way and was
 * reachable from the UI. The source scan in every-call-recorded.test.ts caught
 * the field's absence at a call site but could not see a caller one level up
 * that forwarded its own optional `jobId` as the shorthand `jobId,`, so the
 * check moved into the code the shorthand actually reaches.
 *
 * The throw happens BEFORE the request, so a forgotten jobId costs nothing.
 *
 * `unrecorded: true` is the one way out, and it exists so the exceptions have
 * to be written down: the probe/smoke scripts under `scripts/` have no job row
 * to attribute spend to, and openrouter.test.ts exercises the no-ledger path
 * deliberately. Anything reachable from the app is not an exception.
 *
 * `maxTokens` caps the completion (OpenRouter `max_tokens`). It is OMITTED from
 * the request when undefined so every step that does not ask for it keeps the
 * provider default unchanged; only long single-string outputs (the content
 * calendar) need to raise it.
 *
 * `onCitations` receives the documents a search-backed model retrieved for this
 * call (#47), once, only on the success path. A CALLBACK rather than a changed
 * return type deliberately: the citations are relevant to exactly one step
 * (secondary_data), and every other caller — and every existing test fake —
 * keeps working untouched by simply not passing it. An empty array is a normal
 * outcome (a model with no search returns no annotations) and is passed through
 * as such, so the caller can tell "nothing was retrieved" from "not asked".
 */
export async function generateStructured<T>(opts: {
  prompt: string;
  schema: z.ZodType<T>;
  model: string;
  jobId?: string;
  /** Opt out of ledger recording. See the note above; not for app code. */
  unrecorded?: boolean;
  system?: string;
  maxTokens?: number;
  onCitations?: (citations: Citation[]) => void;
  client?: OpenAILike;
  sleep?: SleepFn;
}): Promise<T> {
  // Before the client is even resolved: a forgotten jobId must cost nothing.
  if (!opts.unrecorded && !opts.jobId?.trim()) {
    throw new Error(
      "generateStructured jobId olmadan çağrıldı: bu çağrı faturalanır ama " +
        "llm_calls satırı yazılmaz, yani /spend eksik toplamı eksiksiz diye " +
        "raporlar. Gerçekten kayıtsız kalması gerekiyorsa `unrecorded: true` " +
        "geçilmeli (yalnızca scripts/ ve testler için).",
    );
  }

  const client = opts.client ?? getOpenRouterClient();
  const sleep = opts.sleep ?? defaultSleep;

  const jsonSchema = zodToJsonSchema(opts.schema, { target: "jsonSchema7" });
  const response_format = {
    type: "json_schema",
    json_schema: { name: "result", strict: true, schema: jsonSchema },
  };

  const messages: Array<{ role: "system" | "user"; content: string }> = [];
  if (opts.system) messages.push({ role: "system", content: opts.system });
  messages.push({ role: "user", content: opts.prompt });

  let response: Awaited<
    ReturnType<OpenAILike["chat"]["completions"]["create"]>
  > | null = null;

  // Timed PER ATTEMPT, not around the loop. llm_calls.duration_ms is one column
  // and it means "how long the model took to answer"; timing the whole loop put
  // every failed attempt plus the 0.5s and 1.5s backoff sleeps into it, so any
  // latency reading over that column silently mixed model latency with our own
  // retry overhead and there was no second column to tell them apart. Total
  // elapsed time is deliberately NOT recorded instead of overloading this one —
  // adding it means adding a column, which is a schema decision, not a fix.
  let durationMs = 0;

  let lastError: unknown = null;
  for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
    const attemptStart = Date.now();
    try {
      response = await client.chat.completions.create({
        model: opts.model,
        messages,
        response_format,
        ...(opts.maxTokens === undefined ? {} : { max_tokens: opts.maxTokens }),
      });
      durationMs = Date.now() - attemptStart;
      lastError = null;
      break;
    } catch (err) {
      lastError = err;
      if (!isTransient(err)) {
        // Name the model. OpenRouter's routing errors ("no endpoints
        // available…") describe the account's provider rules but never say
        // which model was asked for, so the same message appears whether the
        // model is genuinely blocked or the process is simply still running
        // with a stale OPENROUTER_MODEL. Without this you cannot tell those
        // two apart from the UI.
        throw new LlmPermanentError(
          `OpenRouter isteği kalıcı olarak başarısız oldu (model: ${opts.model}): ${describe(err)}`,
          { cause: err },
        );
      }
      // transient: retry unless this was the last attempt
      if (attempt < MAX_ATTEMPTS - 1) {
        await sleep(BACKOFF_MS[attempt] ?? BACKOFF_MS[BACKOFF_MS.length - 1]);
      }
    }
  }

  if (!response) {
    throw new LlmTransientError(
      `OpenRouter isteği ${MAX_ATTEMPTS} denemeden sonra başarısız oldu: ${describe(lastError)}`,
      { cause: lastError },
    );
  }

  // ── USAGE RECORDING (T39) ────────────────────────────────────────────────
  // A response came back, so the call was BILLED — whether or not we can use
  // what it contains. Recording only on the success path hid exactly the most
  // expensive failures (a truncated calendar burns the full completion ceiling)
  // from the per-brand / per-project / per-platform spend view the usage records
  // exist to provide, which is what the API-level limits will be set from.
  // So every path below that returns after a response records first, then fails.

  const usage = response.usage ?? undefined;
  const cost = usage?.cost ?? usage?.total_cost ?? null;
  const record = async () => {
    if (!opts.jobId) return;
    await recordLlmCall({
      jobId: opts.jobId,
      model: opts.model,
      promptTokens: usage?.prompt_tokens ?? 0,
      completionTokens: usage?.completion_tokens ?? 0,
      costUsd: typeof cost === "number" ? cost : null,
      durationMs,
    });
  };

  /**
   * Record the spend, then throw the generation failure.
   *
   * The recording error is neither swallowed (hard rule 5) nor allowed to
   * REPLACE the generation error: the latter is the actionable one — it is what
   * the worker writes onto the failed job and what the user reads — so a failed
   * insert is appended to its message instead of thrown in its place.
   */
  const recordThenFail = async (error: LlmPermanentError): Promise<never> => {
    try {
      await record();
    } catch (recordErr) {
      throw new LlmPermanentError(
        `${error.message} (ayrıca kullanım kaydı yazılamadı: ${describe(recordErr)})`,
        { cause: error },
      );
    }
    throw error;
  };

  // TRUNCATION, checked BEFORE the JSON parse (T38).
  //
  // When max_tokens cuts a `response_format: json_schema` completion, the
  // content comes back as a half-written JSON string. Without this check the
  // only symptom is "Model çıktısı geçerli JSON değil" — which points the user
  // at a malformed-output problem when the real cause is the token ceiling,
  // and reads identically to a genuinely broken model response.
  //
  // PERMANENT by the taxonomy in errors.ts: a bare retry re-sends the same
  // request with the same ceiling and is cut at the same place, so retrying
  // cannot fix it. The fix is a higher ceiling or a smaller ask, both of which
  // are decisions outside this function. Hence no new retry loop here.
  if (response.choices?.[0]?.finish_reason === "length") {
    const limit =
      opts.maxTokens === undefined
        ? "sağlayıcı varsayılanı"
        : `${opts.maxTokens} token`;
    throw await recordThenFail(
      new LlmPermanentError(
        `Model yanıtı tamamlanma sınırına takıldı ve yarıda kesildi ` +
          `(model: ${opts.model}, sınır: ${limit}). Çıktı bozuk değil, eksik: ` +
          `istenen içerik sınıra sığmıyor. Daha az içerik isteyin veya sınırı yükseltin.`,
      ),
    );
  }

  // Empty content is recorded too, for the same reason as the other three: the
  // prompt tokens were sent and billed even though nothing usable came back.
  const content = response.choices?.[0]?.message?.content;
  if (typeof content !== "string" || content.length === 0) {
    throw await recordThenFail(new LlmPermanentError("Model boş içerik döndürdü"));
  }

  let raw: unknown;
  try {
    raw = JSON.parse(content);
  } catch (err) {
    throw await recordThenFail(
      new LlmPermanentError("Model çıktısı geçerli JSON değil", { cause: err }),
    );
  }

  const parsed = opts.schema.safeParse(raw);
  if (!parsed.success) {
    throw await recordThenFail(
      new LlmPermanentError("Model çıktısı beklenen şemaya uymadı", {
        cause: parsed.error,
      }),
    );
  }

  await record();

  // Citations LAST, and only here: the output is valid, so this is the one path
  // where the caller will actually keep what the model produced. Reporting
  // retrieved sources for a generation that then failed would attach them to
  // content nobody stores.
  opts.onCitations?.(parseCitations(response.choices?.[0]?.message));

  return parsed.data;
}

function describe(err: unknown): string {
  if (err instanceof Error) return err.message;
  return String(err);
}
