import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import {
  brands,
  generationJobs,
  llmCalls,
  projects,
  userBrands,
  users,
  type WorkflowStep,
} from "../db/schema";
import { AccessError } from "../tenancy/errors";
import { getBrandSpend, getProjectSpend } from "./spend";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

async function makeUser() {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({ username: `t42-${randomUUID()}`, passwordHash: "x" })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

async function makeBrand() {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: `brand-${randomUUID()}`, isActive: true })
    .returning();
  createdBrandIds.push(brand.id);
  return brand;
}

async function grant(userId: string, brandId: string) {
  await getDb().insert(userBrands).values({ userId, brandId });
}

async function makeProject(brandId: string, createdBy: string) {
  const db = getDb();
  const [project] = await db
    .insert(projects)
    .values({ brandId, name: `proj-${randomUUID()}`, createdBy })
    .returning();
  return project;
}

async function makeJob(projectId: string, step: WorkflowStep) {
  const db = getDb();
  const [job] = await db
    .insert(generationJobs)
    .values({ projectId, step, status: "succeeded", input: {} })
    .returning();
  return job;
}

/** Record one llm_call. `costUsd: null` = OpenRouter reported no cost. */
async function makeCall(
  jobId: string,
  opts: {
    model: string;
    costUsd: number | null;
    promptTokens?: number;
    completionTokens?: number;
  },
) {
  await getDb()
    .insert(llmCalls)
    .values({
      jobId,
      model: opts.model,
      promptTokens: opts.promptTokens ?? 1000,
      completionTokens: opts.completionTokens ?? 500,
      costUsd: opts.costUsd === null ? null : String(opts.costUsd),
      durationMs: 1234,
    });
}

describe.skipIf(!hasDb)("llm/spend", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      // Cascades to user_brands, projects, generation_jobs, llm_calls.
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  describe("getProjectSpend", () => {
    it("sums reported cost and breaks it down by step and by model", async () => {
      const user = await makeUser();
      const brand = await makeBrand();
      await grant(user.id, brand.id);
      const project = await makeProject(brand.id, user.id);

      // The costs CROSS A DIGIT-COUNT BOUNDARY on purpose. `cost_usd` is
      // numeric, and text ordering puts "9.5" after "12.0" while numeric
      // ordering does the opposite — so a pair like 0.315 / 0.02 would satisfy
      // both the right implementation and the string-sorting wrong one, and a
      // byModel assertion built on it could not fail on the real bug.
      const pillars = await makeJob(project.id, "sm_pillars");
      await makeCall(pillars.id, {
        model: "anthropic/claude-sonnet-5",
        costUsd: 9.5,
      });

      // secondary_data routes to perplexity (#47), so a project spans models.
      const secondary = await makeJob(project.id, "secondary_data");
      await makeCall(secondary.id, {
        model: "perplexity/sonar",
        costUsd: 12,
      });

      const spend = await getProjectSpend(user.id, project.id);

      expect(spend.total.costUsd).toBeCloseTo(21.5, 6);
      expect(spend.total.callCount).toBe(2);
      expect(spend.total.complete).toBe(true);
      expect(spend.total.unpricedCallCount).toBe(0);

      // byStep is ordered by the workflow enum, not by cost.
      expect(spend.byStep).toEqual([
        expect.objectContaining({ step: "secondary_data", costUsd: 12 }),
        expect.objectContaining({ step: "sm_pillars", costUsd: 9.5 }),
      ]);

      // byModel is "most expensive first", NUMERICALLY. As text, "9.5" sorts
      // above "12" and this expectation inverts.
      const models = spend.byModel.map((m) => m.model);
      expect(models).toEqual([
        "perplexity/sonar",
        "anthropic/claude-sonnet-5",
      ]);
    });

    it("does not overflow int on a brand's lifetime token count", async () => {
      // sum(prompt_tokens) over an `integer` column is a bigint in Postgres.
      // Casting it back down to `int` throws a raw "integer out of range" past
      // 2,147,483,647 lifetime tokens and takes the whole /spend page with it,
      // rather than degrading. Two calls are enough to cross it.
      const user = await makeUser();
      const brand = await makeBrand();
      await grant(user.id, brand.id);
      const project = await makeProject(brand.id, user.id);

      const job = await makeJob(project.id, "content_calendar");
      for (let i = 0; i < 2; i++) {
        await makeCall(job.id, {
          model: "anthropic/claude-sonnet-5",
          costUsd: null,
          promptTokens: 2_000_000_000,
          completionTokens: 2_000_000_000,
        });
      }

      const spend = await getProjectSpend(user.id, project.id);

      expect(spend.total.promptTokens).toBe(4_000_000_000);
      expect(spend.total.completionTokens).toBe(4_000_000_000);
      expect(spend.total.unpricedPromptTokens).toBe(4_000_000_000);
      expect(spend.total.unpricedCompletionTokens).toBe(4_000_000_000);

      // And the brand rollup, which is the query that actually 500s the page.
      const brandSpend = await getBrandSpend(user.id, brand.id);
      expect(brandSpend.total.promptTokens).toBe(4_000_000_000);
    });

    it("does NOT silently treat a missing cost as zero", async () => {
      const user = await makeUser();
      const brand = await makeBrand();
      await grant(user.id, brand.id);
      const project = await makeProject(brand.id, user.id);

      const job = await makeJob(project.id, "sm_posts");
      await makeCall(job.id, {
        model: "anthropic/claude-sonnet-5",
        costUsd: 0.319,
      });
      // OpenRouter returned no cost for this one. It still burned tokens.
      await makeCall(job.id, {
        model: "anthropic/claude-sonnet-5",
        costUsd: null,
        promptTokens: 4000,
        completionTokens: 2000,
      });

      const spend = await getProjectSpend(user.id, project.id);

      // The figure is the sum of what IS known...
      expect(spend.total.costUsd).toBeCloseTo(0.319, 6);
      // ...but it must announce itself as a lower bound, not a total.
      expect(spend.total.complete).toBe(false);
      expect(spend.total.callCount).toBe(2);
      expect(spend.total.pricedCallCount).toBe(1);
      expect(spend.total.unpricedCallCount).toBe(1);
      // and the size of the blind spot must be visible in tokens.
      expect(spend.total.unpricedPromptTokens).toBe(4000);
      expect(spend.total.unpricedCompletionTokens).toBe(2000);

      // The incompleteness must propagate to the breakdown rows too, so a
      // per-model row can't look authoritative while the total is hedged.
      expect(spend.byModel).toHaveLength(1);
      expect(spend.byModel[0].complete).toBe(false);
      expect(spend.byModel[0].unpricedCallCount).toBe(1);
      expect(spend.byStep[0].complete).toBe(false);
    });

    it("reports a project with no calls as a complete zero", async () => {
      const user = await makeUser();
      const brand = await makeBrand();
      await grant(user.id, brand.id);
      const project = await makeProject(brand.id, user.id);

      const spend = await getProjectSpend(user.id, project.id);

      expect(spend.total.costUsd).toBe(0);
      expect(spend.total.callCount).toBe(0);
      // Nothing is unknown, because nothing happened.
      expect(spend.total.complete).toBe(true);
      expect(spend.byStep).toEqual([]);
      expect(spend.byModel).toEqual([]);
    });
  });

  describe("getBrandSpend", () => {
    it("rolls up every project in the brand and only that brand", async () => {
      const user = await makeUser();
      const brand = await makeBrand();
      const otherBrand = await makeBrand();
      await grant(user.id, brand.id);
      await grant(user.id, otherBrand.id);

      const p1 = await makeProject(brand.id, user.id);
      const p2 = await makeProject(brand.id, user.id);
      const foreign = await makeProject(otherBrand.id, user.id);

      // p1 is the CHEAPER project but has the longer text representation: as
      // text "9.50" sorts above "12.00", numerically it is the other way
      // round. Elif reads the top of this table to decide where a cap belongs,
      // so the order is the assertion, not an incidental detail.
      await makeCall(
        (await makeJob(p1.id, "sm_pillars")).id,
        { model: "anthropic/claude-sonnet-5", costUsd: 9.5 },
      );
      await makeCall(
        (await makeJob(p2.id, "content_calendar")).id,
        { model: "anthropic/claude-sonnet-5", costUsd: 12 },
      );
      // Must NOT leak into `brand`'s rollup.
      await makeCall(
        (await makeJob(foreign.id, "sm_posts")).id,
        { model: "anthropic/claude-sonnet-5", costUsd: 99 },
      );

      const spend = await getBrandSpend(user.id, brand.id);

      expect(spend.total.costUsd).toBeCloseTo(21.5, 6);
      expect(spend.byProject).toHaveLength(2);
      // Order-preserving, unlike .sort()/.find(): most expensive FIRST.
      expect(spend.byProject.map((p) => p.projectId)).toEqual([p2.id, p1.id]);
      expect(spend.byProject.map((p) => p.costUsd)).toEqual([12, 9.5]);
      expect(spend.byProject.every((p) => p.costUsd !== 99)).toBe(true);
    });

    it("lists a project with no spend at all, so it is not mistaken for missing", async () => {
      const user = await makeUser();
      const brand = await makeBrand();
      await grant(user.id, brand.id);
      const spent = await makeProject(brand.id, user.id);
      const untouched = await makeProject(brand.id, user.id);

      await makeCall((await makeJob(spent.id, "sm_pillars")).id, {
        model: "anthropic/claude-sonnet-5",
        costUsd: 0.1,
      });

      const spend = await getBrandSpend(user.id, brand.id);

      expect(spend.byProject).toHaveLength(2);
      const zero = spend.byProject.find((p) => p.projectId === untouched.id);
      expect(zero).toBeDefined();
      expect(zero!.costUsd).toBe(0);
      expect(zero!.callCount).toBe(0);
    });
  });

  // ── Hard rule 2: brand isolation ─────────────────────────────────────
  // Spend is a scoped read. A cost figure is not campaign copy, but it does
  // reveal that a brand is active and how hard it is being worked, so it goes
  // through the same gate as everything else.
  describe("brand isolation", () => {
    it("refuses project spend to a user with no grant on the brand", async () => {
      const owner = await makeUser();
      const outsider = await makeUser();
      const brand = await makeBrand();
      await grant(owner.id, brand.id);
      const project = await makeProject(brand.id, owner.id);

      await makeCall((await makeJob(project.id, "sm_pillars")).id, {
        model: "anthropic/claude-sonnet-5",
        costUsd: 0.42,
      });

      // The owner can see it.
      await expect(
        getProjectSpend(owner.id, project.id),
      ).resolves.toMatchObject({ total: expect.objectContaining({ costUsd: 0.42 }) });

      // The outsider gets nothing — not a zero, an AccessError.
      await expect(
        getProjectSpend(outsider.id, project.id),
      ).rejects.toBeInstanceOf(AccessError);
    });

    it("refuses brand spend to a user with no grant on the brand", async () => {
      const owner = await makeUser();
      const outsider = await makeUser();
      const brand = await makeBrand();
      await grant(owner.id, brand.id);
      const project = await makeProject(brand.id, owner.id);

      await makeCall((await makeJob(project.id, "sm_posts")).id, {
        model: "anthropic/claude-sonnet-5",
        costUsd: 0.7,
      });

      await expect(getBrandSpend(owner.id, brand.id)).resolves.toMatchObject({
        total: expect.objectContaining({ costUsd: 0.7 }),
      });
      await expect(
        getBrandSpend(outsider.id, brand.id),
      ).rejects.toBeInstanceOf(AccessError);
    });

    it("gives a super admin nothing extra through the MEMBERSHIP-SCOPED readers", async () => {
      // What this proves, exactly: `getBrandSpend` and `getProjectSpend` — the
      // two functions in THIS file — remain role-blind. They go through
      // requireBrandAccess/requireProjectAccess, `access.ts` has no role check
      // anywhere in it, and an admin without a `user_brands` row is refused by
      // them like anyone else.
      //
      // What it does NOT prove, and an earlier version of this comment wrongly
      // claimed: that an admin cannot see this brand's spend. Since #50 they
      // can, through `core/llm/admin-spend.ts` — a separate, audited path,
      // deliberately kept OUT of these functions so that granting a permission
      // over cost did not grant it to every caller of the access gate. This
      // test is what pins that separation down: if the exception ever migrated
      // into the shared readers, this goes red.
      const db = getDb();
      const [admin] = await db
        .insert(users)
        .values({
          username: `t42-admin-${randomUUID()}`,
          passwordHash: "x",
          role: "admin",
        })
        .returning();
      createdUserIds.push(admin.id);

      const owner = await makeUser();
      const brand = await makeBrand();
      await grant(owner.id, brand.id);
      const project = await makeProject(brand.id, owner.id);
      await makeCall((await makeJob(project.id, "sm_pillars")).id, {
        model: "anthropic/claude-sonnet-5",
        costUsd: 1.63,
      });

      await expect(
        getProjectSpend(admin.id, project.id),
      ).rejects.toBeInstanceOf(AccessError);
      await expect(
        getBrandSpend(admin.id, brand.id),
      ).rejects.toBeInstanceOf(AccessError);
    });
  });
});
