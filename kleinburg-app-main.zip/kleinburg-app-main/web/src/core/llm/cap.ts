/**
 * The per-brand monthly spend cap (T51): what has been spent this month, what
 * is permitted, and the refusal that stops new work.
 *
 * ═══ WHAT ELIF DECIDED, AND WHAT FOLLOWS FROM IT ══════════════════════════
 * A cap PER BRAND, PER MONTH. Warn at 80%, refuse at 100%. No default — the
 * column ships null (unlimited) and the super admin sets a number. Work
 * already queued or running is never interrupted; the cap refuses NEW work.
 *
 * Three consequences that shape every function below:
 *
 *  1. THE COUNT COMES FROM #42'S AGGREGATION, not a second one. This module
 *     owns no SQL. It calls `readBrandSpendWindowUnscoped` in `spend.ts`,
 *     which is the /spend page's query with a WHERE clause. If the cap and the
 *     page ever disagreed about what a brand has spent, the cap would be the
 *     one nobody believed.
 *
 *  2. THE CHECK RUNS BEFORE THE JOB ROW EXISTS. It is called from
 *     `enqueueGeneration` (core/jobs/worker.ts), ahead of `createJob`, so a
 *     refusal leaves no job row, no `llm_calls` row and no partial content —
 *     and so no route, present or future, can reach the queue around it. A
 *     disabled button is not a limit; this is.
 *
 *  3. A REFUSAL SAYS WHAT HAPPENED. `SpendCapExceededError` carries the brand,
 *     the cap, what has been spent, how much of that is estimated, and when
 *     the window resets. Hard rule 5 in money form: the operator has to be
 *     able to act on the message without opening a database.
 *
 * ═══ THE CRUX: CALLS WITH NO PRICE ════════════════════════════════════════
 * `llm_calls.cost_usd` is NULLABLE — OpenRouter does not always report a cost.
 * SQL `sum()` skips NULLs, so the obvious query treats an unknown cost as ZERO.
 * For the /spend page #42 handled this by labelling the figure a lower bound
 * ("≥ $X") and showing how many calls were unpriced. A cap cannot do that,
 * because a cap is not read, it is COMPARED — and comparing a lower bound
 * against a ceiling silently permits overspend in exactly the situation where
 * the system has least idea what it is spending. Unknown-as-zero is the one
 * answer that is definitely wrong here.
 *
 * Three options were on the table:
 *
 *   (a) COUNT UNKNOWN AS ZERO. Rejected: it is the silent failure the issue
 *       names, and it fails in the dangerous direction. The worse the pricing
 *       feed gets, the more the cap under-counts, so the control weakens
 *       precisely when the operator's own visibility is worst.
 *
 *   (b) REFUSE WHENEVER ANY CALL IS UNPRICED. Honest, and unusable: one
 *       unpriced call in a month would halt a brand that had spent 3% of its
 *       cap. That converts a supplier's telemetry gap into a production
 *       outage, which is the failure #51 explicitly did not want when it chose
 *       no default cap.
 *
 *   (c) PRICE THE UNKNOWN CALLS FROM WHAT THIS BRAND'S PRICED CALLS ACTUALLY
 *       COST, and count the estimate. Chosen.
 *
 * ── WHY (c) IS NOT A PRICE TABLE ─────────────────────────────────────────
 * `spend.ts` refuses to hardcode prices, and it is right to: a constant written
 * today is already dated (Sonnet 5's promotional pricing ends 31 Aug 2026) and
 * would drift out of agreement with the invoice while still looking
 * authoritative. This module hardcodes nothing. The rate it uses is MEASURED
 * from the same `llm_calls` rows the totals come from — cost actually reported
 * by OpenRouter, divided by tokens actually burned. On 1 September the observed
 * rate rises by itself, on the first priced call at the new price, with no
 * code change and no one remembering to make one.
 *
 * ── HOW THE RATE IS MEASURED, AND WHERE IT IS WRONG ──────────────────────
 * PER MODEL, blended across prompt and completion tokens: for each model,
 * (cost of that model's priced calls) / (tokens those calls burned). An
 * unpriced call is charged its own model's observed rate.
 *
 * Per model matters because the models differ by an order of magnitude, and a
 * single blended rate would price a Sonnet call at the average of Sonnet and
 * Perplexity. Blending prompt and completion within a model is the deliberate
 * imprecision: completion tokens cost roughly 5x prompt tokens, and separating
 * them from a single `cost_usd` column would mean solving for two unknowns per
 * model — real work, to sharpen an estimate that is already only used to
 * decide which side of a threshold something falls on. So a completion-heavy
 * unpriced call is UNDER-estimated and a prompt-heavy one is OVER-estimated,
 * bounded by that ~5x within one model. That is written down rather than
 * smoothed over, and it is the reason the estimate is reported separately from
 * the measurement everywhere it surfaces, never silently added into one figure
 * the operator would read as fact.
 *
 * The fallbacks, in order, and each is narrower than it looks:
 *   1. the model's own priced calls IN THIS WINDOW — the best evidence, and
 *      the only one that reflects a price change mid-month;
 *   2. the model's priced calls in this brand's WHOLE HISTORY — for a model
 *      whose every call this month happened to be unpriced;
 *   3. the HIGHEST rate this brand has been quoted for any model, over its
 *      whole history — for a model this brand has never once been priced for.
 * All three stay inside the brand. There is deliberately no cross-brand
 * fallback: it would be a marginally better estimate bought by making one
 * brand's numbers depend on another's, and hard rule 2 is not worth spending
 * on a rounding aid.
 *
 * ── WHY FALLBACK 3 IS THE HIGHEST RATE AND NOT THE BLENDED ONE ───────────
 * It used to be this brand's token-weighted blended rate, and that quietly
 * reintroduced the very thing the paragraph above rejects: a blend IS "the
 * average of Sonnet and Perplexity", arriving by the back door. Worse, it is a
 * weighted average, so a brand with a million cheap tokens and a handful of
 * dear ones gets a blend within a rounding error of the cheap rate. Measured on
 * a real shape — 1M `perplexity/sonar` prompt tokens at $1, then an unpriced
 * 50k-token Sonnet call — it imputed $0.05 against a true ~$0.63. That is 12.6x
 * UNDER, in the direction that permits work which should have been refused, and
 * it broke the ~5x bound this module claims two paragraphs up.
 *
 * The highest observed rate has no such failure mode in that direction. It
 * over-estimates a model cheaper than the brand's dearest, and over-estimating
 * costs an operator a refusal they can clear by raising the cap; under-
 * estimating costs them money they never agreed to spend, and they find out
 * from an invoice. Between a bounded annoyance and an unbounded bill, a cap
 * picks the annoyance.
 *
 * ── SO, HONESTLY, WHAT ARE THE BOUNDS ────────────────────────────────────
 * Stated per fallback, because they are NOT the same and the old header
 * implied they were:
 *
 *   Fallbacks 1 and 2 (a rate for THIS model): within ~5x either way, from
 *   blending prompt and completion tokens inside one model. Completion-heavy
 *   calls are under-estimated, prompt-heavy ones over-estimated.
 *
 *   Fallback 3 (no rate for this model, ever): at least as large as any rate
 *   this brand has been quoted, so it cannot under-price relative to the
 *   brand's own observed range — but it is NOT an upper bound in the absolute.
 *   A model dearer than everything the brand has ever run, every call of which
 *   was unpriced, is still under-estimated, and by an amount nothing in this
 *   brand's data can bound. That residual is written down rather than papered
 *   over. It requires the pricing feed to have failed for a model the brand has
 *   never once been quoted for, which is a neighbour of the unpriceable case
 *   below rather than an ordinary month.
 *
 * ── A RATE NEEDS EVIDENCE BEFORE IT IS BELIEVED ──────────────────────────
 * `MIN_RATE_EVIDENCE_TOKENS` and `MAX_PLAUSIBLE_RATE_USD_PER_TOKEN`. A rate is
 * a division, and a division by a small denominator is not a measurement. One
 * priced call of 10 tokens costing $0.30 — a supplier minimum charge, or a
 * `numeric(12,6)` artifact — implies $0.03/token, four hundred times the
 * dearest rate on the market. Believed, it prices a 50,000-token unpriced call
 * at $1,500 and blocks the brand for the rest of the month on a single bad row,
 * with no recourse but raising the cap past a number that is pure noise. That
 * REFUSES work that should have run, which is the mirror of the failure above
 * and just as much a bug.
 *
 * So a row's rate counts only once its priced calls have burned at least
 * `MIN_RATE_EVIDENCE_TOKENS`, and whatever survives is clamped to
 * `MAX_PLAUSIBLE_RATE_USD_PER_TOKEN`. An untrusted row does not fail: it falls
 * through to the next fallback, which is what the fallback chain is for.
 *
 * ── AND IF NOTHING CAN BE OBSERVED, IT FAILS CLOSED — BUT BOUNDED ────────
 * If a brand has unpriced calls this month and not one trusted rate in its
 * entire history, no rate exists and those tokens cannot be priced from this
 * brand's data at all.
 *
 * They are not therefore unbounded. They are charged at
 * `MAX_PLAUSIBLE_RATE_USD_PER_TOKEN` — a deliberately absurd worst case, never
 * reported as a cost — and the question becomes whether even THAT fits under
 * the cap. If it does, work continues. If it does not, the state is
 * `unmeasurable` and generation is refused, because a cap that cannot be shown
 * to hold is not a cap.
 *
 * That "if it does, work continues" is load-bearing, and it is the fix for a
 * real outage. `deleteProject` cascades through `generation_jobs` to
 * `llm_calls` and needs only ordinary project membership. A brand with priced
 * calls in project A and unpriced ones in project B loses every priced call it
 * has the moment a member deletes project A — and under the old rule that
 * refused EVERY project in the brand, immediately, clearable only by a super
 * admin. One ordinary user, one ordinary delete, whole-brand outage. Bounding
 * the unpriceable tokens instead means the brand keeps working for as long as
 * the worst case still fits, which for any realistic token volume against any
 * realistic cap is most of the time. See `core/tenancy/projects.ts`.
 *
 * The door stays narrow either way. It cannot fire for a brand with no cap
 * (nothing is evaluated), nor for one whose calls are all priced (the
 * overwhelming normal case), nor for a brand that has never generated anything.
 *
 * ── ONE MORE THING THE CHECK CANNOT DO: BE ATOMIC ────────────────────────
 * The cap is read, and then a job is created. Two requests against two
 * different projects in the same brand can both read the spend under the cap
 * and both enqueue, so a brand can cross its ceiling by one step per concurrent
 * request. That is inherent to check-then-act and it is BOUNDED: a step costs
 * on the order of $0.32, so the overshoot is roughly $0.32 x concurrency, and
 * the next request is refused. It is not fixed with a lock because the honest
 * lock — a per-brand advisory lock held across the check, the job insert and
 * the queue send — would serialise every generation in a brand to buy back a
 * sum smaller than the rounding on the invoice. Written down rather than
 * discovered.
 *
 * ═══ WHICH MONTH, AND WHOSE MIDNIGHT ══════════════════════════════════════
 * See `SPEND_MONTH_TIMEZONE`.
 *
 * ═══ WHAT THIS MODULE DOES NOT DO ═════════════════════════════════════════
 * It does not forecast, it does not stop a running job, and it does not know
 * what anything costs. It answers one question — may a NEW job start — from
 * money already spent.
 */

import { eq } from "drizzle-orm";

import { getDb } from "../db/client";
import { brands, type Brand } from "../db/schema";
import { APP_TIMEZONE } from "../i18n/timezone";
import { ConflictError } from "../tenancy/errors";
import {
  readBrandSpendByModelUnscoped,
  readBrandSpendWindowUnscoped,
  type ModelSpend,
  type SpendWindow,
} from "./spend";

/**
 * The timezone whose calendar decides where one month ends and the next
 * begins.
 *
 * ── THE DECISION ─────────────────────────────────────────────────────────
 * Europe/Istanbul, not UTC. The candidates and the trade:
 *
 *   UTC matches how OpenRouter bills and how `timestamptz` is stored, so a
 *   month boundary drawn here would line up with the invoice to the instant.
 *
 *   Europe/Istanbul matches the calendar of the person the cap is FOR. Turkey
 *   is UTC+3, so a UTC boundary resets a brand's budget at 03:00 local on the
 *   1st. An operator refused at 01:00 on 1 August, reading a message that says
 *   the cap resets in August, would be looking at a bug — and would be right
 *   to. The cap is an operational control read by a human, not a reconciliation
 *   to the cent, and the human's month is the one the message names.
 *
 * So: local calendar wins, and the divergence is stated rather than hidden.
 * Up to three hours of spend at each month boundary is attributed to a
 * different month here than on OpenRouter's invoice. That is real and it is
 * accepted: at ~$1.63 for a full four-platform run, three hours of ordinary
 * activity is not a sum that changes whether a cap was the right number. Do
 * not use these windows to reconcile an invoice line by line; they are not
 * for that.
 *
 * A named IANA zone, resolved through `Intl` at call time, rather than a fixed
 * +03:00 offset: Turkey has been on permanent UTC+3 since 2016, but that is a
 * political decision and not a law of nature, and a hardcoded offset would go
 * quietly wrong the year it changed. The runtime's tz database is the right
 * owner of that fact.
 *
 * One constant, exported, so the boundary is defined in exactly one place and
 * a test can assert on it rather than restate it.
 *
 * Since #58 the value comes from `APP_TIMEZONE`, the single zone the whole
 * application draws its calendar in. The name stays because the cap's reasons
 * are its own — but the cap's reset date is also PRINTED by next-intl, and if
 * the two constants could be edited apart the message would name a different
 * day from the boundary it describes. That is exactly the bug #58 was.
 */
export const SPEND_MONTH_TIMEZONE = APP_TIMEZONE;

/**
 * The fraction of the cap at which the interface starts warning.
 *
 * Elif's number: 80%. The warning exists so that "we are close" is discovered
 * while there is still room to decide something, rather than by a refusal.
 */
export const CAP_WARNING_RATIO = 0.8;

/**
 * How many priced tokens a row must have burned before the rate divided out of
 * it is believed.
 *
 * A rate is `cost / tokens`, and with a tiny denominator that is not a
 * measurement, it is an artifact — a supplier minimum charge, or `numeric(12,6)`
 * rounding, divided by ten tokens. 1000 is chosen because it is well below any
 * real call (a single wizard step burns tens of thousands) and well above the
 * handful-of-tokens rows that produce nonsense, so it excludes the artifacts
 * without excluding evidence. A row under the floor is not an error; it simply
 * does not get a vote, and the next fallback answers instead.
 */
export const MIN_RATE_EVIDENCE_TOKENS = 1000;

/**
 * The most any token is ever assumed to have cost, in USD.
 *
 * ── THIS IS NOT A PRICE TABLE, AND THE DISTINCTION IS THE WHOLE POINT ────
 * `spend.ts` refuses to hardcode prices and this module agrees: a constant
 * written today drifts out of agreement with the invoice while still looking
 * authoritative. That argument is about numbers REPORTED AS COST. This one is
 * never reported as a cost. It is an absurdity bound, used in two places and
 * only ever to answer "could this possibly matter":
 *
 *   1. clamping a derived rate, so a rounding artifact cannot reach the cap
 *      comparison as a five-figure sum;
 *   2. pricing tokens no observed rate can price at all, as a worst case.
 *
 * $0.001/token is $1,000 per million tokens. The dearest published output token
 * on the market is around $75 per million, so this sits more than an order of
 * magnitude clear of every real price — which is what lets it go years without
 * maintenance and makes being wrong about it harmless. If it ever binds on real
 * data, the figure it replaced was noise.
 */
export const MAX_PLAUSIBLE_RATE_USD_PER_TOKEN = 0.001;

/** The calendar month a cap is measured over, as absolute instants. */
export interface SpendMonth extends SpendWindow {
  /** Calendar year in `SPEND_MONTH_TIMEZONE`. */
  year: number;
  /** Calendar month, 1-12, in `SPEND_MONTH_TIMEZONE`. */
  month: number;
}

/**
 * The month containing `now`, as the half-open instant range `[since, until)`.
 *
 * `now` is a REQUIRED argument rather than a default of `new Date()`. That is
 * deliberate: every caller in the request path has a natural instant to pass,
 * and making it explicit is what lets a test pin a month boundary to an exact
 * instant instead of hoping the suite does not run at midnight on the 1st. A
 * default would have made the untestable version the convenient one.
 */
export function spendMonthOf(now: Date): SpendMonth {
  const { year, month } = civilFieldsOf(now);
  return {
    year,
    month,
    since: instantOfLocalMonthStart(year, month),
    // Month 13 rolls to January of the next year; `instantOfLocalMonthStart`
    // normalises it via Date.UTC, which handles the overflow.
    until: instantOfLocalMonthStart(year, month + 1),
  };
}

/** Year and month of an instant, read in `SPEND_MONTH_TIMEZONE`. */
function civilFieldsOf(instant: Date): { year: number; month: number } {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: SPEND_MONTH_TIMEZONE,
    year: "numeric",
    month: "2-digit",
  }).formatToParts(instant);
  const field = (type: string) =>
    Number(parts.find((p) => p.type === type)?.value ?? "0");
  return { year: field("year"), month: field("month") };
}

/**
 * The absolute instant at which local midnight begins on the 1st of the given
 * month.
 *
 * Two passes. The first guesses that local midnight is at the same wall-clock
 * instant as UTC midnight and measures how far off that guess is; the second
 * corrects it. A single pass would be wrong by the offset; the correction is
 * re-measured at the corrected instant so that a zone whose offset changes
 * across the boundary lands on the offset actually in force on the 1st.
 */
function instantOfLocalMonthStart(year: number, month: number): Date {
  const naive = Date.UTC(year, month - 1, 1, 0, 0, 0, 0);
  const firstGuess = naive - offsetMsAt(new Date(naive));
  return new Date(naive - offsetMsAt(new Date(firstGuess)));
}

/** How far ahead of UTC `SPEND_MONTH_TIMEZONE` is at this instant, in ms. */
function offsetMsAt(instant: Date): number {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: SPEND_MONTH_TIMEZONE,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).formatToParts(instant);
  const field = (type: string) =>
    Number(parts.find((p) => p.type === type)?.value ?? "0");
  const asIfUtc = Date.UTC(
    field("year"),
    field("month") - 1,
    field("day"),
    field("hour"),
    field("minute"),
    field("second"),
    instant.getUTCMilliseconds(),
  );
  return asIfUtc - instant.getTime();
}

/** Where a brand stands against its cap right now. */
export type CapState =
  /** No cap set. Nothing is measured and nothing is refused. */
  | "unlimited"
  /** Under the warning threshold. */
  | "ok"
  /** At or over `CAP_WARNING_RATIO` of the cap, but under it. */
  | "warning"
  /** At or over the cap. New generation is refused. */
  | "blocked"
  /** Unpriced calls exist and no rate can be observed. Refused; see above. */
  | "unmeasurable";

/**
 * Everything the UI and the refusal need, computed once.
 *
 * `measuredUsd` and `estimatedUnpricedUsd` are kept APART all the way to the
 * screen, never pre-added into a single number. The operator is entitled to
 * know which part of the figure is a fact and which part is arithmetic, and a
 * combined total would present the estimate with the authority of the
 * measurement. `chargeableUsd` is their sum and is what the cap is compared
 * against — the comparison needs one number, the display does not.
 */
export interface BrandCapStatus {
  brandId: string;
  brandName: string;
  /** null = unlimited. `0` is a real cap meaning "refuse everything". */
  capUsd: number | null;
  month: SpendMonth;
  /** #42's known-cost sum for this window. A fact. */
  measuredUsd: number;
  /** What the unpriced calls in this window most likely cost. An estimate. */
  estimatedUnpricedUsd: number;
  /** `measuredUsd + estimatedUnpricedUsd` — what the cap is compared against. */
  chargeableUsd: number;
  /** How many calls this window contributed the estimate. */
  unpricedCallCount: number;
  /**
   * Tokens this month that NO trusted rate in this brand could price. Usually
   * zero. When it is not, `worstCaseUsd` is what bounds them.
   */
  unpriceableTokens: number;
  /**
   * `chargeableUsd` plus the most the unpriceable tokens could plausibly have
   * cost. Equal to `chargeableUsd` in the normal case. This is what decides
   * `unmeasurable`, and it is deliberately NOT displayed as spend: it is an
   * absurd upper bound, not a figure anyone should read as money owed.
   */
  worstCaseUsd: number;
  /** chargeable / cap, or null when unlimited. Can exceed 1. */
  ratio: number | null;
  state: CapState;
}

/** True when this state refuses new generation. */
export function refusesGeneration(state: CapState): boolean {
  return state === "blocked" || state === "unmeasurable";
}

/** True when the interface should be warning about this state. */
export function warnsAboutSpend(state: CapState): boolean {
  return state === "warning" || refusesGeneration(state);
}

/**
 * A brand's standing against its cap, for the month containing `now`.
 *
 * NO ACCESS CHECK — it takes an already-loaded `Brand`, the same convention
 * and the same warning as the `…Unscoped` readers in `spend.ts`. Callers are
 * `enqueueGeneration` (after `requireProjectAccess` has run in the route) and
 * the /spend page (after its own gate, member or admin).
 *
 * Returns immediately for an uncapped brand WITHOUT querying anything. That is
 * not only a saving: it is the guarantee that shipping this feature changed
 * nothing at all for every brand until someone chooses a number, which is the
 * whole point of there being no default cap.
 */
export async function getBrandCapStatus(
  brand: Pick<Brand, "id" | "name" | "monthlyCapUsd">,
  now: Date,
): Promise<BrandCapStatus> {
  const month = spendMonthOf(now);
  const capUsd = parseCap(brand.monthlyCapUsd);

  if (capUsd === null) {
    return {
      brandId: brand.id,
      brandName: brand.name,
      capUsd: null,
      month,
      measuredUsd: 0,
      estimatedUnpricedUsd: 0,
      chargeableUsd: 0,
      unpricedCallCount: 0,
      unpriceableTokens: 0,
      worstCaseUsd: 0,
      ratio: null,
      state: "unlimited",
    };
  }

  const windowSpend = await readBrandSpendWindowUnscoped(brand.id, month);
  const { total, byModel } = windowSpend;

  // Only pay for the history query when the window cannot answer on its own.
  const needsHistory =
    total.unpricedCallCount > 0 &&
    byModel.some((m) => unpricedTokensOf(m) > 0 && rateOf(m) === null);
  const history = needsHistory
    ? await readBrandSpendByModelUnscoped(brand.id)
    : [];

  const estimate = estimateUnpricedUsd(byModel, history);
  const measuredUsd = round6(total.costUsd);
  const estimatedUnpricedUsd = round6(estimate.usd);
  const chargeableUsd = round6(measuredUsd + estimatedUnpricedUsd);
  const worstCaseUsd = round6(chargeableUsd + estimate.unpriceableCeilingUsd);

  // ORDER MATTERS. `blocked` is checked first because it is established on
  // evidence: a brand actually over its cap is over it, and telling that
  // operator their spend "could not be established" would be the weaker and
  // less true of two available sentences.
  //
  // `unmeasurable` then catches only the case where tokens nothing could price
  // exist AND even their absurd upper bound does not fit under the cap. When it
  // does fit, the brand is simply under its cap and work continues — which is
  // the difference between a supplier's telemetry gap and a brand-wide outage.
  const state: CapState =
    chargeableUsd >= capUsd
      ? "blocked"
      : estimate.unpriceableTokens > 0 && worstCaseUsd >= capUsd
        ? "unmeasurable"
        : capUsd > 0 && chargeableUsd >= capUsd * CAP_WARNING_RATIO
          ? "warning"
          : "ok";

  return {
    brandId: brand.id,
    brandName: brand.name,
    capUsd,
    month,
    measuredUsd,
    estimatedUnpricedUsd,
    chargeableUsd,
    unpricedCallCount: total.unpricedCallCount,
    unpriceableTokens: estimate.unpriceableTokens,
    worstCaseUsd,
    // A cap of 0 has no meaningful ratio; it is `blocked` from the first call
    // and dividing by it would put Infinity in front of a user.
    ratio: capUsd > 0 ? chargeableUsd / capUsd : null,
    state,
  };
}

/**
 * The same thing by brand id, loading the brand row first. NO ACCESS CHECK —
 * the same convention and the same warning as the `…Unscoped` readers in
 * `spend.ts`, and the same exhaustive caller list discipline: today the only
 * caller is the /spend page, which has already gated the brand through either
 * `requireBrandAccess` or the audited admin path before it gets here.
 *
 * A brand that does not exist returns null rather than throwing: the caller is
 * a page that has already resolved the brand and is asking a secondary
 * question, and a race with a brand deletion should not take the page down.
 *
 * ── A CORRUPT CAP RETURNS NULL HERE, AND ONLY HERE ───────────────────────
 * `parseCap` throws on a stored value that is not a usable amount, and it is
 * right to: degrading a broken cap to "unlimited" would turn a data problem
 * into unmetered spend. But that throw used to travel straight up through this
 * function into the /spend page, so one corrupt row took down the whole page —
 * including the tables that had nothing to do with the cap, and including the
 * spend figures the operator would need in order to fix it. The comment two
 * paragraphs up already declines to let a brand deletion do that; this path was
 * quietly doing exactly what it says it does not.
 *
 * So THE READ degrades and THE GATE does not. This function returns null (the
 * page renders without a cap block, as it does for an uncapped brand), while
 * `getBrandCapStatus` — which `assertBrandWithinCap` and therefore
 * `enqueueGeneration` go through — still throws. The corrupt brand cannot
 * generate, which is the fail-closed outcome; it simply does not also lose the
 * ability to look at its own numbers.
 *
 * It is not swallowed (hard rule 5): it is logged, and the fact that the brand
 * cannot generate at all is the loud half of the signal.
 */
export async function readBrandCapStatusUnscoped(
  brandId: string,
  now: Date,
): Promise<BrandCapStatus | null> {
  const [brand] = await getDb()
    .select({
      id: brands.id,
      name: brands.name,
      monthlyCapUsd: brands.monthlyCapUsd,
    })
    .from(brands)
    .where(eq(brands.id, brandId))
    .limit(1);
  if (!brand) return null;
  try {
    return await getBrandCapStatus(brand, now);
  } catch (e) {
    if (!isUnusableCapError(e)) throw e;
    console.error(
      `[cap] brand ${brand.id} has an unusable monthly_cap_usd; ` +
        `/spend renders without the cap block and generation stays refused`,
    );
    return null;
  }
}

/** Marker carried by `parseCap`'s throw, so only IT is degraded above. */
const UNUSABLE_CAP = "KLEINBURG_UNUSABLE_CAP";

function isUnusableCapError(e: unknown): boolean {
  return (
    typeof e === "object" &&
    e !== null &&
    "code" in e &&
    (e as { code?: unknown }).code === UNUSABLE_CAP
  );
}

/**
 * What this window's unpriced calls most likely cost, and whether that could
 * be established at all.
 *
 * Exported for its own tests: this is the arithmetic the whole honesty
 * argument rests on, and it is pure, so it deserves to be pinned directly
 * rather than only through a database.
 */
export function estimateUnpricedUsd(
  windowByModel: readonly ModelSpend[],
  brandHistoryByModel: readonly ModelSpend[],
): UnpricedEstimate {
  const historyRate = new Map<string, number>();
  for (const row of brandHistoryByModel) {
    const rate = rateOf(row);
    if (rate !== null) historyRate.set(row.model, rate);
  }
  const lastResortRate = highestRateOf(brandHistoryByModel);

  let usd = 0;
  let unpriceableTokens = 0;

  for (const row of windowByModel) {
    const tokens = unpricedTokensOf(row);
    if (tokens === 0) continue;

    const rate = rateOf(row) ?? historyRate.get(row.model) ?? lastResortRate;

    if (rate === null) {
      // No trusted price for this model, ever, anywhere in this brand. Nothing
      // is pretended about what these tokens cost — they are counted, and the
      // caller bounds them at the absurdity ceiling. See the header.
      unpriceableTokens += tokens;
      continue;
    }
    usd += rate * tokens;
  }

  return {
    usd,
    unpriceableTokens,
    unpriceableCeilingUsd: unpriceableTokens * MAX_PLAUSIBLE_RATE_USD_PER_TOKEN,
    unmeasurable: unpriceableTokens > 0,
  };
}

/** What this window's unpriced calls cost, and what could not be worked out. */
export interface UnpricedEstimate {
  /** USD imputed from an observed rate. */
  usd: number;
  /** Tokens no trusted rate in this brand could price at all. */
  unpriceableTokens: number;
  /** The most those tokens could plausibly have cost. Never a reported cost. */
  unpriceableCeilingUsd: number;
  /** True iff some tokens could not be priced. Kept as its own word because
   *  it is the condition the refusal message is written about. */
  unmeasurable: boolean;
}

/** Tokens burned by the calls in this row that carried no cost. */
function unpricedTokensOf(row: ModelSpend): number {
  return row.unpricedPromptTokens + row.unpricedCompletionTokens;
}

/**
 * Observed USD per token for the PRICED calls in one row, or null when the row
 * does not carry enough evidence to divide one out.
 *
 * "Enough" is `MIN_RATE_EVIDENCE_TOKENS`, which also disposes of the zero-token
 * priced row that would otherwise divide by zero and yield Infinity. Whatever
 * survives is clamped to `MAX_PLAUSIBLE_RATE_USD_PER_TOKEN`, so a row that
 * clears the floor but still carries a nonsense cost cannot reach the cap
 * comparison intact. Both constants are argued where they are declared.
 */
function rateOf(row: ModelSpend): number | null {
  const pricedTokens =
    row.promptTokens + row.completionTokens - unpricedTokensOf(row);
  if (pricedTokens < MIN_RATE_EVIDENCE_TOKENS) return null;
  const rate = row.costUsd / pricedTokens;
  if (!Number.isFinite(rate) || rate < 0) return null;
  return Math.min(rate, MAX_PLAUSIBLE_RATE_USD_PER_TOKEN);
}

/**
 * The DEAREST rate this brand has been quoted for any one model: the
 * last-resort observation, for a model it has never been quoted for at all.
 *
 * Deliberately the maximum and not the token-weighted blend. The blend is an
 * average over models that differ by an order of magnitude, weighted by volume,
 * so a brand that runs a lot of something cheap gets an average pinned to the
 * cheap rate and under-prices everything else by that same order of magnitude.
 * The full argument, with the measurement, is in the module header.
 */
function highestRateOf(rows: readonly ModelSpend[]): number | null {
  let highest: number | null = null;
  for (const row of rows) {
    const rate = rateOf(row);
    if (rate === null) continue;
    if (highest === null || rate > highest) highest = rate;
  }
  return highest;
}

/**
 * `numeric` arrives from node-postgres as a STRING (it refuses to hand back a
 * float that could have lost precision). null stays null — unlimited.
 *
 * A value that is present but unparseable is a corrupt row, and it throws
 * rather than degrading to "unlimited": quietly treating a broken cap as no
 * cap would turn a data problem into unmetered spend, which is the one outcome
 * this module exists to prevent.
 *
 * The throw carries a `code`, so `readBrandCapStatusUnscoped` can degrade THIS
 * failure without also swallowing a connection error that happened to pass
 * through the same try. A bare `catch` there would have been a wider net than
 * the problem needs.
 */
export function parseCap(raw: string | null | undefined): number | null {
  if (raw === null || raw === undefined) return null;
  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || parsed < 0) {
    throw Object.assign(
      new Error(`brands.monthly_cap_usd is not a usable amount: ${raw}`),
      { code: UNUSABLE_CAP },
    );
  }
  return parsed;
}

/** `cost_usd` is numeric(12,6); round there so float noise never surfaces. */
function round6(value: number): number {
  return Math.round(value * 1e6) / 1e6;
}

/**
 * The refusal (#51 item 4).
 *
 * Carries the numbers rather than only a sentence, so the API layer can render
 * the same facts in the interface language without parsing prose — the same
 * split as every other deliberate error here: a Turkish `message` that is the
 * honest server-side truth and the log line, plus a `code` and structured
 * fields the client maps into its own language.
 *
 * A ConflictError subclass, so `errorResponse` maps it to 409 with its message
 * intact and no route has to learn about it. 409 rather than 403: the caller
 * is entitled to generate, the brand's state is what refuses. And rather than
 * 429: 429 says "you are going too fast, retry", and retrying will not help —
 * nothing changes until a human raises the cap or the month turns over.
 */
export class SpendCapExceededError extends ConflictError {
  readonly status: BrandCapStatus;
  constructor(message: string, status: BrandCapStatus) {
    // TWO STATES, TWO CODES. `blocked` and `unmeasurable` both refuse, but they
    // are not the same claim: one says a brand spent its budget, the other says
    // the supplier's pricing feed failed and the spend cannot be shown to fit.
    // They shared a code once, so a pricing outage told the operator they had
    // hit a cap they might have been nowhere near — a false sentence about a
    // state this module distinguishes carefully everywhere else.
    super(
      message,
      status.state === "unmeasurable"
        ? "SPEND_CAP_UNMEASURABLE"
        : "SPEND_CAP_EXCEEDED",
    );
    this.name = "SpendCapExceededError";
    this.status = status;
  }
}

/**
 * The refusal's facts, flattened for the API error body so the CLIENT can say
 * them in the interface language (#51 review, finding 3).
 *
 * ── WHY THIS EXISTS RATHER THAN THE CLIENT SHOWING `message` ─────────────
 * `describeRefusal` writes the best sentence in this feature and the operator
 * never used to read it: `apiErrorMessage` prefers a code's translation over
 * the server's message, and the translation was "this brand hit its cap, see
 * the Spend page" — all four facts gone, contradicting both this module's
 * "act on the message without opening a database" and #51's item 4.
 *
 * The fix is not to bypass the translation. Turkish text on an English screen
 * would trade one defect for another, and `describeRefusal` still has to exist
 * for the log line and for the honest server-side `message`. Instead the FACTS
 * travel, already formatted as money, and the catalog writes the sentence.
 *
 * Money arrives pre-formatted because `formatUsd` is where "two decimals,
 * because this is money a person reads" is decided, and that decision should
 * not be re-made in two catalogs. The date travels as an ISO instant so each
 * locale can render its own month name; `SPEND_MONTH_TIMEZONE` already decided
 * WHICH instant, which is the part that is not a presentation question.
 */
export function capRefusalDetails(
  status: BrandCapStatus,
): Record<string, string | number> {
  const shared = {
    brand: status.brandName,
    cap: formatUsd(status.capUsd ?? 0),
    resetsAt: status.month.until.toISOString(),
  };

  if (status.state === "unmeasurable") {
    return {
      ...shared,
      worstCase: formatUsd(status.worstCaseUsd),
      unpricedCalls: status.unpricedCallCount,
    };
  }

  return {
    ...shared,
    spent: formatUsd(status.chargeableUsd),
    measured: formatUsd(status.measuredUsd),
    estimated: formatUsd(status.estimatedUnpricedUsd),
    // The count is what the catalog's plural branches on, so a brand with
    // nothing estimated gets a sentence with no estimate clause at all rather
    // than one padded with "$0.00".
    estimatedCalls: status.estimatedUnpricedUsd > 0 ? status.unpricedCallCount : 0,
  };
}

/**
 * The gate. Throws `SpendCapExceededError` if this brand may not start new
 * work; returns the status either way for a caller that wants to log it.
 *
 * WHAT IT DELIBERATELY DOES NOT DO: touch anything already running. #51 item 6
 * — a queued or running job completes. A half-finished run wastes the money it
 * already spent AND the content it did not finish, so killing one to save
 * money saves nothing. The cap is a door, not a switch.
 *
 * The message is Turkish and names all four things the issue asks for: which
 * brand, what the cap is, what has been spent, when it resets. Where part of
 * the spend is estimated it says so in the sentence, because "you have spent
 * $50.12" and "you have spent $41.03 plus about $9.09 we had to work out" are
 * different claims and the operator is owed the second one.
 */
export async function assertBrandWithinCap(
  brand: Pick<Brand, "id" | "name" | "monthlyCapUsd">,
  now: Date,
): Promise<BrandCapStatus> {
  const status = await getBrandCapStatus(brand, now);
  if (!refusesGeneration(status.state)) return status;

  throw new SpendCapExceededError(describeRefusal(status), status);
}

/** The Turkish sentence a refused operator reads in the log and the response. */
export function describeRefusal(status: BrandCapStatus): string {
  const resets = formatMonthReset(status.month.until);

  if (status.state === "unmeasurable") {
    return (
      `"${status.brandName}" markasında bu ay fiyatı bildirilmemiş ` +
      `${status.unpricedCallCount} çağrı var ve harcamanın ne kadar olduğu ` +
      `hesaplanamıyor. En iyimser sınırla bile harcama ` +
      `${formatUsd(status.worstCaseUsd)} olabilir; bu da aylık tavanın ` +
      `(${formatUsd(status.capUsd ?? 0)}) üzerinde olduğu için yeni üretim ` +
      `başlatılmadı. Tavan ${resets} tarihinde sıfırlanır.`
    );
  }

  const spent =
    status.estimatedUnpricedUsd > 0
      ? `${formatUsd(status.chargeableUsd)} ` +
        `(${formatUsd(status.measuredUsd)} ölçülen + ` +
        `${formatUsd(status.estimatedUnpricedUsd)} fiyatı bildirilmemiş ` +
        `${status.unpricedCallCount} çağrı için tahmin)`
      : formatUsd(status.chargeableUsd);

  return (
    `"${status.brandName}" markası bu ayki ` +
    `${formatUsd(status.capUsd ?? 0)} harcama tavanına ulaştı ` +
    `(harcanan: ${spent}). Yeni üretim başlatılmadı. ` +
    `Tavan ${resets} tarihinde sıfırlanır; daha önce devam etmek için ` +
    `süper adminin tavanı yükseltmesi gerekir.`
  );
}

/** `$1.63`. Two decimals: this is money a person reads, not a measurement. */
export function formatUsd(value: number): string {
  return `$${value.toFixed(2)}`;
}

/**
 * The reset date, written in the timezone the boundary was drawn in — so the
 * date in the sentence is the date on the operator's own calendar, which is
 * the entire reason `SPEND_MONTH_TIMEZONE` is not UTC.
 */
export function formatMonthReset(until: Date): string {
  return new Intl.DateTimeFormat("tr-TR", {
    timeZone: SPEND_MONTH_TIMEZONE,
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(until);
}
