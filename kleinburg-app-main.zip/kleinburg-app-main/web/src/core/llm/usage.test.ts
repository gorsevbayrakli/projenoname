import { randomUUID } from "node:crypto";
import { eq, inArray } from "drizzle-orm";
import { afterAll, beforeAll, describe, expect, it } from "vitest";

import { closeDb, getDb } from "../db/client";
import { brands, generationJobs, llmCalls, projects } from "../db/schema";
import { createJob } from "../jobs/jobs";
import { recordLlmCall } from "./usage";

import { hasDb } from "@/test/db-gate";

const createdBrandIds: string[] = [];

async function makeProject() {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: `brand-${randomUUID()}` })
    .returning();
  createdBrandIds.push(brand.id);
  const [project] = await db
    .insert(projects)
    .values({ brandId: brand.id, name: `p-${randomUUID()}` })
    .returning();
  return project;
}

describe.skipIf(!hasDb)("recordLlmCall", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdBrandIds.length > 0) {
      // Cascades through projects -> generation_jobs -> llm_calls.
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("inserts a row with correct token counts and cost", async () => {
    const db = getDb();
    const project = await makeProject();
    const job = await createJob(project.id, "brand_context", {}, null);

    await recordLlmCall({
      jobId: job.id,
      model: "test/model",
      promptTokens: 120,
      completionTokens: 45,
      costUsd: 0.001234,
      durationMs: 987,
    });

    const rows = await db
      .select()
      .from(llmCalls)
      .where(eq(llmCalls.jobId, job.id));
    expect(rows).toHaveLength(1);
    expect(rows[0].model).toBe("test/model");
    expect(rows[0].promptTokens).toBe(120);
    expect(rows[0].completionTokens).toBe(45);
    expect(rows[0].durationMs).toBe(987);
    // numeric is returned as a string by drizzle.
    expect(Number(rows[0].costUsd)).toBeCloseTo(0.001234, 6);
  });

  it("stores a null cost when none is reported", async () => {
    const db = getDb();
    const project = await makeProject();
    const job = await createJob(project.id, "secondary_data", {}, null);

    await recordLlmCall({
      jobId: job.id,
      model: "test/model",
      promptTokens: 10,
      completionTokens: 0,
      costUsd: null,
      durationMs: 50,
    });

    const rows = await db
      .select()
      .from(llmCalls)
      .where(eq(llmCalls.jobId, job.id));
    expect(rows).toHaveLength(1);
    expect(rows[0].costUsd).toBeNull();
  });

  it("cascades: deleting the generation_jobs row removes its llm_calls", async () => {
    const db = getDb();
    const project = await makeProject();
    const job = await createJob(project.id, "user_input", {}, null);
    await recordLlmCall({
      jobId: job.id,
      model: "test/model",
      promptTokens: 1,
      completionTokens: 1,
      costUsd: null,
      durationMs: 1,
    });

    await db.delete(generationJobs).where(eq(generationJobs.id, job.id));

    const rows = await db
      .select()
      .from(llmCalls)
      .where(eq(llmCalls.jobId, job.id));
    expect(rows).toHaveLength(0);
  });
});
