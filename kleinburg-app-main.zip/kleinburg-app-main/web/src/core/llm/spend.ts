import { and, asc, desc, eq, gte, lt, sql } from "drizzle-orm";

import { getDb } from "../db/client";
import {
  generationJobs,
  llmCalls,
  projects,
  type Brand,
  type Project,
  type WorkflowStep,
} from "../db/schema";
import { requireBrandAccess, requireProjectAccess } from "../tenancy/access";

/**
 * Spend aggregation over `llm_calls` (T42).
 *
 * ## Who can read what
 *
 * The two exported gates here — `getBrandSpend` and `getProjectSpend` — are
 * MEMBERSHIP-scoped and contain no role exception. They are what an ordinary
 * user gets, and T50 changed nothing about them.
 *
 * The super admin's cross-brand view lives in `core/llm/admin-spend.ts` and
 * reuses the two `…Unscoped` readers below. It is deliberately a separate
 * module with separate function names: see that file's header for the decision
 * and the reasoning about why the exception is not in `core/tenancy/access.ts`.
 *
 * ## Where the money figure comes from
 *
 * `llm_calls.cost_usd` is the cost **OpenRouter itself reported** for the call.
 * There is deliberately no price table in this codebase and this module does
 * not introduce one: reconstructing cost as tokens x a hardcoded rate would
 * produce a number that drifts out of agreement with the invoice silently and
 * keeps looking authoritative while it does. (Concretely: Sonnet 5's
 * promotional pricing ends 31 Aug 2026, so any constant written today is
 * already dated.) Everything here is historical actual cost. Nothing here
 * forecasts.
 *
 * ## Why every shape carries `complete`
 *
 * `cost_usd` is NULLABLE — not every OpenRouter response reports a cost. SQL
 * `sum()` skips NULLs, so the naive query returns a number that quietly treats
 * unknown costs as zero and understates the bill. That is exactly the silent
 * failure hard rule 5 forbids, in numeric form.
 *
 * So `costUsd` here is only ever **the sum of what is known**, and every
 * summary ships next to it the count of calls whose cost was not reported plus
 * the tokens those calls burned. When `complete` is false the caller must
 * render the figure as a lower bound ("at least $X"), never as a total. The
 * flag is on the breakdown rows too, so a per-model row cannot look certain
 * while the total it belongs to is hedged.
 *
 * ## A known under-report this module cannot see
 *
 * Truncation / JSON-error / schema-error paths used to skip `recordLlmCall`
 * entirely, so failed-but-billed calls left no row at all. Fixed under #39/#46.
 * Rows written before that fix under-report, and no query can detect it after
 * the fact — an absent row is indistinguishable from a call that never
 * happened. It is therefore surfaced as a standing caveat in the UI rather
 * than guessed at here. Pinning a cutoff timestamp in code would be the same
 * stale-constant mistake as a price table.
 *
 * ## Deleting a project deletes its spend
 *
 * `projects` cascades to `generation_jobs`, which cascades to `llm_calls`. So a
 * deleted project takes its real, already-invoiced spend out of the brand total
 * with it, leaving nothing behind for any query here to notice. Every figure
 * this module returns is therefore "spend by the projects that still exist",
 * not "spend ever made against this brand". Surfaced in the UI as a standing
 * caveat and documented at the delete itself (core/tenancy/projects.ts).
 */

/** Sum of what is known, plus the exact size of what is not. */
export interface SpendSummary {
  /**
   * Sum of the costs OpenRouter reported, in USD. A LOWER BOUND, not a total,
   * whenever `complete` is false.
   */
  costUsd: number;
  /** Every recorded call, priced or not. */
  callCount: number;
  /** Calls OpenRouter reported a cost for. */
  pricedCallCount: number;
  /** Calls it did not — these contribute 0 to `costUsd` but were still billed. */
  unpricedCallCount: number;
  promptTokens: number;
  completionTokens: number;
  /** Tokens burned by the unpriced calls: how big the blind spot is. */
  unpricedPromptTokens: number;
  unpricedCompletionTokens: number;
  /** True iff every recorded call carried a cost, i.e. `costUsd` is a total. */
  complete: boolean;
}

export interface StepSpend extends SpendSummary {
  step: WorkflowStep;
}

export interface ModelSpend extends SpendSummary {
  model: string;
}

export interface ProjectSpendRow extends SpendSummary {
  projectId: string;
  projectName: string;
}

export interface ProjectSpend {
  projectId: string;
  projectName: string;
  brandId: string;
  brandName: string;
  total: SpendSummary;
  /** In workflow order (the pgEnum sorts by declaration order in Postgres). */
  byStep: StepSpend[];
  /**
   * Most expensive first. `secondary_data` bills to TWO models (#52): a
   * perplexity/sonar retrieval call and a default-model writing call, so it is
   * the one step that appears under two model names.
   */
  byModel: ModelSpend[];
}

export interface BrandSpend {
  brandId: string;
  brandName: string;
  total: SpendSummary;
  /** Every project in the brand, including ones that have spent nothing. */
  byProject: ProjectSpendRow[];
  byModel: ModelSpend[];
}

/**
 * The aggregate columns, defined once. `count(id)` rather than `count(*)` so a
 * LEFT JOIN that matched no calls counts 0 instead of 1. `sum(cost_usd)` is the
 * known-cost sum only; the `filter`ed sums quantify what it leaves out.
 */
const AGGREGATES = {
  callCount: sql<number>`count(${llmCalls.id})::int`,
  pricedCallCount: sql<number>`count(${llmCalls.costUsd})::int`,
  costUsd: sql<string>`coalesce(sum(${llmCalls.costUsd}), 0)::text`,
  promptTokens: sql<string>`coalesce(sum(${llmCalls.promptTokens}), 0)::bigint`,
  completionTokens: sql<string>`coalesce(sum(${llmCalls.completionTokens}), 0)::bigint`,
  unpricedPromptTokens: sql<string>`coalesce(sum(${llmCalls.promptTokens}) filter (where ${llmCalls.costUsd} is null), 0)::bigint`,
  unpricedCompletionTokens: sql<string>`coalesce(sum(${llmCalls.completionTokens}) filter (where ${llmCalls.costUsd} is null), 0)::bigint`,
} as const;

/**
 * The ORDER BY expression for "most expensive first".
 *
 * Deliberately NOT `AGGREGATES.costUsd`: that one carries a `::text` cast so
 * drizzle hands back the numeric at full precision instead of a lossy float,
 * and sorting by it sorts LEXICALLY. Text order puts 9.50 above 100.00, and it
 * looks correct right up until two rows stop sharing an integer-digit count —
 * which is exactly when the table starts mattering, because the number Elif
 * reads off the top of it is the input to "where does a cap belong".
 *
 * So display and ordering are two separate expressions over the same sum.
 */
const COST_ORDER = sql`coalesce(sum(${llmCalls.costUsd}), 0)`;

type AggregateRow = {
  callCount: number;
  pricedCallCount: number;
  costUsd: string;
  // bigint: Postgres `sum()` of an `integer` column is int8, and a brand's
  // LIFETIME token count outgrows int4 (2,147,483,647) long before anything
  // else here strains. Casting back down to `int` made the whole page throw a
  // raw "integer out of range" rather than degrade. node-postgres returns int8
  // as a string to avoid a silent precision loss, so these arrive as strings.
  promptTokens: string;
  completionTokens: string;
  unpricedPromptTokens: string;
  unpricedCompletionTokens: string;
};

/**
 * int8-as-string -> number. Safe here: Number.MAX_SAFE_INTEGER is ~9e15, four
 * million times the int4 ceiling we just escaped, so a token count reaches it
 * only in a world where this module has bigger problems.
 */
function toCount(raw: string): number {
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : 0;
}

/** cost_usd is numeric(12,6); round at that scale so float noise never shows. */
function toUsd(raw: string): number {
  const parsed = Number(raw);
  if (!Number.isFinite(parsed)) return 0;
  return Math.round(parsed * 1e6) / 1e6;
}

function toSummary(row: AggregateRow): SpendSummary {
  const unpricedCallCount = row.callCount - row.pricedCallCount;
  return {
    costUsd: toUsd(row.costUsd),
    callCount: row.callCount,
    pricedCallCount: row.pricedCallCount,
    unpricedCallCount,
    promptTokens: toCount(row.promptTokens),
    completionTokens: toCount(row.completionTokens),
    unpricedPromptTokens: toCount(row.unpricedPromptTokens),
    unpricedCompletionTokens: toCount(row.unpricedCompletionTokens),
    complete: unpricedCallCount === 0,
  };
}

const EMPTY_ROW: AggregateRow = {
  callCount: 0,
  pricedCallCount: 0,
  costUsd: "0",
  promptTokens: "0",
  completionTokens: "0",
  unpricedPromptTokens: "0",
  unpricedCompletionTokens: "0",
};

/* ── The windowed read (T51) ───────────────────────────────────────────── */

/** A half-open instant range, `[since, until)`. */
export interface SpendWindow {
  /** Inclusive lower bound. */
  since: Date;
  /** EXCLUSIVE upper bound — see `readBrandSpendWindowUnscoped`. */
  until: Date;
}

/** A brand's spend inside one window, total and per model. */
export interface WindowedBrandSpend {
  total: SpendSummary;
  /** Needed by the cap check to price unpriced calls per model; see cap.ts. */
  byModel: ModelSpend[];
}

/**
 * A brand's spend restricted to a time window, with NO ACCESS CHECK.
 *
 * ── WHY THIS LIVES HERE AND NOT IN cap.ts ────────────────────────────────
 * Because #51 item 1 says the cap must count with #42's arithmetic and not a
 * second one, and "the same arithmetic" has to mean the same `AGGREGATES`
 * object, the same `toSummary`, the same nullable-cost handling and the same
 * join chain — not a similar-looking query in another file that agrees today.
 * Two places computing spend differently is how a cap becomes untrustworthy:
 * the /spend page would say $48 while the refusal said $52 and neither number
 * would be defensible. So this is the existing aggregation with a WHERE clause
 * added, and nothing else.
 *
 * ── THE WINDOW IS HALF-OPEN, `[since, until)` ────────────────────────────
 * `>= since AND < until`, so consecutive months tile the timeline exactly
 * once. A closed upper bound would count a call landing precisely on the
 * boundary instant in both months — rare, and therefore the kind of thing that
 * would be found by a customer rather than a test.
 *
 * ── WHICH TIMESTAMP DECIDES THE MONTH ────────────────────────────────────
 * `llm_calls.created_at`: when the CALL was made, which is when the money was
 * spent and what OpenRouter's invoice is a sum of. Deliberately not the job's
 * `created_at`, which is when someone pressed the button. The two differ for a
 * job that is queued at 23:59 on the 31st and runs at 00:02 on the 1st, and
 * the honest answer there is that the money was spent in the new month —
 * that is the month whose invoice will carry it. This also means a run
 * straddling midnight is split across two windows, which is correct for the
 * same reason and is what #51 item 6 requires: nothing is interrupted, the
 * spend simply lands where it happened.
 *
 * `created_at` is `timestamptz`, so it is an absolute instant and the `Date`
 * bounds compare against it without any timezone reasoning happening here. The
 * question of which instants bound "this month" is answered exactly once, in
 * `core/llm/cap.ts`.
 */
export async function readBrandSpendWindowUnscoped(
  brandId: string,
  window: SpendWindow,
): Promise<WindowedBrandSpend> {
  const db = getDb();

  const scope = and(
    eq(projects.brandId, brandId),
    gte(llmCalls.createdAt, window.since),
    lt(llmCalls.createdAt, window.until),
  );

  const [totalRows, byModel] = await Promise.all([
    db
      .select(AGGREGATES)
      .from(llmCalls)
      .innerJoin(generationJobs, eq(llmCalls.jobId, generationJobs.id))
      .innerJoin(projects, eq(generationJobs.projectId, projects.id))
      .where(scope),
    db
      .select({ model: llmCalls.model, ...AGGREGATES })
      .from(llmCalls)
      .innerJoin(generationJobs, eq(llmCalls.jobId, generationJobs.id))
      .innerJoin(projects, eq(generationJobs.projectId, projects.id))
      .where(scope)
      .groupBy(llmCalls.model)
      .orderBy(desc(COST_ORDER), asc(llmCalls.model)),
  ]);

  return {
    total: toSummary(totalRows[0] ?? EMPTY_ROW),
    byModel: byModel.map((row) => ({ model: row.model, ...toSummary(row) })),
  };
}

/**
 * A brand's LIFETIME spend per model, with no access check. The fallback
 * observation the cap check falls back to when the current month contains no
 * priced call of a given model; see `core/llm/cap.ts`. Same aggregation again.
 */
export async function readBrandSpendByModelUnscoped(
  brandId: string,
): Promise<ModelSpend[]> {
  const db = getDb();
  const rows = await db
    .select({ model: llmCalls.model, ...AGGREGATES })
    .from(llmCalls)
    .innerJoin(generationJobs, eq(llmCalls.jobId, generationJobs.id))
    .innerJoin(projects, eq(generationJobs.projectId, projects.id))
    .where(eq(projects.brandId, brandId))
    .groupBy(llmCalls.model)
    .orderBy(desc(COST_ORDER), asc(llmCalls.model));
  return rows.map((row) => ({ model: row.model, ...toSummary(row) }));
}

/**
 * Spend for one project, broken down by workflow step and by model.
 *
 * Scoped read: goes through `requireProjectAccess`, so it throws AccessError
 * for a user with no grant on the brand (hard rule 2). There is no role bypass
 * IN THIS FUNCTION — a super admin with no grant is refused here exactly like
 * anyone else, and that is still worth relying on.
 *
 * It is no longer the whole story, though: since T50 a super admin has a
 * SEPARATE path to the same numbers, `getProjectSpendAsSuperAdmin` in
 * `core/llm/admin-spend.ts`, which does not consult `user_brands` and writes
 * an audit row instead. Two functions rather than a flag inside this one, so
 * that a call site cannot acquire admin scope by accident.
 */
export async function getProjectSpend(
  userId: string,
  projectId: string,
): Promise<ProjectSpend> {
  const { project, brand } = await requireProjectAccess(userId, projectId);
  return readProjectSpendUnscoped(project, brand);
}

/**
 * The project aggregation with NO ACCESS CHECK OF ANY KIND.
 *
 * ── READ THIS BEFORE CALLING ─────────────────────────────────────────────
 * This function trusts its caller completely. It takes an already-loaded
 * project and brand rather than ids, which makes handing it a bare id take a
 * deliberate TypeScript cast rather than a slip — a speed bump, not a barrier,
 * and it enforces nothing either way. Calling it without having authorised the
 * caller first is a brand-isolation bug (CLAUDE.md hard rule 2), not a
 * shortcut.
 *
 * It exists so that the two paths allowed to read this data can share one
 * query instead of drifting into two. Those paths are, exhaustively:
 *
 *   1. `getProjectSpend` above — after `requireProjectAccess`.
 *   2. `core/llm/admin-spend.ts` — after `requireSuperAdmin` AND after the
 *      crossing has been written to the audit trail (T50).
 *
 * Do not add a third without a very good reason and a name that says so.
 */
export async function readProjectSpendUnscoped(
  project: Project,
  brand: Brand,
): Promise<ProjectSpend> {
  const projectId = project.id;
  const db = getDb();

  // llm_calls reaches a project only via its job: job_id -> project_id.
  const scoped = db
    .select({ step: generationJobs.step, ...AGGREGATES })
    .from(llmCalls)
    .innerJoin(generationJobs, eq(llmCalls.jobId, generationJobs.id))
    .where(eq(generationJobs.projectId, projectId));

  const [byStep, byModel, totalRows] = await Promise.all([
    scoped.groupBy(generationJobs.step).orderBy(asc(generationJobs.step)),
    db
      .select({ model: llmCalls.model, ...AGGREGATES })
      .from(llmCalls)
      .innerJoin(generationJobs, eq(llmCalls.jobId, generationJobs.id))
      .where(eq(generationJobs.projectId, projectId))
      .groupBy(llmCalls.model)
      .orderBy(desc(COST_ORDER), asc(llmCalls.model)),
    db
      .select(AGGREGATES)
      .from(llmCalls)
      .innerJoin(generationJobs, eq(llmCalls.jobId, generationJobs.id))
      .where(eq(generationJobs.projectId, projectId)),
  ]);

  return {
    projectId: project.id,
    projectName: project.name,
    brandId: brand.id,
    brandName: brand.name,
    total: toSummary(totalRows[0] ?? EMPTY_ROW),
    byStep: byStep.map((row) => ({
      step: row.step,
      ...toSummary(row),
    })),
    byModel: byModel.map((row) => ({ model: row.model, ...toSummary(row) })),
  };
}

/**
 * Spend for one brand, broken down by project and by model.
 *
 * Scoped read via `requireBrandAccess`. Projects that have spent nothing are
 * listed with a zero rather than omitted, so "no spend" is visibly different
 * from "not shown".
 */
export async function getBrandSpend(
  userId: string,
  brandId: string,
): Promise<BrandSpend> {
  const brand = await requireBrandAccess(userId, brandId);
  return readBrandSpendUnscoped(brand);
}

/**
 * The brand aggregation with NO ACCESS CHECK OF ANY KIND. The same warning and
 * the same exhaustive caller list as `readProjectSpendUnscoped` above apply
 * here verbatim — read it before calling this.
 */
export async function readBrandSpendUnscoped(
  brand: Brand,
): Promise<BrandSpend> {
  const brandId = brand.id;
  const db = getDb();

  const [byProject, byModel, totalRows] = await Promise.all([
    // LEFT JOINs so a project with no jobs, or jobs with no calls, still
    // produces a row (a zero), instead of vanishing from the list.
    db
      .select({
        projectId: projects.id,
        projectName: projects.name,
        ...AGGREGATES,
      })
      .from(projects)
      .leftJoin(generationJobs, eq(generationJobs.projectId, projects.id))
      .leftJoin(llmCalls, eq(llmCalls.jobId, generationJobs.id))
      .where(eq(projects.brandId, brandId))
      .groupBy(projects.id, projects.name)
      .orderBy(desc(COST_ORDER), asc(projects.name)),
    db
      .select({ model: llmCalls.model, ...AGGREGATES })
      .from(llmCalls)
      .innerJoin(generationJobs, eq(llmCalls.jobId, generationJobs.id))
      .innerJoin(projects, eq(generationJobs.projectId, projects.id))
      .where(eq(projects.brandId, brandId))
      .groupBy(llmCalls.model)
      .orderBy(desc(COST_ORDER), asc(llmCalls.model)),
    db
      .select(AGGREGATES)
      .from(llmCalls)
      .innerJoin(generationJobs, eq(llmCalls.jobId, generationJobs.id))
      .innerJoin(projects, eq(generationJobs.projectId, projects.id))
      .where(eq(projects.brandId, brandId)),
  ]);

  return {
    brandId: brand.id,
    brandName: brand.name,
    total: toSummary(totalRows[0] ?? EMPTY_ROW),
    byProject: byProject.map((row) => ({
      projectId: row.projectId,
      projectName: row.projectName,
      ...toSummary(row),
    })),
    byModel: byModel.map((row) => ({ model: row.model, ...toSummary(row) })),
  };
}
