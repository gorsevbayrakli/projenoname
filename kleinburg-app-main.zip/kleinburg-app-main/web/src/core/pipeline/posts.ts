import type { PostItem } from "./inputs";

// The platform vocabulary lives in the registry now (core/platforms.ts). These
// re-exports keep this module the single import site for post-slice work.
export {
  normalizePlatform,
  PLATFORM_CODES as VALID_PLATFORMS,
  type Platform,
} from "../platforms";

/**
 * sm_posts platform-slice helpers. Framework-neutral (no react/next).
 *
 * The generated posts for EVERY selected platform live in ONE flat array
 * (step_contents.content.posts), each item tagged with its `platform`. The UI
 * treats that array as a set of per-platform slices: rendering filters by
 * platform, and regenerating one platform must replace ONLY that platform's
 * slice, leaving the other platform's posts untouched.
 *
 * This matters because the worker persists a step's output with
 * upsertStepContent, which REPLACES content wholesale. Without the merge below,
 * generating Facebook posts would silently delete the user's Instagram posts
 * (and vice versa) — exactly the legacy bug that `core/posts.py`'s
 * merge_platform_posts fixed.
 *
 * ── SLICE KEY: PLATFORM ALONE (deliberate simplification) ──────────────────
 * Legacy sliced by (platform, language) because one legacy session could hold
 * posts in several languages at once. In this architecture a PROJECT HAS ONE
 * LANGUAGE (`projects.language`), so every post in a project's sm_posts row is
 * already in that single language and the language half of the key is always
 * constant. The slice key is therefore PLATFORM ALONE. If per-project
 * multi-language generation is ever added, this is the place to restore the
 * (platform, language) pair — and mergePlatformPosts' signature is the seam.
 * ──────────────────────────────────────────────────────────────────────────
 */

/**
 * Return `existing` with the `platform` slice replaced by `incoming`.
 *
 * Every existing post whose platform matches (case-insensitively, whitespace
 * trimmed) is dropped; the other platform's posts are kept in their original
 * relative order, and `incoming` is appended after them. `incoming` is expected
 * to already carry the platform tag (runStep stamps it). Both inputs may be
 * empty.
 *
 * Legacy parity: mirrors core/posts.py merge_platform_posts, minus the language
 * half of the slice key (see the module comment).
 */
export function mergePlatformPosts(
  existing: PostItem[],
  incoming: PostItem[],
  platform: string,
): PostItem[] {
  const target = platform.trim().toLowerCase();
  const kept = (existing ?? []).filter(
    (p) => (p.platform ?? "").trim().toLowerCase() !== target,
  );
  return [...kept, ...(incoming ?? [])];
}
