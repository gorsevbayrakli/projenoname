import { z } from "zod";

import { PLATFORM_CODES } from "../platforms";

import type { WorkflowStep } from "@/core/db/schema";

/**
 * Per-step structured-output schemas.
 *
 * These schemas are the contract that T12 (runStep) passes to
 * `generateStructured` (see core/llm/openrouter.ts): the LLM is asked to
 * return JSON matching the schema for the step, and output that fails the
 * schema is a failed job (no regex/prose parsing, no partial saves).
 *
 * Shapes are derived from the legacy parser structure.
 */

/**
 * One source behind a secondary_data item (#47).
 *
 * `z.string()`, not `z.string().url()`: a malformed URL here must not fail the
 * whole (expensive, already-billed) generation. Every URL is filtered against
 * the call's real citations in run-step.ts before it is stored, and checked
 * again for scheme at the render site, so a bad one is dropped rather than
 * shown — a schema-level rejection would throw the good items away with it.
 */
export const itemSourceSchema = z.object({
  url: z.string(),
  title: z.string(),
});

/**
 * THE source shape for a secondary_data item's sources — one definition for the
 * engine, the serializers and the UI.
 *
 * There used to be three (this file's `z.infer`, an interface in
 * components/wizard/source-links.tsx, and an inline type in pipeline/inputs.ts)
 * and they had already drifted on whether `title` was optional. Three shapes for
 * one stored field means a change to it type-checks in two places and silently
 * misses the third, which is precisely the class of gap that let unsourced items
 * render as sourced.
 *
 * `title` is OPTIONAL here even though `itemSourceSchema` requires it, and that
 * is not a drift — the two describe different populations. The schema is the
 * MODEL's output contract, where a missing title is a contract violation. This
 * interface is the READ shape for content already in the database, which
 * includes rows written before #47 and rows hand-edited since. The assertion
 * below pins the one direction that must hold: anything the schema accepts is a
 * valid ItemSource.
 *
 * Declared as an interface rather than re-exported from the UI so `core/` keeps
 * its framework-neutrality (hard rule 1) — the dependency runs core → UI, never
 * the other way. UI modules import it `import type`, so nothing of core's
 * runtime crosses into a client bundle.
 */
export interface ItemSource {
  url: string;
  title?: string;
}

/** Compile-time proof that the model contract satisfies the read shape. */
const _itemSourceContractFitsReadShape: ItemSource = {} as z.infer<
  typeof itemSourceSchema
>;
void _itemSourceContractFitsReadShape;

// secondary_data: a flat list of researched entries, each with its sources.
//
// `sources` is REQUIRED (an empty array is the "I found nothing" answer) rather
// than optional, because OpenRouter's `strict: true` json_schema mode requires
// every declared property, and because an item that forgot the field would be
// indistinguishable from one that honestly has no source. This is the model's
// output contract only — STORED content from before this change has no such
// field, and is read tolerantly (see step-3.tsx extractItems).
export const secondaryDataSchema = z.object({
  items: z.array(
    z.object({
      title: z.string(),
      description: z.string(),
      sources: z.array(itemSourceSchema),
    }),
  ),
});

/**
 * The RETRIEVAL call's output (#52). Not a step schema: secondary_data is the
 * only step that takes two model calls — a search model retrieves, and the
 * writing model turns what came back into the step's real `items` output — and
 * this is the contract of the first of those two. It is deliberately absent
 * from STEP_SCHEMAS: nothing shaped like this is ever stored.
 *
 * `note` is English on purpose; the retrieval prompt says so and explains why
 * (perplexity/sonar drops non-ASCII letters, which mangled every Turkish word
 * it wrote on the 2026-07-20 live run). The project's language is applied by
 * the writing call, which does not have that defect.
 *
 * `sourceUrls` are what the search model TYPED. They are cross-checked against
 * the documents the call really retrieved before the writing model ever sees
 * them (serializeRetrievedMaterial in run-step.ts), so nothing here is trusted
 * on the model's word.
 */
export const researchRetrievalSchema = z.object({
  findings: z.array(
    z.object({
      note: z.string(),
      sourceUrls: z.array(z.string()),
    }),
  ),
});

// creative_sparks: a flat list of observational insight bullets.
export const creativeSparksSchema = z.object({
  items: z.array(
    z.object({
      title: z.string(),
      description: z.string(),
    }),
  ),
});

// sm_pillars: 21 content themes across three pillar categories. The split
// between the categories is NOT fixed — it follows the brand, subject to a
// floor per category (see PILLAR_FLOOR_PER_CATEGORY in run-step.ts). Neither
// the total nor the floor is expressed here: counts are checked after parsing
// so a miss can name the actual numbers and re-ask, which a Zod .length()
// cannot (hard rule 4 / T26).
export const smPillarsSchema = z.object({
  pillars: z.array(
    z.object({
      category: z.enum(["INSPIRATIONAL", "ENTERTAINING", "INFORMATIONAL"]),
      // The pillar's engaging title (legacy "PILLAR #: [title]"). Required
      // because the content_calendar step references pillars by name.
      title: z.string(),
      topicBlend: z.string(),
      creativeSpark: z.string(),
      hook: z.string(),
      contentBrief: z.string(),
    }),
  ),
});

// sm_posts: platform-specific post concepts.
export const smPostsSchema = z.object({
  posts: z.array(
    z.object({
      platform: z.enum(PLATFORM_CODES),
      theme: z.string(),
      hook: z.string(),
      caption: z.string(),
      cta: z.string(),
      hashtags: z.array(z.string()),
    }),
  ),
});

// brand_context: freeform Brand Key analysis, a single text field.
export const brandContextSchema = z.object({
  brandContext: z.string(),
});

// content_calendar: structured rows per platform (T29 + T33).
//
// Was one freeform markdown table whose Post column held the whole caption —
// hook, body, CTA and hashtags joined with <br> in a single cell. Unreadable in
// the UI and worse in Excel. The fields already exist separately upstream in
// sm_posts; the calendar was collapsing them, so the fix is to stop collapsing.
export const calendarRowSchema = z.object({
  /** "Day 1" … "Day 30". English on purpose: production shorthand (T11). */
  day: z.string(),
  format: z.string(),
  pillar: z.string(),
  hook: z.string(),
  caption: z.string(),
  cta: z.string(),
  hashtags: z.array(z.string()),
});

/**
 * A platform the calendar could not fill to its requested count.
 *
 * OPTIONAL on the calendar below, and that is not laziness: every calendar
 * stored before the step became deterministic has no such field, and those rows
 * still render. A present-but-empty array means "built by the builder, nothing
 * missing"; an ABSENT one means "we do not know", which is the honest reading
 * of a calendar a model wrote.
 */
export const calendarShortfallSchema = z.object({
  platform: z.string(),
  requested: z.number(),
  scheduled: z.number(),
});

export const contentCalendarSchema = z.object({
  calendars: z.array(
    z.object({
      platform: z.enum(PLATFORM_CODES),
      rows: z.array(calendarRowSchema),
    }),
  ),
  /**
   * Platforms that got fewer rows than the project asked for.
   *
   * Carried in the STORED content rather than only in the job, because the gap
   * outlives the run that found it: someone opening step 9 a week later has to
   * see that LinkedIn is four posts short, and the job row is not what that
   * screen reads. Hard rule 5 — the short calendar must never look complete.
   */
  shortfalls: z.array(calendarShortfallSchema).optional(),
});

export type CalendarRow = z.infer<typeof calendarRowSchema>;

export type SecondaryData = z.infer<typeof secondaryDataSchema>;
export type ResearchRetrieval = z.infer<typeof researchRetrievalSchema>;
export type CreativeSparks = z.infer<typeof creativeSparksSchema>;
export type SmPillars = z.infer<typeof smPillarsSchema>;
export type SmPosts = z.infer<typeof smPostsSchema>;
export type BrandContext = z.infer<typeof brandContextSchema>;
export type ContentCalendar = z.infer<typeof contentCalendarSchema>;

/**
 * Maps each generative workflow_step to its output schema.
 *
 * `user_input` is user-entered content, not model-generated, so it has no
 * schema and is intentionally omitted.
 */
export const STEP_SCHEMAS = {
  brand_context: brandContextSchema,
  secondary_data: secondaryDataSchema,
  creative_sparks: creativeSparksSchema,
  sm_pillars: smPillarsSchema,
  sm_posts: smPostsSchema,
  content_calendar: contentCalendarSchema,
} satisfies Partial<Record<WorkflowStep, z.ZodType>>;

export type GenerativeStep = keyof typeof STEP_SCHEMAS;
