/**
 * LEGACY parsing for content_calendar payloads.
 *
 * content_calendar returns structured rows now (`contentCalendarSchema`:
 * `{ calendars: [{ platform, rows }] }`, T33). This module exists for the
 * projects generated BEFORE that, whose stored content is still a single
 * `calendar` string holding a markdown pipe table (Day / [Platform] / Format /
 * Content Pillar / Post). step-9.tsx parses those on read so old projects keep
 * rendering; nothing on the generation path uses this any more.
 *
 * Two rules of the old prompt shape this parser and must not be "simplified"
 * away:
 *  - cells never contain "|" (the prompt forbids it), so a bare split on "|" is
 *    correct and needs no escaping logic;
 *  - in-cell line breaks arrive as the literal "<br>", which we convert back to
 *    real newlines here so both the table cells and the exports carry them.
 *
 * Tolerance is deliberate: an LLM may prepend prose, append a note, or emit a
 * ragged row. Anything we cannot recognise as a table yields
 * `{ headers: [], rows: [] }` so the caller can fall back to showing the raw
 * text — visibly, never silently (hard rule 5).
 *
 * Engine module: no react/next imports.
 */

export type ParsedCalendar = {
  headers: string[];
  rows: string[][];
};

const EMPTY: ParsedCalendar = { headers: [], rows: [] };

/** A markdown table separator cell: ---, :---, ---:, :---: (any dash count ≥1). */
const SEPARATOR_CELL = /^:?-+:?$/;

/**
 * Parse a markdown-style pipe table out of `raw`.
 *
 * Detection: the first line whose cells are ALL separator cells marks the
 * table; the preceding pipe line is the header. Data rows are the contiguous
 * pipe lines that follow — the first non-pipe line ends the table, so trailing
 * prose is dropped. When there is no separator line we fall back to treating
 * the first line of the FIRST run of three consecutive pipe lines of equal
 * width as the header, which rescues a table emitted without the `---|---`
 * rule. (Three, not two, and first, not longest — see the reasoning at the
 * fallback loop itself; ordinary prose containing "|" must not be promoted.)
 *
 * Rows are padded/truncated to the header width so callers can index cells
 * without bounds checks.
 */
export function parseCalendarTable(raw: string): ParsedCalendar {
  if (typeof raw !== "string" || raw.trim() === "") return EMPTY;

  const lines = raw.split(/\r?\n/);
  const start = findTableStart(lines);
  if (!start) return EMPTY;

  const headers = splitRow(lines[start.headerIndex]);
  if (headers.length === 0) return EMPTY;

  const rows: string[][] = [];
  for (let i = start.firstDataIndex; i < lines.length; i++) {
    const line = lines[i];
    if (line.trim() === "") break;
    if (!isPipeLine(line)) break;
    // A stray second separator (some models repeat it) is skipped, not stored.
    if (isSeparatorLine(line)) continue;
    rows.push(fit(splitRow(line), headers.length));
  }

  return { headers, rows };
}

/**
 * Where the table begins: the header line index and the index of the first
 * data line after it. Null when no table is present.
 */
function findTableStart(
  lines: string[],
): { headerIndex: number; firstDataIndex: number } | null {
  for (let i = 1; i < lines.length; i++) {
    if (!isSeparatorLine(lines[i])) continue;
    // The header is the nearest preceding pipe line, walking back past blank
    // lines: a blank line between header and separator must not make us elect
    // the separator itself as the header (which produced "---" column titles).
    let headerIndex = i - 1;
    while (headerIndex >= 0 && lines[headerIndex].trim() === "") headerIndex--;
    if (
      headerIndex >= 0 &&
      isPipeLine(lines[headerIndex]) &&
      !isSeparatorLine(lines[headerIndex])
    ) {
      return { headerIndex, firstDataIndex: i + 1 };
    }
  }

  // Fallback: no separator anywhere. Require a run of ≥3 pipe lines with a
  // consistent cell count so ordinary prose that happens to contain "|" is not
  // promoted into a table (the caller then shows the raw text instead).
  for (let i = 0; i < lines.length - 2; i++) {
    const run = [lines[i], lines[i + 1], lines[i + 2]];
    if (!run.every((l) => isPipeLine(l) && !isSeparatorLine(l))) continue;
    const width = rawCells(lines[i]).length;
    if (width < 2) continue;
    if (run.every((l) => rawCells(l).length === width)) {
      return { headerIndex: i, firstDataIndex: i + 1 };
    }
  }

  return null;
}

/** A line that carries table cells: at least one "|" and some other content. */
function isPipeLine(line: string | undefined): boolean {
  if (line === undefined) return false;
  const trimmed = line.trim();
  return trimmed.includes("|") && trimmed.replace(/\|/g, "").trim() !== "";
}

/** A `---|---`-style separator line (every cell is dashes). */
function isSeparatorLine(line: string | undefined): boolean {
  if (line === undefined) return false;
  const cells = rawCells(line);
  return cells.length > 0 && cells.every((c) => SEPARATOR_CELL.test(c));
}

/** Trimmed cells of a pipe line, with the optional leading/trailing pipes gone. */
function rawCells(line: string): string[] {
  let trimmed = line.trim();
  if (!trimmed.includes("|")) return [];
  if (trimmed.startsWith("|")) trimmed = trimmed.slice(1);
  if (trimmed.endsWith("|")) trimmed = trimmed.slice(0, -1);
  return trimmed.split("|").map((c) => c.trim());
}

/** Cells of a data/header row, with "<br>" converted back to real newlines. */
function splitRow(line: string): string[] {
  return rawCells(line).map(unbr);
}

/** "<br>" / "<br/>" / "<BR />" → "\n" (the prompt's in-cell line-break token). */
function unbr(cell: string): string {
  return cell.replace(/<br\s*\/?>/gi, "\n").trim();
}

/**
 * Make a row match the header width. Short rows are padded with "".
 *
 * Long rows are NOT truncated: an extra cell almost always means the model put a
 * literal "|" inside a cell (the prompt bans it, but that is a soft constraint on
 * an LLM, and the column it breaks is the long Post caption). Dropping the
 * overflow would silently lose caption text in the table AND in both exports, so
 * the overflow is rejoined into the last cell instead — a slightly odd cell beats
 * silent data loss.
 */
function fit(cells: string[], width: number): string[] {
  if (cells.length === width) return cells;
  if (cells.length > width) {
    const head = cells.slice(0, width - 1);
    const tail = cells.slice(width - 1).join(" | ");
    return [...head, tail];
  }
  return [...cells, ...Array<string>(width - cells.length).fill("")];
}
