import { describe, expect, it } from "vitest";

import { parseCalendarTable } from "./calendar";

describe("parseCalendarTable", () => {
  it("parses a well-formed markdown table", () => {
    const raw = [
      "| Gün | Format | İçerik Sütunu | Gönderi |",
      "| --- | --- | --- | --- |",
      "| Day 1 | Reel | Ilham | Merhaba |",
      "| Day 3 | Carousel | Egitim | Selam |",
    ].join("\n");

    expect(parseCalendarTable(raw)).toEqual({
      headers: ["Gün", "Format", "İçerik Sütunu", "Gönderi"],
      rows: [
        ["Day 1", "Reel", "Ilham", "Merhaba"],
        ["Day 3", "Carousel", "Egitim", "Selam"],
      ],
    });
  });

  it("ignores preamble prose before the table and prose after it", () => {
    const raw = [
      "Elbette! İşte 30 günlük takviminiz:",
      "",
      "Day | Format | Post",
      "---|---|---",
      "Day 1 | Reel | Merhaba",
      "",
      "Umarım beğenirsiniz.",
    ].join("\n");

    expect(parseCalendarTable(raw)).toEqual({
      headers: ["Day", "Format", "Post"],
      rows: [["Day 1", "Reel", "Merhaba"]],
    });
  });

  it("converts <br> variants inside cells to real newlines", () => {
    const raw = [
      "| Day | Post |",
      "| --- | --- |",
      "| Day 1 | Kanca<br>Gövde<BR />CTA<br/>#etiket |",
    ].join("\n");

    const { rows } = parseCalendarTable(raw);
    expect(rows[0][1]).toBe("Kanca\nGövde\nCTA\n#etiket");
  });

  it("pads short rows and rejoins overflow into the last cell", () => {
    // Overflow is rejoined rather than truncated: an extra cell means the model
    // put a literal "|" inside the caption, and dropping it would silently lose
    // text in the table and in both exports.
    const raw = [
      "| Day | Format | Post |",
      "| --- | --- | --- |",
      "| Day 1 | Reel |",
      "| Day 2 | Reel | Metin | fazlalık |",
    ].join("\n");

    expect(parseCalendarTable(raw).rows).toEqual([
      ["Day 1", "Reel", ""],
      ["Day 2", "Reel", "Metin | fazlalık"],
    ]);
  });

  it("handles a table with no separator line by using the first pipe run", () => {
    const raw = ["Day | Post", "Day 1 | Merhaba", "Day 2 | Selam"].join("\n");

    expect(parseCalendarTable(raw)).toEqual({
      headers: ["Day", "Post"],
      rows: [
        ["Day 1", "Merhaba"],
        ["Day 2", "Selam"],
      ],
    });
  });

  it("skips a repeated separator row inside the body", () => {
    const raw = [
      "| Day | Post |",
      "| --- | --- |",
      "| :--- | :---: |",
      "| Day 1 | Merhaba |",
    ].join("\n");

    expect(parseCalendarTable(raw).rows).toEqual([["Day 1", "Merhaba"]]);
  });

  it("returns an empty result when there is no table at all", () => {
    expect(parseCalendarTable("Takvim üretilemedi, üzgünüm.")).toEqual({
      headers: [],
      rows: [],
    });
  });

  it("returns an empty result for an empty or blank string", () => {
    expect(parseCalendarTable("")).toEqual({ headers: [], rows: [] });
    expect(parseCalendarTable("   \n \n")).toEqual({ headers: [], rows: [] });
  });

  it("returns an empty result for a header with no data rows", () => {
    const raw = ["| Day | Post |", "| --- | --- |"].join("\n");
    expect(parseCalendarTable(raw)).toEqual({
      headers: ["Day", "Post"],
      rows: [],
    });
  });
});

describe("parseCalendarTable — review-hardened cases", () => {
  it("keeps overflow when a cell contains a literal | (no silent truncation)", () => {
    const raw = "| Gün | Post |\n| --- | --- |\n| 1. Gün | a|b |";
    const { rows } = parseCalendarTable(raw);
    // The caption must survive; dropping "b" would lose text in the exports too.
    expect(rows[0][1]).toContain("a");
    expect(rows[0][1]).toContain("b");
  });

  it("finds the header across a blank line before the separator", () => {
    const raw = "| Gün | Post |\n\n| --- | --- |\n| 1. Gün | x |";
    const { headers, rows } = parseCalendarTable(raw);
    expect(headers).toEqual(["Gün", "Post"]);
    expect(rows).toEqual([["1. Gün", "x"]]);
  });

  it("does not promote two prose lines containing | into a table", () => {
    const raw = "Takvim üretilemedi | üzgünüm\nLütfen | tekrar deneyin";
    expect(parseCalendarTable(raw)).toEqual({ headers: [], rows: [] });
  });
});
