import { describe, expect, it } from "vitest";

import {
  brandContextSchema,
  contentCalendarSchema,
  creativeSparksSchema,
  secondaryDataSchema,
  smPillarsSchema,
  smPostsSchema,
  STEP_SCHEMAS,
} from "./schemas";

describe("secondaryDataSchema", () => {
  it("parses a valid example, sources included", () => {
    expect(
      secondaryDataSchema.parse({
        items: [
          {
            title: "Zipf's law",
            description: "Word frequency is inversely proportional to rank.",
            sources: [
              { url: "https://example.org/zipf", title: "Zipf's law" },
            ],
          },
        ],
      }).items,
    ).toHaveLength(1);
  });

  it("accepts an empty sources array — the honest 'found nothing' answer (#47)", () => {
    expect(
      secondaryDataSchema.safeParse({
        items: [{ title: "x", description: "y", sources: [] }],
      }).success,
    ).toBe(true);
  });

  it("rejects an item with no sources field at all", () => {
    // Required, not optional: under strict json_schema output the model must
    // always answer the sources question, and a forgotten field must not be
    // mistakable for an honest empty list.
    expect(
      secondaryDataSchema.safeParse({
        items: [{ title: "x", description: "y" }],
      }).success,
    ).toBe(false);
  });

  it("rejects a missing description", () => {
    expect(
      secondaryDataSchema.safeParse({ items: [{ title: "x", sources: [] }] })
        .success,
    ).toBe(false);
  });
});

describe("creativeSparksSchema", () => {
  it("parses a valid example", () => {
    expect(
      creativeSparksSchema.safeParse({
        items: [{ title: "The silent wrapper", description: "That meeting-room crinkle everyone hears." }],
      }).success,
    ).toBe(true);
  });

  it("rejects a non-array items field", () => {
    expect(creativeSparksSchema.safeParse({ items: "nope" }).success).toBe(false);
  });
});

describe("smPillarsSchema", () => {
  const pillar = {
    category: "INSPIRATIONAL" as const,
    title: "Tutku's Guide to Stealth Snacking",
    topicBlend: "Storytelling × Humanization",
    creativeSpark: "spark",
    hook: "hook",
    contentBrief: "brief",
  };

  it("parses a valid example", () => {
    expect(smPillarsSchema.parse({ pillars: [pillar] }).pillars[0].category).toBe("INSPIRATIONAL");
  });

  it("rejects a pillar with a bad category", () => {
    expect(smPillarsSchema.safeParse({ pillars: [{ ...pillar, category: "FUNNY" }] }).success).toBe(false);
  });
});

describe("smPostsSchema", () => {
  const post = {
    platform: "instagram" as const,
    theme: "theme",
    hook: "hook",
    caption: "caption",
    cta: "cta",
    hashtags: ["#a", "#b"],
  };

  it("parses a valid example", () => {
    expect(smPostsSchema.parse({ posts: [post] }).posts[0].hashtags).toHaveLength(2);
  });

  it("rejects non-array hashtags", () => {
    expect(smPostsSchema.safeParse({ posts: [{ ...post, hashtags: "#a #b" }] }).success).toBe(false);
  });

  it("rejects an unknown platform", () => {
    expect(smPostsSchema.safeParse({ posts: [{ ...post, platform: "myspace" }] }).success).toBe(false);
  });
});

describe("freeform single-field schemas", () => {
  it("brandContextSchema parses text and rejects a non-string", () => {
    expect(brandContextSchema.parse({ brandContext: "## CONTEXT" }).brandContext).toBe("## CONTEXT");
    expect(brandContextSchema.safeParse({ brandContext: 42 }).success).toBe(false);
  });

  it("contentCalendarSchema parses structured rows per platform", () => {
    const parsed = contentCalendarSchema.parse({
      calendars: [
        { platform: "instagram", rows: [{
          day: "Day 1",
          format: "Reel",
          pillar: "Sütun",
          hook: "kanca",
          caption: "gövde",
          cta: "kaydet",
          hashtags: ["#a"],
        }] },
        { platform: "tiktok", rows: [] },
      ],
    });
    expect(parsed.calendars).toHaveLength(2);
    // T33: the caption parts stay apart, which is what makes the export
    // readable as columns instead of one wall of text.
    expect(parsed.calendars[0].rows[0].hook).toBe("kanca");
    expect(parsed.calendars[0].rows[0].hashtags).toEqual(["#a"]);
  });

  it("contentCalendarSchema rejects older shapes and unknown platforms", () => {
    expect(contentCalendarSchema.safeParse({}).success).toBe(false);
    // Pre-T33 markdown-table output is no longer valid MODEL output; the
    // readers still tolerate it for rows already in the database.
    expect(
      contentCalendarSchema.safeParse({
        calendars: [{ platform: "instagram", calendar: "| a |" }],
      }).success,
    ).toBe(false);
    expect(
      contentCalendarSchema.safeParse({
        calendars: [{ platform: "myspace", rows: [] }],
      }).success,
    ).toBe(false);
  });
});

describe("STEP_SCHEMAS", () => {
  it("maps every generative step and omits user_input", () => {
    expect(Object.keys(STEP_SCHEMAS).sort()).toEqual([
      "brand_context",
      "content_calendar",
      "creative_sparks",
      "secondary_data",
      "sm_pillars",
      "sm_posts",
    ]);
    expect("user_input" in STEP_SCHEMAS).toBe(false);
  });
});
