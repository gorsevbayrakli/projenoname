import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

// web/src/core/pipeline -> web/prompts
const PROMPTS_DIR = join(dirname(fileURLToPath(import.meta.url)), "../../../prompts");

export interface PromptFrontmatter {
  step: string;
  /** Legacy .txt this was migrated from. Absent for prompts written here. */
  source?: string;
  version: number;
  languageSlot: boolean;
  variables: string[];
  platform?: string;
  variant?: string;
}

export interface LoadedPrompt {
  frontmatter: PromptFrontmatter;
  body: string;
}

const cache = new Map<string, LoadedPrompt>();

/**
 * Parse the tiny YAML frontmatter dialect our prompt files use: a leading
 * `---` block containing `key: value` scalars and `key:` + indented `  - item`
 * lists. Deliberately hand-rolled to avoid a gray-matter dependency.
 */
function parseFrontmatter(raw: string): { frontmatter: PromptFrontmatter; body: string } {
  const match = /^---\n([\s\S]*?)\n---\n?([\s\S]*)$/.exec(raw);
  if (!match) throw new Error("prompt is missing YAML frontmatter");

  const [, fmBlock, body] = match;
  const fm: Record<string, string | number | boolean | string[]> = {};
  const lines = fmBlock.split("\n");
  let currentList: string[] | null = null;
  let currentKey: string | null = null;

  for (const line of lines) {
    if (line.trim() === "") continue;
    const listItem = /^\s+-\s+(.*)$/.exec(line);
    if (listItem && currentList && currentKey) {
      currentList.push(listItem[1].trim());
      continue;
    }
    const kv = /^([A-Za-z_][A-Za-z0-9_]*):\s*(.*)$/.exec(line);
    if (!kv) throw new Error(`unparseable frontmatter line: ${line}`);
    const [, key, rawValue] = kv;
    if (rawValue === "") {
      currentList = [];
      currentKey = key;
      fm[key] = currentList;
    } else {
      currentList = null;
      currentKey = null;
      fm[key] = coerceScalar(rawValue.trim());
    }
  }

  return { frontmatter: fm as unknown as PromptFrontmatter, body };
}

function coerceScalar(value: string): string | number | boolean {
  const unquoted = value.replace(/^["']|["']$/g, "");
  if (unquoted === "true") return true;
  if (unquoted === "false") return false;
  if (/^-?\d+$/.test(unquoted)) return Number(unquoted);
  return unquoted;
}

/** Load and cache a prompt by file name (with or without the `.md` suffix). */
export function loadPrompt(name: string): LoadedPrompt {
  const fileName = name.endsWith(".md") ? name : `${name}.md`;
  const cached = cache.get(fileName);
  if (cached) return cached;

  const raw = readFileSync(join(PROMPTS_DIR, fileName), "utf8");
  const { frontmatter, body } = parseFrontmatter(raw);
  const loaded: LoadedPrompt = { frontmatter, body };
  cache.set(fileName, loaded);
  return loaded;
}

/** Escape regex metacharacters in a declared variable name. */
function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Render a prompt by replacing each `{key}` placeholder with `vars[key]`.
 * Every variable declared in the frontmatter must be supplied; a missing one
 * throws (this catches a step wiring up the wrong inputs).
 *
 * Substitution is a SINGLE pass over the body: one regex alternation of all
 * declared names, replaced in one scan. Sequential per-variable replacement
 * would re-scan already-injected text, so a value carrying a literal like
 * `{language}` (perfectly possible — values are prior steps' model output and
 * user documents) would be rewritten by a later variable's turn, silently
 * altering the prompt. With one pass, injected values are never re-scanned and
 * survive verbatim.
 */
export function renderPrompt(name: string, vars: Record<string, string>): string {
  const { frontmatter, body } = loadPrompt(name);
  for (const key of frontmatter.variables) {
    if (!(key in vars)) {
      throw new Error(`missing variable "${key}" for prompt "${name}"`);
    }
  }
  if (frontmatter.variables.length === 0) return body;

  const pattern = new RegExp(
    `\\{(${frontmatter.variables.map(escapeRegExp).join("|")})\\}`,
    "g",
  );
  // The replacer is a function, so `$&`/`$1` inside a value are literal too.
  return body.replace(pattern, (_match, key: string) => vars[key]);
}

/** Test/reset hook: clears the in-memory prompt cache. */
export function clearPromptCache(): void {
  cache.clear();
}
