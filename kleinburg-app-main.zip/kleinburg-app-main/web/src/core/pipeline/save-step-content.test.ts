import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { and, eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "@/core/db/client";
import { brands, projects, stepContents, users } from "@/core/db/schema";
import { getStepContent, saveStepContent } from "./inputs";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

async function seedProject() {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({ username: `t15-${randomUUID()}`, passwordHash: "x" })
    .returning();
  createdUserIds.push(user.id);
  const [brand] = await db
    .insert(brands)
    .values({ name: `brand-${randomUUID()}` })
    .returning();
  createdBrandIds.push(brand.id);
  const [project] = await db
    .insert(projects)
    .values({
      brandId: brand.id,
      name: `proj-${randomUUID()}`,
      createdBy: user.id,
    })
    .returning();
  return project;
}

describe.skipIf(!hasDb)("saveStepContent", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      // Cascades to projects + step_contents.
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("upserts content, then updates it, then sets selections — one row", async () => {
    const project = await seedProject();
    const db = getDb();

    // 1. Insert content on a fresh (project, step).
    await saveStepContent(project.id, "brand_context", {
      content: { brandContext: "first" },
    });
    let row = await getStepContent(project.id, "brand_context");
    expect(row?.content).toEqual({ brandContext: "first" });
    expect(row?.selections).toBeNull();

    // 2. Update content only — selections untouched (still null).
    await saveStepContent(project.id, "brand_context", {
      content: { brandContext: "second" },
    });
    row = await getStepContent(project.id, "brand_context");
    expect(row?.content).toEqual({ brandContext: "second" });
    expect(row?.selections).toBeNull();

    // 3. Set selections only — content preserved from step 2.
    await saveStepContent(project.id, "brand_context", {
      selections: { selectedIndices: [0, 2] },
    });
    row = await getStepContent(project.id, "brand_context");
    expect(row?.content).toEqual({ brandContext: "second" });
    expect(row?.selections).toEqual({ selectedIndices: [0, 2] });

    // Exactly one row for (project, step).
    const all = await db
      .select({ id: stepContents.id })
      .from(stepContents)
      .where(
        and(
          eq(stepContents.projectId, project.id),
          eq(stepContents.step, "brand_context"),
        ),
      );
    expect(all).toHaveLength(1);
  });
});
