import { describe, expect, it } from "vitest";

import {
  calendarTargets,
  containDocumentText,
  NO_SOURCE_MARKER,
  postsContentToArray,
  selectItems,
  serializeItems,
  serializePillars,
  serializePosts,
  serializeSourcedItems,
  type PostItem,
} from "./inputs";
import type { Project } from "../db/schema";

describe("selectItems", () => {
  const items = [{ v: "a" }, { v: "b" }, { v: "c" }];

  it("returns all items when selections is null", () => {
    expect(selectItems(items, null)).toEqual(items);
  });

  it("returns all items when selectedIndices is empty", () => {
    expect(selectItems(items, { selectedIndices: [] })).toEqual(items);
  });

  it("filters to the chosen indices", () => {
    expect(selectItems(items, { selectedIndices: [0, 2] })).toEqual([
      { v: "a" },
      { v: "c" },
    ]);
  });

  it("ignores out-of-range indices", () => {
    expect(selectItems(items, { selectedIndices: [1, 9, -1] })).toEqual([
      { v: "b" },
    ]);
  });
});

describe("serializeItems", () => {
  it("numbers title/description lines", () => {
    const out = serializeItems([
      { title: "T1", description: "D1" },
      { title: "T2", description: "D2" },
    ]);
    expect(out).toContain("1. T1: D1");
    expect(out).toContain("2. T2: D2");
  });

  it("handles an empty list", () => {
    expect(serializeItems([])).toBe("");
  });
});

/**
 * serializeSourcedItems (#47): the serialization the post prompts' grounding
 * rule reads. A sourced finding and an unsourced one must survive into the
 * prompt DIFFERENTLY, or the rule that treats them differently has nothing to
 * act on.
 */
describe("serializeSourcedItems", () => {
  it("lists an item's sources under its line", () => {
    const out = serializeSourcedItems([
      {
        title: "T1",
        description: "D1",
        sources: [
          { url: "https://example.org/a", title: "Doc A" },
          { url: "https://example.org/b" },
        ],
      },
    ]);
    expect(out).toContain("1. T1: D1");
    expect(out).toContain("Doc A — https://example.org/a");
    // A source with no title still shows its URL.
    expect(out).toContain("https://example.org/b");
    expect(out).not.toContain(NO_SOURCE_MARKER);
  });

  it("marks an item with an empty sources list", () => {
    const out = serializeSourcedItems([
      { title: "T1", description: "D1", sources: [] },
    ]);
    expect(out).toContain(`1. T1: D1\n   ${NO_SOURCE_MARKER}`);
  });

  it("marks a legacy item with no sources field at all", () => {
    // Pre-#47 stored content: written by a model with no search behind it, so
    // "no source" is its honest history, not a formatting fallback.
    const out = serializeSourcedItems([{ title: "T1", description: "D1" }]);
    expect(out).toContain(NO_SOURCE_MARKER);
  });

  it("handles an empty list", () => {
    expect(serializeSourcedItems([])).toBe("");
  });
});

describe("serializePillars", () => {
  it("includes title, category, and brief fields", () => {
    const out = serializePillars([
      {
        category: "INSPIRATIONAL",
        title: "Stealth Snacking",
        topicBlend: "A × B",
        creativeSpark: "spark",
        hook: "hook",
        contentBrief: "brief",
      },
    ]);
    expect(out).toContain("Stealth Snacking");
    expect(out).toContain("INSPIRATIONAL");
    expect(out).toContain("brief");
  });
});

describe("serializePosts", () => {
  it("prepends an uppercase Platform line (required by the combined calendar)", () => {
    const out = serializePosts([
      {
        platform: "facebook",
        theme: "Th",
        hook: "H",
        caption: "C",
        cta: "Go",
        hashtags: ["#a", "#b"],
      },
    ]);
    expect(out).toContain("Platform: FACEBOOK");
    expect(out).toContain("Theme: Th");
    expect(out).toContain("Hashtags: #a #b");
  });

  it("skips empty fields", () => {
    const out = serializePosts([{ platform: "instagram", theme: "Only" }]);
    expect(out).toContain("Platform: INSTAGRAM");
    expect(out).toContain("Theme: Only");
    expect(out).not.toContain("Hook:");
    expect(out).not.toContain("Caption:");
  });
});

describe("postsContentToArray", () => {
  it("extracts the posts array from the content shape", () => {
    expect(
      postsContentToArray({ posts: [{ platform: "instagram" }] }),
    ).toEqual([{ platform: "instagram" }]);
  });

  it("returns [] for malformed content", () => {
    expect(postsContentToArray(null)).toEqual([]);
    expect(postsContentToArray({})).toEqual([]);
    expect(postsContentToArray("nope")).toEqual([]);
  });
});

/**
 * calendarTargets is the load-bearing single source of truth for the calendar
 * step: the SAME list fills the prompt's `{active_platforms}` slot and sizes
 * runStep's under-delivery check (T38). If the two ever derive their platforms
 * or counts differently, the check either fails every good run or passes short
 * ones — so the function itself is pinned here, and the prompt/check invariant
 * is pinned in gather-vars.test.ts where a real project is available.
 */
describe("calendarTargets", () => {
  /** The only two project columns calendarTargets reads. */
  function project(
    platforms: string[],
    postCounts: Record<string, unknown> = {},
  ): Project {
    return { platforms, postCounts } as unknown as Project;
  }

  const post = (platform?: string): PostItem => ({ platform, theme: "t" });

  it("is the UNION of the project's selection and the platforms with posts", () => {
    // Narrowed to facebook after instagram posts were already generated: the
    // calendar still has to schedule what the project produced.
    expect(
      calendarTargets(project(["facebook"]), [post("instagram")]).map(
        (t) => t.platform,
      ),
    ).toEqual(["instagram", "facebook"]);
  });

  it("de-duplicates and returns registry order, not input order", () => {
    expect(
      calendarTargets(project(["tiktok", "facebook", "facebook"]), [
        post("tiktok"),
      ]).map((t) => t.platform),
    ).toEqual(["facebook", "tiktok"]);
  });

  it("uses each platform's registry default count when the project has none", () => {
    expect(calendarTargets(project(["instagram", "linkedin"]), [])).toEqual([
      { platform: "instagram", count: 16 },
      { platform: "linkedin", count: 10 },
    ]);
  });

  it("postCounts OVERRIDES the registry default, per platform", () => {
    // instagram overridden, facebook left to its default of 12.
    expect(
      calendarTargets(
        project(["instagram", "facebook"], { instagram: 5 }),
        [],
      ),
    ).toEqual([
      { platform: "instagram", count: 5 },
      { platform: "facebook", count: 12 },
    ]);
  });

  it("falls back to the default for out-of-range or non-integer stored counts", () => {
    // A bad stored number must not brick the calendar step, and must not ask
    // the model for 0 or 900 posts.
    for (const bad of [0, -3, 31, 2.5, "12", null, undefined, NaN]) {
      expect(
        calendarTargets(project(["instagram"], { instagram: bad }), []),
      ).toEqual([{ platform: "instagram", count: 16 }]);
    }
  });

  it("is empty for a project with no platforms and no posts", () => {
    expect(calendarTargets(project([]), [])).toEqual([]);
  });

  // THE JUNK-TAG HAZARD: normalizePlatform falls back to instagram, so mapping
  // post tags through it would pull a full 16-post Instagram calendar into the
  // targets of a project that deliberately deselected Instagram. sortPlatforms
  // whitelists instead, so junk is DROPPED.
  it("DROPS unknown post tags rather than defaulting them to instagram", () => {
    expect(
      calendarTargets(project(["facebook"]), [
        post("linkedin"),
        post("Nonsense"),
        post(""),
        post(undefined),
      ]).map((t) => t.platform),
    ).toEqual(["facebook", "linkedin"]);
  });

  it("still accepts a well-formed tag that merely needs case/space folding", () => {
    expect(
      calendarTargets(project([]), [post("  Instagram ")]).map(
        (t) => t.platform,
      ),
    ).toEqual(["instagram"]);
  });
});

/**
 * #61 containment, at the unit level. The rendered-prompt assertions live in
 * gather-vars.test.ts (that is where the property actually matters); this
 * describe pins the tag-form matrix, which is too wide to seed a document for
 * one form at a time.
 *
 * The two halves are inseparable and are tested as such: EVERY form a model
 * would read as a delimiter must be neutralised, and NOTHING else may be
 * touched. Brand documents are full of angle brackets, and a containment that
 * mangles them corrupts the analysis in the name of defending it.
 */
describe("containDocumentText", () => {
  /**
   * Forms that function as a close (or a forged open) when a model parses the
   * block. The original fix matched only the first two, so a tag carrying
   * attributes or whitespace before the name escaped the container intact.
   */
  const NEUTRALISED: Array<[string, string]> = [
    ["</brand_documents>", "[/brand_documents]"],
    ["</brand_documents >", "[/brand_documents ]"],
    ["<brand_documents>", "[brand_documents]"],
    // Whitespace before the name — still a close to any tag parser.
    ["</ brand_documents>", "[/ brand_documents]"],
    ["< /brand_documents>", "[ /brand_documents]"],
    ["</\tbrand_documents>", "[/\tbrand_documents]"],
    // Attributes. A close tag with attributes is invalid XML, and a model
    // reads it as a close anyway — which is the only thing that matters here.
    ['</brand_documents lang="en">', '[/brand_documents lang="en"]'],
    ['<brand_documents source="x">', '[brand_documents source="x"]'],
    // Self-closing: not a close in XML, but a forged empty block in practice.
    ["<brand_documents/>", "[brand_documents/]"],
    ["</brand_documents/>", "[/brand_documents/]"],
    // Case is the model's business, not the parser's.
    ["</BRAND_DOCUMENTS>", "[/BRAND_DOCUMENTS]"],
    ["</Brand_Documents >", "[/Brand_Documents ]"],
  ];

  for (const [form, contained] of NEUTRALISED) {
    it(`neutralises ${JSON.stringify(form)}`, () => {
      expect(containDocumentText(`önce ${form} sonra`)).toBe(
        `önce ${contained} sonra`,
      );
    });
  }

  it("neutralises every occurrence, not just the first", () => {
    expect(
      containDocumentText('</brand_documents> x <brand_documents a="1"> y'),
    ).toBe('[/brand_documents] x [brand_documents a="1"] y');
  });

  /**
   * The other half. Every string here is something a real brand document says,
   * and each one must survive byte for byte.
   */
  const UNTOUCHED = [
    "Kayıp oranı <5% churn. 2025 > 2024.",
    "Etiket: <documents> ve <brand> kullanılır.",
    '<div class="hero"><p>Pasted markup</p></div>',
    // The tag NAME in prose, with no angle brackets, is just a word.
    "The container is called brand_documents in the prompt.",
    // A different tag whose name merely starts the same way.
    "<brand_documents_v2>",
    "</brand_documentsx>",
    // An unterminated bracket must not swallow the rest of the paragraph.
    // Both halves of this fixture are load-bearing: the SPACE after the name
    // gets it past the separator lookahead, and the ">" on the LATER line is
    // what a newline-crossing attribute run would reach for. Drop either and
    // the string stops distinguishing a contained pattern from a greedy one.
    "<brand_documents bölümü şöyle açılır\nve 2025 > 2024 olur.",
    // Escaped form: the extractor decodes these, so by the time text reaches
    // containDocumentText they are literal — an entity that survived is prose.
    "&lt;/brand_documents&gt;",
    "a < b and b > c",
  ];

  for (const text of UNTOUCHED) {
    it(`leaves ${JSON.stringify(text)} untouched`, () => {
      expect(containDocumentText(text)).toBe(text);
    });
  }
});
