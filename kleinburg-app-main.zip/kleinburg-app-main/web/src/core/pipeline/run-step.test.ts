import { randomUUID } from "node:crypto";
import { and, eq, inArray } from "drizzle-orm";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";

import { closeDb, getDb } from "../db/client";
import {
  brands,
  documents,
  projects,
  stepContents,
  type WorkflowStep,
} from "../db/schema";
import { LlmPermanentError } from "../llm/errors";
import { createJob, getJob } from "../jobs/jobs";
import { handleGenerateJob } from "../jobs/worker";
import {
  attachRetrievedSources,
  NO_RETRIEVED_MATERIAL,
  runStep,
  serializeRetrievedMaterial,
  type RunStepDeps,
} from "./run-step";
import { RESEARCH_MODEL } from "../llm/models";
import { researchRetrievalSchema } from "./schemas";
import type { Citation } from "../llm/openrouter";
import type { JobInput } from "./inputs";

import { hasDb } from "@/test/db-gate";

const createdBrandIds: string[] = [];

async function makeProject(brandName = "brand") {
  const db = getDb();
  const [brand] = await db
    .insert(brands)
    .values({ name: `${brandName}-${randomUUID()}` })
    .returning();
  createdBrandIds.push(brand.id);
  const [project] = await db
    .insert(projects)
    .values({ brandId: brand.id, name: `p-${randomUUID()}`, language: "tr" })
    .returning();
  return project;
}

async function seedStep(
  projectId: string,
  step: WorkflowStep,
  content: unknown,
  selections: unknown = null,
) {
  await getDb()
    .insert(stepContents)
    .values({ projectId, step, content, selections });
}

async function seedDocument(projectId: string, text: string) {
  await getDb().insert(documents).values({
    projectId,
    filename: "doc.txt",
    kind: "url",
    extractedText: text,
  });
}

type FakeCall = {
  prompt: string;
  model: string;
  jobId?: string;
  maxTokens?: number;
};

/**
 * A fake generateStructured that records its opts and returns a fixed value.
 *
 * The fixture goes through `opts.schema.parse` — the very STEP_SCHEMAS[step]
 * entry the real generateStructured validates against — so a fixture that
 * drifts from its schema fails HERE, loudly, instead of flowing into runStep as
 * a shape production can never produce. This is not belt-and-braces: the old
 * `{ platform, calendar }` calendar fixture survived the whole T33 migration
 * precisely because this fake cast its way past Zod with `as never`, and a
 * production guard sat silently disabled behind green tests for a whole
 * release.
 */
function fakeLlm(
  returnValue: unknown,
  citations: Citation[] = [],
  retrieval: unknown = RETRIEVAL,
) {
  const calls: FakeCall[] = [];
  const deps: RunStepDeps = {
    generateStructured: async (opts) => {
      calls.push({
        prompt: opts.prompt,
        model: opts.model,
        jobId: opts.jobId,
        maxTokens: opts.maxTokens,
      });
      // secondary_data is two calls since #52, and only the FIRST one searches.
      // Dispatching on the schema identity (not on call order) keeps the fake
      // honest if the order ever changes, and keeps citations attached to the
      // retrieval call alone — which is exactly the production behaviour: the
      // writing model has no search and returns no annotations.
      // The cast is only to compare identities: `opts.schema` is the generic
      // ZodType<T> the caller asked for, which TS knows cannot overlap this
      // concrete object type. The runtime check is exactly what we want.
      if ((opts.schema as unknown) === (researchRetrievalSchema as unknown)) {
        const parsedRetrieval = researchRetrievalSchema.parse(retrieval);
        opts.onCitations?.(citations);
        return parsedRetrieval as never;
      }
      const parsed = opts.schema.parse(returnValue);
      return parsed;
    },
  };
  return { deps, calls };
}

/**
 * A fake generateStructured that returns a DIFFERENT value per call, so a test
 * can drive runStep's one-retry path (bad output first, good output second).
 * Each value is schema-parsed, same as fakeLlm.
 */
function fakeLlmSequence(values: unknown[]) {
  const calls: FakeCall[] = [];
  const deps: RunStepDeps = {
    generateStructured: async (opts) => {
      calls.push({
        prompt: opts.prompt,
        model: opts.model,
        jobId: opts.jobId,
        maxTokens: opts.maxTokens,
      });
      return opts.schema.parse(
        values[Math.min(calls.length - 1, values.length - 1)],
      );
    },
  };
  return { deps, calls };
}

// Schema-valid sample outputs per step.
const BRAND_CONTEXT = { brandContext: "## CONTEXT\nAcme is bold." };
// #47: every secondary_data item carries the sources the model attributed to
// it. What SURVIVES into stored content is decided by runStep against the
// citations the call actually returned — see the source-attribution tests.
const ZIPF_URL = "https://example.org/zipf";
const DUNBAR_URL = "https://example.org/dunbar";
const SECONDARY = {
  items: [
    {
      title: "Zipf's law",
      description: "Frequency ∝ 1/rank.",
      sources: [{ url: ZIPF_URL, title: "Zipf, as the model titled it" }],
    },
    {
      title: "Dunbar",
      description: "150 stable relationships.",
      sources: [{ url: DUNBAR_URL, title: "Dunbar, as the model titled it" }],
    },
  ],
};
/** The citations a search-backed call would return for SECONDARY. */
const SECONDARY_CITATIONS: Citation[] = [
  { url: ZIPF_URL, title: "Zipf's law — retrieved title" },
  { url: DUNBAR_URL, title: "Dunbar's number — retrieved title" },
];
/**
 * What the RETRIEVAL call returns (#52): English notes plus the URLs the search
 * model says they came from. The third finding cites a URL that is NOT in
 * SECONDARY_CITATIONS — a URL the search model invented — so every test using
 * this fixture also exercises the filter in serializeRetrievedMaterial.
 */
const FABRICATED_URL = "https://example.org/never-retrieved";
const RETRIEVAL = {
  findings: [
    { note: "Word frequency falls off as 1/rank.", sourceUrls: [ZIPF_URL] },
    { note: "Stable relationships top out near 150.", sourceUrls: [DUNBAR_URL] },
    { note: "Something the search model remembered.", sourceUrls: [FABRICATED_URL] },
  ],
};
const SPARKS = {
  items: [{ title: "The crinkle", description: "Everyone hears the wrapper." }],
};
const PILLARS = {
  pillars: [
    {
      category: "INSPIRATIONAL" as const,
      title: "Bold Mornings",
      topicBlend: "A × B",
      creativeSpark: "spark",
      hook: "hook",
      contentBrief: "brief",
    },
  ],
};
const CATEGORIES = [
  "INSPIRATIONAL",
  "ENTERTAINING",
  "INFORMATIONAL",
] as const;

type PillarCategory = (typeof CATEGORIES)[number];

/**
 * A schema-valid sm_pillars output of exactly `perCategory` pillars in each of
 * the given categories — the shape runStep's count check demands (T26).
 */
function makePillars(
  perCategory: number,
  categories: readonly PillarCategory[] = CATEGORIES,
) {
  const pillars = categories.flatMap((category) =>
    Array.from({ length: perCategory }, (_, i) => ({
      ...PILLARS.pillars[0],
      category,
      title: `${category}-${i}`,
    })),
  );
  return { pillars };
}

/**
 * A well-formed 21-pillar output. 7/7/7 is no longer REQUIRED (the equal split
 * was removed on 2026-07-21 — see the distribution cases below), but it is
 * still legal: 21 total, every category clear of the floor.
 */
const PILLARS_21 = makePillars(7);

const POSTS = {
  posts: [
    {
      platform: "instagram" as const,
      theme: "theme",
      hook: "hook",
      caption: "caption",
      cta: "cta",
      hashtags: ["#a"],
    },
  ],
};


describe.skipIf(!hasDb)("runStep", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("rejects a non-generative step (user_input)", async () => {
    const project = await makeProject();
    await expect(
      runStep(project.id, "user_input", {}, JOB),
    ).rejects.toThrow(/üretken/);
  });

  it("brand_context: gathers brand name + documents and returns output", async () => {
    const project = await makeProject("Acme Corp");
    await seedDocument(project.id, "doc one");
    await seedDocument(project.id, "doc two");
    const { deps, calls } = fakeLlm(BRAND_CONTEXT);

    const out = await runStep(project.id, "brand_context", {}, JOB, deps);

    expect(out).toEqual(BRAND_CONTEXT);
    expect(calls[0].prompt).toContain("Acme Corp");
    expect(calls[0].prompt).toContain("doc one");
    expect(calls[0].prompt).toContain("doc two");
  });

  /**
   * #52. The two-call shape, end to end: Sonar searches, Sonnet writes, and the
   * writing call is the one that produces the step's output.
   */
  it("secondary_data: searches with the research model, then writes with the default", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    const { deps, calls } = fakeLlm(SECONDARY, SECONDARY_CITATIONS);

    const out = await runStep(project.id, "secondary_data", {}, JOB, deps);

    expect(calls).toHaveLength(2);

    // Call 1 SEARCHES. It runs on the search model and asks for findings.
    expect(calls[0].model).toBe(RESEARCH_MODEL);
    expect(calls[0].prompt).toContain("Acme is bold.");
    expect(calls[0].prompt).toContain("`findings`");

    // Call 2 WRITES, on the default model — the whole point of the split is
    // that Sonar never writes the text a person reads (it mangles non-ASCII).
    expect(calls[1].model).toBe("anthropic/claude-sonnet-5");
    expect(calls[1].model).not.toBe(RESEARCH_MODEL);
    expect(calls[1].prompt).toContain("Acme is bold.");
    expect(calls[1].prompt).toContain("`items`");

    // Not toEqual(SECONDARY): runStep rewrites each item's sources against the
    // citations the RETRIEVAL call really returned (#47), replacing the
    // model-written titles with the retrieved ones. The per-item mapping itself
    // is covered by the attachRetrievedSources suite below.
    const items = (out as { items: Array<{ sources: Citation[] }> }).items;
    expect(items).toHaveLength(2);
    expect(items[0].sources).toEqual([SECONDARY_CITATIONS[0]]);
    expect(items[1].sources).toEqual([SECONDARY_CITATIONS[1]]);
  });

  /**
   * #52. What the WRITER is allowed to see. The retrieved material reaches the
   * writing prompt — otherwise the search would be decorative — and a URL the
   * search model invented does NOT, so it can never be copied into an item's
   * sources in the first place.
   */
  it("secondary_data: hands the writer the retrieved documents, minus the invented URL", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    const { deps, calls } = fakeLlm(SECONDARY, SECONDARY_CITATIONS);

    await runStep(project.id, "secondary_data", {}, JOB, deps);

    const writerPrompt = calls[1].prompt;
    // The notes and the retrieved URLs are there…
    expect(writerPrompt).toContain("Word frequency falls off as 1/rank.");
    expect(writerPrompt).toContain(ZIPF_URL);
    expect(writerPrompt).toContain(DUNBAR_URL);
    // …with the citation's own title, not the search model's paraphrase.
    expect(writerPrompt).toContain("Zipf's law — retrieved title");
    // …and the finding whose only URL was never retrieved is gone entirely:
    // both the URL and the note it was hung on.
    expect(writerPrompt).not.toContain(FABRICATED_URL);
    expect(writerPrompt).not.toContain("Something the search model remembered.");
    // And it is genuinely the writer, not the searcher, that got it.
    expect(calls[0].prompt).not.toContain("Word frequency falls off as 1/rank.");
  });

  /**
   * #52. Both calls are billed, so both must be attributed to the job. A step
   * that silently doubled in cost while reporting one call's usage would make
   * the spend cap (#51) guard a number that was never true.
   */
  it("secondary_data: records BOTH calls against the job", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    const { deps, calls } = fakeLlm(SECONDARY, SECONDARY_CITATIONS);

    await runStep(project.id, "secondary_data", {}, "job-52", deps);

    expect(calls.map((c) => c.jobId)).toEqual(["job-52", "job-52"]);
  });

  /**
   * #47 review, hard rule 5. A secondary_data run that retrieves NOTHING is the
   * signature of the failure this whole change exists to prevent — the provider
   * renaming `annotations`, routing moving sonar off a search endpoint, search
   * being silently off — and it currently SUCCEEDS, storing every item
   * unsourced and reverting output quality to pre-#47 with no trace anywhere.
   * Nothing else in the system counts citations. It must at least be named.
   */
  it("secondary_data: warns loudly when the call retrieved zero citations", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    const { deps } = fakeLlm(SECONDARY, []);
    // mockClear, because this file has no global mock restore: a second
    // spyOn returns the SAME mock, still carrying the previous test's calls.
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    warn.mockClear();

    const out = await runStep(project.id, "secondary_data", {}, JOB, deps);

    // Still a success: an honestly empty search must not fail a billed call.
    const items = (out as { items: Array<{ sources: unknown[] }> }).items;
    expect(items.every((i) => i.sources.length === 0)).toBe(true);

    const message = warn.mock.calls.map((c) => String(c[0])).join("\n");
    expect(message).toContain("ZERO retrieved citations");
    // Names the model, which is what separates "the search found nothing" from
    // "we are not running on a search model any more".
    expect(message).toContain(RESEARCH_MODEL);
  });

  /**
   * #52, hard rule 5. A DIFFERENT fault from the one above and it must not read
   * the same in the log: documents WERE fetched, but no finding cited any of
   * them, so serializeRetrievedMaterial throws every finding away and the
   * writing call runs on nothing. That is the retrieval prompt's `sourceUrls`
   * contract breaking, not an empty search — silence here would make a broken
   * contract look exactly like a quiet day on the web.
   */
  it("secondary_data: warns differently when citations came back but no finding used them", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    const { deps, calls } = fakeLlm(SECONDARY, SECONDARY_CITATIONS, {
      findings: [
        { note: "Recalled, not retrieved.", sourceUrls: [FABRICATED_URL] },
      ],
    });
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    warn.mockClear();

    await runStep(project.id, "secondary_data", {}, JOB, deps);

    const message = warn.mock.calls.map((c) => String(c[0])).join("\n");
    expect(message).toContain("but no finding cited any of them");
    expect(message).toContain("2 document(s)");
    // NOT the empty-search warning: citations did come back.
    expect(message).not.toContain("ZERO retrieved citations");
    // And the writer was told plainly that it has nothing to stand behind,
    // rather than being handed an empty block to fill in.
    expect(calls[1].prompt).toContain(NO_RETRIEVED_MATERIAL);
  });

  it("secondary_data: stays quiet when the call did retrieve citations", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    const { deps } = fakeLlm(SECONDARY, SECONDARY_CITATIONS);
    // mockClear, because this file has no global mock restore: a second
    // spyOn returns the SAME mock, still carrying the previous test's calls.
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    warn.mockClear();

    await runStep(project.id, "secondary_data", {}, JOB, deps);

    expect(
      warn.mock.calls.map((c) => String(c[0])).join("\n"),
    ).not.toContain("ZERO retrieved citations");
  });

  it("creative_sparks: consumes brand_context AND user_input text", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    await seedStep(project.id, "user_input", { text: "coffee lovers" });
    const { deps, calls } = fakeLlm(SPARKS);

    const out = await runStep(project.id, "creative_sparks", {}, JOB, deps);

    expect(out).toEqual(SPARKS);
    expect(calls[0].prompt).toContain("coffee lovers");
    // T28: the audience comes from the brand context, so the step is useless
    // without it reaching the prompt.
    expect(calls[0].prompt).toContain("Acme is bold.");
  });

  it("creative_sparks: refuses to run without a brand context", async () => {
    const project = await makeProject();
    await seedStep(project.id, "user_input", { text: "coffee lovers" });
    const { deps } = fakeLlm(SPARKS);

    // Failing loudly beats generating sparks about nobody in particular.
    await expect(
      runStep(project.id, "creative_sparks", {}, JOB, deps),
    ).rejects.toThrow("Önce marka bağlamı üretilmeli");
  });

  it("sm_pillars: consumes selected secondary_data + sparks", async () => {
    const project = await makeProject("Acme Corp");
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    // Only the second secondary_data item is selected.
    await seedStep(project.id, "secondary_data", SECONDARY, {
      selectedIndices: [1],
    });
    await seedStep(project.id, "creative_sparks", SPARKS);
    const { deps, calls } = fakeLlm(PILLARS_21);

    const out = await runStep(project.id, "sm_pillars", {}, JOB, deps);

    expect(out).toEqual(PILLARS_21);
    // Selected item present, unselected item absent.
    expect(calls[0].prompt).toContain("Dunbar");
    expect(calls[0].prompt).not.toContain("Zipf");
    expect(calls[0].prompt).toContain("The crinkle");
  });

  // Regression: sm_pillars stores its entries under `pillars`, not `items`, so
  // the shared selected-items reader used to return [] and render an EMPTY
  // {selected_pillars} block into the sm_posts / content_calendar prompts.
  it("sm_posts: the selected pillars actually reach the prompt", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    await seedStep(project.id, "secondary_data", SECONDARY);
    await seedStep(project.id, "sm_pillars", PILLARS);
    const { deps, calls } = fakeLlm(POSTS);

    await runStep(project.id, "sm_posts", {}, JOB, deps);

    expect(calls[0].prompt).toContain("Bold Mornings");
  });
  it("sm_posts (instagram default): tags posts and uses the instagram prompt", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    await seedStep(project.id, "secondary_data", SECONDARY);
    await seedStep(project.id, "sm_pillars", PILLARS);
    const { deps, calls } = fakeLlm(POSTS);

    const out = (await runStep(project.id, "sm_posts", {}, JOB, deps)) as {
      posts: Array<{ platform: string }>;
    };

    expect(out.posts[0].platform).toBe("instagram");
    expect(calls[0].prompt).toContain("Instagram");
    expect(calls[0].prompt).not.toContain("Facebook craft rules");
  });

  it("sm_posts (facebook): selects the facebook prompt and tags posts facebook", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    await seedStep(project.id, "secondary_data", SECONDARY);
    await seedStep(project.id, "sm_pillars", PILLARS);
    // The model returns instagram posts; runStep must re-tag to the requested platform.
    const { deps, calls } = fakeLlm(POSTS);

    const input: JobInput = { platform: "facebook" };
    const out = (await runStep(
      project.id,
      "sm_posts",
      input,
      JOB,
      deps,
    )) as { posts: Array<{ platform: string }> };

    expect(out.posts[0].platform).toBe("facebook");
    // Distinguishing text of the facebook prompt (the instagram prompt never
    // mentions Facebook at all).
    expect(calls[0].prompt).toContain("Facebook craft rules");
  });

  // ── THE SLICE MERGE (T20) ────────────────────────────────────────────────
  // The worker persists runStep's return value with upsertStepContent, which
  // REPLACES content. So runStep must return the MERGED set, or generating one
  // platform silently deletes the other's posts (the legacy bug).
  it("sm_posts: generating FACEBOOK preserves the existing instagram posts", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    await seedStep(project.id, "secondary_data", SECONDARY);
    await seedStep(project.id, "sm_pillars", PILLARS);
    // Instagram posts already stored (from a prior generation).
    await seedStep(project.id, "sm_posts", {
      posts: [
        { ...POSTS.posts[0], theme: "ig-a" },
        { ...POSTS.posts[0], theme: "ig-b" },
      ],
    });
    const { deps } = fakeLlm({
      posts: [{ ...POSTS.posts[0], theme: "fb-new" }],
    });

    const out = (await runStep(
      project.id,
      "sm_posts",
      { platform: "facebook" },
      JOB,
      deps,
    )) as { posts: Array<{ platform: string; theme: string }> };

    expect(out.posts.map((p) => p.theme)).toEqual(["ig-a", "ig-b", "fb-new"]);
    expect(out.posts.map((p) => p.platform)).toEqual([
      "instagram",
      "instagram",
      "facebook",
    ]);
  });

  it("sm_posts: regenerating INSTAGRAM replaces only the instagram slice", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    await seedStep(project.id, "secondary_data", SECONDARY);
    await seedStep(project.id, "sm_pillars", PILLARS);
    await seedStep(project.id, "sm_posts", {
      posts: [
        { ...POSTS.posts[0], theme: "ig-old" },
        { ...POSTS.posts[0], platform: "facebook", theme: "fb-keep" },
      ],
    });
    const { deps } = fakeLlm({
      posts: [{ ...POSTS.posts[0], theme: "ig-fresh" }],
    });

    const out = (await runStep(
      project.id,
      "sm_posts",
      { platform: "instagram" },
      JOB,
      deps,
    )) as { posts: Array<{ platform: string; theme: string }> };

    expect(out.posts.map((p) => p.theme)).toEqual(["fb-keep", "ig-fresh"]);
    expect(out.posts.map((p) => p.platform)).toEqual(["facebook", "instagram"]);
  });

  it("sm_posts: the MERGED set is what the worker persists (end-to-end)", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    await seedStep(project.id, "secondary_data", SECONDARY);
    await seedStep(project.id, "sm_pillars", PILLARS);
    await seedStep(project.id, "sm_posts", {
      posts: [{ ...POSTS.posts[0], theme: "ig-existing" }],
    });
    const { deps } = fakeLlm({
      posts: [{ ...POSTS.posts[0], theme: "fb-generated" }],
    });

    // Drive the REAL worker path (runStep -> markSucceeded -> upsertStepContent).
    const job = await createJob(
      project.id,
      "sm_posts",
      { platform: "facebook" },
      null,
    );
    await handleGenerateJob(job.id, {
      runStep: (projectId, step, input, jobId) =>
        runStep(projectId, step, input, jobId, deps),
    });

    expect((await getJob(job.id))?.status).toBe("succeeded");
    const [row] = await getDb()
      .select()
      .from(stepContents)
      .where(
        and(
          eq(stepContents.projectId, project.id),
          eq(stepContents.step, "sm_posts"),
        ),
      );
    const stored = (row?.content as { posts: Array<{ theme: string }> }).posts;
    // Both platforms are in the DB after a facebook-only generation.
    expect(stored.map((p) => p.theme)).toEqual(["ig-existing", "fb-generated"]);
  });
  // ── OUTPUT-COUNT ENFORCEMENT (T26) ───────────────────────────────────────
  // Counts are checked after schema parsing, with ONE retry, then an honest
  // failure naming the actual numbers.

  /** Seed everything sm_pillars needs. */
  async function projectReadyForPillars() {
    const project = await makeProject("Acme Corp");
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    await seedStep(project.id, "secondary_data", SECONDARY);
    await seedStep(project.id, "creative_sparks", SPARKS);
    return project;
  }

  /** Seed everything sm_posts needs, with `pillarCount` selected pillars. */
  async function projectReadyForPosts(pillarCount: number) {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    await seedStep(project.id, "secondary_data", SECONDARY);
    await seedStep(project.id, "sm_pillars", makePillars(pillarCount / 3));
    return project;
  }

  it("sm_pillars: an even 21 (7/7/7) passes with a single call", async () => {
    const project = await projectReadyForPillars();
    const { deps, calls } = fakeLlm(PILLARS_21);

    const out = await runStep(project.id, "sm_pillars", {}, JOB, deps);

    expect(out).toEqual(PILLARS_21);
    expect(calls).toHaveLength(1);
  });

  // ── THE 7/7/7 EQUAL SPLIT WAS REMOVED (2026-07-21) ─────────────────────
  // The prompt used to demand exactly 7 pillars per category and checkCounts
  // enforced it. The product owner killed the equal split after a live run:
  // the brand talks to CMOs about AI strategy, the INFORMATIONAL block was
  // good and usable, and the INSPIRATIONAL ones read "very cheesey". That is
  // structural, not luck — demanding 7 inspirational pillars from a brand with
  // no inspirational register forces the model to manufacture them, and
  // manufactured inspiration reads as cheese. The mix now follows the brand.
  //
  // What survives is a TOTAL RANGE (10–24; downstream posts = pillars x 1) and
  // a FLOOR per category, so a skew cannot collapse the mix to one note. The
  // range replaced an exact-21 check on 2026-07-24 (Elif, issue #21): top
  // models miss the exact number by one or two and failing the whole run over
  // that is worse than a slightly different count.

  it("sm_pillars: a hard skew (15/3/3) is LEGAL now that the mix follows the brand", async () => {
    // INVERTED from "a correct total with a skewed 9/7/5 split still fails".
    // 15/3/3 is the most extreme split the floor permits, so if anything still
    // enforces an even distribution it fails here.
    const project = await projectReadyForPillars();
    const skewed = {
      pillars: [
        ...makePillars(15, ["INSPIRATIONAL"]).pillars,
        ...makePillars(3, ["ENTERTAINING"]).pillars,
        ...makePillars(3, ["INFORMATIONAL"]).pillars,
      ],
    };
    const { deps, calls } = fakeLlm(skewed);

    const out = await runStep(project.id, "sm_pillars", {}, JOB, deps);

    expect(out).toEqual(skewed);
    // One call: a legal split must not trigger the retry either.
    expect(calls).toHaveLength(1);
  });

  it("sm_pillars: the old 9/7/5 split now passes too", async () => {
    // This exact fixture was the "still fails" case before the reversal.
    const project = await projectReadyForPillars();
    const skewed = {
      pillars: [
        ...makePillars(9, ["INSPIRATIONAL"]).pillars,
        ...makePillars(7, ["ENTERTAINING"]).pillars,
        ...makePillars(5, ["INFORMATIONAL"]).pillars,
      ],
    };
    const { deps } = fakeLlm(skewed);

    await expect(
      runStep(project.id, "sm_pillars", {}, JOB, deps),
    ).resolves.toEqual(skewed);
  });

  it("sm_pillars: a category BELOW the floor fails, naming the floor", async () => {
    // 17/2/2 = 21, so the total is right and only the floor catches it. The
    // message is asserted verbatim: it is what the user reads.
    const project = await projectReadyForPillars();
    const starved = {
      pillars: [
        ...makePillars(17, ["INSPIRATIONAL"]).pillars,
        ...makePillars(2, ["ENTERTAINING", "INFORMATIONAL"]).pillars,
      ],
    };
    const { deps, calls } = fakeLlm(starved);

    await expect(
      runStep(project.id, "sm_pillars", {}, JOB, deps),
    ).rejects.toThrow(
      "Model içerik sütunlarını 17/2/2 dağıttı; her kategoride en az 3 olmalı (INSPIRATIONAL/ENTERTAINING/INFORMATIONAL). Tekrar deneyin.",
    );
    // Still the post-parse + one-retry design, not a schema failure.
    expect(calls).toHaveLength(2);
  });

  it("sm_pillars: a category at EXACTLY the floor passes", async () => {
    // The boundary: 3 is legal, 2 is not. Without this, an off-by-one in the
    // comparison (> instead of >=) would go unnoticed.
    const project = await projectReadyForPillars();
    const atFloor = {
      pillars: [
        ...makePillars(3, ["INSPIRATIONAL"]).pillars,
        ...makePillars(3, ["ENTERTAINING"]).pillars,
        ...makePillars(15, ["INFORMATIONAL"]).pillars,
      ],
    };
    const { deps } = fakeLlm(atFloor);

    await expect(
      runStep(project.id, "sm_pillars", {}, JOB, deps),
    ).resolves.toEqual(atFloor);
  });

  it("sm_pillars: an empty category fails on the floor, not silently", async () => {
    // The step-7 UI groups by category, and a zero category means one of those
    // groups simply never renders.
    const project = await projectReadyForPillars();
    const missing = {
      pillars: [
        ...makePillars(11, ["INSPIRATIONAL"]).pillars,
        ...makePillars(10, ["ENTERTAINING"]).pillars,
      ],
    };
    const { deps } = fakeLlm(missing);

    await expect(
      runStep(project.id, "sm_pillars", {}, JOB, deps),
    ).rejects.toThrow(/11\/10\/0 dağıttı; her kategoride en az 3 olmalı/);
  });

  it("sm_pillars: ABOVE the max total fails even when every floor is met", async () => {
    // 9/9/9 = 27, above the 24 ceiling. Every category clears the floor, so
    // only the ceiling catches it — the ceiling bounds cost (posts = pillars x 1).
    // 24 itself is legal (boundary), 27 is not.
    const project = await projectReadyForPillars();
    const tooMany = { pillars: makePillars(9).pillars };
    const { deps } = fakeLlm(tooMany);

    await expect(
      runStep(project.id, "sm_pillars", {}, JOB, deps),
    ).rejects.toThrow(
      "Model 27 içerik sütunu üretti (kategori dağılımı: 9/9/9); 10-24 arası olmalı. Tekrar deneyin.",
    );
  });

  it("sm_pillars: a mid-range total that isn't 21 PASSES (the #21 fix)", async () => {
    // 8/7/7 = 22. Not the 21 target, but inside 10–24 with every floor met.
    // Before the range this failed with "21 yerine 22"; that exact-count
    // rejection is exactly what issue #21 removed.
    const project = await projectReadyForPillars();
    const twentyTwo = {
      pillars: [
        ...makePillars(8, ["INSPIRATIONAL"]).pillars,
        ...makePillars(7, ["ENTERTAINING", "INFORMATIONAL"]).pillars,
      ],
    };
    const { deps } = fakeLlm(twentyTwo);

    await expect(
      runStep(project.id, "sm_pillars", {}, JOB, deps),
    ).resolves.toEqual(twentyTwo);
  });

  it("sm_pillars: a short first result is retried ONCE and the retry is kept", async () => {
    const project = await projectReadyForPillars();
    // 6 (2/2/2) is below the 10 minimum, so the first result is retried.
    const { deps, calls } = fakeLlmSequence([makePillars(2), PILLARS_21]);

    const out = await runStep(project.id, "sm_pillars", {}, JOB, deps);

    expect(out).toEqual(PILLARS_21);
    expect(calls).toHaveLength(2);
    // The retry re-asks with the SAME prompt.
    expect(calls[1].prompt).toBe(calls[0].prompt);
  });

  it("sm_pillars: BELOW the min total throws after the retry, naming the range", async () => {
    const project = await projectReadyForPillars();
    // 9 pillars: 3 / 3 / 3. Every category clears the floor, so only the
    // 10-minimum catches it. Both the first result and the retry are short.
    const short = { pillars: makePillars(3).pillars };
    const { deps, calls } = fakeLlm(short);

    await expect(
      runStep(project.id, "sm_pillars", {}, JOB, deps),
    ).rejects.toThrow(/9 içerik sütunu.*3\/3\/3.*10-24 arası olmalı/);
    expect(calls).toHaveLength(2);
  });

  it("sm_posts: the expected count is selected pillars × posts_per_pillar", async () => {
    // 6 selected pillars, 1 post each -> 6 posts is correct.
    const project = await projectReadyForPosts(6);
    const six = { posts: Array.from({ length: 6 }, () => POSTS.posts[0]) };
    const { deps, calls } = fakeLlm(six);

    const out = (await runStep(project.id, "sm_posts", {}, JOB, deps)) as {
      posts: unknown[];
    };

    expect(out.posts).toHaveLength(6);
    expect(calls).toHaveLength(1);
  });

  it("sm_posts: a short first result is retried ONCE and the retry is kept", async () => {
    const project = await projectReadyForPosts(6);
    const six = { posts: Array.from({ length: 6 }, () => POSTS.posts[0]) };
    const four = { posts: Array.from({ length: 4 }, () => POSTS.posts[0]) };
    const { deps, calls } = fakeLlmSequence([four, six]);

    const out = (await runStep(project.id, "sm_posts", {}, JOB, deps)) as {
      posts: unknown[];
    };

    expect(out.posts).toHaveLength(6);
    expect(calls).toHaveLength(2);
  });

  it("sm_posts: two short results throw naming actual vs expected", async () => {
    const project = await projectReadyForPosts(6);
    const four = { posts: Array.from({ length: 4 }, () => POSTS.posts[0]) };
    const { deps, calls } = fakeLlm(four);

    await expect(
      runStep(project.id, "sm_posts", {}, JOB, deps),
    ).rejects.toThrow(/6 yerine 4 gönderi/);
    expect(calls).toHaveLength(2);
  });

  it("sm_posts: only the SELECTED pillars size the expectation", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    await seedStep(project.id, "secondary_data", SECONDARY);
    // 21 pillars stored, but only 2 selected -> 2 posts expected.
    await seedStep(project.id, "sm_pillars", PILLARS_21, {
      selectedIndices: [0, 1],
    });
    const two = { posts: [POSTS.posts[0], POSTS.posts[0]] };
    const { deps, calls } = fakeLlm(two);

    await runStep(project.id, "sm_posts", {}, JOB, deps);

    expect(calls).toHaveLength(1);
  });

  // ── CALENDAR: BUILT, NOT GENERATED (T33) ─────────────────────────────────
  //
  // This section used to be "COMPLETION LIMIT + TRUNCATION (T26)" and guarded a
  // model call: a completion ceiling, a truncation check, a count-drift retry.
  // None of those exist any more — the step schedules approved posts in code —
  // so the section covers what replaced them: no model call, and an honest
  // shortfall when there are fewer approved posts than requested rows.

  /**
   * Seed everything content_calendar needs, with explicit per-platform counts so
   * a fixture can be a handful of rows rather than the registry default.
   * `instagram` must always be present: the seeded sm_posts are instagram, and
   * the active-platform set unions the project's choice with the posts'.
   */
  async function projectReadyForCalendar(counts: Record<string, number>) {
    const project = await makeProject();
    await getDb()
      .update(projects)
      .set({ platforms: Object.keys(counts), postCounts: counts })
      .where(eq(projects.id, project.id));
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    await seedStep(project.id, "sm_pillars", PILLARS);
    await seedStep(project.id, "sm_posts", POSTS);
    return project;
  }

  /**
   * The calendar is BUILT, not generated. Every word it shows already exists in
   * the approved posts, so the step schedules rather than writes.
   *
   * This test is the whole point of the change: no model call at all. It is
   * asserted on `calls` rather than on the output, because a builder that
   * happened to produce the right rows while still paying for a generation
   * would satisfy any output-shaped assertion and none of the reasons this was
   * done — the ~84k-token ceiling, the #46 truncation, the count-drift retry.
   */
  it("content_calendar: schedules the approved posts without calling a model", async () => {
    const project = await projectReadyForCalendar({ instagram: 1 });
    const { deps, calls } = fakeLlm({ calendars: [] });

    const out = (await runStep(
      project.id,
      "content_calendar",
      {},
      JOB,
      deps,
    )) as { calendars: Array<{ platform: string; rows: Array<{ caption: string }> }> };

    expect(calls).toHaveLength(0);
    expect(out.calendars).toHaveLength(1);
    expect(out.calendars[0].platform).toBe("instagram");
    // The approved post's own words, copied rather than rewritten.
    expect(out.calendars[0].rows[0].caption).toBe("caption");
  });

  it("content_calendar: reports a shortfall instead of failing the step", async () => {
    // Three posts asked for, one approved post exists. The old step fabricated
    // the missing two; a builder cannot, and refusing outright would throw away
    // a usable calendar. So it schedules what exists and says so.
    const project = await projectReadyForCalendar({ instagram: 3 });
    const { deps, calls } = fakeLlm({ calendars: [] });

    const out = (await runStep(
      project.id,
      "content_calendar",
      {},
      JOB,
      deps,
    )) as { shortfalls?: Array<{ platform: string; requested: number; scheduled: number }> };

    expect(calls).toHaveLength(0);
    expect(out.shortfalls).toEqual([
      { platform: "instagram", requested: 3, scheduled: 1 },
    ]);
  });

  it("missing prerequisite: secondary_data without brand_context throws", async () => {
    const project = await makeProject();
    const { deps } = fakeLlm(SECONDARY);
    await expect(
      runStep(project.id, "secondary_data", {}, JOB, deps),
    ).rejects.toThrow("Önce marka bağlamı üretilmeli");
  });

  /**
   * #52, hard rule 5. A failing SEARCH must fail the step, not fall through to
   * the writing call.
   *
   * This is the failure mode the split makes dangerous. Before #52 a dead
   * search provider failed the one call and the step failed with it. Now the
   * writing call could happily produce 20 plausible entries with no material at
   * all, so swallowing the retrieval error would produce a full, unsourced,
   * successful-looking result — the "research step that researched nothing"
   * bug, back again and now invisible, because the output no longer looks
   * degraded.
   *
   * The assertion is on the CALL COUNT, not just the throw: a version that
   * caught the error and carried on would still look right from the outside.
   */
  it("secondary_data: a failing retrieval call never reaches the writing call", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    const calls: string[] = [];
    const deps: RunStepDeps = {
      generateStructured: async (opts) => {
        calls.push(opts.model);
        throw new LlmPermanentError(
          `OpenRouter isteği kalıcı olarak başarısız oldu (model: ${opts.model})`,
        );
      },
    };

    await expect(
      runStep(project.id, "secondary_data", {}, JOB, deps),
    ).rejects.toThrow(RESEARCH_MODEL);

    // Exactly one call was attempted, and it was the search.
    expect(calls).toEqual([RESEARCH_MODEL]);
  });

  it("propagates an LlmPermanentError from generateStructured", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    const deps: RunStepDeps = {
      generateStructured: vi.fn(async () => {
        throw new LlmPermanentError("Model çıktısı beklenen şemaya uymadı");
      }),
    };
    await expect(
      runStep(project.id, "secondary_data", {}, JOB, deps),
    ).rejects.toThrow("beklenen şemaya uymadı");
  });
});

describe.skipIf(!hasDb)("runStep via worker", () => {
  afterAll(async () => {
    const db = getDb();
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("succeeds and upserts step_contents through the worker path", async () => {
    const project = await makeProject();
    await seedStep(project.id, "brand_context", BRAND_CONTEXT);
    const job = await createJob(project.id, "secondary_data", {}, null);

    const runStepDep = vi.fn().mockResolvedValue(SECONDARY);
    await handleGenerateJob(job.id, { runStep: runStepDep });

    expect((await getJob(job.id))?.status).toBe("succeeded");
    const [content] = await getDb()
      .select()
      .from(stepContents)
      .where(
        and(
          eq(stepContents.projectId, project.id),
          eq(stepContents.step, "secondary_data"),
        ),
      );
    expect(content?.content).toEqual(SECONDARY);
  });

  it("fails the job and writes NO step_contents when runStep throws", async () => {
    const project = await makeProject();
    const job = await createJob(project.id, "secondary_data", {}, null);

    const runStepDep = vi.fn().mockRejectedValue(
      new LlmPermanentError("Model çıktısı beklenen şemaya uymadı"),
    );

    await expect(
      handleGenerateJob(job.id, { runStep: runStepDep }),
    ).rejects.toThrow("beklenen şemaya uymadı");

    const after = await getJob(job.id);
    expect(after?.status).toBe("failed");
    expect(after?.error).toContain("beklenen şemaya uymadı");

    const rows = await getDb()
      .select()
      .from(stepContents)
      .where(
        and(
          eq(stepContents.projectId, project.id),
          eq(stepContents.step, "secondary_data"),
        ),
      );
    expect(rows).toHaveLength(0);
  });
});

// ── CALENDAR COMPLETION CEILING (T39 / #46) ─────────────────────────────────
// Not DB-gated: calendarMaxTokens is a pure function of its arguments, so these
// run on every `npm test`, gate open or closed.
//
// The measured runs these numbers answer to (2026-07-20, 58-row calendar):
//   ceiling 31000, 6 approved posts  -> 27537 used, completed
//   ceiling 31000, 24 approved posts -> 31000 used, TRUNCATED
//   ceiling 48000, 24 approved posts -> 25914 used, completed
/**
 * serializeRetrievedMaterial (#52) — the FIRST of the two URL cross-checks, and
 * the one that decides what the writing model is even allowed to see.
 *
 * It is not a duplicate of attachRetrievedSources below. That one keeps a
 * fabricated endpoint out of the STORED OUTPUT; this one keeps it out of the
 * writer's PROMPT, so there is nothing to copy in the first place. Pure
 * function, so no DB gate.
 */
/** #68: runStep now requires a jobId, so every call in this file names one. */
const JOB = "job-run-step-test";

describe("serializeRetrievedMaterial", () => {
  const REAL = "https://example.org/real";
  const CITATION: Citation = { url: REAL, title: "A real document" };

  it("passes through a finding whose URL was really retrieved", () => {
    const out = serializeRetrievedMaterial(
      [{ note: "A retrieved fact.", sourceUrls: [REAL] }],
      [CITATION],
    );
    expect(out).toContain("A retrieved fact.");
    expect(out).toContain(REAL);
    // The citation's title, not the search model's words.
    expect(out).toContain("A real document");
    expect(out).not.toBe(NO_RETRIEVED_MATERIAL);
  });

  it("drops a finding whose only URL was never retrieved — note and all", () => {
    const out = serializeRetrievedMaterial(
      [{ note: "Recalled, not retrieved.", sourceUrls: ["https://example.org/fake"] }],
      [CITATION],
    );
    // NOT merely "the URL is stripped": the note goes too. A note with no
    // retrieved document behind it is the search model's memory, and passing it
    // on dressed as research is the failure mode this step keeps having.
    expect(out).not.toContain("Recalled, not retrieved.");
    expect(out).not.toContain("example.org/fake");
    expect(out).toBe(NO_RETRIEVED_MATERIAL);
  });

  it("keeps the grounded finding and drops the ungrounded one from the same call", () => {
    const out = serializeRetrievedMaterial(
      [
        { note: "Grounded.", sourceUrls: [REAL] },
        { note: "Ungrounded.", sourceUrls: ["https://example.org/fake"] },
      ],
      [CITATION],
    );
    // Different STATES, not just different text: one survives, one vanishes.
    expect(out).toContain("Grounded.");
    expect(out).not.toContain("Ungrounded.");
  });

  it("matches a retrieved URL through tracking params and a trailing slash", () => {
    // The same urlKey normalisation attachRetrievedSources uses — Perplexity
    // hands back referral-tagged URLs, and dropping a real source over a utm_
    // parameter costs the reviewer a check they could have made.
    const out = serializeRetrievedMaterial(
      [{ note: "Grounded.", sourceUrls: [`${REAL}/?utm_source=perplexity`] }],
      [CITATION],
    );
    expect(out).toContain("Grounded.");
  });

  it("says so plainly when nothing was retrieved at all", () => {
    expect(serializeRetrievedMaterial([], [])).toBe(NO_RETRIEVED_MATERIAL);
    // And the message tells the writer what to DO, not just that the block is
    // empty — an empty block invites the model to fill it.
    expect(NO_RETRIEVED_MATERIAL).toContain("empty `sources` array");
  });
});

/**
 * attachRetrievedSources (#47) — the cross-check that keeps a model-WRITTEN
 * URL from being displayed on its own authority. An item keeps a source only
 * when the same URL also appears in the citations the call really retrieved,
 * and the retrieved title wins over the model's paraphrase. Pure function, so
 * no DB gate.
 */
describe("attachRetrievedSources", () => {
  const CITED: Citation = {
    url: "https://example.org/zipf",
    title: "Zipf's law — retrieved title",
  };

  function item(sources: Array<{ url: string; title: string }>) {
    return { title: "t", description: "d", sources };
  }

  it("keeps a claimed source that the call really retrieved, with the retrieved title", () => {
    const out = attachRetrievedSources(
      { items: [item([{ url: CITED.url, title: "model's own paraphrase" }])] },
      [CITED],
    ) as { items: Array<{ sources: Citation[] }> };

    expect(out.items[0].sources).toEqual([CITED]);
  });

  it("drops a source the call never retrieved — the fabrication case", () => {
    const out = attachRetrievedSources(
      { items: [item([{ url: "https://example.org/invented", title: "x" }])] },
      [CITED],
    ) as { items: Array<{ sources: Citation[] }> };

    expect(out.items[0].sources).toEqual([]);
  });

  it("empties every item when nothing was retrieved at all", () => {
    // The visible alarm for a research step that silently is not one: whatever
    // the model wrote, a call with no citations has sourced nothing.
    const out = attachRetrievedSources(
      { items: [item([{ url: CITED.url, title: "x" }])] },
      [],
    ) as { items: Array<{ sources: Citation[] }> };

    expect(out.items[0].sources).toEqual([]);
  });

  it("matches URLs across a trailing slash and whitespace, and dedupes", () => {
    const out = attachRetrievedSources(
      {
        items: [
          item([
            { url: "https://example.org/zipf/", title: "a" },
            { url: " https://example.org/zipf ", title: "b" },
          ]),
        ],
      },
      [CITED],
    ) as { items: Array<{ sources: Citation[] }> };

    expect(out.items[0].sources).toEqual([CITED]);
  });

  /**
   * URL identity (#47 review). Perplexity hands back URLs carrying tracking
   * parameters and fragments; a model writing the same page's clean URL was
   * compared byte-for-byte against them and lost a legitimate source. Failing
   * safe is not the same as working.
   */
  describe("URL normalization", () => {
    function keptFrom(claimed: string, cited: Citation): Citation[] {
      const out = attachRetrievedSources(
        { items: [item([{ url: claimed, title: "model's label" }])] },
        [cited],
      ) as { items: Array<{ sources: Citation[] }> };
      return out.items[0].sources;
    }

    it("matches across tracking parameters on the retrieved URL", () => {
      const tracked: Citation = {
        url: "https://example.org/zipf?utm_source=perplexity&utm_medium=ai&fbclid=xyz",
        title: "Zipf's law — retrieved title",
      };
      expect(keptFrom("https://example.org/zipf", tracked)).toEqual([tracked]);
    });

    it("matches across host case and a fragment", () => {
      expect(
        keptFrom("https://EXAMPLE.org/zipf#section-3", CITED),
      ).toEqual([CITED]);
    });

    it("matches across query parameter order", () => {
      const cited: Citation = { url: "https://example.org/s?a=1&b=2", title: "S" };
      expect(keptFrom("https://example.org/s?b=2&a=1", cited)).toEqual([cited]);
    });

    it("still distinguishes genuinely different pages", () => {
      // The normalization must not over-merge: a meaningful query parameter is
      // NOT tracking, and dropping it would let a URL the call never retrieved
      // satisfy the cross-check — the failure that runs the dangerous way.
      const cited: Citation = { url: "https://example.org/p?id=1", title: "P1" };
      expect(keptFrom("https://example.org/p?id=2", cited)).toEqual([]);
      expect(keptFrom("https://example.org/other", cited)).toEqual([]);
    });

    it("drops an unparseable URL rather than throwing", () => {
      expect(keptFrom("not a url at all", CITED)).toEqual([]);
    });
  });

  it("returns non-secondary-shaped output untouched", () => {
    const passthrough = { brandContext: "not items" };
    expect(attachRetrievedSources(passthrough, [CITED])).toBe(passthrough);
  });
});
