import { afterEach, describe, expect, it, vi } from "vitest";

import {
  ALWAYS_ENOUGH_WORDS,
  assessToneStrength,
  MIN_SECTION_WORDS,
  resetSegmenterForTests,
} from "./tone-strength";

/**
 * T35. The heuristic exists to catch ONE thing: a brand context whose tone
 * section is too thin for the post prompts to work from, which otherwise fails
 * silently (fluent posts that are not the brand's voice).
 *
 * Two properties matter more than any single case:
 *   - it is generous. A false alarm on a rich section trains people to ignore
 *     the warning, so ambiguity resolves to "fine".
 *   - it is not language-keyed. The analysis is written in the project's chosen
 *     language and its headings are translated with it, so the tests below run
 *     the same shapes through Turkish, Japanese and Greek.
 *
 * The fixtures deliberately do NOT all share the prompt template's exact bytes.
 * An earlier suite only ever probed that one shape, so it stayed green while
 * the locator false-alarmed on every reflowed, flattened or annotated variant
 * of a perfectly good section. Those variants are first-class cases below.
 */

/** A full brand context whose last bullet is the tone section under test. */
function contextWith(toneSection: string): string {
  return [
    "## CONTEXT for Brand Key: Örnek Marka",
    "",
    "- **General info:** A regional coffee roaster selling single-origin beans.",
    "- **Values & Personality:** Curious, exacting, unpretentious about craft.",
    "- **Essence:** Coffee worth slowing down for.",
    "- **Target Group:** Urban professionals aged 25-45 who cook at home.",
    toneSection,
  ].join("\n");
}

const RICH_TONE = [
  "- **Tone of voice:**",
  "  - Voice: warm and exacting, the way a roaster talks across the counter to a",
  "    regular. Short declarative sentences, concrete nouns, never a superlative",
  "    where a measurement would do. Speaks to the reader as an equal who is",
  "    curious, not as a novice who needs teaching.",
  '  - Example lines: 1) "This one tastes like the last week of summer." 2) "We',
  '    roasted it three degrees lighter and it changed everything." 3) "Ask us',
  '    what we are drinking today."',
  "  - Never: no hype words, no exclamation marks, no talk of journeys or",
  "    experiences, no calling anyone a coffee lover.",
].join("\n");

describe("assessToneStrength", () => {
  it("passes a rich tone section", () => {
    const result = assessToneStrength(contextWith(RICH_TONE));

    expect(result.weak).toBe(false);
    expect(result.locator).toBe("block");
    expect(result.signals).toBe(3);
  });

  it("flags a tone section that is only the empty template shape", () => {
    // The prompt DEMANDS example lines and a never-say note, so a model with
    // nothing to say still emits the three sub-bullets — empty. Shape alone
    // must not satisfy the heuristic.
    const result = assessToneStrength(
      contextWith(
        [
          "- **Tone of voice:**",
          "  - Voice: —",
          "  - Example lines: —",
          "  - Never: —",
        ].join("\n"),
      ),
    );

    expect(result.weak).toBe(true);
    expect(result.locator).toBe("block");
    expect(result.exampleCount).toBe(0);
  });

  it("flags a one-line tone section", () => {
    const result = assessToneStrength(
      contextWith("- **Tone of voice:** Professional and friendly. (hypothesis)"),
    );

    expect(result.weak).toBe(true);
  });

  it("flags a thin section even when it carries the required shape and quotes", () => {
    // Quoted examples exist, so signal B holds — but one signal is not enough.
    const result = assessToneStrength(
      contextWith(
        [
          "- **Tone of voice:**",
          '  - Voice: modern. Example lines: 1) "Hello there" 2) "Welcome back"',
          "  - Never: clichés.",
        ].join("\n"),
      ),
    );

    expect(result.weak).toBe(true);
    expect(result.signals).toBe(1);
  });

  it("stays silent on a rich section written entirely in Turkish", () => {
    const result = assessToneStrength(
      contextWith(
        [
          "- **Ses tonu:**",
          "  - Ses: sıcak ve net; tezgâhın arkasından konuşan bir kavurmacı gibi.",
          "    Kısa cümleler, somut isimler, ölçünün yeteceği yerde asla abartı yok.",
          '  - Örnek cümleler: 1) "Bu, yazın son haftası gibi kokuyor." 2) "Üç derece',
          '    daha açık kavurduk, her şey değişti." 3) "Bugün ne içiyoruz, sorun."',
          "  - Asla: abartı kelimeler yok, ünlem yok, yolculuk ya da deneyim edebiyatı",
          "    yok, kimseye kahve tutkunu demek yok.",
        ].join("\n"),
      ),
    );

    expect(result.weak).toBe(false);
  });

  it("stays silent on a rich section in a script without word spacing", () => {
    // Japanese + Greek: no shared vocabulary with the English or Turkish cases,
    // and Japanese has no spaces at all — a whitespace word count would read
    // this as a handful of "words" and fire a false alarm.
    const result = assessToneStrength(
      contextWith(
        [
          "- **ブランドの声:**",
          "  - 声: 焙煎士がカウンター越しに常連へ話しかけるような、温かく正確な口調。",
          "    短い断定的な文、具体的な名詞、数値で足りる場面で誇張は使わない。",
          "    読み手を教える相手ではなく、対等な同好の士として扱う。",
          "  - 例文: 1)「夏の終わりの週のような味がする。」 2)「三度浅く焙煎したら",
          "    すべてが変わった。」 3)「今日は何を飲んでいるか聞いてください。」",
          "  - 使わない言葉: 誇張表現、感嘆符、旅や体験という言い回し、コーヒー愛好家という呼びかけ。",
        ].join("\n"),
      ),
    );

    expect(result.weak).toBe(false);
  });

  it("flags a thin section in a non-Latin script the same way", () => {
    const result = assessToneStrength(
      contextWith("- **ブランドの声:** 親しみやすく、プロフェッショナル。"),
    );

    expect(result.weak).toBe(true);
  });

  it("never flags a long tone section that still shows the voice", () => {
    // The generosity valve. Real varied prose, not one token repeated: a
    // paragraph built from `"λέξη ".repeat(70)` exercises the counter's
    // arithmetic and nothing whatsoever about Greek.
    const paragraph = [
      "Ύφος ζεστό και ακριβές, όπως μιλάει ο καβουρδιστής πάνω από τον πάγκο σε",
      "έναν τακτικό πελάτη που ήδη ξέρει τι θέλει. Σύντομες προτάσεις, συγκεκριμένα",
      "ουσιαστικά, μετρήσεις αντί για υπερθετικά, καμία υπόσχεση που δεν μπορεί να",
      "σταθεί μέσα στο φλιτζάνι. Ο αναγνώστης αντιμετωπίζεται ως ίσος και περίεργος,",
      "ποτέ ως αρχάριος που χρειάζεται μάθημα, και ο λόγος μένει πάντα κοντά στο",
      "προϊόν, στη σοδειά, στον χρόνο και στη θερμοκρασία του καβουρδίσματος.",
    ].join("\n  ");
    const result = assessToneStrength(contextWith(`- **Ύφος:** ${paragraph}`));

    expect(result.wordCount).toBeGreaterThanOrEqual(ALWAYS_ENOUGH_WORDS);
    expect(result.weak).toBe(false);
  });

  it("documents the length boundary: one signal short of the word threshold", () => {
    // A shapeless section of exactly MIN_SECTION_WORDS words holds signal A but
    // nothing else — one signal, and under the length override, so it is
    // flagged. This is a `bullet` read, so it must also clear the share guard;
    // standing alone as the whole document, it does.
    const atThreshold = `- **Ton:** ${"kelime ".repeat(MIN_SECTION_WORDS - 1)}son.`;
    const result = assessToneStrength(atThreshold);

    expect(result.locator).toBe("bullet");
    expect(result.wordCount).toBeGreaterThanOrEqual(MIN_SECTION_WORDS);
    expect(result.wordCount).toBeLessThan(ALWAYS_ENOUGH_WORDS);
    expect(result.signals).toBe(1);
    expect(result.weak).toBe(true);
  });

  it("documents the boundary: two signals is enough to stay silent", () => {
    // Same length band as the case above, but now with quoted examples: two
    // signals, and the section passes without ever reaching the word override.
    const result = assessToneStrength(
      contextWith(
        [
          "- **Ton:**",
          `  - Ses: ${"kelime ".repeat(MIN_SECTION_WORDS - 8)}son.`,
          '  - Örnekler: 1) "Bugün ne içiyoruz" 2) "Üç derece daha açık kavurduk"',
        ].join("\n"),
      ),
    );

    expect(result.wordCount).toBeLessThan(ALWAYS_ENOUGH_WORDS);
    expect(result.signals).toBe(2);
    expect(result.weak).toBe(false);
  });

  it("reads the LAST tone block, not an earlier long criterion", () => {
    // A brand context whose earlier criteria are long must not mask a thin tone
    // section at the end — including when an earlier criterion is itself a
    // sub-bulleted block, as Benefits is in the prompt's own template.
    const result = assessToneStrength(
      [
        "- **General info:** " + "word ".repeat(120),
        "- **Benefits:**",
        "  - Functional: " + "word ".repeat(60),
        "  - Emotional: " + "word ".repeat(60),
        "- **Tone of voice:**",
        "  - Voice: —",
        "  - Never: —",
      ].join("\n"),
    );

    expect(result.locator).toBe("block");
    expect(result.weak).toBe(true);
    expect(result.wordCount).toBeLessThan(MIN_SECTION_WORDS);
  });

  it("falls back to the whole text when there is no bullet structure", () => {
    // A hand-edited brand context written as prose: nothing to navigate by, so
    // the whole text is assessed. Any real one clears the override easily.
    const prose = assessToneStrength("Marka hakkında " + "cümle ".repeat(200));

    expect(prose.locator).toBe("text");
    expect(prose.weak).toBe(false);
  });

  it("treats empty, blank and missing content as weak", () => {
    for (const value of ["", "   \n  ", null, undefined]) {
      expect(assessToneStrength(value).weak).toBe(true);
    }
  });

  it("does not count apostrophes as quoted examples", () => {
    // Turkish suffix apostrophes and English contractions would otherwise
    // manufacture "examples" out of ordinary prose.
    const result = assessToneStrength(
      contextWith("- **Ton:** Markanın sesi don't ve markanın tonu."),
    );

    expect(result.exampleCount).toBe(0);
  });
});

/**
 * The verbose-emptiness case: the prompt tells the model to write a strategic
 * hypothesis when the documents cover nothing, so a model with nothing to say
 * does NOT emit a "—" stub. It emits several wordy lines whose literal content
 * is "there is no tone information here" — long enough that a volume-of-words
 * rule waves it through. This is the ACTUAL target of the feature, and it used
 * to be the one case that stayed silent.
 */
describe("assessToneStrength — verbose emptiness", () => {
  it("flags a wordy tone section that contains no example at all", () => {
    const result = assessToneStrength(
      contextWith(
        [
          "- **Tone of voice:** (hypothesis)",
          "  - Voice: The uploaded documents do not contain any explicit tone of",
          "    voice guidance for this brand, so the following is a strategic",
          "    hypothesis that a human should verify before it is used anywhere.",
          "  - Example lines: No example copy was present in the supplied",
          "    documents, so no lines can be quoted here with any confidence.",
          "  - Never: No never-say list could be derived from the documents that",
          "    were provided for this analysis.",
        ].join("\n"),
      ),
    );

    // Wordy enough that length and line-count both hold: under a rule of three
    // interchangeable signals that was two out of three, i.e. silence.
    expect(result.wordCount).toBeGreaterThanOrEqual(MIN_SECTION_WORDS);
    expect(result.signals).toBeGreaterThanOrEqual(2);
    // But not one example fragment, and that is a necessary condition.
    expect(result.exampleCount).toBe(0);
    expect(result.weak).toBe(true);
  });

  it("clears the same section as soon as it carries one real example", () => {
    // The necessary condition is a floor, not a template check: ONE fragment of
    // the brand actually speaking is enough to stop warning.
    const result = assessToneStrength(
      contextWith(
        [
          "- **Tone of voice:** (hypothesis)",
          "  - Voice: The uploaded documents do not contain any explicit tone of",
          "    voice guidance for this brand, so the following is a strategic",
          "    hypothesis that a human should verify before it is used anywhere.",
          '  - Example lines: "Bugün ne içiyoruz, sorun."',
          "  - Never: No never-say list could be derived from the documents that",
          "    were provided for this analysis.",
        ].join("\n"),
      ),
    );

    expect(result.exampleCount).toBeGreaterThanOrEqual(1);
    expect(result.weak).toBe(false);
  });

  it("does not require an example of a read it does not trust", () => {
    // Only a located `block` carries the example requirement. A one-paragraph
    // hand-written voice description quotes nothing and is perfectly fine.
    const result = assessToneStrength(
      "Markanın sesi hakkında uzun bir paragraf. " + "cümle ".repeat(100),
    );

    expect(result.locator).toBe("text");
    expect(result.exampleCount).toBe(0);
    expect(result.weak).toBe(false);
  });
});

/**
 * The locator, against the shapes LLMs and markdown tooling actually produce.
 * Every case here holds a genuinely RICH tone section; every one of them used
 * to fire a false alarm, which is the failure that teaches users to ignore the
 * warning entirely.
 */
describe("assessToneStrength — locating a rich section", () => {
  it("stays silent when the sub-bullets are not indented", () => {
    // Flat nested lists come out of LLMs constantly, out of any markdown
    // normalizer, and out of a user reflowing text in the textarea.
    const flat = RICH_TONE.split("\n")
      .map((line) => line.replace(/^ +/, ""))
      .join("\n");
    const result = assessToneStrength(contextWith(flat));

    expect(result.weak).toBe(false);
  });

  it("stays silent when the enumerated examples sit on their own lines", () => {
    const result = assessToneStrength(
      contextWith(
        [
          "- **Tone of voice:**",
          "  - Voice: warm and exacting, the way a roaster talks across the",
          "    counter to a regular. Short declarative sentences, concrete nouns,",
          "    never a superlative where a measurement would do.",
          "  - Example lines:",
          '    1) "This one tastes like the last week of summer."',
          '    2) "We roasted it three degrees lighter and it changed everything."',
          '    3) "Ask us what we are drinking today."',
          "  - Never: no hype words, no exclamation marks, no talk of journeys.",
        ].join("\n"),
      ),
    );

    expect(result.weak).toBe(false);
  });

  it("stays silent when a trailing bullet follows the tone section", () => {
    // "Last top-level bullet" is not the same thing as "the tone section":
    // models add a closing note, a caveat, a source list.
    const result = assessToneStrength(
      contextWith(
        RICH_TONE + "\n- **Note:** Bu analiz yüklenen dokümanlara dayanır.",
      ),
    );

    expect(result.locator).toBe("block");
    expect(result.weak).toBe(false);
  });

  it("stays silent when the tone section is closed by a heading or a rule", () => {
    for (const closer of ["## Kaynaklar", "===", "---"]) {
      const result = assessToneStrength(
        contextWith(
          `${RICH_TONE}\n\n${closer}\n\nEk not: bu analiz tartışmaya açıktır.`,
        ),
      );

      expect(result.weak).toBe(false);
    }
  });

  it("does not absorb trailing prose into an empty tone section", () => {
    // The reverse failure: a stub plus a closing note plus a sign-off reached
    // enough words to trip the generosity valve, so the emptiest possible tone
    // section went silent.
    const result = assessToneStrength(
      contextWith(
        [
          "- **Tone of voice:**",
          "  - Voice: —",
          "  - Example lines: —",
          "  - Never: —",
          "",
          "Bu analiz yalnızca sağlanan dokümanlara dayanmaktadır ve marka ekibi",
          "tarafından doğrulanmalıdır. Eksik kalan kriterler için ek doküman",
          "paylaşılması halinde analiz yeniden üretilebilir.",
          "",
          "Hazırlayan: kıdemli marka stratejisti. Tüm bulgular tartışmaya açıktır.",
        ].join("\n"),
      ),
    );

    expect(result.locator).toBe("block");
    expect(result.weak).toBe(true);
  });

  it("stays silent rather than guessing when a flat read finds only a fragment", () => {
    // No block shape anywhere, and the last bullet is a sliver of the document:
    // that reads as a locator miss, not as a thin tone section. An unlocatable
    // section must produce silence, not a wolf cry.
    const result = assessToneStrength(
      [
        "- **General info:** " + "word ".repeat(200),
        "- **Understanding:** " + "word ".repeat(200),
        "- **Tone of voice:** friendly.",
      ].join("\n"),
    );

    expect(result.locator).toBe("bullet");
    expect(result.wordCount).toBeLessThan(MIN_SECTION_WORDS);
    expect(result.weak).toBe(false);
  });
});

/** Example counting: what is one example, and what is merely a number. */
describe("assessToneStrength — counting examples", () => {
  it("counts a quoted string inside an enumerated item once", () => {
    // Summing quoted spans and enumerated items with no overlap check made
    // MIN_EXAMPLES=2 effectively mean 1 — on the exact format the prompt asks
    // for.
    const result = assessToneStrength(
      '- **Ton:**\n  - Example lines: 1) "Hello there"',
    );

    expect(result.exampleCount).toBe(1);
  });

  it("counts each item of an inline enumeration, quoted or not", () => {
    // A greedy body made the whole line one match, so the inline shape the
    // prompt's own template prescribes counted once however many items it held.
    const result = assessToneStrength(
      "- **Ton:**\n  - Örnekler: 1) günaydın demek 2) sade konuşmak 3) kısa cümle kurmak",
    );

    expect(result.exampleCount).toBe(3);
  });

  it("does not read ordinary ordinals as examples", () => {
    for (const line of [
      "- **Ton:**\n  - Ses: 3. tekil şahıs kullanılır ve resmi bir dil tercih edilir.",
      "- **Ton:**\n  - Ses: 1998. yılından beri aynı sade dili kullanıyoruz her yerde.",
      "- **Ton:**\n  - Ses: fiyat 25. günde güncellenir, 40. haftada tekrar bakılır.",
    ]) {
      expect(assessToneStrength(line).exampleCount).toBe(0);
    }
  });

  it("does not double-count a span two quote styles both match", () => {
    const result = assessToneStrength(
      '- **Ton:**\n  - Örnek: “Bugün ne içiyoruz”',
    );

    expect(result.exampleCount).toBe(1);
  });
});

/** The runtime guarantee: a cosmetic warning may never break the wizard. */
describe("assessToneStrength — runtime without Intl.Segmenter", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    resetSegmenterForTests();
  });

  it("stays silent instead of throwing when the segmenter is missing", () => {
    // Firefox only shipped Intl.Segmenter in 125, and this module runs inside a
    // "use client" component in both SSR and the browser. A throw here would
    // take out the whole brand-context step over a cosmetic warning.
    resetSegmenterForTests();
    vi.stubGlobal("Intl", { ...Intl, Segmenter: undefined });

    const result = assessToneStrength(
      "- **Ton:**\n  - Ses: —\n  - Örnek: —\n  - Asla: —",
    );

    expect(result.measurable).toBe(false);
    expect(result.weak).toBe(false);
    // The counts still come back, from the crude fallback split.
    expect(result.wordCount).toBeGreaterThan(0);
  });

  it("reports itself as measurable on a runtime that has one", () => {
    resetSegmenterForTests();

    expect(assessToneStrength(contextWith(RICH_TONE)).measurable).toBe(true);
  });
});
