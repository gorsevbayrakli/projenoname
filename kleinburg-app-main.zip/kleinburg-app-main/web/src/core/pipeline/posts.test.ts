import { describe, expect, it } from "vitest";

import type { PostItem } from "./inputs";
import { mergePlatformPosts, normalizePlatform } from "./posts";

/**
 * The legacy-parity core of T20. Generating one platform must replace ONLY that
 * platform's slice — the worker persists runStep's return value with
 * upsertStepContent (a full REPLACE), so anything the merge drops is gone.
 */

function post(platform: string, theme: string): PostItem {
  return {
    platform,
    theme,
    hook: `${theme}-hook`,
    caption: `${theme}-caption`,
    cta: `${theme}-cta`,
    hashtags: [`#${theme}`],
  };
}

const themes = (posts: PostItem[]) => posts.map((p) => p.theme);
const platforms = (posts: PostItem[]) => posts.map((p) => p.platform);

describe("mergePlatformPosts", () => {
  it("returns the incoming posts when nothing exists yet", () => {
    const incoming = [post("instagram", "i1"), post("instagram", "i2")];
    expect(mergePlatformPosts([], incoming, "instagram")).toEqual(incoming);
  });

  it("replacing INSTAGRAM keeps every facebook post untouched", () => {
    const existing = [
      post("instagram", "old-i1"),
      post("facebook", "f1"),
      post("instagram", "old-i2"),
      post("facebook", "f2"),
    ];
    const incoming = [post("instagram", "new-i1")];

    const merged = mergePlatformPosts(existing, incoming, "instagram");

    // Facebook survives, in its original relative order; new IG is appended.
    expect(themes(merged)).toEqual(["f1", "f2", "new-i1"]);
    expect(platforms(merged)).toEqual(["facebook", "facebook", "instagram"]);
    // The kept facebook posts are the very same objects, not rebuilt.
    expect(merged[0]).toBe(existing[1]);
    expect(merged[1]).toBe(existing[3]);
  });

  it("replacing FACEBOOK keeps every instagram post untouched", () => {
    const existing = [
      post("instagram", "i1"),
      post("facebook", "old-f1"),
      post("instagram", "i2"),
    ];
    const incoming = [post("facebook", "new-f1"), post("facebook", "new-f2")];

    const merged = mergePlatformPosts(existing, incoming, "facebook");

    expect(themes(merged)).toEqual(["i1", "i2", "new-f1", "new-f2"]);
  });

  it("generating FACEBOOK for the first time appends without touching instagram", () => {
    const existing = [post("instagram", "i1"), post("instagram", "i2")];
    const incoming = [post("facebook", "f1")];

    const merged = mergePlatformPosts(existing, incoming, "facebook");

    expect(themes(merged)).toEqual(["i1", "i2", "f1"]);
  });

  it("matches the platform tag case-insensitively (and ignores stray whitespace)", () => {
    const existing = [
      post("Instagram", "old-mixed-case"),
      post("  INSTAGRAM  ", "old-padded"),
      post("Facebook", "keep-fb"),
    ];
    const incoming = [post("instagram", "new-i")];

    const merged = mergePlatformPosts(existing, incoming, "instagram");

    expect(themes(merged)).toEqual(["keep-fb", "new-i"]);
  });

  it("accepts a mixed-case target platform too", () => {
    const existing = [post("facebook", "old-f"), post("instagram", "i1")];

    const merged = mergePlatformPosts(existing, [post("facebook", "new-f")], "FaceBook");

    expect(themes(merged)).toEqual(["i1", "new-f"]);
  });

  it("an empty incoming list CLEARS only that platform's slice", () => {
    const existing = [post("instagram", "i1"), post("facebook", "f1")];

    const merged = mergePlatformPosts(existing, [], "instagram");

    expect(themes(merged)).toEqual(["f1"]);
  });

  it("leaves untagged posts alone (they belong to neither slice)", () => {
    const existing = [
      { theme: "untagged", hook: "", caption: "", cta: "", hashtags: [] },
      post("instagram", "old-i"),
    ];

    const merged = mergePlatformPosts(existing, [post("instagram", "new-i")], "instagram");

    expect(themes(merged)).toEqual(["untagged", "new-i"]);
  });

  it("does not mutate its inputs", () => {
    const existing = [post("instagram", "i1"), post("facebook", "f1")];
    const incoming = [post("instagram", "i2")];

    mergePlatformPosts(existing, incoming, "instagram");

    expect(themes(existing)).toEqual(["i1", "f1"]);
    expect(themes(incoming)).toEqual(["i2"]);
  });
});

describe("normalizePlatform", () => {
  it("lowercases and trims a valid tag", () => {
    expect(normalizePlatform("  Facebook ")).toBe("facebook");
    expect(normalizePlatform("INSTAGRAM")).toBe("instagram");
  });

  it("falls back for junk, blank and non-string values", () => {
    expect(normalizePlatform("twitter")).toBe("instagram");
    expect(normalizePlatform("")).toBe("instagram");
    expect(normalizePlatform(undefined)).toBe("instagram");
    expect(normalizePlatform(null)).toBe("instagram");
    expect(normalizePlatform(42)).toBe("instagram");
  });

  it("honours an explicit fallback", () => {
    expect(normalizePlatform("junk", "facebook")).toBe("facebook");
  });
});
