import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import {
  brands,
  generationJobs,
  llmCalls,
  projects,
  stepContents,
  userBrands,
  users,
} from "../db/schema";
import { getBrandSpend, getProjectSpend } from "../llm/spend";
import { recommendPostCounts } from "./cadence";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

/**
 * A project with a brand_context row, i.e. the state step 6 is reachable from.
 * Returns the granted user too, because every read below is a scoped read.
 */
async function makeProjectWithContext() {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({ username: `cad-${randomUUID()}`, passwordHash: "x" })
    .returning();
  createdUserIds.push(user.id);

  const [brand] = await db
    .insert(brands)
    .values({ name: `brand-${randomUUID()}`, isActive: true })
    .returning();
  createdBrandIds.push(brand.id);

  await db.insert(userBrands).values({ userId: user.id, brandId: brand.id });

  const [project] = await db
    .insert(projects)
    .values({ brandId: brand.id, name: `proj-${randomUUID()}`, createdBy: user.id })
    .returning();

  await db.insert(stepContents).values({
    projectId: project.id,
    step: "brand_context",
    content: { brandContext: "A snack brand for teenagers. ".repeat(20) },
  });

  return { user, brand, project };
}

/** A fake generateStructured that reports usage the way OpenRouter does. */
function fakeLlm(opts?: { costUsd?: number | null; fail?: boolean }) {
  const seen: Array<{ jobId?: string; model: string; maxTokens?: number }> = [];
  const fn = async (args: {
    prompt: string;
    schema: unknown;
    model: string;
    jobId?: string;
    maxTokens?: number;
  }) => {
    seen.push({
      jobId: args.jobId,
      model: args.model,
      maxTokens: args.maxTokens,
    });
    // Stand in for the recording generateStructured does internally: the call
    // was billed, so a row is written whether or not the output is usable.
    if (args.jobId) {
      await getDb()
        .insert(llmCalls)
        .values({
          jobId: args.jobId,
          model: args.model,
          promptTokens: 900,
          completionTokens: 120,
          costUsd:
            opts?.costUsd === undefined || opts.costUsd === null
              ? null
              : String(opts.costUsd),
          durationMs: 700,
        });
    }
    if (opts?.fail) throw new Error("model bozuk çıktı verdi");
    return {
      counts: [{ platform: "instagram", postsPerMonth: 8 }],
      rationale: "Ince icerik arzi.",
    };
  };
  return { fn, seen };
}

describe.skipIf(!hasDb)("pipeline/cadence spend recording", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("records the billed call, so /spend does not claim a complete total that omits it", async () => {
    const { user, project } = await makeProjectWithContext();
    const llm = fakeLlm({ costUsd: 0.004 });

    const advice = await recommendPostCounts(
      project.id,
      ["instagram"],
      user.id,
      { generateStructured: llm.fn },
    );
    expect(advice.counts.instagram).toBe(8);

    // The defect: `generateStructured` was called with no jobId, and
    // recordLlmCall's `if (!opts.jobId) return` meant no row could ever exist.
    expect(llm.seen).toHaveLength(1);
    expect(llm.seen[0].jobId).toBeTruthy();

    const spend = await getProjectSpend(user.id, project.id);
    expect(spend.total.callCount).toBe(1);
    expect(spend.total.costUsd).toBeCloseTo(0.004, 6);
    expect(spend.total.complete).toBe(true);
  });

  it("gives cadence its own step row instead of loading it onto a wizard step", async () => {
    const { user, project } = await makeProjectWithContext();
    const llm = fakeLlm({ costUsd: 0.004 });

    await recommendPostCounts(project.id, ["instagram"], user.id, {
      generateStructured: llm.fn,
    });

    const spend = await getProjectSpend(user.id, project.id);
    // Exactly one step row, and it is the synthetic one — no generative step
    // has been inflated by a cost that is not its own.
    expect(spend.byStep.map((s) => s.step)).toEqual(["platform_cadence"]);
    expect(spend.byStep[0].costUsd).toBeCloseTo(0.004, 6);
  });

  it("counts an unpriced cadence call in the blind spot rather than losing it", async () => {
    const { user, project } = await makeProjectWithContext();
    const llm = fakeLlm({ costUsd: null });

    await recommendPostCounts(project.id, ["instagram"], user.id, {
      generateStructured: llm.fn,
    });

    const spend = await getProjectSpend(user.id, project.id);
    expect(spend.total.callCount).toBe(1);
    expect(spend.total.unpricedCallCount).toBe(1);
    // The page must hedge, not present $0.00 as a settled figure.
    expect(spend.total.complete).toBe(false);
  });

  it("keeps the money when the generation itself fails", async () => {
    const { user, project } = await makeProjectWithContext();
    const llm = fakeLlm({ costUsd: 0.004, fail: true });

    await expect(
      recommendPostCounts(project.id, ["instagram"], user.id, {
        generateStructured: llm.fn,
      }),
    ).rejects.toThrow(/bozuk/);

    // The user still got billed, so the spend view must still show it...
    const spend = await getProjectSpend(user.id, project.id);
    expect(spend.total.callCount).toBe(1);
    expect(spend.total.costUsd).toBeCloseTo(0.004, 6);

    // ...and the job row must say what happened (hard rule 5).
    const [job] = await getDb()
      .select()
      .from(generationJobs)
      .where(eq(generationJobs.projectId, project.id));
    expect(job.status).toBe("failed");
    expect(job.error).toMatch(/bozuk/);
  });

  it("rolls cadence spend up into the brand total", async () => {
    const { user, brand, project } = await makeProjectWithContext();
    const llm = fakeLlm({ costUsd: 0.004 });

    await recommendPostCounts(project.id, ["instagram"], user.id, {
      generateStructured: llm.fn,
    });

    const spend = await getBrandSpend(user.id, brand.id);
    expect(spend.total.costUsd).toBeCloseTo(0.004, 6);
    const row = spend.byProject.find((p) => p.projectId === project.id);
    expect(row!.callCount).toBe(1);
  });

  it("does not open a job when the request is rejected before the LLM call", async () => {
    const { user, project } = await makeProjectWithContext();
    const llm = fakeLlm({ costUsd: 0.004 });

    await expect(
      recommendPostCounts(project.id, [], user.id, {
        generateStructured: llm.fn,
      }),
    ).rejects.toThrow(/platform/i);

    // Nothing was billed, so nothing may appear in the ledger.
    const rows = await getDb()
      .select()
      .from(generationJobs)
      .where(eq(generationJobs.projectId, project.id));
    expect(rows).toHaveLength(0);
  });

  /**
   * MEASURED, not hypothetical. On the 2026-07-20 baseline run this call — two
   * integers and a one-sentence rationale — consumed 65536 completion tokens
   * (the provider's own default ceiling), ran for 434 seconds, cost $0.66 and
   * then FAILED on truncation. The step's tiny output said nothing about how
   * much the model would spend reaching it.
   *
   * The ceiling is what makes the runaway cheap and fast to hit instead of
   * expensive and slow. It is asserted as an upper bound rather than an exact
   * number so the constant can be tuned without rewriting the test, but it must
   * be far below the 65536 that was actually burned.
   */
  it("caps the completion budget so a runaway cannot burn the provider default", async () => {
    const { user, project } = await makeProjectWithContext();
    const llm = fakeLlm();

    await recommendPostCounts(project.id, ["instagram"], user.id, {
      generateStructured: llm.fn,
    });

    const ceiling = llm.seen[0].maxTokens;
    expect(ceiling).toBeDefined();
    expect(ceiling).toBeLessThan(8000);
  });
});
