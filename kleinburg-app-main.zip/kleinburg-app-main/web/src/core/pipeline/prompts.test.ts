import { readdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

import { beforeEach, describe, expect, it } from "vitest";

import { PLATFORMS } from "../platforms";
import { NO_SOURCE_MARKER, serializePillars } from "./inputs";
import { clearPromptCache, loadPrompt, renderPrompt } from "./prompts";
import { PILLAR_FLOOR_PER_CATEGORY, PILLAR_TOTAL } from "./run-step";

const PROMPTS_DIR = join(dirname(fileURLToPath(import.meta.url)), "../../../prompts");

const promptFiles = readdirSync(PROMPTS_DIR).filter((f) => f.endsWith(".md"));

function placeholdersInBody(body: string): Set<string> {
  const set = new Set<string>();
  const re = /\{([A-Za-z_][A-Za-z0-9_]*)\}/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(body)) !== null) set.add(m[1]);
  return set;
}

beforeEach(() => clearPromptCache());

describe("migrated prompt files", () => {
  // 10, not 9: secondary_data has TWO prompts since #52 — one for the search
  // call and one for the writing call.
  it("finds all 10 prompt files", () => {
    expect(promptFiles).toHaveLength(10);
  });

  for (const file of promptFiles) {
    describe(file, () => {
      it("declares frontmatter variables that exactly match body placeholders", () => {
        const { frontmatter, body } = loadPrompt(file);
        const declared = [...frontmatter.variables].sort();
        const present = [...placeholdersInBody(body)].sort();
        expect(declared).toEqual(present);
      });

      it("declares a plausible frontmatter contract", () => {
        const { frontmatter } = loadPrompt(file);
        expect(typeof frontmatter.step).toBe("string");
        // v2 was the structured-output rewrite and is the floor. Individual
        // prompts move past it as they are revised (creative_sparks went to 3
        // when T28 made the audience, not the typed text, its subject), so this
        // pins the floor rather than freezing every file at the same number.
        expect(typeof frontmatter.version).toBe("number");
        // Migrated prompts floor at v2 (the structured-output rewrite). Prompts
        // written for this product start at v1 and have no legacy ancestor.
        expect(frontmatter.version).toBeGreaterThanOrEqual(frontmatter.source ? 2 : 1);
        expect(typeof frontmatter.languageSlot).toBe("boolean");
        if (frontmatter.source) {
          expect(frontmatter.source.endsWith(".txt")).toBe(true);
        }
        // languageSlot must agree with the presence of a {language} placeholder.
        expect(frontmatter.variables.includes("language")).toBe(frontmatter.languageSlot);
      });

      it("renders with all declared vars filled and no placeholder residue", () => {
        const { frontmatter } = loadPrompt(file);
        const vars = Object.fromEntries(frontmatter.variables.map((v) => [v, `<<${v}>>`]));
        const rendered = renderPrompt(file, vars);
        for (const v of frontmatter.variables) {
          expect(rendered).not.toContain(`{${v}}`);
          expect(rendered).toContain(`<<${v}>>`);
        }
      });

      it("throws when a declared variable is missing", () => {
        const { frontmatter } = loadPrompt(file);
        if (frontmatter.variables.length === 0) return;
        const partial = Object.fromEntries(frontmatter.variables.slice(1).map((v) => [v, "x"]));
        expect(() => renderPrompt(file, partial)).toThrow(/missing variable/);
      });
    });
  }
});

describe("v2 prompt bodies match the structured-output pipeline", () => {
  it("contains no markdown code fences (schema output, not prose formats)", () => {
    for (const file of promptFiles) {
      expect(loadPrompt(file).body).not.toContain("```");
    }
  });

  it("kept the freeform brand_context format section (single-string field)", () => {
    expect(loadPrompt("context_generation_prompt.md").body).toContain("Format your response as follows:");
  });

  /**
   * T35 coupling. `core/pipeline/tone-strength.ts` locates the tone section by
   * the SHAPE this template prescribes — a top-level bullet whose next lines
   * are more-indented sub-bullets — and by nothing else, because the headings
   * themselves are written in whatever language the analysis uses. Reflow this
   * template flat and the heuristic loses its anchor and falls back to silence.
   * Changing the creative text needs Elif's approval (hard rule 6); this test
   * exists so that such a change cannot silently disable the warning too.
   */
  it("keeps the tone-of-voice template as an indented sub-bullet block", () => {
    const body = loadPrompt("context_generation_prompt.md").body;
    const lines = body.split("\n");
    const opener = lines.findIndex((l) => /^- \*\*Tone of voice:\*\*\s*$/.test(l));

    expect(opener).toBeGreaterThan(-1);
    const subBullets = lines
      .slice(opener + 1)
      .filter((l) => /^\s+- \S/.test(l))
      .length;
    // Voice / Example lines / Never — the heuristic needs at least two.
    expect(subBullets).toBeGreaterThanOrEqual(3);
    // And the example line stays an enumeration, which is what the example
    // counter reads as evidence that the brand actually speaks somewhere.
    expect(body).toMatch(/^\s+- Example lines: 1\) .* 2\) .* 3\) /m);
  });

  it("kept the sm_pillars worked example", () => {
    expect(loadPrompt("sm_pillar_generation.md").body).toContain("The Stealth Snacker's Guide");
  });

  /**
   * THE PROMPT AND checkCounts MUST AGREE ON THE DISTRIBUTION RULE.
   *
   * They are two statements of one rule in two files, and run-step.ts's own
   * comment has warned since T26 that changing one without the other silently
   * desyncs them: the model is told one thing and graded against another, and
   * the user gets a retry loop nobody can explain from either file alone.
   *
   * The equal 7/7/7 split was removed on 2026-07-21 (product owner). This
   * pins the replacement in the prompt against the constants the check reads,
   * so a future edit to either side has to face the other.
   */
  it("sm_pillars states the SAME total and floor that checkCounts enforces", () => {
    const { body } = loadPrompt("sm_pillar_generation.md");

    expect(body).toContain(`Return exactly ${PILLAR_TOTAL} pillars`);
    expect(body).toContain(
      `at least ${PILLAR_FLOOR_PER_CATEGORY} pillars in every category`,
    );
    // And the fixed blocks are really gone from the copy, not just from the
    // check — leaving them would keep manufacturing the cheesey pillars.
    expect(body).not.toMatch(/pillars 1-7|8-14|15-21|exactly 7 pillars/);
  });

  // Each prompt must name the schema container the CALL it drives is validated
  // against, so the instructions and the enforced response_format agree.
  //
  // Keyed by step AND variant, because since #52 one step does not imply one
  // schema: secondary_data's retrieval call is validated against
  // researchRetrievalSchema (`findings`) and its writing call against
  // secondaryDataSchema (`items`). Keying by step alone made the retrieval
  // prompt assert `items`, a container it must never produce.
  const SCHEMA_FIELD: Record<string, string> = {
    brand_context: "`brandContext`",
    "secondary_data:retrieval": "`findings`",
    "secondary_data:writing": "`items`",
    creative_sparks: "`items`",
    sm_pillars: "`pillars`",
    sm_posts: "`posts`",
    content_calendar: "`calendars`",
  };

  for (const file of promptFiles) {
    it(`${file} references its call's schema field`, () => {
      const { frontmatter, body } = loadPrompt(file);
      const key = frontmatter.variant
        ? `${frontmatter.step}:${frontmatter.variant}`
        : frontmatter.step;
      const field = SCHEMA_FIELD[key];
      // A prompt whose step/variant is not in the table would otherwise pass
      // `toContain(undefined)`-shaped vacuity; make the omission loud instead.
      expect(field, `no schema field registered for "${key}"`).toBeDefined();
      expect(body).toContain(field);
    });
  }

  // T35. Every post prompt takes the brand's voice from BRAND_CONTEXT's tone
  // section, so every post prompt needs the same instruction for what to do
  // when that section is thin — otherwise the model fills the gap with a
  // generic creator voice and the drift is invisible in the output. Driven off
  // the platform registry so adding a platform cannot quietly skip the rule.
  // The wording is TikTok's, reused verbatim rather than re-invented per file.
  it("tells every platform what to do when the tone section is thin", () => {
    const RULE =
      "If the brand context's tone of voice is thin or missing, stay closer to the brand's own documents and write plainly, rather than filling the gap with generic creator voice.";
    for (const platform of PLATFORMS) {
      const { body } = loadPrompt(platform.postPrompt);
      expect(body, `${platform.postPrompt} is missing the weak-tone rule`).toContain(RULE);
    }
  });

  /**
   * #52. THE SUBJECT OF THE STEP, pinned in the prompt because nothing
   * downstream can check it (hard rule 4 forbids regexing model prose).
   *
   * #47 asked the step to write nothing it could not source. On the 2026-07-20
   * live run that inverted the intended relationship: the only material a
   * search reliably returns for a BRAND NAME is trade press, so the requirement
   * to be sourced made search CHOOSE the subject, and the step produced a
   * company profile — founding year, acquisition price, sales growth, all
   * correctly sourced to business press and all useless as social content.
   *
   * The rule now is "search verifies, it does not choose": the subject is the
   * category and the audience's life, an unsourced entry is legitimate (it just
   * comes back marked), and corporate facts are banned outright however well
   * sourced they are. The anti-fabrication half of #47 survives verbatim in
   * spirit, re-aimed at the retrieved material the writer is given.
   */
  it("makes the category, not the brand, the subject of secondary_data", () => {
    const { body } = loadPrompt("secondarydata_prompt.md");

    // THE DELETION Elif asked for by name. This one sentence is what pushed the
    // model onto whatever it could find sources for. It must not come back.
    expect(body).not.toContain(
      "An entry you could have written without searching does not belong here",
    );
    // And its inversion has to be stated, not merely implied by the absence.
    expect(body).toContain("**The search verifies; it does not choose.**");

    // The subject, named explicitly.
    expect(body).toContain(
      "The subject is the brand's CATEGORY and the LIFE OF ITS AUDIENCE",
    );
    expect(body).toContain("The subject is NEVER the brand as a company.");

    // The ban, itemised — a general "stay on the category" is exactly what v4
    // had ("related to the brand's category, audience, and cultural
    // territory") and it did not stop a single corporate entry.
    expect(body).toContain("**A corporate fact is never an entry.**");
    for (const banned of [
      "founding date",
      "ownership",
      "acquisitions",
      "revenue",
      "market share",
      "product launches",
      "awards",
    ]) {
      expect(body, `the corporate-fact ban omits "${banned}"`).toContain(banned);
    }
    // Sourcing must not be a loophole: the live entries WERE sourced.
    expect(body).toContain(
      "even when a retrieved document states them plainly, and even when they are true",
    );
  });

  /**
   * #47's anti-fabrication guarantees, still enforced after the #52 rewrite.
   * The writing call no longer searches, so every one of these is re-aimed at
   * <retrieved_material> rather than at "what you retrieved" — the guarantee is
   * the same, the thing it points at moved.
   */
  it("keeps secondary_data from inventing evidence or sources", () => {
    const { body } = loadPrompt("secondarydata_prompt.md");
    expect(body).toContain("**Never invent evidence.**");
    expect(body).toContain(
      'Never write "studies show", "research proves" or "experts say" unless <retrieved_material> genuinely says it',
    );
    // The step must ask for the sources the cross-check will judge, and must
    // forbid a URL that was never retrieved — attachRetrievedSources drops one,
    // but a prompt that invites it wastes the source and the reviewer's trust.
    expect(body).toContain("`sources`");
    expect(body).toContain(
      "Copy the URL character for character from the material; never reconstruct, recall or shorten one, and never use a URL that does not appear there.",
    );
    // An empty sources array is now the EXPECTED answer for a category entry
    // the material does not happen to back. v4 allowed it "only for an entry
    // that makes no factual claim at all", which under the new subject rule
    // would push the model back towards writing only what it could source.
    expect(body).toContain(
      "Return an empty array whenever the material does not support the entry",
    );
    expect(body).not.toContain(
      "Return an empty array only for an entry that makes no factual claim at all",
    );
    // The "angles, not evidence" reframing is gone: it described a step with no
    // search behind it at all.
    expect(body).not.toContain("Angles, not evidence");
  });

  /**
   * The RETRIEVAL prompt (#52). It drives the one call in the system that
   * really searches, and it is the only place the subject can be steered
   * BEFORE the documents come back — a search aimed at the brand name returns
   * company news no downstream rule can rescue.
   */
  it("aims the retrieval call at the category and away from company news", () => {
    const { body } = loadPrompt("secondarydata_retrieval_prompt.md");
    expect(body).toContain(
      "The subject is the brand's CATEGORY and the LIFE OF ITS AUDIENCE — never the brand as a company.",
    );
    expect(body).toContain("## What NOT to search for");
    expect(body).toContain(
      "search the category, the ingredient, the ritual or the audience, not the brand name",
    );
    // It reports what it retrieved; it does not write entries, and it must not
    // be tempted to fill gaps from memory.
    expect(body).toContain(
      "Report only what a document you actually retrieved says.",
    );
    expect(body).toContain(
      "an empty `findings` array is a valid, honest answer",
    );
    // The URLs must be the retrieved ones — serializeRetrievedMaterial drops
    // anything else, so a reconstructed URL silently costs a real source.
    expect(body).toContain("Never reconstruct, shorten or recall a URL.");
  });

  /**
   * EVERY prompt that receives serializeSourcedItems output must know how to
   * read it — and that set is NOT the platform registry.
   *
   * gatherVars feeds `selected_data` to sm_pillars AND sm_posts. The first
   * version of this test iterated PLATFORMS (correct for the four post files,
   * which vary by platform) and so proved nothing about the pillar prompt, which
   * has no platform and was therefore never checked. It shipped receiving
   * `[sources: …]` and `[no retrieved source]` markers with no rule telling it
   * what either one means. The list below is derived from the CONSUMERS of the
   * serializer instead, so a prompt that starts taking `selected_data` cannot
   * quietly skip the rule again.
   */
  const SOURCED_DATA_CONSUMERS = [
    "sm_pillar_generation",
    ...PLATFORMS.map((p) => p.postPrompt),
  ];

  it("gives every selected_data consumer the grounding rule", () => {
    // Derived from the prompts themselves, not hand-listed: any prompt whose
    // frontmatter declares selected_data is a consumer and must be covered.
    const declared = promptFiles
      .filter((file) =>
        loadPrompt(file).frontmatter.variables.includes("selected_data"),
      )
      .map((file) => file.replace(/\.md$/, ""));
    expect(declared.sort()).toEqual([...SOURCED_DATA_CONSUMERS].sort());

    for (const file of SOURCED_DATA_CONSUMERS) {
      const { body } = loadPrompt(file);
      // The marker the rule names is the one the serializer writes.
      expect(
        body,
        `${file} names a different marker than serializeSourcedItems emits`,
      ).toContain(NO_SOURCE_MARKER);
      // The retrieval/support distinction, in every consumer.
      expect(
        body,
        `${file} does not tell the model a listed source is unverified`,
      ).toContain(
        "the match between an entry and its listed source was asserted by a model and has not been verified, so a listed source makes an entry usable, not proven",
      );
    }
  });

  /**
   * The post-side rule, driven off the platform registry like the T35 weak-tone
   * rule so a platform added later cannot quietly ship without it. One block,
   * reused verbatim in all four files rather than re-invented per platform.
   *
   * SOFTENED (#47 review). The previous version said a sourced entry "may be
   * stated as fact". That granted more than the system can back: the cross-check
   * in run-step.ts proves a URL was RETRIEVED for the call, never that the
   * document SUPPORTS the item it was hung on — the model chose that pairing and
   * nothing checks it. Licensing the post to state such a pairing as fact is how
   * a fabricated claim ends up in published copy wearing a real publication's
   * name. So the entry may still be USED, at its own confidence and no higher.
   */
  it("lets every platform use a sourced entry without raising its certainty", () => {
    const RULE =
      "You yourself have no internet access and have researched nothing, so never add a statistic, study, report or news claim of your own, and never fabricate names, companies, or events. Some selected data entries list sources: those documents were genuinely retrieved by the research step, but the match between an entry and its listed source was asserted by a model and has not been verified, so a listed source makes an entry usable, not proven. You may build a post on such an entry at exactly the confidence the entry itself carries: keep whatever hedging it uses and never harden it into certainty, never add a number, a percentage, a date, a detail or a named institution the entry does not contain, never attribute a claim to a study, publication or expert the entry does not name, and never tell the reader that research or a source says something — the entry is what you have, not the document behind it. An entry marked [no retrieved source] is unverified thinking, not a finding — use its idea as the brand's own observation, and never present it as sourced fact.";

    for (const platform of PLATFORMS) {
      const { body } = loadPrompt(platform.postPrompt);
      expect(
        body,
        `${platform.postPrompt} is missing the softened grounding rule`,
      ).toContain(RULE);
      // The licence that made a model-asserted pairing into fact. Never again.
      expect(
        body,
        `${platform.postPrompt} still licenses a sourced entry to be stated as fact`,
      ).not.toContain("may be stated as fact");
      // The contradiction the pre-#47 wording left behind: a prompt cannot tell
      // the model its input is unresearched while the input carries sources.
      expect(
        body,
        `${platform.postPrompt} still calls the selected entries unverified`,
      ).not.toContain("unverified angles a model generated");
    }
  });

  /**
   * The STRUCTURAL half of the pillar fix (#47 review), and the reason the rule
   * alone is not enough.
   *
   * serializePillars emits title / category / topicBlend / hook / contentBrief —
   * and NOT the sources, which live on the secondary_data entries the pillar was
   * built from. So a figure the pillar step copies out of a sourced entry into a
   * contentBrief reaches the post step as bare prose with no `[sources: …]`
   * marker and no `[no retrieved source]` marker either: provenance-free text
   * that the post prompt has no way to recognise as unbacked. That is a
   * laundering path no wording in the POST prompt can close, because by then the
   * evidence is already gone.
   *
   * It is closed at the producer: the pillar prompt is told to keep figures out
   * of exactly the three free-text fields serializePillars forwards.
   */
  it("stops the pillar prompt from forwarding figures stripped of provenance", () => {
    const { body } = loadPrompt("sm_pillar_generation");
    expect(body).toContain(
      "`title`, `hook` and `contentBrief` must carry no statistic, percentage, date, study or named institution — not even one copied from a selected data entry.",
    );
    // The three fields named above are exactly the free-text fields
    // serializePillars forwards to the post step. If that serializer starts
    // carrying another field, this rule has a hole and must be re-aimed.
    const forwarded = serializePillars([
      {
        category: "INFORMATIONAL",
        title: "T",
        topicBlend: "A × B",
        creativeSpark: "SPARK-ONLY-TEXT",
        hook: "H",
        contentBrief: "C",
      },
    ]);
    expect(forwarded).toContain("T");
    expect(forwarded).toContain("H");
    expect(forwarded).toContain("C");
    // creativeSpark quotes the source entry verbatim, so it would be the worst
    // carrier of a stripped figure — it is not forwarded, and must stay that way.
    expect(forwarded).not.toContain("SPARK-ONLY-TEXT");
  });

  it("fences interpolated inputs against prompt injection", () => {
    for (const file of promptFiles) {
      expect(loadPrompt(file).body).toContain("not instructions");
    }
  });
});

// The steps whose output language is set explicitly by the project's language,
// rather than mirrored from the input. sm_pillars joined this list in T26 so
// pillar titles follow the project language.
describe("language slot", () => {
  // Every generative step binds its output language to the project's language.
  // Earlier there were three exceptions (brand_context, secondary_data,
  // creative_sparks) that inferred the language from their input and fell back
  // to Türkçe when that was ambiguous. Elif's #11 review removed that: the app
  // is international, Türkçe is one market among several, and a project whose
  // brand analysis and posts came out in different languages was the bug.
  /**
   * The one prompt whose {language} slot is NOT its output language (#52).
   *
   * secondarydata_retrieval_prompt drives the search call, and that call's
   * prose is never read by anyone: perplexity/sonar drops non-ASCII letters
   * ("Doğadan" -> "Doçıı" on the 2026-07-20 live run), so its notes are
   * requested in English and consumed by the writing call, which does apply
   * {language}. Its {language} slot steers WHICH LANGUAGES IT SEARCHES IN.
   *
   * Carved out by name rather than by a `variant` check, so adding a second
   * retrieval-shaped prompt is a deliberate decision that shows up here.
   */
  const NOT_OUTPUT_LANGUAGE = ["secondarydata_retrieval_prompt.md"];

  for (const file of promptFiles.filter(
    (f) => !NOT_OUTPUT_LANGUAGE.includes(f),
  )) {
    it(`${file} takes its output language from {language}`, () => {
      const { frontmatter, body } = loadPrompt(file);
      expect(frontmatter.languageSlot).toBe(true);
      expect(frontmatter.variables).toContain("language");
      expect(body).toContain("{language}");
    });
  }

  it("the retrieval prompt uses {language} to search and English to report", () => {
    const { frontmatter, body } = loadPrompt("secondarydata_retrieval_prompt.md");
    // It still HAS the slot — the frontmatter contract is unchanged.
    expect(frontmatter.languageSlot).toBe(true);
    expect(body).toContain("Search in {language} and in English");
    // And its own output language is fixed, with the reason attached so nobody
    // "fixes" it back to {language} and reinstates the mangled Turkish.
    expect(body).toContain("Write every `note` in ENGLISH, whatever {language} is.");
    expect(body).toContain("This is deliberate and is not a mistake to correct");
  });

  it("no prompt hardcodes a fallback language", () => {
    for (const file of promptFiles) {
      const { body } = loadPrompt(file);
      expect(body).not.toMatch(/default to (Türkçe|Turkish|English)/i);
    }
  });

  it("sm_pillars binds its output language to {language}", () => {
    const { body } = loadPrompt("sm_pillar_generation.md");
    expect(body).toContain("Write `title`, `hook` and `contentBrief` in {language}.");
  });
});

describe("renderPrompt substitutes in a SINGLE pass", () => {
  // An injected value is prior model output or a user document, so it can
  // legitimately contain a literal like "{language}". Sequential substitution
  // would let a LATER variable rewrite it and silently change the prompt.
  it("keeps a {language}-like literal inside a value verbatim", () => {
    const { frontmatter } = loadPrompt("sm_post_generation.md");
    const vars = Object.fromEntries(
      frontmatter.variables.map((v) => [v, `<<${v}>>`]),
    );
    vars.BRAND_CONTEXT =
      "Marka kılavuzu: tüm başlıklar {language} olarak yazılır.";
    vars.language = "Türkçe";

    const rendered = renderPrompt("sm_post_generation.md", vars);

    expect(rendered).toContain(
      "Marka kılavuzu: tüm başlıklar {language} olarak yazılır.",
    );
    // The real {language} slots were still filled.
    expect(rendered).toContain("Türkçe");
  });

  it("does not interpret $-sequences inside a value", () => {
    const { frontmatter } = loadPrompt("sm_post_generation.md");
    const vars = Object.fromEntries(
      frontmatter.variables.map((v) => [v, `<<${v}>>`]),
    );
    vars.BRAND_CONTEXT = "Fiyatlandırma: $& ve $1 sembolleri korunur.";

    const rendered = renderPrompt("sm_post_generation.md", vars);

    expect(rendered).toContain("Fiyatlandırma: $& ve $1 sembolleri korunur.");
  });

  it("still throws when a declared variable is missing", () => {
    expect(() => renderPrompt("sm_pillar_generation.md", {})).toThrow(
      /missing variable/,
    );
  });
});

describe("loadPrompt caching", () => {
  it("returns the same cached object on repeat reads", () => {
    const a = loadPrompt("secondarydata_prompt.md");
    const b = loadPrompt("secondarydata_prompt");
    expect(a).toBe(b);
  });
});

// v2 prompts are rewrites, not transcriptions; the legacy .txt files remain
// referenced via frontmatter `source` for provenance. Verify the pointer holds.
describe("legacy provenance", () => {
  const LEGACY_DIR = join(dirname(fileURLToPath(import.meta.url)), "../../../../prompts");

  // Only the migrated ones. LinkedIn and TikTok were written for this product
  // and declare no source, so there is nothing to trace.
  for (const file of promptFiles) {
    const { frontmatter } = loadPrompt(file);
    if (!frontmatter.source) continue;
    it(`${file} names an existing legacy source file`, () => {
      expect(readFileSync(join(LEGACY_DIR, frontmatter.source!), "utf8").length).toBeGreaterThan(0);
    });
  }
});
