import { describe, expect, it } from "vitest";

import { buildCalendars } from "./build-calendar";
import type { PillarItem, PostItem } from "./inputs";

/**
 * The content calendar used to be a model call. It is arithmetic: the approved
 * posts already carry every word the calendar shows, so the step's real job is
 * scheduling — which day, which format, which pillar — not writing.
 *
 * These tests pin the properties that made the LLM version expensive and
 * fragile, and that a deterministic builder must get right for free:
 *   - approved copy is reproduced VERBATIM (the old prompt asked nicely; here
 *     it is structural),
 *   - nothing is ever invented when there is not enough material,
 *   - a short calendar is reported, never silently padded or silently short.
 */

const pillar = (title: string): PillarItem => ({
  category: "INSPIRATIONAL",
  title,
  topicBlend: "blend",
  hook: "hook",
  contentBrief: "brief",
});

const post = (over: Partial<PostItem> = {}): PostItem => ({
  platform: "instagram",
  theme: "Sabah Ritüeli — Reel: yakın çekim",
  hook: "Günün ilk ışığı",
  caption: "Kahveni demlerken geçen o iki dakika senin.",
  cta: "Sen nasıl başlıyorsun?",
  hashtags: ["#sabah", "#ritüel"],
  ...over,
});

describe("buildCalendars", () => {
  it("copies an approved post's words into its row verbatim", () => {
    const { calendars } = buildCalendars({
      targets: [{ platform: "instagram", count: 1 }],
      posts: [post()],
      pillars: [pillar("Sabah Ritüeli")],
    });

    expect(calendars).toHaveLength(1);
    expect(calendars[0].platform).toBe("instagram");
    expect(calendars[0].rows).toHaveLength(1);

    const row = calendars[0].rows[0];
    expect(row.hook).toBe("Günün ilk ışığı");
    expect(row.caption).toBe("Kahveni demlerken geçen o iki dakika senin.");
    expect(row.cta).toBe("Sen nasıl başlıyorsun?");
    expect(row.hashtags).toEqual(["#sabah", "#ritüel"]);
  });

  /**
   * The sm_posts prompt defines `theme` as "the exact pillar title, then ' — ',
   * then the format and visual direction". So the pillar IS already in the
   * data — but as a model-written prefix, which is a soft convention.
   *
   * The resolution therefore MATCHES AGAINST THE KNOWN PILLAR TITLES rather
   * than splitting the string on " — " and trusting whatever comes back. A
   * blind split would happily produce a "pillar" that no pillar step ever
   * emitted (an em dash inside the title, a model that used a colon, a theme
   * written without the separator at all) and the calendar would then group
   * rows under a heading that exists nowhere upstream.
   */
  it("resolves a row's pillar by matching the theme against known pillar titles", () => {
    const { calendars } = buildCalendars({
      targets: [{ platform: "instagram", count: 1 }],
      posts: [post({ theme: "Sabah Ritüeli — Reel: yakın çekim" })],
      pillars: [pillar("Akşam Rutini"), pillar("Sabah Ritüeli")],
    });

    expect(calendars[0].rows[0].pillar).toBe("Sabah Ritüeli");
  });

  it("reports a post whose theme matches no known pillar instead of inventing one", () => {
    const { unresolvedPillars, calendars } = buildCalendars({
      targets: [{ platform: "instagram", count: 1 }],
      posts: [post({ theme: "Bilinmeyen Konu — Reel: bir şey" })],
      pillars: [pillar("Sabah Ritüeli")],
    });

    expect(unresolvedPillars).toHaveLength(1);
    // The row still renders — losing a real post because its label drifted
    // would be worse than showing it under an unmatched heading.
    expect(calendars[0].rows).toHaveLength(1);
  });

  /**
   * CAPACITY. The old prompt handled the two directions with opposite rules:
   * more approved posts than requested meant "schedule every one and exceed the
   * count, completeness wins"; fewer meant "fill the rest with new posts".
   *
   * A builder can honour the first rule exactly. It cannot honour the second at
   * all — writing a publishable Turkish post is the thing a model was there
   * for. So the second becomes a REPORT rather than a silent short calendar:
   * the shortfall is the caller's cue to send the user back to step 8, which is
   * where posts are supposed to be written anyway.
   */
  it("schedules every approved post even when they outnumber the requested count", () => {
    const posts = [
      post({ hook: "bir" }),
      post({ hook: "iki" }),
      post({ hook: "üç" }),
    ];

    const { calendars, shortfalls } = buildCalendars({
      targets: [{ platform: "instagram", count: 2 }],
      posts,
      pillars: [pillar("Sabah Ritüeli")],
    });

    expect(calendars[0].rows).toHaveLength(3);
    expect(shortfalls).toHaveLength(0);
  });

  it("reports a shortfall instead of padding when posts run out", () => {
    const { calendars, shortfalls } = buildCalendars({
      targets: [{ platform: "instagram", count: 5 }],
      posts: [post(), post()],
      pillars: [pillar("Sabah Ritüeli")],
    });

    expect(calendars[0].rows).toHaveLength(2);
    expect(shortfalls).toEqual([
      { platform: "instagram", requested: 5, scheduled: 2 },
    ]);
  });

  it("reports a platform that was asked for but has no posts at all", () => {
    const { calendars, shortfalls } = buildCalendars({
      targets: [
        { platform: "instagram", count: 1 },
        { platform: "linkedin", count: 3 },
      ],
      posts: [post({ platform: "instagram" })],
      pillars: [pillar("Sabah Ritüeli")],
    });

    expect(calendars).toHaveLength(2);
    expect(calendars[1].rows).toHaveLength(0);
    expect(shortfalls).toContainEqual({
      platform: "linkedin",
      requested: 3,
      scheduled: 0,
    });
  });

  /**
   * DAYS. The prompt asked for "Day 1".."Day 30", only days that carry a post,
   * spread rather than clustered, in day order. Spreading is division: n posts
   * over a 30-day month sit every 30/n days.
   *
   * The labels stay English ("Day 1") on purpose — the prompt calls them
   * production shorthand and keeps them untranslated in every language, so the
   * builder has to reproduce that, not localise it.
   */
  it("spreads posts across the month instead of clustering them at the start", () => {
    const posts = Array.from({ length: 3 }, (_, i) => post({ hook: `h${i}` }));

    const { calendars } = buildCalendars({
      targets: [{ platform: "instagram", count: 3 }],
      posts,
      pillars: [pillar("Sabah Ritüeli")],
    });

    const days = calendars[0].rows.map((r) => r.day);
    expect(days).toEqual(["Day 1", "Day 11", "Day 21"]);
  });

  /**
   * 60 posts, and the number is load-bearing — do not "simplify" it.
   *
   * The last day is `1 + round((n-1) * 30/n)`, which stays at 30 until the
   * rounding tips over: it only reaches 31 once 30/n <= 0.5, i.e. n >= 60. At
   * 30, 40 or even 59 posts a builder with NO clamp at all produces identical
   * output and the test proves nothing. 60 is the smallest fixture that fails
   * against the unclamped version, which is the only reason to pick it.
   *
   * Reachable in practice because sm_posts MERGES across runs (see
   * mergeIntoStoredPosts) and "completeness wins over the number" schedules
   * every stored post, so one platform can accumulate more posts than the
   * month has days.
   */
  it("never schedules past Day 30 even when posts outnumber the days", () => {
    const posts = Array.from({ length: 60 }, (_, i) => post({ hook: `h${i}` }));

    const { calendars } = buildCalendars({
      targets: [{ platform: "instagram", count: 30 }],
      posts,
      pillars: [pillar("Sabah Ritüeli")],
    });

    expect(calendars[0].rows).toHaveLength(60);

    const numbers = calendars[0].rows.map((r) =>
      Number(r.day.replace("Day ", "")),
    );
    expect(Math.min(...numbers)).toBeGreaterThanOrEqual(1);
    expect(Math.max(...numbers)).toBeLessThanOrEqual(30);
    // Day order is part of the output contract ("rows in day order").
    expect([...numbers]).toEqual([...numbers].sort((a, b) => a - b));
  });

  /**
   * PACING. "Never schedule the same pillar on consecutive posting days."
   *
   * sm_posts emits posts pillar by pillar, so the natural input order is the
   * worst possible calendar: every pillar's posts back to back. Interleaving
   * pillars is the whole job.
   */
  it("does not put the same pillar on consecutive posting days", () => {
    const posts = [
      post({ theme: "A — Reel", hook: "a1" }),
      post({ theme: "A — Reel", hook: "a2" }),
      post({ theme: "B — Reel", hook: "b1" }),
      post({ theme: "B — Reel", hook: "b2" }),
    ];

    const { calendars } = buildCalendars({
      targets: [{ platform: "instagram", count: 4 }],
      posts,
      pillars: [pillar("A"), pillar("B")],
    });

    const order = calendars[0].rows.map((r) => r.pillar);
    for (let i = 1; i < order.length; i++) {
      expect(order[i]).not.toBe(order[i - 1]);
    }
    // Interleaving must not drop or duplicate anything.
    expect(calendars[0].rows.map((r) => r.hook).sort()).toEqual([
      "a1",
      "a2",
      "b1",
      "b2",
    ]);
  });

  /**
   * FORMAT. The sm_posts prompt already had the model decide a format and write
   * it into `theme` ("Pillar — Reel: ..."), and the calendar prompt then listed
   * the formats each platform may use. So the format is upstream data too —
   * read it rather than re-deciding it, or the calendar contradicts the post it
   * is scheduling.
   *
   * Matched against the PLATFORM'S OWN list for the same reason pillars are
   * matched against the known titles: a format lifted blindly out of prose can
   * be anything, including another platform's.
   */
  it("uses the format the post already chose when the platform offers it", () => {
    const { calendars } = buildCalendars({
      targets: [{ platform: "instagram", count: 1 }],
      posts: [post({ theme: "Sabah Ritüeli — Carousel: üç kare" })],
      pillars: [pillar("Sabah Ritüeli")],
    });

    expect(calendars[0].rows[0].format).toBe("Carousel");
  });

  it("varies through the platform's own formats when the post named none", () => {
    const posts = Array.from({ length: 3 }, (_, i) =>
      post({ theme: "Sabah Ritüeli — görsel yön", hook: `h${i}` }),
    );

    const { calendars } = buildCalendars({
      targets: [{ platform: "instagram", count: 3 }],
      posts,
      pillars: [pillar("Sabah Ritüeli")],
    });

    const formats = calendars[0].rows.map((r) => r.format);
    expect(new Set(formats).size).toBeGreaterThan(1);
  });

  it("never labels a row with another platform's format", () => {
    const { calendars } = buildCalendars({
      targets: [{ platform: "linkedin", count: 1 }],
      // "Reel" is an Instagram format; LinkedIn must not inherit it even though
      // the post's own theme says so.
      posts: [post({ platform: "linkedin", theme: "Sabah Ritüeli — Reel: x" })],
      pillars: [pillar("Sabah Ritüeli")],
    });

    expect(calendars[0].rows[0].format).not.toBe("Reel");
    expect(["Text post", "Document post", "Native video", "Poll"]).toContain(
      calendars[0].rows[0].format,
    );
  });

  /**
   * OBSERVED, on the 2026-07-20 baseline run. The sm_posts prompt asks for
   * "the exact pillar title, then ' — '", and the model wrote:
   *
   *   pillar title : "Hâlâ Burada"
   *   post theme   : "Pillar 1: Hâlâ Burada — Reel: Storytelling and metaphors…"
   *
   * It prefixed the ordinal. Matching with startsWith missed ALL 21 posts, so
   * every row fell back to the model's own label and the whole calendar was
   * grouped under headings no pillar step emitted.
   *
   * The title is therefore located WITHIN the theme's head — the segment before
   * the first " — " — rather than anchored at its start. The head, not the whole
   * theme, because the tail is a free-text visual direction that can easily
   * contain another pillar's words and would otherwise steal the match.
   */
  it("matches a pillar title the model prefixed with an ordinal", () => {
    const { calendars, unresolvedPillars } = buildCalendars({
      targets: [{ platform: "instagram", count: 1 }],
      posts: [
        post({
          theme: "Pillar 1: Hâlâ Burada — Reel: Storytelling and metaphors",
        }),
      ],
      pillars: [pillar("Hâlâ Burada"), pillar("Toprağa Bıraktığı İz")],
    });

    expect(calendars[0].rows[0].pillar).toBe("Hâlâ Burada");
    expect(unresolvedPillars).toHaveLength(0);
  });

  it("ignores a pillar title that only appears in the visual direction", () => {
    const { calendars } = buildCalendars({
      targets: [{ platform: "instagram", count: 1 }],
      posts: [
        post({
          // "Islatmayı Unutanlar" is a real pillar, but here it is prose in the
          // direction, not the post's own pillar. The head decides.
          theme:
            "Pillar 5: İsraf Etmeme Sözü — Carousel: Islatmayı Unutanlar temasına gönderme yapan kartlar",
        }),
      ],
      pillars: [pillar("İsraf Etmeme Sözü"), pillar("Islatmayı Unutanlar")],
    });

    expect(calendars[0].rows[0].pillar).toBe("İsraf Etmeme Sözü");
  });

  /**
   * Nothing upstream stops a pillar title from containing an em dash: `title`
   * is a bare string and the prompt only asks for something memorable. When it
   * happens, the head-before-the-first-em-dash rule used to cut the title in
   * half, no candidate could match, and every post for that pillar was grouped
   * under an invented heading the pillars step never emitted — the exact
   * outcome the title matching exists to prevent.
   */
  it("resolves a pillar whose own title contains an em dash", () => {
    const { calendars, unresolvedPillars } = buildCalendars({
      targets: [{ platform: "instagram", count: 1 }],
      posts: [post({ theme: "Hâlâ Burada — Yine — Reel: macro shots" })],
      pillars: [pillar("Hâlâ Burada — Yine"), pillar("Toprağa Bıraktığı İz")],
    });

    expect(calendars[0].rows[0].pillar).toBe("Hâlâ Burada — Yine");
    expect(unresolvedPillars).toEqual([]);
  });

  /**
   * The silent variant of the same bug: when the truncated head happens to
   * equal ANOTHER real pillar's title, the row resolved to the wrong pillar and
   * nothing was reported at all, because from the builder's side it looked like
   * a clean match.
   */
  it("prefers the em-dash title over the shorter pillar its head collides with", () => {
    const { calendars, unresolvedPillars } = buildCalendars({
      targets: [{ platform: "instagram", count: 1 }],
      posts: [post({ theme: "Hâlâ Burada — Yine — Reel: macro shots" })],
      pillars: [pillar("Hâlâ Burada"), pillar("Hâlâ Burada — Yine")],
    });

    expect(calendars[0].rows[0].pillar).toBe("Hâlâ Burada — Yine");
    expect(unresolvedPillars).toEqual([]);
  });

  /**
   * The head rule still has to hold for titles WITHOUT an em dash: a title that
   * only shows up in the free-text direction must not win just because the
   * search stopped truncating.
   */
  it("still refuses a title that appears only after the separator", () => {
    const { calendars, unresolvedPillars } = buildCalendars({
      targets: [{ platform: "instagram", count: 1 }],
      posts: [post({ theme: "Bilinmeyen — Reel: Sabah Ritüeli göndermesi" })],
      pillars: [pillar("Sabah Ritüeli")],
    });

    expect(calendars[0].rows[0].pillar).toBe("Bilinmeyen");
    expect(unresolvedPillars).toHaveLength(1);
  });
});
