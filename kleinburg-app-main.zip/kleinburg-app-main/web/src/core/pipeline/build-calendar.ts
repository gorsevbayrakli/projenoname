import { platformDef } from "../platforms";
import type { CalendarTarget, PillarItem, PostItem } from "./inputs";
import type { ContentCalendar } from "./schemas";

/**
 * Deterministic content calendar.
 *
 * Builds the content_calendar step's output from material that already exists,
 * with no model call. Framework-neutral (no react/next), like the rest of core.
 */

export interface BuildCalendarInput {
  targets: readonly CalendarTarget[];
  posts: readonly PostItem[];
  pillars: readonly PillarItem[];
}

/** A post whose `theme` could not be tied back to any selected pillar. */
export interface UnresolvedPillar {
  platform: string;
  theme: string;
}

/**
 * A platform that got fewer rows than the project asked for.
 *
 * `scheduled` is what the approved posts could fill; the gap is the number of
 * posts step 8 still owes. The builder never closes that gap itself — the copy
 * would have to be invented, which is precisely the job that was moved out of
 * this step.
 */
export interface CalendarShortfall {
  platform: string;
  requested: number;
  scheduled: number;
}

export interface BuildCalendarResult {
  calendars: ContentCalendar["calendars"];
  /** Platforms whose row count fell short of the requested count. */
  shortfalls: CalendarShortfall[];
  /**
   * Posts scheduled under a pillar heading that no selected pillar produced.
   *
   * Reported rather than swallowed: the row is still worth showing (see the
   * test), but a heading with no pillar behind it is a real drift signal and
   * the caller has to be able to say so out loud (hard rule 5).
   */
  unresolvedPillars: UnresolvedPillar[];
}

/**
 * The pillar title a post's `theme` refers to, or null when none matches.
 *
 * The sm_posts prompt writes `theme` as "<pillar title> — <format and visual
 * direction>". Matching against the known titles (rather than taking whatever
 * sits before the separator) is what keeps a drifted separator, an em dash
 * inside a title, or a missing separator from minting a pillar that the pillars
 * step never emitted.
 *
 * SEARCHED WITHIN THE HEAD, NOT ANCHORED AT ITS START. The prompt says the
 * theme begins with the title; the 2026-07-20 baseline run says otherwise —
 * the model wrote "Pillar 1: Hâlâ Burada — Reel: …" against a pillar titled
 * "Hâlâ Burada", and an anchored match missed all 21 posts, dropping the entire
 * calendar onto headings no pillar step emitted. So the ordinal (or any other
 * decoration the model adds) is tolerated.
 *
 * THE TITLE MUST BEGIN IN THE HEAD — before the first em dash — because the
 * tail is a free-text visual direction that routinely mentions other pillars'
 * words. Searching the whole theme freely would let a direction reading
 * "…Islatmayı Unutanlar temasına gönderme…" steal the row from its real pillar.
 *
 * The constraint is on where the title STARTS, not on where it ends, and that
 * distinction is the whole point: a title may itself contain an em dash. Cutting
 * the theme at the first dash and searching only the fragment left behind meant
 * a title like "Hâlâ Burada — Yine" could never match its own theme, so every
 * post under it was grouped beneath the invented heading "Hâlâ Burada" — the
 * exact failure this function exists to prevent, and worse when that fragment
 * happens to be another real pillar, since then the row resolves to the wrong
 * pillar with nothing reported.
 *
 * LONGEST TITLE FIRST, so that when one pillar's title contains another's
 * ("Sabah" vs "Sabah Ritüeli", or "Hâlâ Burada" vs "Hâlâ Burada — Yine") the
 * more specific one wins. Shortest-first would match "Sabah" inside every
 * "Sabah Ritüeli" theme and silently mislabel them.
 */
function resolvePillar(
  theme: string,
  pillars: readonly PillarItem[],
): string | null {
  const haystack = theme.trim();
  const headEnd = headEndIndex(haystack);
  const candidates = [...pillars]
    .map((p) => p.title.trim())
    .filter((title) => title.length > 0)
    .sort((a, b) => b.length - a.length);

  for (const title of candidates) {
    const at = haystack.indexOf(title);
    if (at !== -1 && at < headEnd) return title;
  }
  return null;
}

/**
 * Where the head ends: the first em dash, or the end of the string.
 *
 * A title is allowed to start anywhere before this point and to run past it,
 * which is how a title carrying its own em dash still matches.
 */
function headEndIndex(theme: string): number {
  const at = theme.indexOf("—");
  return at === -1 ? theme.length : at;
}

/**
 * The part of a theme that was supposed to name the pillar: everything before
 * the prompt's own " — " separator, or the whole string when it has none. Used
 * only for the unmatched label — resolution itself no longer truncates here.
 *
 * Split on the em dash alone rather than on " — " with its spaces, because the
 * spacing around it is the model's to get wrong and the dash is the signal.
 */
function themeHead(theme: string): string {
  const [head] = theme.split("—");
  return (head ?? theme).trim();
}

/**
 * What to show when no pillar matched: the head of the theme. Deliberately NOT a guess at which pillar was
 * meant — it reproduces what the model actually wrote, and `unresolvedPillars`
 * carries the fact that it is unbacked.
 */
function fallbackPillarLabel(theme: string): string {
  return themeHead(theme);
}

/** Days in the month a calendar covers. Matches the prompt's "Day 1".."Day 30". */
export const CALENDAR_DAYS = 30;

/**
 * The format a post already chose, if the platform offers it.
 *
 * sm_posts writes the format into `theme` after the pillar title ("Pillar —
 * Reel: macro shots"), so the decision was already made one step upstream and
 * re-deciding it here would let the calendar contradict the post it schedules.
 *
 * Matched against THIS PLATFORM'S list, which is the whole safety property: a
 * LinkedIn post whose theme says "Reel" (a model slip, or a theme copied
 * between platforms) must not put an Instagram format on a LinkedIn row.
 * Unmatched falls through to rotation rather than being trusted.
 *
 * Longest-first so "Native video" wins over a hypothetical "video", for the
 * same reason pillar titles are matched longest-first.
 */
function formatFromTheme(
  theme: string,
  formats: readonly string[],
): string | null {
  const haystack = theme.toLowerCase();
  const candidates = [...formats].sort((a, b) => b.length - a.length);
  for (const format of candidates) {
    if (haystack.includes(format.toLowerCase())) return format;
  }
  return null;
}

/**
 * Reorder so the same pillar never lands on consecutive posting days.
 *
 * sm_posts emits posts pillar by pillar ("output all posts for Pillar 1, then
 * Pillar 2, never interleave"), so the input order is the worst possible
 * calendar and interleaving is the actual work.
 *
 * Greedy, largest-bucket-first: at each slot take the pillar with the most
 * posts still unplaced, except the one just placed. Taking the largest is what
 * makes the spacing achievable — a pillar holding half the posts has to be
 * placed every other day, and any other choice strands it in a run at the end.
 *
 * When the ONLY posts left belong to the pillar just placed, the constraint is
 * arithmetically impossible (e.g. 3 of 4 posts share a pillar) and the run is
 * accepted rather than dropping a post. Losing real approved copy to satisfy a
 * pacing preference would be the wrong trade.
 */
function interleaveByPillar<T>(
  items: readonly T[],
  pillarOf: (item: T) => string,
): T[] {
  const buckets = new Map<string, T[]>();
  for (const item of items) {
    const key = pillarOf(item);
    const bucket = buckets.get(key);
    if (bucket) bucket.push(item);
    else buckets.set(key, [item]);
  }

  const ordered: T[] = [];
  let previous: string | null = null;

  while (ordered.length < items.length) {
    const available = [...buckets.entries()].filter(
      ([, list]) => list.length > 0,
    );
    const preferred = available.filter(([key]) => key !== previous);
    const pool = preferred.length > 0 ? preferred : available;
    // Ties broken by first appearance, which `Map` preserves, so the output is
    // deterministic for a given input rather than dependent on sort stability.
    const [key, list] = pool.reduce((best, entry) =>
      entry[1].length > best[1].length ? entry : best,
    );
    ordered.push(list.shift() as T);
    previous = key;
  }

  return ordered;
}

/**
 * The day label for post `index` of `total`, spread evenly across the month.
 *
 * Even division rather than consecutive days: three posts belong on days 1, 11
 * and 21, not 1, 2, 3. Clamped at CALENDAR_DAYS because a platform can carry
 * more than 30 posts once "completeness wins over the number" applies, and a
 * "Day 34" would be outside the month the calendar claims to cover.
 */
function dayLabelFor(index: number, total: number): string {
  const step = CALENDAR_DAYS / Math.max(total, 1);
  const day = Math.min(CALENDAR_DAYS, 1 + Math.round(index * step));
  return `Day ${day}`;
}

export function buildCalendars(input: BuildCalendarInput): BuildCalendarResult {
  const unresolvedPillars: UnresolvedPillar[] = [];
  const shortfalls: CalendarShortfall[] = [];

  const calendars = input.targets.map((target) => {
    // Pillars are resolved BEFORE ordering, because the pacing rule is stated
    // in terms of pillars: interleaving raw posts would space `theme` strings,
    // and two themes under one pillar would still land back to back.
    const labelled = input.posts
      .filter((post) => post.platform === target.platform)
      .map((post) => {
        const theme = post.theme ?? "";
        const matched = resolvePillar(theme, input.pillars);
        if (matched === null) {
          unresolvedPillars.push({ platform: target.platform, theme });
        }
        return { post, pillar: matched ?? fallbackPillarLabel(theme) };
      });

    const ordered = interleaveByPillar(labelled, (entry) => entry.pillar);
    const formats = platformDef(target.platform)?.formats ?? [];

    // Rotation position is tracked separately from the row index so that posts
    // which named their own format do not consume a slot: three posts that all
    // say "Reel" must not push the two unnamed ones onto the same fallback.
    let rotation = 0;

    return {
      platform: target.platform,
      rows: ordered.map(({ post, pillar }, index) => {
        const chosen = formatFromTheme(post.theme ?? "", formats);
        const format =
          chosen ??
          (formats.length > 0 ? formats[rotation++ % formats.length] : "");
        return {
          day: dayLabelFor(index, ordered.length),
          format,
          pillar,
          hook: post.hook ?? "",
          caption: post.caption ?? "",
          cta: post.cta ?? "",
          hashtags: post.hashtags ?? [],
        };
      }),
    };
  });

  for (const [index, target] of input.targets.entries()) {
    const scheduled = calendars[index].rows.length;
    // Only a SHORTFALL is reported. Exceeding the count is the documented and
    // intended outcome when a platform has more approved posts than its
    // cadence asked for ("completeness wins over the number"), so it is not a
    // finding and must not be surfaced as one.
    if (scheduled < target.count) {
      shortfalls.push({
        platform: target.platform,
        requested: target.count,
        scheduled,
      });
    }
  }

  return { calendars, shortfalls, unresolvedPillars };
}
