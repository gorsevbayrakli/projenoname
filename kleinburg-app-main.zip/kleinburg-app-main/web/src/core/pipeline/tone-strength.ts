/**
 * T35 — measuring how substantive the brand context's "Tone of voice" section is.
 *
 * Every post prompt takes the brand's voice from BRAND_CONTEXT's tone section.
 * When that section is thin — the uploaded documents said little about tone —
 * the model has nothing to translate and silently falls back to the platform's
 * generic voice. Nothing in the output looks wrong: the posts are fluent, they
 * just are not this brand. That is a silent failure (hard rule 5), so the
 * engine measures the input and the UI warns a human.
 *
 * ## What this is NOT
 *
 * - Not an LLM judge. A model call here would add cost and nondeterminism to
 *   every single generation, and could not be unit-tested.
 * - Not prose parsing of raw model output (hard rule 4). The input here is the
 *   ALREADY Zod-validated `brandContext` string — a value that passed
 *   `brandContextSchema`. We are inspecting validated content, not extracting
 *   structure the schema failed to guarantee. Nothing downstream depends on
 *   what we find: the worst case of a wrong read is a warning a human ignores.
 *   This stays a MEASUREMENT; no caller may treat its output as a data contract.
 * - Not language-keyed. The analysis is written in the project's chosen
 *   language (Elif's decision — no defaulting to Turkish), and the section
 *   headings get translated with it. So the heuristic counts STRUCTURE —
 *   words, quoted fragments, lines — and never looks for "Tone of voice",
 *   "Ton", "Never", "(hypothesis)", or any other vocabulary. Word counting goes
 *   through Intl.Segmenter, so scripts without word spacing (Japanese, Chinese,
 *   Thai) are counted correctly rather than collapsing to one "word".
 *
 * ## Locating the section without reading the headings
 *
 * `context_generation_prompt.md` prescribes one exact shape for criterion 11 —
 * a top-level bullet followed by indented sub-bullets:
 *
 *     - **Tone of voice:**
 *       - Voice: …
 *       - Example lines: 1) … 2) … 3) …
 *       - Never: …
 *
 * So the anchor is that SHAPE, not "the last line indented by at most one
 * space": a top-level bullet whose next non-blank line is a more-indented list
 * item, with at least two such items under it. The LAST such block in the text
 * is the tone section, and it ends at the first following non-blank line whose
 * indent is <= the opening bullet's (a sibling bullet, a closing paragraph), or
 * at a markdown heading, or at a `===` separator — the prompts are full of
 * those. `prompts.test.ts` pins that template so the coupling cannot rot
 * silently.
 *
 * Two weaker fallbacks, both biased hard toward silence:
 *
 *   - `bullet` — bullets exist but nothing carries the block shape (an LLM
 *     emitting a flat list, a markdown normalizer stripping indentation, a user
 *     reflowing the textarea). We read the last top-level bullet, but we do not
 *     trust it: if what we read is an implausibly small share of the document
 *     (< MIN_SECTION_SHARE), the read is treated as a miss and nothing is
 *     flagged. An unlocatable section must produce silence, not a wolf cry.
 *   - `text` — no bullet structure at all (a hand-edited brand context). The
 *     whole text is assessed, which for any real brand context clears every
 *     threshold and stays silent.
 *
 * ## The rule, and why these thresholds
 *
 * One NECESSARY condition, then three interchangeable signals.
 *
 * Necessary (on a `block` read only): at least MIN_EXAMPLE_FRAGMENTS example
 * fragment. The prompt mandates 2-3 example lines, so a located tone block with
 * zero real example fragments is thin almost by definition — and this is the
 * case the feature exists for. A model with nothing to say does NOT emit a "—"
 * stub; the prompt tells it to write a hypothesis, so it produces a wordy
 * paragraph explaining that the documents contained no tone guidance. That
 * paragraph is long, so a pure volume-of-words rule passes a section whose
 * literal content is "there is no tone information here". Requiring an example
 * fragment catches it STRUCTURALLY, without ever matching on vocabulary. The
 * condition is not applied to the weaker reads: there we are not confident we
 * are looking at the tone section at all, and a legitimate one-paragraph voice
 * description quotes nothing.
 *
 * Signals, of which fewer than two means thin:
 *
 *   A. length      — at least 45 word-like tokens in the section
 *   B. examples    — at least 2 example fragments (quoted spans, or items of
 *                    an "1) … 2) …" enumeration)
 *   C. parts       — at least 3 substantive lines (>= 4 words each), i.e. the
 *                    section has a voice description AND examples AND a
 *                    never-say note rather than one stub line
 *
 * Plus one generosity valve: a section of 70+ words is not flagged whatever its
 * shape — but only once the necessary condition above has held. A long
 * paragraph that happens to quote nothing is a legitimate way to describe a
 * voice, and this warning has to survive being shown to people: a false alarm
 * on a genuinely rich section teaches users to ignore it, which costs more than
 * a missed weak one. Every threshold is deliberately set on the permissive side
 * for the same reason: when the read is ambiguous, the section is treated as
 * fine.
 */

/** How the section under test was found. */
export type ToneLocator =
  /** The prompt's bullet + indented sub-bullets block. Trusted. */
  | "block"
  /** Bullets exist but no block shape; the last top-level bullet. Untrusted. */
  | "bullet"
  /** No bullet structure; the whole text was assessed. */
  | "text";

/**
 * The full read. The extra fields exist so the TESTS can pin WHY a verdict was
 * reached, not just what it was. The UI deliberately reads only `.weak`:
 * surfacing a reason to the user would need Turkish copy that does not exist in
 * the message catalog yet.
 */
export interface ToneStrength {
  /** True when the tone section looks too thin to carry the brand's voice. */
  weak: boolean;
  /** Word-like tokens in the located section. */
  wordCount: number;
  /** Quoted or enumerated example fragments found in the section. */
  exampleCount: number;
  /** Lines in the section carrying at least MIN_LINE_WORDS words. */
  substantiveLineCount: number;
  /** How many of the three signals held (0-3). */
  signals: number;
  /** How the section was located. */
  locator: ToneLocator;
  /**
   * False when the runtime has no `Intl.Segmenter` and the read fell back to a
   * crude split. The verdict is then forced to `weak: false` — an environment
   * we cannot measure in must not produce warnings.
   */
  measurable: boolean;
}

/** Signal A: words in the section. */
export const MIN_SECTION_WORDS = 45;
/** Signal B: example fragments in the section. */
export const MIN_EXAMPLES = 2;
/** Signal C: lines carrying real content. */
export const MIN_SUBSTANTIVE_LINES = 3;
/** Words a line needs before it counts toward signal C. */
const MIN_LINE_WORDS = 4;
/** Words above which the section is never flagged, whatever its shape. */
export const ALWAYS_ENOUGH_WORDS = 70;
/** Signals needed to stay unflagged. */
const REQUIRED_SIGNALS = 2;
/**
 * Example fragments a LOCATED tone block must carry before any other signal is
 * even consulted. One, not two: the bar is "the section shows the brand's voice
 * at all", not "the model followed the template exactly".
 */
export const MIN_EXAMPLE_FRAGMENTS = 1;
/**
 * Share of the document's words a fallback (`bullet`) read must reach before it
 * is trusted enough to warn on. Below this we assume the locator missed.
 */
export const MIN_SECTION_SHARE = 0.1;
/** Words inside a quoted span before it counts as an example. */
const MIN_QUOTE_WORDS = 2;
/** Words in an enumerated item before it counts as an example. */
const MIN_ENUM_WORDS = 2;
/** Sub-items a top-level bullet needs under it to read as the prompt's block. */
const MIN_SUB_ITEMS = 2;

/** A markdown list item at any indent: `- x`, `* x`, `+ x`, `1. x`, `1) x`. */
const LIST_ITEM = /^[ \t]*(?:[-*+•]|\d+[).])[ \t]+\S/;
/** A markdown heading, which ends a section. */
const HEADING = /^#{1,6}\s/;
/** A rule line, which also ends a section (the prompts are full of `===`). */
const SEPARATOR = /^[ \t]*(?:={3,}|-{3,}|_{3,})[ \t]*$/;
/** Indent at or below which a bullet counts as top-level. */
const TOP_LEVEL_INDENT = 1;
/** Leading list/emphasis noise stripped before counting a line's words. */
const LINE_PREFIX = /^\s*(?:[-*+•—]|\d+[.)])\s*/;

/**
 * Quote pairs used across the languages this app runs in. Straight single
 * quotes are deliberately absent: they collide with apostrophes (Turkish
 * "markanın", English "don't") and would invent examples that are not there.
 */
const QUOTE_PATTERNS: readonly RegExp[] = [
  /"([^"\n]+)"/g,
  /“([^”\n]+)”/g, // “ … ”
  /„([^“”\n]+)[“”]/g, // „ … “ / „ … ”
  /«([^»\n]+)»/g, // « … »
  /「([^」\n]+)」/g, // 「 … 」
  /‘([^’\n]+)’/g, // ‘ … ’
];

/**
 * One item of an "1) … 2) … 3) …" enumeration.
 *
 * The body is LAZY and stops at the next enumerator on the line: a greedy
 * `[^\n]*` swallows the whole line, so the inline form the prompt's own output
 * template prescribes matched exactly once no matter how many items it held.
 */
const ENUMERATED_ITEM = /(?:^|[\s(])(\d+)[).][ \t]*([^\n]*?)(?=[ \t]\d+[).][ \t]|$)/gm;

/** A half-open [start, end) range of the section string. */
interface Span {
  start: number;
  end: number;
}

/**
 * Word segmentation per Unicode rather than a split on spaces, so scripts
 * without word spacing are counted rather than read as a single word.
 *
 * Built ONCE: `Intl.Segmenter` is stateless, and this used to be constructed
 * per quote match and per line — hundreds of constructions per keystroke on a
 * large hand-edited context. An explicit locale keeps it deterministic across
 * machines; it selects segmentation rules, not a vocabulary, so no language is
 * privileged.
 *
 * `undefined` = not yet probed, `null` = unavailable in this runtime. The
 * constructor is genuinely absent on older browsers (Firefox shipped it in
 * 125), and this module runs inside a "use client" component in both SSR and
 * the browser — an unguarded throw during render would take out the whole
 * brand-context step for the sake of a cosmetic warning.
 */
let cachedSegmenter: Intl.Segmenter | null | undefined;

function wordSegmenter(): Intl.Segmenter | null {
  if (cachedSegmenter !== undefined) return cachedSegmenter;
  if (typeof Intl === "undefined" || typeof Intl.Segmenter !== "function") {
    cachedSegmenter = null;
    return cachedSegmenter;
  }
  try {
    cachedSegmenter = new Intl.Segmenter("en", { granularity: "word" });
  } catch {
    // Not a swallowed pipeline failure (hard rule 5): this is a capability
    // probe, and its result is reported out as `measurable: false`, which
    // forces the verdict to silence rather than hiding a broken read.
    cachedSegmenter = null;
  }
  return cachedSegmenter;
}

/** Word-like tokens, or a crude split when the runtime cannot segment. */
function countWords(text: string): number {
  const segmenter = wordSegmenter();
  if (!segmenter) {
    return text.split(/[\s\p{P}\p{S}]+/u).filter(Boolean).length;
  }
  let count = 0;
  for (const segment of segmenter.segment(text)) {
    if (segment.isWordLike) count += 1;
  }
  return count;
}

/** Visual indent of a line, tabs expanded so mixed indentation still orders. */
function indentOf(line: string): number {
  const lead = /^[ \t]*/.exec(line)?.[0] ?? "";
  let width = 0;
  for (const ch of lead) width += ch === "\t" ? 4 : 1;
  return width;
}

/** True for a line that terminates a section opened at `openIndent`. */
function endsSection(line: string, openIndent: number): boolean {
  if (line.trim() === "") return false; // blank lines belong to the section
  if (HEADING.test(line) || SEPARATOR.test(line)) return true;
  return indentOf(line) <= openIndent;
}

/** Where the bullet opened at `start` stops (exclusive). */
function sectionEnd(lines: readonly string[], start: number): number {
  const openIndent = indentOf(lines[start]);
  for (let i = start + 1; i < lines.length; i += 1) {
    if (endsSection(lines[i], openIndent)) return i;
  }
  return lines.length;
}

/**
 * The tone section, plus how much we trust the read. See the module docstring
 * for why the anchor is the prompt's block shape and not "the last bullet".
 */
function locateToneSection(text: string): {
  section: string;
  locator: ToneLocator;
} {
  const lines = text.split("\n");

  let lastTopLevel = -1;
  let lastBlock = -1;
  for (let i = 0; i < lines.length; i += 1) {
    if (!LIST_ITEM.test(lines[i])) continue;
    const openIndent = indentOf(lines[i]);
    if (openIndent > TOP_LEVEL_INDENT) continue;
    lastTopLevel = i;

    // A block is a top-level bullet whose next non-blank line is a MORE
    // indented list item, with at least MIN_SUB_ITEMS of them under it.
    const end = sectionEnd(lines, i);
    let subItems = 0;
    let sawFirstNonBlank = false;
    let opensWithSubItem = false;
    for (let j = i + 1; j < end; j += 1) {
      const isSubItem =
        LIST_ITEM.test(lines[j]) && indentOf(lines[j]) > openIndent;
      if (!sawFirstNonBlank && lines[j].trim() !== "") {
        sawFirstNonBlank = true;
        opensWithSubItem = isSubItem;
      }
      if (isSubItem) subItems += 1;
    }
    if (opensWithSubItem && subItems >= MIN_SUB_ITEMS) lastBlock = i;
  }

  if (lastBlock !== -1) {
    return {
      section: lines.slice(lastBlock, sectionEnd(lines, lastBlock)).join("\n"),
      locator: "block",
    };
  }
  if (lastTopLevel !== -1) {
    return {
      section: lines
        .slice(lastTopLevel, sectionEnd(lines, lastTopLevel))
        .join("\n"),
      locator: "bullet",
    };
  }
  return { section: text, locator: "text" };
}

/** Quoted spans carrying real words, deduplicated and never nested. */
function quoteSpans(section: string): Span[] {
  const found: Span[] = [];
  for (const pattern of QUOTE_PATTERNS) {
    // Fresh lastIndex per call: the module-level /g regexes are reused.
    pattern.lastIndex = 0;
    let match: RegExpExecArray | null;
    while ((match = pattern.exec(section)) !== null) {
      if (countWords(match[1]) < MIN_QUOTE_WORDS) continue;
      found.push({ start: match.index, end: match.index + match[0].length });
    }
  }
  found.sort((a, b) => a.start - b.start || b.end - a.end);
  const spans: Span[] = [];
  for (const span of found) {
    const last = spans[spans.length - 1];
    // Different quote styles can match the same or a nested region; one
    // example fragment must never be counted twice.
    if (last && span.start < last.end) continue;
    spans.push(span);
  }
  return spans;
}

/**
 * Example fragments: quoted spans, plus enumerated items not already counted as
 * a quote. The overlap check is the point — `1) "Hello there"` is ONE example,
 * and summing the two families made MIN_EXAMPLES=2 effectively mean 1.
 *
 * Enumerated items count only when they form a run 1, 2, … — the shape the
 * prompt asks for. A lone "3." or "1998." is an ordinary ordinal in running
 * prose ("3. tekil şahıs kullanılır", "1998. yılından beri") and used to
 * register as an example. Requiring the run keeps the exclusion structural
 * rather than language-keyed.
 */
function countExamples(section: string): number {
  const quotes = quoteSpans(section);
  let count = quotes.length;

  ENUMERATED_ITEM.lastIndex = 0;
  let expected = 1;
  const run: Span[] = [];
  let match: RegExpExecArray | null;
  while ((match = ENUMERATED_ITEM.exec(section)) !== null) {
    if (Number(match[1]) !== expected) continue;
    expected += 1;
    if (countWords(match[2]) < MIN_ENUM_WORDS) continue;
    run.push({ start: match.index, end: match.index + match[0].length });
  }
  // A single "1)" is an ordinal, not an enumeration.
  if (expected - 1 < 2) return count;

  for (const item of run) {
    const alreadyQuoted = quotes.some(
      (quote) => quote.start >= item.start && quote.start < item.end,
    );
    if (!alreadyQuoted) count += 1;
  }
  return count;
}

/** Lines carrying real content, once list markers and emphasis are stripped. */
function countSubstantiveLines(section: string): number {
  return section
    .split("\n")
    .map((line) => line.replace(LINE_PREFIX, "").replace(/\*\*/g, ""))
    .filter((line) => countWords(line) >= MIN_LINE_WORDS).length;
}

/**
 * Assess the tone section of a Zod-validated brand context.
 *
 * Does not throw for any string input, and degrades to `weak: false` on a
 * runtime without `Intl.Segmenter` rather than throwing during render: a wrong
 * read must cost a missing warning, never a broken step. Empty or missing
 * content reads as weak — callers gate on "content exists" before showing
 * anything.
 */
export function assessToneStrength(
  brandContext: string | null | undefined,
): ToneStrength {
  const text = typeof brandContext === "string" ? brandContext : "";
  const { section, locator } = locateToneSection(text);
  const measurable = wordSegmenter() !== null;

  const wordCount = countWords(section);
  const exampleCount = countExamples(section);
  const substantiveLineCount = countSubstantiveLines(section);

  const signals =
    (wordCount >= MIN_SECTION_WORDS ? 1 : 0) +
    (exampleCount >= MIN_EXAMPLES ? 1 : 0) +
    (substantiveLineCount >= MIN_SUBSTANTIVE_LINES ? 1 : 0);

  const thin = wordCount < ALWAYS_ENOUGH_WORDS && signals < REQUIRED_SIGNALS;

  let weak: boolean;
  if (!measurable) {
    weak = false;
  } else if (locator === "block") {
    // The one read we trust: the prompt's own shape, found where it belongs.
    weak = exampleCount < MIN_EXAMPLE_FRAGMENTS || thin;
  } else if (locator === "bullet") {
    const totalWords = countWords(text);
    const share = totalWords > 0 ? wordCount / totalWords : 1;
    weak = share >= MIN_SECTION_SHARE && thin;
  } else {
    weak = thin;
  }

  return {
    weak,
    wordCount,
    exampleCount,
    substantiveLineCount,
    signals,
    locator,
    measurable,
  };
}

/** Test seam: forget the probed segmenter so a stubbed runtime is re-read. */
export function resetSegmenterForTests(): void {
  cachedSegmenter = undefined;
}
