/**
 * Turning an unexpected throw into a line that is SAFE to write to the server
 * log (#40 review, finding 3).
 *
 * Hard rule 5 forbids swallowing an error silently, so the generic 500 path in
 * `lib/api-errors.ts` must log. But "log the error" and "log a password" are one
 * careless interpolation apart: a driver error can quote the statement that
 * failed, and a hand-written message can quote its own input. So nothing is
 * logged verbatim.
 *
 * The contract, in order:
 *  1. Only `name`, `message` and `stack` are read. Arbitrary enumerable
 *     properties of the thrown value are NEVER walked — that is where a driver
 *     parks bound parameters (`err.parameters`, `err.query`, `err.detail`).
 *  2. Whatever survives is run through the masks below, so a secret that
 *     reaches `message` anyway still does not reach the log.
 *
 * Framework-neutral (hard rule 1): no next, no react, no logger dependency —
 * it returns a string and lets the caller decide where it goes.
 */

/** What a masked run of characters is replaced with. */
export const REDACTED = "[redacted]";

/**
 * The masks, applied in order. Each one targets a shape a secret actually
 * arrives in, not a general "looks secret" heuristic — a guess that is too
 * broad would redact the very words that make a log useful.
 */
const MASKS: readonly { pattern: RegExp; replacement: string }[] = [
  // argon2 / bcrypt style hashes: `$argon2id$v=19$m=...$<salt>$<hash>`.
  // A hash is not a password but it is still credential material, and it is the
  // single most likely secret to appear in a Postgres error about `users`.
  // The comma is NOT a terminator here: argon2 encodes its parameters as
  // `m=65536,t=3,p=4`, so stopping at the first comma would leave the salt and
  // the digest in the log.
  { pattern: /\$(?:argon2[a-z]*|2[aby])\$[^\s"')]*/gi, replacement: REDACTED },

  // `password=hunter2`, `currentPassword: hunter2`, `secret => hunter2`.
  {
    pattern:
      /\b([A-Za-z_]*(?:password|passwd|secret|token|apikey|api_key|authorization)[A-Za-z_]*)\b(\s*(?:[:=]>?|=)\s*)("[^"]*"|'[^']*'|[^\s,;)}\]]+)/gi,
    replacement: `$1$2${REDACTED}`,
  },

  // JSON: `"password":"hunter2"` — covered by the rule above only when the key
  // is unquoted, so quoted keys get their own pass.
  {
    pattern:
      /("(?:[A-Za-z_]*(?:password|passwd|secret|token|apikey|api_key|authorization)[A-Za-z_]*)"\s*:\s*)("[^"]*"|[^\s,;)}\]]+)/gi,
    replacement: `$1"${REDACTED}"`,
  },

  // Postgres unique-violation detail: `Key (password_hash)=(…) already exists`.
  {
    pattern:
      /(\((?:[A-Za-z_]*(?:password|passwd|secret|token)[A-Za-z_]*)\)\s*=\s*)\([^)]*\)/gi,
    replacement: `$1(${REDACTED})`,
  },
];

/** Apply every mask to a single string. */
export function redactSecrets(text: string): string {
  return MASKS.reduce(
    (acc, { pattern, replacement }) => acc.replace(pattern, replacement),
    text,
  );
}

/**
 * A log-safe description of a thrown value.
 *
 * Deliberately lossy. An operator gets the error class, the message and the
 * stack — enough to find the line — and never gets a credential. If the value
 * is not an Error at all, its type is reported rather than its contents,
 * because a thrown plain object is exactly the case where the contents are
 * most likely to be a request body.
 */
export function describeErrorForLog(e: unknown): string {
  if (!(e instanceof Error)) {
    return `non-Error thrown (typeof ${typeof e})`;
  }
  const head = `${e.name}: ${redactSecrets(e.message)}`;
  const stack = e.stack ? redactSecrets(e.stack) : "";
  // The stack normally starts with `Name: message`; avoid printing it twice.
  return stack.startsWith(`${e.name}:`) ? stack : `${head}\n${stack}`;
}
