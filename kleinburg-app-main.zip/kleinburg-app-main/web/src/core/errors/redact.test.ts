import { describe, expect, it } from "vitest";

import { describeErrorForLog, REDACTED, redactSecrets } from "./redact";

/**
 * The generic 500 path logs (hard rule 5) — these tests are what stop it
 * logging a credential while doing so (#40 review, finding 3).
 */
describe("redactSecrets", () => {
  it("masks an argon2 hash", () => {
    const out = redactSecrets(
      'insert into users failed: $argon2id$v=19$m=65536,t=3,p=4$c29tZXNhbHQ$hashbytes',
    );
    expect(out).toContain(REDACTED);
    expect(out).not.toContain("hashbytes");
    expect(out).not.toContain("argon2id$v=19");
  });

  it("masks password-ish key/value pairs whatever the separator", () => {
    for (const sample of [
      "password=hunter2correct",
      "currentPassword: hunter2correct",
      'temporaryPassword => "hunter2correct"',
      "API_KEY=hunter2correct",
      "authorization: hunter2correct",
    ]) {
      const out = redactSecrets(sample);
      expect(out, sample).not.toContain("hunter2correct");
      expect(out, sample).toContain(REDACTED);
    }
  });

  it("masks a JSON body with a quoted password key", () => {
    const out = redactSecrets('{"username":"elif","newPassword":"hunter2correct"}');
    expect(out).not.toContain("hunter2correct");
    // The non-secret field survives — a log that redacts everything is useless.
    expect(out).toContain("elif");
  });

  it("masks a Postgres unique-violation detail naming a password column", () => {
    const out = redactSecrets(
      "Key (password_hash)=(abc123secret) already exists.",
    );
    expect(out).not.toContain("abc123secret");
  });

  it("leaves an ordinary message untouched", () => {
    const message = 'duplicate key value violates unique constraint "users_username_unique"';
    expect(redactSecrets(message)).toBe(message);
  });
});

describe("describeErrorForLog", () => {
  it("reports the error class and message", () => {
    const out = describeErrorForLog(new TypeError("pool exhausted"));
    expect(out).toContain("TypeError");
    expect(out).toContain("pool exhausted");
  });

  it("redacts a secret that reached the message", () => {
    const out = describeErrorForLog(
      new Error('failed for password="hunter2correct"'),
    );
    expect(out).not.toContain("hunter2correct");
  });

  /**
   * The load-bearing half: a driver parks bound parameters on the error OBJECT,
   * not in its message. Reading only name/message/stack is what keeps them out.
   */
  it("never walks arbitrary properties of the thrown value", () => {
    const err = Object.assign(new Error("insert failed"), {
      parameters: ["elif", "hunter2correct"],
      query: "insert into users (password_hash) values ($1)",
    });
    const out = describeErrorForLog(err);
    expect(out).not.toContain("hunter2correct");
    expect(out).not.toContain("password_hash");
  });

  it("reports a non-Error by TYPE, never by contents", () => {
    const out = describeErrorForLog({ newPassword: "hunter2correct" });
    expect(out).not.toContain("hunter2correct");
    expect(out).toBe("non-Error thrown (typeof object)");
  });
});
