/**
 * Stable, machine-readable identifiers for every error the API deliberately
 * surfaces to a browser (T25 follow-up).
 *
 * ── WHY CODES ────────────────────────────────────────────────────────────
 * The engine's error MESSAGES are Turkish and stay Turkish: they are the honest
 * server-side truth and the log line, and core/ may not import next-intl (hard
 * rule 1). But an English user must not read Turkish. So every deliberate error
 * additionally carries a code — a plain string, no framework, no i18n — which
 * the client maps to `apiErrors.<CODE>` in the interface language.
 *
 * The response body keeps BOTH: `{ error: <turkish message>, code }`. If a code
 * is missing or unknown to the catalog, the client falls back to `error`, so a
 * new code can never produce a blank message — only an untranslated one.
 * `messages.test.ts` walks this list and fails if either catalog lacks a key,
 * which is what stops an untranslated code from shipping at all.
 *
 * This module is deliberately dependency-free so core/, route handlers and
 * client components can all import the same source of truth.
 */
export const API_ERROR_CODES = [
  /** Fallback for an unexpected throw — message is NOT echoed (hard rule 5). */
  "UNEXPECTED",
  /** No session cookie / expired session. */
  "UNAUTHENTICATED",
  /** Authenticated, but not permitted to touch this resource (AccessError). */
  "ACCESS_DENIED",
  /** Generic NotFoundError default. */
  "NOT_FOUND",
  /** Generic ValidationError default — malformed body, bad params. */
  "INVALID_REQUEST",
  /** Generic ConflictError default. */
  "CONFLICT",

  // Auth
  "INVALID_CREDENTIALS",

  // Wizard / routing
  "INVALID_STEP",
  "CONTENT_OR_SELECTIONS_REQUIRED",

  // Resources
  "JOB_NOT_FOUND",
  "DOCUMENT_NOT_FOUND",
  "PROJECT_NOT_FOUND",

  // Projects
  "PROJECT_NAME_TAKEN",
  "PROJECT_NAME_EMPTY",
  "PROJECT_LANGUAGE_INVALID",
  "PROJECT_PLATFORMS_EMPTY",
  "PROJECT_POST_COUNT_INVALID",

  // Uploads
  "FILE_TOO_LARGE",
  "FILE_MISSING",

  // URL ingest (core/ingest/url-guard.ts + extract.ts)
  "URL_MISSING",
  "URL_INVALID",
  "URL_SCHEME",
  "URL_BLOCKED",
  "URL_FETCH_FAILED",
  "URL_TIMEOUT",
  "URL_TOO_MANY_REDIRECTS",
  "CONTENT_TOO_LARGE",

  // Document extraction
  "DOC_UNSUPPORTED_TYPE",
  "DOC_TOO_LITTLE_TEXT",
  /**
   * The parser itself threw: corrupt, password-protected, or otherwise
   * unreadable. Deliberately NOT DOC_TOO_LITTLE_TEXT — that code claims the
   * document was read and found empty, which is a different instruction to the
   * user (re-scan it) than this one (unlock or re-export it).
   */
  "DOC_PARSE_FAILED",

  // Admin / roles (T40)
  /** Authenticated, but not the super admin. */
  "ADMIN_REQUIRED",
  "BRAND_NAME_EMPTY",
  "BRAND_NAME_TAKEN",
  "BRAND_NOT_FOUND",
  "USERNAME_EMPTY",
  "USERNAME_TAKEN",
  "USER_NOT_FOUND",
  /**
   * A role change was refused because it would have left the installation
   * with no active administrator (#89). Not an ACCESS failure — the caller is
   * entitled to change roles — but a conflict with the state of the system,
   * so it travels as a ConflictError (409).
   */
  "LAST_ADMIN",

  // First-login password change (T40)
  /**
   * The account still carries an admin-set temporary password. Every API except
   * the change-password endpoint refuses until it is replaced.
   */
  "PASSWORD_CHANGE_REQUIRED",
  "PASSWORD_TOO_SHORT",
  "PASSWORD_SAME_AS_CURRENT",
  "CURRENT_PASSWORD_INVALID",

  /**
   * Too many failed credential attempts in the window; the caller must wait
   * (#40 review). Distinct from INVALID_CREDENTIALS so the UI can say "wait"
   * rather than "wrong password", which would be a lie.
   */
  "TOO_MANY_ATTEMPTS",

  // Account area (T43)
  "DISPLAY_NAME_TOO_LONG",
  "EMAIL_INVALID",
  "EMAIL_TOO_LONG",
  /** Another account already carries this address (case-insensitive). */
  "EMAIL_TAKEN",
  /** Interface language outside the supported set. */
  "LOCALE_INVALID",

  // Monthly spend cap (T51)
  /**
   * The brand has reached its monthly cap and new generation is refused.
   * Distinct from CONFLICT so the UI can say which cap, what was spent and
   * when it resets rather than "conflict".
   */
  "SPEND_CAP_EXCEEDED",
  /**
   * The brand's spend this month could not be established — the provider
   * reported no price for some calls and nothing in this brand can price them
   * — and even the most generous bound does not fit under the cap.
   *
   * ITS OWN CODE, and that is the point. It used to share SPEND_CAP_EXCEEDED,
   * so a broken pricing feed told the operator they had hit a cap they might
   * be nowhere near: a factually false sentence about a state the server had
   * gone to some trouble to distinguish. Two states, two codes, two sentences.
   */
  "SPEND_CAP_UNMEASURABLE",
  /** The submitted cap is not a usable amount (negative, NaN, too large). */
  "BRAND_CAP_INVALID",
] as const;

export type ApiErrorCode = (typeof API_ERROR_CODES)[number];
