/**
 * The role primitive (T40). Framework-neutral: no react/next, no drizzle query
 * — just the predicate and the guard that every admin-only operation starts
 * with.
 *
 * ── WHERE THE BRAND BOUNDARY IS, EXACTLY ─────────────────────────────────
 * CLAUDE.md hard rule 2 says every project-scoped read/write goes through
 * `requireProjectAccess`. An admin panel is the obvious place for that rule to
 * spring a leak, so the exception is drawn as narrowly as it can be:
 *
 *   The super admin may administer the DIRECTORY — create brands, create
 *   users, grant and revoke brand membership, reset a temporary password,
 *   and CHANGE AN EXISTING USER'S ROLE (#89).
 *
 *   That last one is the directory power that acts on this very predicate, so
 *   it is worth being explicit: an admin can create other admins and can take
 *   the rights away again, including their own. The only thing `setUserRole`
 *   refuses is a demotion that would leave the installation with no ACTIVE
 *   admin, because there is no self-service route back from that — every
 *   endpoint that could fix it starts with `requireSuperAdmin`. It is audited
 *   (`user_role_change`, atomically) with both the old and the new role.
 *
 *   The super admin may read any brand's SPEND — every brand, with project
 *   names, step and model breakdowns — WITHOUT membership. Elif's decision of
 *   20 July (#50), taken with the exposure understood: project names describe
 *   campaigns, so this is content. It is bounded to `core/llm/admin-spend.ts`,
 *   it is audited (`spend_view_admin`), and the UI marks a non-member brand.
 *
 *   The super admin may not read or write any OTHER brand content *by role* —
 *   documents, briefs, generated posts, step contents, calendars, settings.
 *   `admin` is not a bypass in `requireProjectAccess`, `requireBrandAccess`,
 *   `userCanAccessBrand` or `listAccessibleBrands`; neither T40 nor T50
 *   touched a single line of `core/tenancy/access.ts`, and
 *   `admin-spend.test.ts` asserts that against the source text. An admin who
 *   is not a member of a brand gets the same AccessError as anybody else on
 *   every path except spend.
 *
 * An admin who genuinely needs to see a brand's projects grants themselves
 * membership through the panel, which writes a `user_brands` row. A silent
 * `if (user.role === "admin")` inside the access gate would leave no trace at
 * all; a row is at least a thing that exists. That is also exactly why #50's
 * exception went into its own module instead of into the gate: a permission
 * granted over COST must not become a permission over CONTENT by inheritance,
 * silently, for every present and future caller of the door.
 *
 * ── WHAT THIS DOES *NOT* CLAIM (#40 review finding 12; #50) ──────────────
 * The accurate statement is that an admin cannot read brand content QUIETLY —
 * NOT that an admin cannot read it. There are now three routes in:
 *
 *   1. grant -> read -> revoke, via `grantBrandAccess` / `revokeBrandAccess`.
 *   2. reset the user's password and sign in as them. That reaches the content
 *      with no membership row at any point.
 *   3. SPEND, since #50: no membership, no password reset, no round trip —
 *      the admin simply opens /spend and reads every brand's project names and
 *      costs. This one is not a loophole to be closed; it is a decision Elif
 *      took deliberately, because "which brand or project is the outlier, is a
 *      cap warranted" is unanswerable without it. It is the narrowest of the
 *      three in what it exposes and the only one that is direct.
 *
 * All three are OPEN — the boundary is a deterrent, not a wall, and anything
 * describing it as a wall is wrong. What T41 changed is that all of them are
 * AUDITED: `membership_grant`, `membership_revoke`, `user_password_reset` and
 * (from #50) `spend_view_admin` each leave a row in `audit_events`, an
 * append-only table the database itself refuses to update, delete or truncate.
 * Revoke is still a hard DELETE of the `user_brands` row, but it no longer
 * erases the fact — so the round trip that once left the database
 * byte-identical now leaves permanent evidence.
 *
 * The residual limits, stated plainly because a half-true security claim is
 * worse than none:
 *   - for routes 1 and 2 the trail records that an admin took access to a
 *     brand and when they gave it up, NOT which projects they opened in
 *     between (ordinary reads are not logged — see core/audit/service.ts for
 *     why). Route 3 is the exception and the only audited READ in the product:
 *     `spend_view_admin` names the brand and, on a drill-down, the project.
 *     It is COALESCED per (admin, brand, project) over 30 minutes, so it
 *     answers "did they look, at what, roughly when" and deliberately not "how
 *     many times";
 *   - a `user_password_reset` row shows the credential was replaced; the
 *     subsequent `auth_login` is recorded as the USER, because that is who
 *     signed in. THERE IS NO RELIABLE SIGNAL that distinguishes an admin
 *     signing in as someone from that someone being onboarded (#41 review,
 *     finding 9). An earlier version of this comment offered "a reset with no
 *     matching `user_password_change`" as the tell; that is wrong, and wrong in
 *     the direction that flatters the system. `setTemporaryPassword` sets
 *     `mustChangePassword`, so an admin who resets and signs in as the user is
 *     FORCED through the change-password page and produces reset → login →
 *     change: the exact sequence a benign first-time onboarding produces. The
 *     pattern therefore catches only the impersonator who stops before the
 *     forced change, i.e. the careless one. What the trail does give, and it is
 *     not nothing, is that the reset itself is permanent and attributed: an
 *     admin cannot replace a user's credential without leaving a row naming
 *     them, so the QUESTION can always be raised even when the log cannot
 *     answer it. If Elif ever needs the answer rather than the question, that
 *     needs a real impersonation mechanism — an explicit "sign in as" action
 *     that audits itself and marks the session — not more inference from
 *     these rows;
 *   - THE TRAIL IS NOT A NOTIFICATION. `listAuditEvents` scopes every
 *     non-admin to their own rows, so a brand's members cannot see that an
 *     admin read their spend — only the admin can. The record deters, and it
 *     answers the question later; it does not inform the party it is about.
 *     That is coherent while there is exactly one super admin and she is the
 *     person the trail exists for. A second admin makes it incoherent, and the
 *     fix then is a per-brand view of `spend_view_admin` for that brand's
 *     members, not more rows (#50 review, m8; also in docs/AUTONOMOUS-STATUS.md);
 *   - the trigger stops accidental and casual erasure, not a party with DDL
 *     rights — and on the previous host (Render, removed while a new one is
 *     chosen) the running app held those rights, because it owned the table
 *     (see core/audit/service.ts). Whichever host comes next inherits the same
 *     exposure unless deliberately set up otherwise — this is a hosting
 *     decision, not something this module enforces.
 * So: still few, trusted admins — but now with a record.
 *
 * `roles.test.ts` and `core/admin/service.test.ts` both assert the by-role
 * half that still stands: an admin is refused a non-member brand's PROJECT
 * CONTENT. `core/llm/admin-spend.test.ts` asserts the shape of the one
 * exception — that spend is reachable, that it is audited, that an ordinary
 * user gains nothing, and that `access.ts` remains role-blind.
 */

import type { User } from "../db/schema";
import { AccessError } from "../tenancy/errors";

/** The subset of a user this module needs. Keeps callers free to pass a DTO. */
export type RoleBearer = Pick<User, "role">;

/**
 * True iff the user is the super admin. The only role predicate in the
 * codebase — do not compare `user.role` to a string literal anywhere else.
 */
export function isSuperAdmin(user: RoleBearer): boolean {
  return user.role === "admin";
}

/**
 * Gate every directory-administration operation. Throws AccessError (-> 403)
 * for ordinary users.
 *
 * Called at the TOP of each `core/admin/service.ts` function rather than in the
 * route handler, so authorization cannot be lost by adding a second caller. The
 * route handlers check as well; both layers are deliberate, and the service
 * layer is the one the tests treat as authoritative.
 */
export function requireSuperAdmin(user: RoleBearer): void {
  if (!isSuperAdmin(user)) {
    throw new AccessError(
      "Bu işlem için yönetici yetkisi gerekiyor",
      "ADMIN_REQUIRED",
    );
  }
}
