/**
 * Self-service password change (T40) — the second half of the first-login flow.
 *
 * The admin sets a temporary password and flags the account
 * (`must_change_password`); this is where the user retires it. Requires the
 * current password even though the session already proves identity: a session
 * left open on a shared machine should not be enough to take the account over,
 * and the temporary password is by definition known to someone else.
 *
 * Nothing here echoes, returns or logs either password. The failure cases are
 * distinguishable from each other by CODE only — "wrong current password" and
 * "too short" are different user mistakes with different fixes, and neither
 * message ever contains password text.
 */

import { eq } from "drizzle-orm";

import { recordAuditEvent } from "../audit/service";
import { getDb } from "../db/client";
import { users } from "../db/schema";
import { NotFoundError, ValidationError } from "../tenancy/errors";
import { hashPassword, MIN_PASSWORD_LENGTH, verifyPassword } from "./password";

/**
 * Verify `currentPassword`, store `newPassword`, and clear the
 * must-change-password flag.
 *
 * Sessions are NOT invalidated — the caller's own session stays valid, which is
 * what lets the user land on /projects instead of the login screen right after
 * changing it. This matches the pre-existing `seed set-password` behaviour
 * (sessions cascade on user delete, not on password change), so T40 introduces
 * no change in session semantics.
 */
export async function changePassword(
  userId: string,
  currentPassword: string,
  newPassword: string,
): Promise<void> {
  const db = getDb();
  const [user] = await db
    .select({
      id: users.id,
      username: users.username,
      passwordHash: users.passwordHash,
    })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  if (!user) throw new NotFoundError("Kullanıcı bulunamadı", "USER_NOT_FOUND");

  const ok = await verifyPassword(currentPassword, user.passwordHash);
  if (!ok) {
    throw new ValidationError(
      "Mevcut şifre hatalı",
      "CURRENT_PASSWORD_INVALID",
    );
  }

  if (newPassword.length < MIN_PASSWORD_LENGTH) {
    throw new ValidationError(
      `Şifre en az ${MIN_PASSWORD_LENGTH} karakter olmalı`,
      "PASSWORD_TOO_SHORT",
    );
  }

  // Checked by comparison, not by hashing the new password and matching
  // digests — argon2 salts every hash, so equal passwords produce unequal
  // hashes and a digest comparison would never fire.
  if (currentPassword === newPassword) {
    throw new ValidationError(
      "Yeni şifre mevcut şifreden farklı olmalı",
      "PASSWORD_SAME_AS_CURRENT",
    );
  }

  await db
    .update(users)
    .set({ passwordHash: await hashPassword(newPassword), mustChangePassword: false })
    .where(eq(users.id, userId));

  // T41. Recorded AFTER the update, and only on success: the four throws above
  // are user mistakes, not events. Best-effort — a user who has just retired a
  // password an admin knows must not be told to try again because a log table
  // is unwritable. See core/audit/service.ts on the atomic/best-effort split.
  //
  // Its value is as the other half of `user_password_reset`: a reset with no
  // matching change means the temporary password is still live and a second
  // person can still sign in as this user.
  await recordAuditEvent({
    action: "user_password_change",
    actorUserId: user.id,
    actorUsername: user.username,
  });
}
