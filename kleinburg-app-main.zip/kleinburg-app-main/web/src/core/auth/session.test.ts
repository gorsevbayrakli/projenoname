import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import { sessions, users } from "../db/schema";
import { hashPassword } from "./password";
import {
  ABSOLUTE_MS,
  authenticate,
  createSession,
  deleteSession,
  IDLE_MS,
  validateSession,
} from "./session";
import { generateSessionToken, hashToken } from "./tokens";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];

/** Create a user with a unique username; returns { id, username, password }. */
async function makeUser(opts: { isActive?: boolean } = {}) {
  const db = getDb();
  const username = `t6-${randomUUID()}`;
  const password = `pw-${randomUUID()}`;
  const [user] = await db
    .insert(users)
    .values({
      username,
      passwordHash: await hashPassword(password),
      isActive: opts.isActive ?? true,
    })
    .returning();
  createdUserIds.push(user.id);
  return { id: user.id, username, password };
}

/** Insert a session row directly with a controlled createdAt/expiresAt. */
async function insertSession(
  userId: string,
  token: string,
  createdAt: Date,
  expiresAt: Date,
) {
  const db = getDb();
  await db.insert(sessions).values({
    userId,
    tokenHash: hashToken(token),
    createdAt,
    expiresAt,
  });
}

describe.skipIf(!hasDb)("session", () => {
  beforeAll(() => {
    // Ensure DB is reachable before running the suite.
    getDb();
  });

  afterAll(async () => {
    if (createdUserIds.length > 0) {
      const db = getDb();
      // Sessions cascade on user delete.
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    await closeDb();
  });

  it("createSession stores only the token hash, never the raw token", async () => {
    const db = getDb();
    const user = await makeUser();
    const { token } = await createSession(user.id);

    const [row] = await db
      .select()
      .from(sessions)
      .where(eq(sessions.userId, user.id));

    expect(row.tokenHash).not.toBe(token);
    expect(row.tokenHash).toBe(hashToken(token));
  });

  it("validateSession returns the user for a fresh token", async () => {
    const user = await makeUser();
    const { token } = await createSession(user.id);

    const result = await validateSession(token);
    expect(result).not.toBeNull();
    expect(result?.user.id).toBe(user.id);
  });

  it("validateSession returns null for a garbage token", async () => {
    const result = await validateSession(generateSessionToken());
    expect(result).toBeNull();
  });

  it("slides the idle window forward on use", async () => {
    const user = await makeUser();
    const token = generateSessionToken();
    const now = Date.now();
    // Mid-life: created recently, expiring in 1h (well under the 4h idle window).
    const createdAt = new Date(now - 60 * 60 * 1000);
    const expiresAt = new Date(now + 60 * 60 * 1000);
    await insertSession(user.id, token, createdAt, expiresAt);

    const result = await validateSession(token);
    expect(result?.user.id).toBe(user.id);

    const db = getDb();
    const [row] = await db
      .select()
      .from(sessions)
      .where(eq(sessions.tokenHash, hashToken(token)));
    expect(row.expiresAt.getTime()).toBeGreaterThan(expiresAt.getTime());
  });

  it("treats an expired session as invalid and deletes the row", async () => {
    const user = await makeUser();
    const token = generateSessionToken();
    const now = Date.now();
    const createdAt = new Date(now - 5 * 60 * 60 * 1000);
    const expiresAt = new Date(now - 60 * 1000); // expired 1 min ago
    await insertSession(user.id, token, createdAt, expiresAt);

    const result = await validateSession(token);
    expect(result).toBeNull();

    const db = getDb();
    const rows = await db
      .select()
      .from(sessions)
      .where(eq(sessions.tokenHash, hashToken(token)));
    expect(rows).toHaveLength(0);
  });

  it("caps the sliding window at createdAt + ABSOLUTE_MS", async () => {
    const user = await makeUser();
    const token = generateSessionToken();
    const now = Date.now();
    // Created 8 days ago, so createdAt + 7d is already in the past, but the row
    // is still idle-valid (expires in the near future) so validation proceeds.
    const createdAt = new Date(now - 8 * 24 * 60 * 60 * 1000);
    const expiresAt = new Date(now + 60 * 1000);
    await insertSession(user.id, token, createdAt, expiresAt);

    const result = await validateSession(token);
    expect(result?.user.id).toBe(user.id);

    const db = getDb();
    const [row] = await db
      .select()
      .from(sessions)
      .where(eq(sessions.tokenHash, hashToken(token)));
    const absoluteDeadline = createdAt.getTime() + ABSOLUTE_MS;
    // The new expiry is capped at the absolute deadline, which is now in the
    // past — so the session is effectively expired on the next use.
    expect(row.expiresAt.getTime()).toBeLessThanOrEqual(absoluteDeadline);
    expect(row.expiresAt.getTime()).toBeLessThanOrEqual(now);
    // Sanity: without the cap it would have slid to ~now + IDLE_MS.
    expect(row.expiresAt.getTime()).toBeLessThan(now + IDLE_MS);
  });

  it("deleteSession removes the session", async () => {
    const user = await makeUser();
    const { token } = await createSession(user.id);
    await deleteSession(token);
    expect(await validateSession(token)).toBeNull();
  });

  it("authenticate returns a token for correct credentials", async () => {
    const user = await makeUser();
    const result = await authenticate(user.username, user.password);
    expect(result).not.toBeNull();
    expect(typeof result?.token).toBe("string");

    const check = await validateSession(result!.token);
    expect(check?.user.id).toBe(user.id);
  });

  it("authenticate returns null for a wrong password", async () => {
    const user = await makeUser();
    const result = await authenticate(user.username, "definitely-wrong");
    expect(result).toBeNull();
  });

  it("authenticate returns null for an unknown user", async () => {
    const result = await authenticate(`nobody-${randomUUID()}`, "whatever");
    expect(result).toBeNull();
  });

  it("authenticate returns null for an inactive user", async () => {
    const user = await makeUser({ isActive: false });
    const result = await authenticate(user.username, user.password);
    expect(result).toBeNull();
  });
});
