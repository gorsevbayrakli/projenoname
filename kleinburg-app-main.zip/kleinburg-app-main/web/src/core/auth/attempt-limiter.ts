/**
 * A sliding-window ceiling on failed credential attempts (#40 review,
 * finding 11).
 *
 * ── WHAT THIS DEFENDS ────────────────────────────────────────────────────
 * `/api/auth/change-password` demands the CURRENT password. That check is the
 * only thing standing between a stolen session cookie and a permanent account
 * takeover, and until now it could be attempted without limit. A ceiling turns
 * an offline-speed guessing loop back into something that takes visible time.
 *
 * ── WHAT IT DELIBERATELY IS NOT ──────────────────────────────────────────
 * In-process and in-memory. The deployment target is a SINGLE Render web
 * service (see CLAUDE.md), so one process sees every attempt; if that ever
 * becomes two processes this must move to Postgres or Redis, and the comment
 * on the singleton in the route says so. It is also not a general HTTP rate
 * limiter — it counts FAILURES for a key, not requests.
 *
 * Framework-neutral (hard rule 1) and clock-injectable, so the window is
 * tested by moving time rather than by sleeping.
 */

export interface AttemptLimiterOptions {
  /** Failures within the window before the key is refused. */
  maxAttempts: number;
  /** Sliding window length in milliseconds. */
  windowMs: number;
  /** Injectable clock; defaults to `Date.now`. */
  now?: () => number;
}

export interface AttemptDecision {
  allowed: boolean;
  /** Whole seconds until the oldest counted failure leaves the window. */
  retryAfterSeconds: number;
}

export class AttemptLimiter {
  readonly #maxAttempts: number;
  readonly #windowMs: number;
  readonly #now: () => number;
  /** key -> timestamps of failures still inside the window. */
  readonly #failures = new Map<string, number[]>();

  constructor(options: AttemptLimiterOptions) {
    this.#maxAttempts = options.maxAttempts;
    this.#windowMs = options.windowMs;
    this.#now = options.now ?? (() => Date.now());
  }

  /** Number of tracked keys. Exposed so a test can prove eviction happens. */
  get size(): number {
    return this.#failures.size;
  }

  /**
   * Drop expired timestamps for `key`, and drop the key entirely if nothing is
   * left. The second half is what stops the map growing without bound in a
   * long-lived process.
   */
  #prune(key: string): number[] {
    const cutoff = this.#now() - this.#windowMs;
    const kept = (this.#failures.get(key) ?? []).filter((t) => t > cutoff);
    if (kept.length === 0) this.#failures.delete(key);
    else this.#failures.set(key, kept);
    return kept;
  }

  /** Sweep every key. Cheap: this map is bounded by concurrent active users. */
  #pruneAll(): void {
    for (const key of [...this.#failures.keys()]) this.#prune(key);
  }

  /** May this key attempt again, and if not, for how long? */
  check(key: string): AttemptDecision {
    const attempts = this.#prune(key);
    if (attempts.length < this.#maxAttempts) {
      return { allowed: true, retryAfterSeconds: 0 };
    }
    const oldest = Math.min(...attempts);
    const waitMs = oldest + this.#windowMs - this.#now();
    return {
      allowed: false,
      retryAfterSeconds: Math.max(1, Math.ceil(waitMs / 1000)),
    };
  }

  /** Count one failed attempt against this key. */
  recordFailure(key: string): void {
    this.#pruneAll();
    const attempts = this.#failures.get(key) ?? [];
    attempts.push(this.#now());
    this.#failures.set(key, attempts);
  }

  /** Forget this key's failures — call on a SUCCESSFUL credential check. */
  reset(key: string): void {
    this.#failures.delete(key);
  }
}
