import { eq } from "drizzle-orm";

import { recordFailedLoginAuditEvent } from "../audit/auth-failures";
import { recordAuditEvent } from "../audit/service";
import { getDb } from "../db/client";
import { sessions, users, type User } from "../db/schema";
import { verifyPassword } from "./password";
import { generateSessionToken, hashToken } from "./tokens";

/** Idle timeout: a session survives 4h of inactivity, sliding on each use. */
export const IDLE_MS = 4 * 60 * 60 * 1000;
/** Absolute cap: a session can never live longer than 7 days from creation. */
export const ABSOLUTE_MS = 7 * 24 * 60 * 60 * 1000;

/**
 * A pre-computed argon2id hash of an arbitrary password. authenticate() verifies
 * against this when the username is unknown so that the response time does not
 * reveal whether the account exists (user-enumeration defense).
 */
const DUMMY_PASSWORD_HASH =
  "$argon2id$v=19$m=19456,t=2,p=1$7srM1rganbxbuI2MdIzqbA$3eBmWHSkGDuZdgnH5fD01Xk197aY6xV047N1VDcFrXk";

/**
 * Create a new session for a user. Generates an opaque token, stores only its
 * hash, and returns the raw token (for the cookie) plus the initial expiry.
 */
export async function createSession(
  userId: string,
): Promise<{ token: string; expiresAt: Date }> {
  const db = getDb();
  const token = generateSessionToken();
  const expiresAt = new Date(Date.now() + IDLE_MS);
  await db.insert(sessions).values({
    userId,
    tokenHash: hashToken(token),
    expiresAt,
  });
  return { token, expiresAt };
}

/**
 * Validate a raw session token. Returns the active user on success and slides
 * the idle window forward (capped at createdAt + ABSOLUTE_MS). Expired sessions
 * are deleted and null is returned; unknown tokens and inactive users also
 * return null.
 */
export async function validateSession(
  token: string,
): Promise<{ user: User } | null> {
  const db = getDb();
  const tokenHash = hashToken(token);

  const [row] = await db
    .select({ session: sessions, user: users })
    .from(sessions)
    .innerJoin(users, eq(sessions.userId, users.id))
    .where(eq(sessions.tokenHash, tokenHash))
    .limit(1);

  if (!row) return null;

  const now = Date.now();
  if (row.session.expiresAt.getTime() <= now) {
    // Expired: clean up the row so it can't linger, and reject.
    await db.delete(sessions).where(eq(sessions.tokenHash, tokenHash));
    return null;
  }

  if (!row.user.isActive) return null;

  // Slide the idle window forward, but never past the absolute cap.
  const absoluteDeadline = row.session.createdAt.getTime() + ABSOLUTE_MS;
  const newExpiresAt = new Date(Math.min(now + IDLE_MS, absoluteDeadline));
  await db
    .update(sessions)
    .set({ expiresAt: newExpiresAt })
    .where(eq(sessions.tokenHash, tokenHash));

  return { user: row.user };
}

/**
 * Delete a session by its raw token (idempotent logout).
 *
 * Audits here rather than in the logout route (T41), for the same reason
 * `authenticate` does: this is the chokepoint. A second caller added later
 * gets the record for free, whereas route-level auditing would quietly miss
 * it.
 *
 * Only a session that actually existed produces a row. A logout POST carrying
 * an expired or forged token deleted nothing and is not a logout; recording it
 * would let anyone write `auth_logout` rows into the trail by posting garbage.
 */
export async function deleteSession(token: string): Promise<void> {
  const db = getDb();
  const [deleted] = await db
    .delete(sessions)
    .where(eq(sessions.tokenHash, hashToken(token)))
    .returning({ userId: sessions.userId });

  if (!deleted) return;

  const [user] = await db
    .select({ id: users.id, username: users.username })
    .from(users)
    .where(eq(users.id, deleted.userId))
    .limit(1);

  await recordAuditEvent({
    action: "auth_logout",
    actorUserId: deleted.userId,
    actorUsername: user?.username ?? deleted.userId,
  });
}

/**
 * Verify credentials and, on success, open a session. Always performs a password
 * verification (against a dummy hash when the user is unknown) so that timing
 * does not leak whether the username exists. Inactive users are rejected.
 *
 * ── AUDIT (T41) ──────────────────────────────────────────────────────────
 * Both outcomes are recorded here, not in the login route, because this is the
 * only place credentials are checked and a route-level record would be one
 * refactor away from being lost.
 *
 * The audit row distinguishes success from failure. It does NOT distinguish
 * WHY a failure failed, and the reason is the same one that makes the response
 * generic: "no such user" and "wrong password" are the two halves of a user
 * enumeration oracle, and an audit log an admin reads is not a good place to
 * rebuild one. `reason` carries only what a reader needs to act — whether the
 * account exists at all is deducible from `actorUserId` being null, which is
 * information the admin already has from the user list.
 *
 * The awaits are deliberate. A fire-and-forget write would let the response
 * race the record, and on a serverless-style runtime the process can be frozen
 * once the response is sent — a login that is never recorded is the one
 * failure mode this whole issue exists to prevent. The cost is one INSERT on a
 * path that already spends far longer verifying an argon2 hash.
 */
export async function authenticate(
  username: string,
  password: string,
): Promise<{ token: string; expiresAt: Date } | null> {
  const db = getDb();
  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.username, username))
    .limit(1);

  // Verify even when the user is missing, against a dummy hash, so the response
  // time is the same whether or not the username exists.
  const passwordHash = user ? user.passwordHash : DUMMY_PASSWORD_HASH;
  const ok = await verifyPassword(password, passwordHash);

  if (!user || !ok || !user.isActive) {
    // NOT `recordAuditEvent` directly. `recordFailedLoginAuditEvent` owns two
    // things this path cannot get wrong (#41 review, findings 1 and 4): it caps
    // how many failed-login rows an unauthenticated caller can drive into a
    // table with no DELETE path, and it hashes the attempted username when no
    // such user exists — the bucket a password typed into the username box
    // falls into. A known username is still stored verbatim.
    await recordFailedLoginAuditEvent({
      attemptedUsername: username,
      actorUserId: user?.id ?? null,
      reason: user && ok && !user.isActive ? "inactive" : "invalid",
    });
    return null;
  }

  const session = await createSession(user.id);
  await recordAuditEvent({
    action: "auth_login",
    actorUserId: user.id,
    actorUsername: user.username,
  });
  return session;
}
