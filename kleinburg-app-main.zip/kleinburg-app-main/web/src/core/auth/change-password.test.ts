import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import { sessions, users } from "../db/schema";
import { NotFoundError, ValidationError } from "../tenancy/errors";
import { changePassword } from "./change-password";
import { hashPassword, verifyPassword } from "./password";
import { createSession, validateSession } from "./session";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];

const CURRENT = "gecici-sifre-2026";
const NEXT = "kendi-sifrem-2026";

async function makeUser(mustChangePassword = true) {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({
      username: `t40-cp-${randomUUID()}`,
      passwordHash: await hashPassword(CURRENT),
      mustChangePassword,
    })
    .returning();
  createdUserIds.push(user.id);
  return user;
}

describe.skipIf(!hasDb)("changePassword", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    await closeDb();
  });

  it("replaces the password and clears the forced-change flag", async () => {
    const user = await makeUser();
    await changePassword(user.id, CURRENT, NEXT);

    const db = getDb();
    const [row] = await db.select().from(users).where(eq(users.id, user.id));
    expect(row.mustChangePassword).toBe(false);
    expect(await verifyPassword(NEXT, row.passwordHash)).toBe(true);
    expect(await verifyPassword(CURRENT, row.passwordHash)).toBe(false);
  });

  it("requires the current password", async () => {
    const user = await makeUser();
    await expect(
      changePassword(user.id, "yanlis-sifre-2026", NEXT),
    ).rejects.toMatchObject({ code: "CURRENT_PASSWORD_INVALID" });

    // The flag survives a failed attempt — the user is still forced to change.
    const db = getDb();
    const [row] = await db.select().from(users).where(eq(users.id, user.id));
    expect(row.mustChangePassword).toBe(true);
    expect(await verifyPassword(CURRENT, row.passwordHash)).toBe(true);
  });

  it("rejects a new password under the minimum length", async () => {
    const user = await makeUser();
    await expect(changePassword(user.id, CURRENT, "kisa")).rejects.toMatchObject({
      code: "PASSWORD_TOO_SHORT",
    });
  });

  /**
   * Without this, "must change password" is satisfiable by retyping the
   * temporary one the admin already knows — the flow would be theatre.
   */
  it("rejects reusing the temporary password", async () => {
    const user = await makeUser();
    await expect(
      changePassword(user.id, CURRENT, CURRENT),
    ).rejects.toMatchObject({ code: "PASSWORD_SAME_AS_CURRENT" });

    const db = getDb();
    const [row] = await db.select().from(users).where(eq(users.id, user.id));
    expect(row.mustChangePassword).toBe(true);
  });

  it("never puts either password in the error message", async () => {
    const user = await makeUser();
    for (const attempt of [
      () => changePassword(user.id, "yanlis-sifre-2026", NEXT),
      () => changePassword(user.id, CURRENT, "kisa"),
      () => changePassword(user.id, CURRENT, CURRENT),
    ]) {
      try {
        await attempt();
        throw new Error("expected a rejection");
      } catch (e) {
        expect(e).toBeInstanceOf(ValidationError);
        const message = (e as Error).message;
        expect(message).not.toContain(CURRENT);
        expect(message).not.toContain(NEXT);
        expect(message).not.toContain("kisa");
      }
    }
  });

  it("reports a missing user honestly", async () => {
    await expect(
      changePassword(randomUUID(), CURRENT, NEXT),
    ).rejects.toBeInstanceOf(NotFoundError);
  });

  /**
   * Existing sessions deliberately survive a password change (unchanged from
   * the `seed set-password` behaviour). If this ever becomes a forced-logout
   * flow it must change in both places at once, and this test is what will say
   * so.
   */
  it("leaves existing sessions valid (documented, not accidental)", async () => {
    const user = await makeUser();
    const { token } = await createSession(user.id);
    expect(await validateSession(token)).not.toBeNull();

    await changePassword(user.id, CURRENT, NEXT);

    expect(await validateSession(token)).not.toBeNull();

    const db = getDb();
    await db.delete(sessions).where(eq(sessions.userId, user.id));
  });
});
