/**
 * The password policy — split out from `password.ts` on purpose.
 *
 * `password.ts` imports `@node-rs/argon2`, a native Node addon. The
 * change-password form is a client component and wants to show the length
 * requirement, so importing the constant from there would drag argon2 into the
 * browser bundle. This module has no dependencies at all and is safe to import
 * from anywhere: server, client, or test.
 */

/**
 * Minimum password length (T40). Applies to the admin-set temporary password
 * and to the replacement the user chooses on first login.
 *
 * Deliberately the only composition rule: NIST 800-63B advises length over
 * character-class theatre, and a rule the admin has to work around encourages
 * "Sifre1!" on every account.
 */
export const MIN_PASSWORD_LENGTH = 12;
