import { describe, expect, it } from "vitest";

import { AttemptLimiter } from "./attempt-limiter";

/**
 * The ceiling on credential guessing (#40 review, finding 11). Without it a
 * stolen session can brute-force `currentPassword` at full speed.
 */
function makeLimiter(now = { t: 0 }) {
  return {
    now,
    limiter: new AttemptLimiter({
      maxAttempts: 3,
      windowMs: 1000,
      now: () => now.t,
    }),
  };
}

describe("AttemptLimiter", () => {
  it("allows attempts below the ceiling", () => {
    const { limiter } = makeLimiter();
    limiter.recordFailure("u1");
    limiter.recordFailure("u1");
    expect(limiter.check("u1").allowed).toBe(true);
  });

  it("refuses once the ceiling is reached", () => {
    const { limiter } = makeLimiter();
    for (let i = 0; i < 3; i++) limiter.recordFailure("u1");
    expect(limiter.check("u1").allowed).toBe(false);
  });

  it("reports how long to wait, rounded up to whole seconds", () => {
    const { limiter, now } = makeLimiter();
    for (let i = 0; i < 3; i++) limiter.recordFailure("u1");
    now.t = 300;
    // 700ms left in the window -> 1s.
    expect(limiter.check("u1").retryAfterSeconds).toBe(1);
  });

  it("keys per user — one user's failures do not lock out another", () => {
    const { limiter } = makeLimiter();
    for (let i = 0; i < 3; i++) limiter.recordFailure("u1");
    expect(limiter.check("u1").allowed).toBe(false);
    expect(limiter.check("u2").allowed).toBe(true);
  });

  it("forgets attempts that fall outside the window", () => {
    const { limiter, now } = makeLimiter();
    for (let i = 0; i < 3; i++) limiter.recordFailure("u1");
    expect(limiter.check("u1").allowed).toBe(false);
    now.t = 1001;
    expect(limiter.check("u1").allowed).toBe(true);
  });

  /**
   * A user who remembers their password mid-way must not stay one typo away
   * from a lockout for the rest of the window.
   */
  it("clears the record on success", () => {
    const { limiter } = makeLimiter();
    for (let i = 0; i < 2; i++) limiter.recordFailure("u1");
    limiter.reset("u1");
    for (let i = 0; i < 2; i++) limiter.recordFailure("u1");
    expect(limiter.check("u1").allowed).toBe(true);
  });

  /**
   * The limiter holds one array per key. Without eviction, a long-lived process
   * would grow a permanent entry for every user id ever seen.
   */
  it("drops keys whose attempts have all expired", () => {
    const { limiter, now } = makeLimiter();
    limiter.recordFailure("u1");
    expect(limiter.size).toBe(1);
    now.t = 5000;
    limiter.recordFailure("u2");
    expect(limiter.size).toBe(1);
  });
});
