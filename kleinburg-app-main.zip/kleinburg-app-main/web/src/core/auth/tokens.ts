import { createHash, randomBytes } from "node:crypto";

/**
 * Generate a fresh opaque session token: 32 random bytes encoded as base64url.
 * The raw token is handed to the client cookie exactly once; the database
 * stores only its hash (see hashToken).
 */
export function generateSessionToken(): string {
  return randomBytes(32).toString("base64url");
}

/**
 * SHA-256 hash of a session token, hex-encoded. This is what lives in
 * sessions.tokenHash. A stolen database therefore never yields usable tokens,
 * and lookups stay constant-time-ish via the unique index on the hash.
 */
export function hashToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}
