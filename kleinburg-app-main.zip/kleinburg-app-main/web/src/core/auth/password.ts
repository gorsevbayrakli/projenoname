import { hash, verify } from "@node-rs/argon2";

// Re-exported so server-side callers keep a single import site for everything
// password-related. Client components must import it from ./password-policy
// directly — this module pulls in a native addon.
export { MIN_PASSWORD_LENGTH } from "./password-policy";

// argon2id parameters per OWASP Password Storage Cheat Sheet:
// 19 MiB memory, 2 iterations, 1 degree of parallelism.
const ARGON2_OPTIONS = {
  memoryCost: 19456,
  timeCost: 2,
  parallelism: 1,
} as const;

/** Hash a plaintext password with argon2id. */
export function hashPassword(plain: string): Promise<string> {
  return hash(plain, ARGON2_OPTIONS);
}

/** Verify a plaintext password against a stored argon2 hash. */
export async function verifyPassword(
  plain: string,
  passwordHash: string,
): Promise<boolean> {
  try {
    return await verify(passwordHash, plain);
  } catch {
    // Malformed hash strings should read as "no match", not crash callers.
    return false;
  }
}
