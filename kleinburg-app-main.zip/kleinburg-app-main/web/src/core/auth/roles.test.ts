import { describe, expect, it } from "vitest";

import { AccessError } from "../tenancy/errors";
import { isSuperAdmin, requireSuperAdmin } from "./roles";

describe("auth/roles", () => {
  it("recognises the super admin", () => {
    expect(isSuperAdmin({ role: "admin" })).toBe(true);
  });

  it("does not treat an ordinary user as an admin", () => {
    expect(isSuperAdmin({ role: "user" })).toBe(false);
  });

  it("requireSuperAdmin passes an admin through", () => {
    expect(() => requireSuperAdmin({ role: "admin" })).not.toThrow();
  });

  it("requireSuperAdmin throws AccessError with ADMIN_REQUIRED", () => {
    try {
      requireSuperAdmin({ role: "user" });
      throw new Error("expected requireSuperAdmin to throw");
    } catch (e) {
      expect(e).toBeInstanceOf(AccessError);
      expect((e as AccessError).code).toBe("ADMIN_REQUIRED");
    }
  });

  /**
   * The role check must be a whitelist, not a "not user" check. If someone
   * later adds a third enum value, it must default to unprivileged rather than
   * inherit admin by falling through the wrong comparison.
   */
  it("denies an unknown future role", () => {
    const future = { role: "auditor" } as unknown as { role: "admin" | "user" };
    expect(isSuperAdmin(future)).toBe(false);
    expect(() => requireSuperAdmin(future)).toThrow(AccessError);
  });
});
