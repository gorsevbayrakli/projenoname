import { describe, expect, it } from "vitest";

import { generateSessionToken, hashToken } from "./tokens";

describe("generateSessionToken", () => {
  it("produces unique tokens", () => {
    const tokens = new Set(
      Array.from({ length: 1000 }, () => generateSessionToken()),
    );
    expect(tokens.size).toBe(1000);
  });

  it("uses only the base64url charset", () => {
    for (let i = 0; i < 50; i++) {
      expect(generateSessionToken()).toMatch(/^[A-Za-z0-9_-]+$/);
    }
  });
});

describe("hashToken", () => {
  it("is deterministic for the same input", () => {
    const token = generateSessionToken();
    expect(hashToken(token)).toBe(hashToken(token));
  });

  it("produces different hashes for different inputs", () => {
    expect(hashToken("a")).not.toBe(hashToken("b"));
  });

  it("does not return the input itself", () => {
    const token = generateSessionToken();
    expect(hashToken(token)).not.toBe(token);
  });

  it("returns a 64-char lowercase hex SHA-256 digest", () => {
    expect(hashToken("anything")).toMatch(/^[0-9a-f]{64}$/);
  });
});
