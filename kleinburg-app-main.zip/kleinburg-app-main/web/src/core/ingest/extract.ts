/**
 * Document text extraction for wizard step 1 ingestion. Framework-neutral
 * (no react/next): node built-ins + parsing libraries only.
 *
 * Library choices:
 *  - pdf  -> `unpdf`: pure-JS (bundled pdf.js), no native builds, runs in the
 *            Next Node runtime. Avoids `pdf-parse`'s debug-mode file read.
 *  - docx -> `mammoth`: raw-text extraction from the document body.
 *  - pptx -> `officeparser`: pulls text from slide XML.
 *  - url  -> global `fetch` (timeout + UA) then a light `node-html-parser`
 *            pass that drops <script>/<style> and returns the text content.
 *
 * The MIN_DOCUMENT_CHARS gate closes the legacy bug where an empty/scanned PDF
 * was accepted silently: too little real text is a hard ValidationError.
 */
import { parse as parseHtml } from "node-html-parser";

import type { DocumentKind } from "../db/schema";
import { describeErrorForLog } from "../errors/redact";
import { ValidationError } from "../tenancy/errors";
import { assertUrlAllowed, type DnsLookup } from "./url-guard";

/** Minimum real characters an extracted document must contain to be accepted. */
export const MIN_DOCUMENT_CHARS = 50;

/** Hard upload ceiling (10MB), enforced by the route before extraction. */
export const MAX_FILE_BYTES = 10 * 1024 * 1024;

/** Hard ceiling (5MB) on a fetched URL body, enforced during the read. */
export const MAX_URL_BYTES = 5 * 1024 * 1024;

/** How many redirect hops we follow (each one re-validated) before giving up. */
const MAX_REDIRECTS = 5;

/** Fetch timeout for URL ingestion. */
const URL_FETCH_TIMEOUT_MS = 15_000;

/** A polite, honest User-Agent so sites don't blanket-block the fetch. */
const URL_USER_AGENT =
  "KleinburgBot/1.0 (+content ingestion; contact: admin)";

export type ExtractSource = { buffer?: Buffer; url?: string };

/**
 * The per-kind primitives, injectable so tests can exercise dispatch + the
 * threshold without shelling out to the real parsers or the network.
 */
export type ExtractDeps = {
  pdf: (buffer: Buffer) => Promise<string>;
  docx: (buffer: Buffer) => Promise<string>;
  pptx: (buffer: Buffer) => Promise<string>;
  fetchUrl: (url: string) => Promise<string>;
};

/** Strip scripts/styles and collapse a fetched HTML page down to readable text. */
export function htmlToText(html: string): string {
  const root = parseHtml(html, {
    // Keep the DOM light; we only need text nodes.
    comment: false,
  });
  for (const el of root.querySelectorAll("script, style, noscript, template")) {
    el.remove();
  }
  const text = root.textContent ?? "";
  // Collapse runs of whitespace (the raw text is full of layout newlines).
  return text.replace(/[ \t\r\f\v]+/g, " ").replace(/\n{3,}/g, "\n\n");
}

async function extractPdf(buffer: Buffer): Promise<string> {
  const { extractText: unpdfExtract, getDocumentProxy } = await import("unpdf");
  const pdf = await getDocumentProxy(new Uint8Array(buffer));
  // mergePages:true resolves `text` to a single string.
  const { text } = await unpdfExtract(pdf, { mergePages: true });
  return text;
}

async function extractDocx(buffer: Buffer): Promise<string> {
  const mammoth = await import("mammoth");
  const { value } = await mammoth.extractRawText({ buffer });
  return value;
}

/**
 * The slice of officeparser's `parseOffice` this module uses, injectable so the
 * fileType hint below can be pinned by a test without a real .pptx fixture.
 */
export type ParseOfficeFn = (
  buffer: Buffer,
  config: { fileType: string },
) => Promise<{ toText: () => string }>;

/**
 * TELL officeparser the type; do NOT let it guess (#83).
 *
 * A .pptx is a zip, and so is a .docx, so magic bytes alone do not separate
 * them — officeparser has to look inside, and that detection depends on a
 * library whose behaviour varies with the Node version. On Render (Node 22) it
 * failed outright:
 *
 *   [OfficeParser]: Auto-detection of file type from buffer failed ... or if
 *   the detection library is incompatible with your Node.js version. Please
 *   provide the 'fileType' hint in your configuration
 *
 * so EVERY .pptx upload was rejected in production while every local run (Node
 * 24) passed. officeparser's own documentation is explicit: "If you are parsing
 * these formats from a Buffer, you must provide this fileType hint."
 *
 * We always knew the answer — the caller already resolved the kind from the
 * filename and MIME type, and this function only ever handles one format. The
 * bug was asking a library to re-derive something we were holding.
 */
async function extractPptx(
  buffer: Buffer,
  parse?: ParseOfficeFn,
): Promise<string> {
  const parseOffice =
    parse ?? ((await import("officeparser")).parseOffice as ParseOfficeFn);
  const ast = await parseOffice(buffer, { fileType: "pptx" });
  return ast.toText();
}

export { extractPptx };

/**
 * Injectable seams for fetchUrlText, so tests can drive the SSRF guard + the
 * manual redirect loop without real DNS or network. Production uses global fetch
 * and node's real resolver (the url-guard default).
 */
export type FetchUrlDeps = {
  fetchImpl?: typeof fetch;
  resolver?: DnsLookup;
};

/**
 * SSRF-hardened URL fetch. Every hop (initial + each redirect) is validated by
 * assertUrlAllowed before we connect, so neither the user URL nor any redirect
 * target can point at loopback/private/link-local/metadata addresses. Redirects
 * are followed MANUALLY (redirect: "manual") up to MAX_REDIRECTS. The body is
 * capped at MAX_URL_BYTES (Content-Length pre-check + actual byte-length check).
 *
 * Known limitation: we validate the resolved IPs, but the global fetch API then
 * re-resolves the host on connect, so a DNS-rebinding attacker could pass here
 * and rebind to an internal IP at connect time (TOCTOU). fetch cannot pin to the
 * validated IP the way the legacy connection-pinned adapter did; per-hop
 * re-validation mitigates the common redirect-based cases. See url-guard.ts.
 */
export async function fetchUrlText(
  url: string,
  deps: FetchUrlDeps = {},
): Promise<string> {
  const doFetch = deps.fetchImpl ?? fetch;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), URL_FETCH_TIMEOUT_MS);
  try {
    let current = url;
    for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
      // Re-validate EVERY hop: a public URL must not redirect into an internal one.
      await assertUrlAllowed(current, { resolver: deps.resolver });

      const res = await doFetch(current, {
        headers: { "User-Agent": URL_USER_AGENT, Accept: "text/html,*/*" },
        redirect: "manual",
        signal: controller.signal,
      });

      // Manual redirect handling: resolve Location against the current URL and
      // loop so the next hop is re-validated at the top.
      if (res.status >= 300 && res.status < 400) {
        const location = res.headers.get("location");
        if (!location) {
          throw new ValidationError(
            `URL getirilemedi (HTTP ${res.status})`,
            "URL_FETCH_FAILED",
          );
        }
        current = new URL(location, current).toString();
        continue;
      }

      if (!res.ok) {
        throw new ValidationError(
          `URL getirilemedi (HTTP ${res.status})`,
          "URL_FETCH_FAILED",
        );
      }

      // Reject early if the server declares an oversize body.
      const declared = Number(res.headers.get("content-length"));
      if (Number.isFinite(declared) && declared > MAX_URL_BYTES) {
        throw new ValidationError(
          "İçerik boyutu sınırı aşıldı (5MB)",
          "CONTENT_TOO_LARGE",
        );
      }

      // Cap the actual read: a lying/absent Content-Length can't smuggle a
      // gigabyte past us.
      const bytes = await res.arrayBuffer();
      if (bytes.byteLength > MAX_URL_BYTES) {
        throw new ValidationError(
          "İçerik boyutu sınırı aşıldı (5MB)",
          "CONTENT_TOO_LARGE",
        );
      }
      const html = new TextDecoder("utf-8").decode(bytes);
      return htmlToText(html);
    }
    throw new ValidationError("Çok fazla yönlendirme", "URL_TOO_MANY_REDIRECTS");
  } catch (e) {
    if (e instanceof ValidationError) throw e;
    if (e instanceof Error && e.name === "AbortError") {
      throw new ValidationError("URL zaman aşımına uğradı", "URL_TIMEOUT");
    }
    throw new ValidationError("URL getirilemedi", "URL_FETCH_FAILED");
  } finally {
    clearTimeout(timer);
  }
}

const defaultDeps: ExtractDeps = {
  pdf: extractPdf,
  docx: extractDocx,
  pptx: extractPptx,
  fetchUrl: fetchUrlText,
};

/**
 * Extract readable text from a document of the given kind.
 *  - pdf/docx/pptx parse `source.buffer`.
 *  - url fetches + strips `source.url`.
 * Throws ValidationError when the source for the kind is missing, when the
 * parser itself fails (DOC_PARSE_FAILED, original error kept as `cause` and
 * logged), or when the trimmed result has fewer than MIN_DOCUMENT_CHARS of
 * real text (DOC_TOO_LITTLE_TEXT). The last two are deliberately different
 * codes: they tell the user to do different things.
 *
 * `deps` is injectable for tests; production uses the real parsers.
 */
export async function extractText(
  kind: DocumentKind,
  source: ExtractSource,
  deps: ExtractDeps = defaultDeps,
): Promise<string> {
  let raw: string;

  if (kind === "url") {
    if (!source.url) throw new ValidationError("URL eksik", "URL_MISSING");
    raw = await deps.fetchUrl(source.url);
  } else {
    if (!source.buffer) throw new ValidationError("Dosya içeriği eksik", "FILE_MISSING");
    try {
      if (kind === "pdf") raw = await deps.pdf(source.buffer);
      else if (kind === "docx") raw = await deps.docx(source.buffer);
      else if (kind === "pptx") raw = await deps.pptx(source.buffer);
      else throw new ValidationError(
          `Desteklenmeyen belge türü: ${kind}`,
          "DOC_UNSUPPORTED_TYPE",
        );
    } catch (e) {
      if (e instanceof ValidationError) throw e;
      // A parser throw is still a 400 rather than an opaque 500: the common
      // cause really is the file (corrupt, truncated, password-protected).
      //
      // But it is NOT the scanned/empty case, and it used to be reported as
      // one (#59): a password-protected PDF was answered with "your document
      // is scanned or empty", which sends the user to re-scan a file that only
      // needed unlocking. DOC_PARSE_FAILED says what actually happened.
      //
      // The original throw survives twice over, because the remaining causes
      // are ours, not the user's — a library regression looks like a stream of
      // users with allegedly bad files unless someone can see it:
      //  - as `cause`, for anything further up that inspects the chain;
      //  - as one log line, the only signal an operator gets, since the 400
      //    branch of lib/api-errors.ts deliberately never logs.
      // The line goes through describeErrorForLog, so a parser that quotes its
      // input cannot spill that input into the log; the client-facing message
      // is a fixed sentence and never interpolates the error or the file.
      console.error(
        `[ingest] PARSER FAILED kind=${kind} -> ${describeErrorForLog(e)}`,
      );
      throw new ValidationError(
        "Belge okunamadı (bozuk veya parola korumalı olabilir)",
        "DOC_PARSE_FAILED",
        { cause: e },
      );
    }
  }

  const trimmed = raw.trim();
  if (trimmed.length < MIN_DOCUMENT_CHARS) {
    throw new ValidationError(
      "Belgeden yeterli metin çıkarılamadı (taranmış/boş olabilir)",
      "DOC_TOO_LITTLE_TEXT",
    );
  }
  return trimmed;
}
