import { describe, expect, it, vi } from "vitest";

import { ValidationError } from "../tenancy/errors";
import { fetchUrlText } from "./extract";
import {
  assertHostAllowed,
  assertUrlAllowed,
  type DnsLookup,
} from "./url-guard";

/** Build an injectable resolver that maps a hostname to fixed IPs. */
function resolverFor(...addresses: string[]): DnsLookup {
  return async () =>
    addresses.map((address) => ({
      address,
      family: address.includes(":") ? 6 : 4,
    }));
}

/** IPs that must always be refused (SSRF targets from the legacy guard). */
const BLOCKED = [
  "127.0.0.1", // loopback
  "::1", // IPv6 loopback
  "10.0.0.5", // private
  "172.16.0.1", // private
  "192.168.1.1", // private
  "169.254.169.254", // link-local + IMDS
  "168.63.129.16", // Azure WireServer carve-out
  "0.0.0.0", // unspecified
  "fc00::1", // IPv6 unique-local
  "fe80::1", // IPv6 link-local
  "::ffff:127.0.0.1", // IPv4-mapped loopback
  "::ffff:10.0.0.1", // IPv4-mapped private
];

describe("assertHostAllowed via injected resolver", () => {
  for (const ip of BLOCKED) {
    it(`blocks a host resolving to ${ip}`, async () => {
      await expect(
        assertHostAllowed("evil.test", resolverFor(ip)),
      ).rejects.toBeInstanceOf(ValidationError);
    });
  }

  it("allows a normal public IPv4", async () => {
    await expect(
      assertHostAllowed("example.test", resolverFor("93.184.216.34")),
    ).resolves.toBeUndefined();
  });

  it("allows a normal public IPv6", async () => {
    await expect(
      assertHostAllowed("example.test", resolverFor("2606:2800:220:1:248:1893:25c8:1946")),
    ).resolves.toBeUndefined();
  });

  it("blocks when ANY of several resolved IPs is internal", async () => {
    await expect(
      assertHostAllowed("mixed.test", resolverFor("93.184.216.34", "10.0.0.1")),
    ).rejects.toBeInstanceOf(ValidationError);
  });

  it("rejects a host that fails to resolve", async () => {
    const resolver: DnsLookup = async () => {
      throw new Error("ENOTFOUND");
    };
    await expect(
      assertHostAllowed("nope.test", resolver),
    ).rejects.toBeInstanceOf(ValidationError);
  });
});

describe("assertHostAllowed with IP-literal hostnames (no DNS)", () => {
  it("blocks http://169.254.169.254 without touching the resolver", async () => {
    const resolver = vi.fn<DnsLookup>();
    await expect(
      assertHostAllowed("169.254.169.254", resolver),
    ).rejects.toBeInstanceOf(ValidationError);
    expect(resolver).not.toHaveBeenCalled();
  });

  it("blocks a bracketed IPv6 literal [::1] without DNS", async () => {
    const resolver = vi.fn<DnsLookup>();
    await expect(assertHostAllowed("[::1]", resolver)).rejects.toBeInstanceOf(
      ValidationError,
    );
    expect(resolver).not.toHaveBeenCalled();
  });

  it("allows a public IP literal without DNS", async () => {
    const resolver = vi.fn<DnsLookup>();
    await expect(
      assertHostAllowed("93.184.216.34", resolver),
    ).resolves.toBeUndefined();
    expect(resolver).not.toHaveBeenCalled();
  });
});

describe("assertUrlAllowed scheme + parse", () => {
  for (const scheme of ["file", "ftp", "gopher", "data"]) {
    it(`blocks the ${scheme}: scheme`, async () => {
      await expect(
        assertUrlAllowed(`${scheme}://example.test/x`, {
          resolver: resolverFor("93.184.216.34"),
        }),
      ).rejects.toThrow("http/https");
    });
  }

  it("rejects an unparseable URL", async () => {
    await expect(
      assertUrlAllowed("not a url", { resolver: resolverFor("93.184.216.34") }),
    ).rejects.toBeInstanceOf(ValidationError);
  });

  it("blocks an IP-literal metadata URL end-to-end", async () => {
    await expect(
      assertUrlAllowed("http://169.254.169.254/latest/meta-data/"),
    ).rejects.toBeInstanceOf(ValidationError);
  });

  it("allows and returns the parsed URL for a public host", async () => {
    const url = await assertUrlAllowed("https://example.test/page", {
      resolver: resolverFor("93.184.216.34"),
    });
    expect(url.hostname).toBe("example.test");
  });
});

describe("fetchUrlText SSRF hardening (injected fetch + resolver)", () => {
  const body = `<body><p>${"Marka bağlamı metni. ".repeat(10)}</p></body>`;

  function okResponse(text: string): Response {
    return new Response(text, {
      status: 200,
      headers: { "content-type": "text/html" },
    });
  }

  it("blocks a 302 redirect into the metadata endpoint (per-hop re-validation)", async () => {
    const fetchImpl = vi.fn(async () =>
      new Response(null, {
        status: 302,
        headers: { location: "http://169.254.169.254/latest/meta-data/" },
      }),
    );
    await expect(
      fetchUrlText("https://public.test/start", {
        fetchImpl: fetchImpl as unknown as typeof fetch,
        resolver: resolverFor("93.184.216.34"),
      }),
    ).rejects.toBeInstanceOf(ValidationError);
  });

  it("follows a redirect to another public URL and returns its text", async () => {
    const fetchImpl = vi
      .fn()
      .mockResolvedValueOnce(
        new Response(null, {
          status: 301,
          headers: { location: "https://public.test/final" },
        }),
      )
      .mockResolvedValueOnce(okResponse(body));
    const out = await fetchUrlText("https://public.test/start", {
      fetchImpl: fetchImpl as unknown as typeof fetch,
      resolver: resolverFor("93.184.216.34"),
    });
    expect(out).toContain("Marka bağlamı metni.");
    expect(fetchImpl).toHaveBeenCalledTimes(2);
  });

  it("refuses the initial URL when it is internal", async () => {
    const fetchImpl = vi.fn();
    await expect(
      fetchUrlText("http://10.0.0.5/secret", {
        fetchImpl: fetchImpl as unknown as typeof fetch,
        resolver: resolverFor("10.0.0.5"),
      }),
    ).rejects.toBeInstanceOf(ValidationError);
    expect(fetchImpl).not.toHaveBeenCalled();
  });

  it("rejects a body over the size cap (declared Content-Length)", async () => {
    const fetchImpl = vi.fn(async () =>
      new Response("x", {
        status: 200,
        headers: {
          "content-type": "text/html",
          "content-length": String(5 * 1024 * 1024 + 1),
        },
      }),
    );
    await expect(
      fetchUrlText("https://public.test/big", {
        fetchImpl: fetchImpl as unknown as typeof fetch,
        resolver: resolverFor("93.184.216.34"),
      }),
    ).rejects.toThrow("boyut");
  });

  it("rejects a body over the size cap when Content-Length lies", async () => {
    const huge = "y".repeat(5 * 1024 * 1024 + 10);
    const fetchImpl = vi.fn(async () =>
      new Response(huge, {
        status: 200,
        headers: { "content-type": "text/html" },
      }),
    );
    await expect(
      fetchUrlText("https://public.test/big", {
        fetchImpl: fetchImpl as unknown as typeof fetch,
        resolver: resolverFor("93.184.216.34"),
      }),
    ).rejects.toThrow("boyut");
  });

  it("gives up after too many redirects", async () => {
    const fetchImpl = vi.fn(async () =>
      new Response(null, {
        status: 302,
        headers: { location: "https://public.test/loop" },
      }),
    );
    await expect(
      fetchUrlText("https://public.test/loop", {
        fetchImpl: fetchImpl as unknown as typeof fetch,
        resolver: resolverFor("93.184.216.34"),
      }),
    ).rejects.toBeInstanceOf(ValidationError);
  });
});
