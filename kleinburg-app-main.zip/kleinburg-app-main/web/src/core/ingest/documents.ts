/**
 * Documents repository for wizard step 1. Framework-neutral (no react/next).
 *
 * Every function is project-scoped: reads and the delete carry the projectId in
 * the WHERE clause so a document id from another project can never be touched.
 * Callers MUST have already passed requireProjectAccess for the project — this
 * module trusts the projectId it is handed.
 */
import { and, asc, eq } from "drizzle-orm";

import { getDb } from "../db/client";
import { documents, type Document, type DocumentKind } from "../db/schema";

/** Insert a document row and return it. */
export async function addDocument(
  projectId: string,
  filename: string,
  kind: DocumentKind,
  extractedText: string,
): Promise<Document> {
  const db = getDb();
  const [row] = await db
    .insert(documents)
    .values({ projectId, filename, kind, extractedText })
    .returning();
  return row;
}

/** All documents for a project, oldest first. */
export async function listDocuments(projectId: string): Promise<Document[]> {
  const db = getDb();
  return db
    .select()
    .from(documents)
    .where(eq(documents.projectId, projectId))
    .orderBy(asc(documents.createdAt));
}

/**
 * Delete a document scoped to its project. Returns true iff a row was removed
 * (false when the id does not exist OR belongs to another project).
 */
export async function deleteDocument(
  projectId: string,
  documentId: string,
): Promise<boolean> {
  const db = getDb();
  const deleted = await db
    .delete(documents)
    .where(and(eq(documents.id, documentId), eq(documents.projectId, projectId)))
    .returning({ id: documents.id });
  return deleted.length > 0;
}
