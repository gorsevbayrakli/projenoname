/**
 * SSRF-safe validation for user-supplied URLs (website ingestion).
 *
 * The wizard lets users hand the server a URL to fetch. Without guards that is a
 * Server-Side Request Forgery primitive: a user could point the server at the
 * cloud metadata endpoint (169.254.169.254 / 168.63.129.16), localhost, or an
 * internal service (10.x, 192.168.x, ...). This module is the single chokepoint
 * that validates a URL before any outbound fetch.
 *
 * Framework-neutral (no react/next): node built-ins + `ipaddr.js` only.
 *
 * Ported from the legacy `core/url_guard.py`. Defenses:
 *  1. Scheme allowlist: only http/https (no file://, ftp://, gopher://, data:).
 *  2. DNS resolution + IP validation: resolve the host to ALL its addresses and
 *     reject if ANY is loopback/private/link-local/reserved/multicast/unspecified
 *     or a cloud-metadata carve-out. Resolving (not string-matching) defeats
 *     encoding tricks (decimal/octal/hex IPs, userinfo @-tricks, IDN) because they
 *     all normalize to a real IP here.
 *  3. The caller (fetchUrlText) follows redirects manually, re-validating every
 *     hop via assertUrlAllowed so a public URL can't 30x-redirect into an internal one.
 *
 * Residual risk: this validates the resolved IPs but the global `fetch` API then
 * re-resolves the hostname on connect, so a DNS-rebinding attacker could answer
 * with a public IP here and an internal IP at connect time (TOCTOU). The legacy
 * pinned the connection to the validated IP; the global fetch API cannot pin, so
 * this is a documented known limitation. Per-hop re-validation mitigates the
 * common redirect-based cases.
 */
import { lookup } from "node:dns/promises";

import ipaddr from "ipaddr.js";

import { ValidationError } from "../tenancy/errors";

/** Only these URL schemes may ever be fetched. */
export const ALLOWED_SCHEMES = ["http:", "https:"] as const;

/**
 * ipaddr.js range() classifications that are never safe to fetch. Covers
 * loopback (127/8, ::1), private (10/8, 172.16/12, 192.168/16), link-local
 * (169.254/16 — includes IMDS 169.254.169.254 — and fe80::/10), unique-local
 * (fc00::/7), unspecified (0.0.0.0, ::), reserved, multicast, broadcast, and
 * carrier-grade NAT (100.64/10).
 */
const BLOCKED_RANGES = new Set<string>([
  "unspecified",
  "broadcast",
  "multicast",
  "linkLocal",
  "loopback",
  "private",
  "reserved",
  "carrierGradeNat",
  "uniqueLocal", // IPv6 fc00::/7
]);

/**
 * Special-use addresses the stdlib range() reports as ordinary unicast but which
 * are actually platform-internal endpoints on a cloud host. 168.63.129.16 is the
 * Azure WireServer / host plugin / platform DNS; 169.254.169.254 is already
 * caught by linkLocal but is listed here for defence in depth.
 */
const BLOCKED_SPECIAL_IPS = new Set<string>([
  "168.63.129.16",
  "169.254.169.254",
]);

/**
 * DNS resolver shape, injectable so tests never hit real DNS. Mirrors node
 * `dns/promises` `lookup(hostname, { all: true })`.
 */
export type DnsLookup = (
  hostname: string,
) => Promise<Array<{ address: string; family: number }>>;

/** Production resolver: node's real DNS, returning every A/AAAA record. */
const defaultLookup: DnsLookup = (hostname) => lookup(hostname, { all: true });

/**
 * True if a single resolved IP string is safe to fetch (globally routable
 * unicast, not a cloud-metadata carve-out). IPv4-mapped/6to4/Teredo IPv6 are
 * unwrapped to the embedded IPv4 first so a mapped private address
 * (e.g. ::ffff:127.0.0.1) can't slip past the range check.
 */
function ipIsPublic(ipStr: string): boolean {
  let addr: ReturnType<typeof ipaddr.parse>;
  try {
    // Strip any IPv6 zone id (fe80::1%eth0) before parsing.
    addr = ipaddr.parse(ipStr.split("%")[0]);
  } catch {
    return false;
  }

  // Unwrap IPv4-mapped IPv6 (::ffff:a.b.c.d) down to the embedded IPv4 so its
  // real range is checked rather than the "ipv4Mapped" wrapper range.
  if (addr.kind() === "ipv6") {
    const v6 = addr as ipaddr.IPv6;
    if (v6.isIPv4MappedAddress()) {
      addr = v6.toIPv4Address();
    }
  }

  const normalized = addr.toNormalizedString();
  if (BLOCKED_SPECIAL_IPS.has(normalized)) return false;

  const range = addr.range();
  if (BLOCKED_RANGES.has(range)) return false;

  // Anything left that isn't plain unicast we treat as unsafe (rfc6145/6052,
  // 6to4, teredo, orchid2, benchmarking, amt, as112, ...). Only "unicast" is a
  // globally routable public address.
  return range === "unicast";
}

/**
 * Resolve `hostname` to every IP and throw ValidationError if ANY is non-public.
 * An IP-literal hostname is validated directly without touching DNS. `resolver`
 * is injectable for tests.
 */
export async function assertHostAllowed(
  hostname: string,
  resolver: DnsLookup = defaultLookup,
): Promise<void> {
  if (!hostname) {
    throw new ValidationError(
      "Bu adrese erişim engellendi (özel/dahili ağ)",
      "URL_BLOCKED",
    );
  }

  // URL hostnames wrap IPv6 literals in brackets ([::1]); strip them.
  const bare =
    hostname.startsWith("[") && hostname.endsWith("]")
      ? hostname.slice(1, -1)
      : hostname;

  // If the host is already an IP literal, validate it directly — no DNS needed.
  if (ipaddr.isValid(bare)) {
    if (!ipIsPublic(bare)) {
      throw new ValidationError(
        "Bu adrese erişim engellendi (özel/dahili ağ)",
        "URL_BLOCKED",
      );
    }
    return;
  }

  let records: Array<{ address: string; family: number }>;
  try {
    records = await resolver(hostname);
  } catch {
    throw new ValidationError("URL getirilemedi", "URL_FETCH_FAILED");
  }

  if (!records || records.length === 0) {
    throw new ValidationError("URL getirilemedi", "URL_FETCH_FAILED");
  }

  for (const { address } of records) {
    if (!ipIsPublic(address)) {
      throw new ValidationError(
        "Bu adrese erişim engellendi (özel/dahili ağ)",
        "URL_BLOCKED",
      );
    }
  }
}

/**
 * Parse and fully validate a single URL (no redirect following). Checks the
 * scheme allowlist then resolves + validates the host. Returns the parsed URL.
 * Call this per redirect hop. `resolver` is injectable for tests.
 */
export async function assertUrlAllowed(
  rawUrl: string,
  opts: { resolver?: DnsLookup } = {},
): Promise<URL> {
  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new ValidationError("Geçersiz URL", "URL_INVALID");
  }

  if (!ALLOWED_SCHEMES.includes(url.protocol as (typeof ALLOWED_SCHEMES)[number])) {
    throw new ValidationError(
      "Yalnızca http/https adresleri desteklenir",
      "URL_SCHEME",
    );
  }

  await assertHostAllowed(url.hostname, opts.resolver ?? defaultLookup);
  return url;
}
