import { describe, expect, it, vi } from "vitest";

import { REDACTED } from "../errors/redact";
import { ValidationError } from "../tenancy/errors";
import {
  extractPptx,
  extractText,
  htmlToText,
  MAX_FILE_BYTES,
  MIN_DOCUMENT_CHARS,
  type ExtractDeps,
  type ParseOfficeFn,
} from "./extract";

/** Build a full deps object; override the piece a test cares about. */
function makeDeps(over: Partial<ExtractDeps> = {}): ExtractDeps {
  return {
    pdf: async () => "unused",
    docx: async () => "unused",
    pptx: async () => "unused",
    fetchUrl: async () => "unused",
    ...over,
  };
}

const longText = "x".repeat(MIN_DOCUMENT_CHARS); // exactly at the threshold

describe("extract constants", () => {
  it("exposes the 10MB ceiling", () => {
    expect(MAX_FILE_BYTES).toBe(10 * 1024 * 1024);
  });
});

describe("extractText threshold", () => {
  it("rejects a file whose extracted text is under MIN_DOCUMENT_CHARS", async () => {
    const deps = makeDeps({ pdf: async () => "too short" });
    await expect(
      extractText("pdf", { buffer: Buffer.from("pdf") }, deps),
    ).rejects.toBeInstanceOf(ValidationError);
  });

  it("carries the scanned/empty PDF message on rejection", async () => {
    const deps = makeDeps({ pdf: async () => "   short   " });
    await expect(
      extractText("pdf", { buffer: Buffer.from("pdf") }, deps),
    ).rejects.toThrow("yeterli metin çıkarılamadı");
  });

  it("accepts text at exactly MIN_DOCUMENT_CHARS", async () => {
    const deps = makeDeps({ docx: async () => longText });
    const out = await extractText("docx", { buffer: Buffer.from("d") }, deps);
    expect(out).toBe(longText);
  });

  it("trims whitespace before measuring and returning", async () => {
    const deps = makeDeps({ pptx: async () => `  \n${longText}\n  ` });
    const out = await extractText("pptx", { buffer: Buffer.from("p") }, deps);
    expect(out).toBe(longText);
  });
});

describe("extractText dispatch", () => {
  it("routes each file kind to its own extractor", async () => {
    const pdf = vi.fn(async () => `pdf-${longText}`);
    const docx = vi.fn(async () => `docx-${longText}`);
    const pptx = vi.fn(async () => `pptx-${longText}`);
    const deps = makeDeps({ pdf, docx, pptx });

    await extractText("pdf", { buffer: Buffer.from("a") }, deps);
    await extractText("docx", { buffer: Buffer.from("a") }, deps);
    await extractText("pptx", { buffer: Buffer.from("a") }, deps);

    expect(pdf).toHaveBeenCalledOnce();
    expect(docx).toHaveBeenCalledOnce();
    expect(pptx).toHaveBeenCalledOnce();
  });

  it("maps a throwing parser (unreadable file) to a parse-failure ValidationError", async () => {
    const deps = makeDeps({
      pdf: async () => {
        throw new Error("pdf.js: invalid PDF structure");
      },
    });
    const err = await extractText(
      "pdf",
      { buffer: Buffer.from("garbage") },
      deps,
    ).catch((e: unknown) => e);

    expect(err).toBeInstanceOf(ValidationError);
    // A parser throw is NOT the scanned/empty case: it must not borrow that
    // code, or a password-protected PDF is reported as an empty one (#59).
    expect((err as ValidationError).code).toBe("DOC_PARSE_FAILED");
    expect((err as ValidationError).message).not.toContain(
      "yeterli metin çıkarılamadı",
    );
  });

  it("keeps the original parser error as the cause instead of discarding it (#59)", async () => {
    const original = new Error("PasswordException: No password given");
    const deps = makeDeps({
      pdf: async () => {
        throw original;
      },
    });
    const err = await extractText(
      "pdf",
      { buffer: Buffer.from("locked") },
      deps,
    ).catch((e: unknown) => e);

    expect((err as Error).cause).toBe(original);
  });

  it("logs the real parser failure for the operator, without the user copy hiding it (#59)", async () => {
    const spy = vi.spyOn(console, "error").mockImplementation(() => {});
    const deps = makeDeps({
      docx: async () => {
        throw new Error("mammoth exploded");
      },
    });
    try {
      await extractText("docx", { buffer: Buffer.from("d") }, deps).catch(
        () => {},
      );
      expect(spy).toHaveBeenCalledOnce();
      const line = String(spy.mock.calls[0]?.[0]);
      expect(line).toContain("docx");
      expect(line).toContain("mammoth exploded");
    } finally {
      spy.mockRestore();
    }
  });

  it("redacts secrets out of the parser log line (#59)", async () => {
    const spy = vi.spyOn(console, "error").mockImplementation(() => {});
    const deps = makeDeps({
      pdf: async () => {
        // A parser that quotes its own input can quote a credential with it;
        // the log line must go through describeErrorForLog, not `${e}`.
        throw new Error('open failed: password="hunter2"');
      },
    });
    try {
      await extractText("pdf", { buffer: Buffer.from("x") }, deps).catch(
        () => {},
      );
      const line = String(spy.mock.calls[0]?.[0]);
      expect(line).toContain(REDACTED);
      expect(line).not.toContain("hunter2");
    } finally {
      spy.mockRestore();
    }
  });

  it("does not leak the parser internals into the user-facing message (#59)", async () => {
    const spy = vi.spyOn(console, "error").mockImplementation(() => {});
    const deps = makeDeps({
      pptx: async () => {
        throw new Error("/srv/uploads/secret-plan.pptx: ZIP central directory");
      },
    });
    try {
      const err = await extractText(
        "pptx",
        { buffer: Buffer.from("p") },
        deps,
      ).catch((e: unknown) => e);
      expect((err as Error).message).not.toContain("secret-plan");
      expect((err as Error).message).not.toContain("ZIP central directory");
    } finally {
      spy.mockRestore();
    }
  });

  it("throws when a file kind has no buffer", async () => {
    await expect(extractText("pdf", {}, makeDeps())).rejects.toBeInstanceOf(
      ValidationError,
    );
  });

  it("throws when the url kind has no url", async () => {
    await expect(extractText("url", {}, makeDeps())).rejects.toBeInstanceOf(
      ValidationError,
    );
  });

  it("routes url to fetchUrl", async () => {
    const fetchUrl = vi.fn(async () => longText);
    await extractText("url", { url: "https://x.test" }, makeDeps({ fetchUrl }));
    expect(fetchUrl).toHaveBeenCalledWith("https://x.test");
  });
});

describe("extractPptx", () => {
  /**
   * This asserts the CALL rather than the extracted text, deliberately.
   *
   * The bug (#83) was that officeparser was asked to auto-detect the format of
   * a buffer, which fails on Render's Node 22 and succeeds on Node 24 — so a
   * test that parses a real .pptx and checks the text would pass on this
   * machine both before and after the fix, and prove nothing. What is stable
   * across every Node version is the contract: we hold the file type already,
   * so we must hand it over instead of asking the library to re-derive it.
   */
  it("tells officeparser the file type instead of letting it guess (#83)", async () => {
    const seen: Array<{ fileType: string }> = [];
    const parse: ParseOfficeFn = async (_buffer, config) => {
      seen.push(config);
      return { toText: () => "slide text" };
    };

    const text = await extractPptx(Buffer.from("PK"), parse);

    expect(text).toBe("slide text");
    expect(seen).toEqual([{ fileType: "pptx" }]);
  });
});

describe("htmlToText", () => {
  it("strips script and style content and keeps readable text", () => {
    const html = `
      <html>
        <head><style>.a{color:red}</style></head>
        <body>
          <h1>Marka</h1>
          <script>console.log("tracking")</script>
          <p>Hoş geldiniz.</p>
        </body>
      </html>`;
    const text = htmlToText(html);
    expect(text).toContain("Marka");
    expect(text).toContain("Hoş geldiniz.");
    expect(text).not.toContain("color:red");
    expect(text).not.toContain("tracking");
  });

  it("feeds through extractText's url path", async () => {
    const html = `<body><p>${"Marka bağlamı metni. ".repeat(5)}</p></body>`;
    const deps = makeDeps({ fetchUrl: async (u) => htmlToText(await Promise.resolve(`<body>${u}${html}</body>`)) });
    const out = await extractText("url", { url: "https://x.test" }, deps);
    expect(out).toContain("Marka bağlamı metni.");
  });
});
