import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "../db/client";
import { brands, documents, projects, users } from "../db/schema";
import { addDocument, deleteDocument, listDocuments } from "./documents";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

async function makeProject() {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({ username: `t14-${randomUUID()}`, passwordHash: "x" })
    .returning();
  createdUserIds.push(user.id);
  const [brand] = await db
    .insert(brands)
    .values({ name: `brand-${randomUUID()}` })
    .returning();
  createdBrandIds.push(brand.id);
  const [project] = await db
    .insert(projects)
    .values({ brandId: brand.id, name: `p-${randomUUID()}`, createdBy: user.id })
    .returning();
  return { user, brand, project };
}

describe.skipIf(!hasDb)("ingest/documents", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    // Deleting brands cascades to projects and their documents.
    if (createdBrandIds.length > 0) {
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    await closeDb();
  });

  it("addDocument inserts and returns the row", async () => {
    const { project } = await makeProject();
    const doc = await addDocument(project.id, "brief.pdf", "pdf", "hello world");
    expect(doc.projectId).toBe(project.id);
    expect(doc.filename).toBe("brief.pdf");
    expect(doc.kind).toBe("pdf");
    expect(doc.extractedText).toBe("hello world");
  });

  it("listDocuments returns a project's documents oldest first", async () => {
    const { project } = await makeProject();
    const a = await addDocument(project.id, "a.pdf", "pdf", "text a");
    const b = await addDocument(project.id, "b.docx", "docx", "text b");
    const rows = await listDocuments(project.id);
    expect(rows.map((r) => r.id)).toEqual([a.id, b.id]);
  });

  it("listDocuments is scoped to the project", async () => {
    const p1 = await makeProject();
    const p2 = await makeProject();
    await addDocument(p1.project.id, "only-p1.pdf", "pdf", "text p1");
    const rows = await listDocuments(p2.project.id);
    expect(rows).toHaveLength(0);
  });

  it("deleteDocument removes a document in its own project", async () => {
    const { project } = await makeProject();
    const doc = await addDocument(project.id, "x.pdf", "pdf", "text");
    const removed = await deleteDocument(project.id, doc.id);
    expect(removed).toBe(true);
    expect(await listDocuments(project.id)).toHaveLength(0);
  });

  it("deleteDocument does NOT delete another project's document", async () => {
    const p1 = await makeProject();
    const p2 = await makeProject();
    const doc = await addDocument(p1.project.id, "p1.pdf", "pdf", "text");
    // Attempt to delete p1's doc while scoped to p2 — must be a no-op.
    const removed = await deleteDocument(p2.project.id, doc.id);
    expect(removed).toBe(false);
    expect(await listDocuments(p1.project.id)).toHaveLength(1);
  });

  it("returns false for a non-existent document id", async () => {
    const { project } = await makeProject();
    const removed = await deleteDocument(project.id, randomUUID());
    expect(removed).toBe(false);
  });

  it("cascades: deleting a project removes its documents", async () => {
    const { project } = await makeProject();
    const doc = await addDocument(project.id, "c.pdf", "pdf", "text");
    const db = getDb();
    await db.delete(projects).where(eq(projects.id, project.id));
    const rows = await db
      .select()
      .from(documents)
      .where(eq(documents.id, doc.id));
    expect(rows).toHaveLength(0);
  });
});
