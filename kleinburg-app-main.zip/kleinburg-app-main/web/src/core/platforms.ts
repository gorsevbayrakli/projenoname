/**
 * The platform registry: the ONE place that knows which social platforms this
 * app can generate for. Framework-neutral (no react/next imports).
 *
 * Before this existed the pair ("instagram", "facebook") was written out by
 * hand in at least six places — a Zod enum, a runtime constant, a job-input
 * type, a ternary picking the prompt, another ternary picking the calendar
 * variant, and the step-7 UI. Adding a platform meant finding all six, and
 * missing one failed at generation time rather than at compile time.
 *
 * Everything downstream now derives from PLATFORMS. Adding LinkedIn or TikTok
 * is one entry here plus its prompt file.
 *
 * What belongs in an entry: facts the ENGINE needs to route and validate. The
 * craft rules (tone, hook length, what a good post looks like) belong in the
 * platform's prompt file, not here — those are Elif's text to approve, and
 * duplicating any of them here would create a second source of truth that
 * silently drifts.
 */

export interface PlatformDef {
  /** Stable storage tag. Persisted in post content and projects.platforms. */
  readonly code: string;
  /**
   * Translation key under `platforms.*` in messages/{tr,en}.json. Never a
   * display string: the label follows the interface language (T25).
   */
  readonly labelKey: string;
  /** Prompt file under web/prompts/ that writes this platform's posts. */
  readonly postPrompt: string;
  /**
   * Default posts per month, used until the user chooses (T34). Reflects the
   * cadence each platform actually rewards, not one number for all of them.
   */
  readonly defaultPostCount: number;
  /**
   * Name used inside prompt text and in the calendar's Platform column.
   * Deliberately NOT translated: the calendar keeps platform names in English
   * as production shorthand (Elif's #11 decision), and the post prompts are
   * written in English.
   */
  readonly promptName: string;
  /**
   * The post formats this platform may be scheduled in, in rotation order.
   *
   * Lifted verbatim from content_calendar_prompt.md. That file is REFERENCE
   * COPY ONLY now — no model reads it, because the calendar step makes no LLM
   * call at all; `pipeline/build-calendar.ts` schedules from this list in code.
   * The two still exist side by side and can drift; the prompt stays the source
   * Elif approves (hard rule 6) and this is its machine-readable twin.
   * Keeping it here, next to the platform's other facts, is what stops a new
   * platform from being registered with no formats to schedule it in.
   *
   * English on purpose, like `promptName`: format names are production
   * shorthand and stay untranslated in every project language.
   */
  readonly formats: readonly string[];
}

export const PLATFORMS = [
  {
    code: "instagram",
    labelKey: "instagram",
    postPrompt: "sm_post_generation",
    defaultPostCount: 16,
    promptName: "Instagram",
    formats: ["Reel", "Carousel", "Single image"],
  },
  {
    code: "facebook",
    labelKey: "facebook",
    postPrompt: "sm_post_generation_facebook",
    defaultPostCount: 12,
    promptName: "Facebook",
    formats: ["Native video", "Photo + story", "Question post"],
  },
  {
    code: "linkedin",
    labelKey: "linkedin",
    postPrompt: "sm_post_generation_linkedin",
    defaultPostCount: 10,
    promptName: "LinkedIn",
    formats: ["Text post", "Document post", "Native video", "Poll"],
  },
  {
    code: "tiktok",
    labelKey: "tiktok",
    postPrompt: "sm_post_generation_tiktok",
    defaultPostCount: 20,
    promptName: "TikTok",
    formats: ["Short video", "Talking to camera", "Demo"],
  },
] as const satisfies readonly PlatformDef[];

export type Platform = (typeof PLATFORMS)[number]["code"];

/** Platform codes, in display order. The Zod enum and the UI both read this. */
export const PLATFORM_CODES = PLATFORMS.map((p) => p.code) as unknown as [
  Platform,
  ...Platform[],
];

/** The default when a tag is missing or unrecognised: the first registered. */
export const DEFAULT_PLATFORM: Platform = PLATFORMS[0].code;

/** Registry entry for a code, or undefined when the code is not registered. */
export function platformDef(code: string): PlatformDef | undefined {
  return PLATFORMS.find((p) => p.code === code);
}

/**
 * Lowercase/whitelist a platform tag, falling back for junk or blanks.
 *
 * Generation tags posts authoritatively, but hand-edited or imported posts
 * bypass that path, so a stray "Facebook " (capitalised, trailing space) would
 * match neither the merge filter nor a render filter and would vanish from the
 * UI entirely. Run untrusted tags through this.
 */
export function normalizePlatform(
  value: unknown,
  fallback: Platform = DEFAULT_PLATFORM,
): Platform {
  const plat = typeof value === "string" ? value.trim().toLowerCase() : "";
  return (PLATFORM_CODES as readonly string[]).includes(plat)
    ? (plat as Platform)
    : fallback;
}

/** Keep only registered codes, de-duplicated, in registry order. */
export function sortPlatforms(codes: readonly string[]): Platform[] {
  const wanted = new Set(codes.map((c) => c.trim().toLowerCase()));
  return PLATFORMS.filter((p) => wanted.has(p.code)).map((p) => p.code);
}

/** Upper bound: one month of daily posting. Elif's cap. */
export const MAX_POST_COUNT = 30;

/**
 * Posts to generate for a platform: the project's stored choice, else the
 * registry default. Out-of-range and non-integer values fall back rather than
 * throwing — a bad stored number must not brick the calendar step.
 */
export function postCountFor(
  code: Platform,
  stored: Record<string, unknown> | null | undefined,
): number {
  const raw = stored?.[code];
  if (
    typeof raw === "number" &&
    Number.isInteger(raw) &&
    raw >= 1 &&
    raw <= MAX_POST_COUNT
  ) {
    return raw;
  }
  return platformDef(code)?.defaultPostCount ?? 12;
}
