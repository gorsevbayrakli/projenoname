/**
 * T43 — the account area's core service.
 *
 * Everything here is SELF-scoped: every function takes the acting user's own id
 * and can only ever read or write that row. There is no "userId to act on"
 * parameter anywhere in this module, which is what keeps it from becoming a
 * second, unguarded admin surface.
 */
import { randomUUID } from "node:crypto";
import { eq, inArray } from "drizzle-orm";
import { afterAll, beforeAll, describe, expect, it } from "vitest";

import { closeDb, getDb } from "../db/client";
import { auditEvents, users } from "../db/schema";
import { hasDb } from "@/test/db-gate";
import { ConflictError, ValidationError } from "../tenancy/errors";
import {
  MAX_DISPLAY_NAME_LENGTH,
  MAX_EMAIL_LENGTH,
  getAccountProfile,
  setAccountLocale,
  updateAccountProfile,
} from "./service";

const createdUserIds: string[] = [];

/**
 * This user's audit rows, oldest first.
 *
 * Nothing deletes them: `audit_events` rejects DELETE by trigger, which is the
 * whole point of the table. Each test therefore uses a fresh user and scopes
 * the read to it rather than truncating anything.
 */
async function auditRowsFor(userId: string) {
  return getDb()
    .select()
    .from(auditEvents)
    .where(eq(auditEvents.actorUserId, userId))
    .orderBy(auditEvents.occurredAt);
}

async function makeUser(): Promise<string> {
  const db = getDb();
  const [row] = await db
    .insert(users)
    .values({ username: `t43-acct-${randomUUID()}`, passwordHash: "x" })
    .returning();
  createdUserIds.push(row.id);
  return row.id;
}

describe.skipIf(!hasDb)("account/service", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    await closeDb();
  });

  it("reads a fresh account with no name, e-mail or locale preference", async () => {
    const userId = await makeUser();
    const profile = await getAccountProfile(userId);

    expect(profile.displayName).toBeNull();
    expect(profile.email).toBeNull();
    expect(profile.uiLocale).toBeNull();
    expect(profile.username).toMatch(/^t43-acct-/);
  });

  it("never exposes the password hash", async () => {
    const userId = await makeUser();
    const profile = await getAccountProfile(userId);
    expect(Object.keys(profile)).not.toContain("passwordHash");
    expect(JSON.stringify(profile)).not.toContain("passwordHash");
  });

  it("saves a display name and e-mail, trimming both", async () => {
    const userId = await makeUser();
    const updated = await updateAccountProfile(userId, {
      displayName: "  Elif Cerit Soylu  ",
      email: "  Elif@Example.COM ",
    });

    expect(updated.displayName).toBe("Elif Cerit Soylu");
    // Stored lowercase: the uniqueness index is case-insensitive, so keeping
    // the typed casing would make "A@x.com" and "a@x.com" look different here
    // while colliding in the database.
    expect(updated.email).toBe("elif@example.com");
  });

  it("treats a blank field as clearing it, not as an empty string", async () => {
    const userId = await makeUser();
    await updateAccountProfile(userId, {
      displayName: "Adı Soyadı",
      email: "clear-me@example.com",
    });

    const cleared = await updateAccountProfile(userId, {
      displayName: "   ",
      email: "",
    });

    expect(cleared.displayName).toBeNull();
    expect(cleared.email).toBeNull();
  });

  it("rejects an address that is not an e-mail", async () => {
    const userId = await makeUser();
    for (const bad of ["nope", "a@b", "a b@example.com", "@example.com", "a@"]) {
      await expect(
        updateAccountProfile(userId, { email: bad }),
      ).rejects.toBeInstanceOf(ValidationError);
    }
  });

  it("rejects over-long values rather than silently truncating", async () => {
    const userId = await makeUser();
    await expect(
      updateAccountProfile(userId, {
        displayName: "a".repeat(MAX_DISPLAY_NAME_LENGTH + 1),
      }),
    ).rejects.toBeInstanceOf(ValidationError);
    await expect(
      updateAccountProfile(userId, {
        email: `${"a".repeat(MAX_EMAIL_LENGTH)}@example.com`,
      }),
    ).rejects.toBeInstanceOf(ValidationError);
  });

  it("refuses an e-mail another account already claims, case-insensitively", async () => {
    const first = await makeUser();
    const second = await makeUser();
    const address = `shared-${randomUUID()}@example.com`;

    await updateAccountProfile(first, { email: address });

    await expect(
      updateAccountProfile(second, { email: address.toUpperCase() }),
    ).rejects.toBeInstanceOf(ConflictError);
  });

  /**
   * Unicode confusables (#43 review, finding 3).
   *
   * `trim()` + `toLowerCase()` compares BYTES. "josé" written as one composed
   * codepoint and as "e" + combining acute are different byte strings that
   * both pass the pattern, and `lower(email)` in the partial unique index
   * compares the same bytes, so it does not fire. Two accounts end up holding
   * an address that is visually identical — which is inert while e-mail is
   * only contact data and is a real account-takeover surface the day a
   * recovery-by-mail flow lands.
   */
  it("treats the NFC and NFD spellings of one address as the same address", async () => {
    const first = await makeUser();
    const second = await makeUser();
    const local = `josé-${randomUUID()}`; // é as one codepoint
    const composed = `${local}@example.com`.normalize("NFC");
    const decomposed = `${local}@example.com`.normalize("NFD"); // e + U+0301

    expect(composed).not.toBe(decomposed); // different bytes, same address

    const saved = await updateAccountProfile(first, { email: decomposed });
    // Stored in one canonical form, whichever spelling was typed.
    expect(saved.email).toBe(composed);

    await expect(
      updateAccountProfile(second, { email: composed }),
    ).rejects.toBeInstanceOf(ConflictError);
  });

  it("strips zero-width characters instead of storing a second lookalike", async () => {
    const first = await makeUser();
    const second = await makeUser();
    const address = `zw-${randomUUID()}@example.com`;

    await updateAccountProfile(first, { email: address });

    // U+200B ZERO WIDTH SPACE: invisible, survives NFKC, and would otherwise
    // make this a distinct string that renders identically.
    await expect(
      updateAccountProfile(second, { email: `zw\u200B${address.slice(2)}` }),
    ).rejects.toBeInstanceOf(ConflictError);
  });

  it("folds compatibility forms onto their plain equivalents", async () => {
    const userId = await makeUser();
    const local = `fw-${randomUUID()}`;

    // U+FF20 FULLWIDTH COMMERCIAL AT. NFKC maps it to a plain "@", so the
    // address is stored — and matched — in the form everyone else would type.
    const saved = await updateAccountProfile(userId, {
      email: `${local}\uFF20example.com`,
    });

    expect(saved.email).toBe(`${local}@example.com`);
  });

  it("lets an account keep its own e-mail on a re-save", async () => {
    const userId = await makeUser();
    const address = `mine-${randomUUID()}@example.com`;
    await updateAccountProfile(userId, { email: address });

    const again = await updateAccountProfile(userId, {
      email: address,
      displayName: "Yeni Ad",
    });

    expect(again.email).toBe(address);
    expect(again.displayName).toBe("Yeni Ad");
  });

  it("leaves an omitted field untouched", async () => {
    const userId = await makeUser();
    await updateAccountProfile(userId, {
      displayName: "Kalıcı Ad",
      email: `keep-${randomUUID()}@example.com`,
    });

    const partial = await updateAccountProfile(userId, {
      displayName: "Değişen Ad",
    });

    expect(partial.displayName).toBe("Değişen Ad");
    expect(partial.email).not.toBeNull();
  });

  /**
   * The e-mail change leaves a row (#43 review, finding 5).
   *
   * T43 recorded nothing here on the grounds that e-mail is not an auth
   * factor. It is still the account's only contact channel, it is mutable by
   * whoever holds the session, and `audit_events` forbids DELETE — so a
   * history that is not written now can never be written later. That
   * asymmetry, not today's threat model, is why these rows exist.
   */
  it("records an audit row when the e-mail changes", async () => {
    const userId = await makeUser();
    const address = `audited-${randomUUID()}@example.com`;

    await updateAccountProfile(userId, { email: address });

    const rows = await auditRowsFor(userId);
    expect(rows).toHaveLength(1);
    expect(rows[0].action).toBe("user_email_change");
    expect(rows[0].metadata).toEqual({
      previousEmail: null,
      newEmail: address,
    });
  });

  it("records clearing the e-mail, which removes the contact channel", async () => {
    const userId = await makeUser();
    const address = `cleared-${randomUUID()}@example.com`;
    await updateAccountProfile(userId, { email: address });

    await updateAccountProfile(userId, { email: "" });

    const rows = await auditRowsFor(userId);
    expect(rows).toHaveLength(2);
    expect(rows[1].metadata).toEqual({
      previousEmail: address,
      newEmail: null,
    });
  });

  it("writes no row when the e-mail is re-saved unchanged", async () => {
    const userId = await makeUser();
    const address = `same-${randomUUID()}@example.com`;
    await updateAccountProfile(userId, { email: address });

    // Same address, different casing and spacing: the STORED value does not
    // move, so there is nothing to record.
    await updateAccountProfile(userId, { email: ` ${address.toUpperCase()} ` });

    expect(await auditRowsFor(userId)).toHaveLength(1);
  });

  it("writes no row for a display-name or language change", async () => {
    // Deliberate: display preferences do not belong in a table with no delete
    // path. Only the contact channel does.
    const userId = await makeUser();

    await updateAccountProfile(userId, { displayName: "Yalnızca Ad" });
    await setAccountLocale(userId, "en");

    expect(await auditRowsFor(userId)).toHaveLength(0);
  });

  it("stores and clears the interface-language preference", async () => {
    const userId = await makeUser();

    expect((await setAccountLocale(userId, "en")).uiLocale).toBe("en");
    expect((await setAccountLocale(userId, "tr")).uiLocale).toBe("tr");
    // null = "no preference", which hands the decision back to the cookie.
    expect((await setAccountLocale(userId, null)).uiLocale).toBeNull();
  });

  it("refuses a locale outside the supported set", async () => {
    const userId = await makeUser();
    await expect(setAccountLocale(userId, "zz")).rejects.toBeInstanceOf(
      ValidationError,
    );

    const db = getDb();
    const [row] = await db.select().from(users).where(eq(users.id, userId));
    expect(row.uiLocale).toBeNull();
  });
});
