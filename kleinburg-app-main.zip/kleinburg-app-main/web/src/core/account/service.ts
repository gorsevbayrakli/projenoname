/**
 * The account area's core service (T43).
 *
 * ── SELF-SCOPE ───────────────────────────────────────────────────────────
 * Every function here takes the ACTING user's own id and writes only that row.
 * There is deliberately no "target user" parameter: editing somebody else is
 * an admin operation and already lives in core/admin/service.ts behind
 * `requireSuperAdmin`. Keeping the two apart is what stops this module from
 * quietly becoming a second admin surface with no role check.
 *
 * Password changing is NOT here. It shipped in T40 as
 * core/auth/change-password.ts and the account area links to that same flow
 * rather than growing a second copy of the rules (hard rule: one password
 * policy, in core/auth/password-policy.ts).
 */
import { and, eq, ne, sql } from "drizzle-orm";

import { isLocale, type Locale } from "../i18n/locales";
import { recordAuditEvent } from "../audit/service";
import { getDb } from "../db/client";
import { users } from "../db/schema";
import { ConflictError, NotFoundError, ValidationError } from "../tenancy/errors";

/** Generous but bounded: a name, not a biography. */
export const MAX_DISPLAY_NAME_LENGTH = 120;

/** The practical limit for an address (RFC 5321 caps the whole path at 254). */
export const MAX_EMAIL_LENGTH = 254;

/**
 * Deliberately loose: one @, something either side, a dot in the domain, no
 * whitespace. Nothing here can prove an address RECEIVES mail — only a
 * confirmation message could, and there is no mail infrastructure. So this
 * catches typos and refuses obvious nonsense, and does not pretend to more.
 */
const EMAIL_PATTERN = /^[^\s@]+@[^\s@.]+(\.[^\s@.]+)+$/;

/** What the account area shows about the signed-in user. Never the hash. */
export interface AccountProfile {
  id: string;
  username: string;
  displayName: string | null;
  email: string | null;
  /** NULL = no account preference; the `kb_locale` cookie decides. */
  uiLocale: Locale | null;
  role: "admin" | "user";
  createdAt: Date;
}

/** Fields the user may change about themselves. Omitted = leave alone. */
export interface AccountProfileInput {
  displayName?: string;
  email?: string;
}

/** Postgres unique_violation SQLSTATE. */
const PG_UNIQUE_VIOLATION = "23505";

function isUniqueViolation(err: unknown): boolean {
  const hasCode = (e: unknown): boolean =>
    typeof e === "object" &&
    e !== null &&
    "code" in e &&
    (e as { code?: unknown }).code === PG_UNIQUE_VIOLATION;
  if (hasCode(err)) return true;
  if (err instanceof Error && hasCode(err.cause)) return true;
  return false;
}

/** Narrow a row to the fields the account area may see. */
function toProfile(row: typeof users.$inferSelect): AccountProfile {
  return {
    id: row.id,
    username: row.username,
    displayName: row.displayName,
    email: row.email,
    // Narrowed on READ, not trusted from the column: a value written before a
    // language was retired must not reach next-intl and fail a message import.
    uiLocale: isLocale(row.uiLocale) ? row.uiLocale : null,
    role: row.role,
    createdAt: row.createdAt,
  };
}

async function readRow(userId: string): Promise<typeof users.$inferSelect> {
  const db = getDb();
  const [row] = await db.select().from(users).where(eq(users.id, userId));
  if (!row) {
    throw new NotFoundError("Kullanıcı bulunamadı", "USER_NOT_FOUND");
  }
  return row;
}

/** The signed-in user's own profile. */
export async function getAccountProfile(
  userId: string,
): Promise<AccountProfile> {
  return toProfile(await readRow(userId));
}

/**
 * Trim a free-text field. An all-whitespace value means "clear this", which is
 * how the form expresses removal — a user who empties the box wants the field
 * gone, and storing "" would give the column two different ways to be empty.
 */
function normalizeOptional(value: string): string | null {
  const trimmed = value.trim();
  return trimmed.length === 0 ? null : trimmed;
}

/**
 * Invisible characters that must not survive into a stored address.
 *
 * Zero-width space/non-joiner/joiner, the word joiner, and the byte-order mark.
 * NFKC does NOT remove them — they are legitimate codepoints with their own
 * canonical form — so they get their own pass. None of them can appear in a
 * real address, and all of them render as nothing, which is exactly what makes
 * them useful for building a second account that looks like the first.
 */
const ZERO_WIDTH = /[\u200B-\u200D\u2060\uFEFF]/g;

/**
 * The stored form of an address (#43 review, finding 3).
 *
 * ── WHY BYTE COMPARISON IS NOT ENOUGH ────────────────────────────────────
 * The uniqueness guarantee is a partial unique index on `lower(email)`, and
 * Postgres compares BYTES. Unicode gives the same visible address several byte
 * spellings: `josé@x.com` composed (U+00E9) and decomposed (`e` + U+0301) are
 * different strings, both pass the pattern, and the index does not fire — so
 * two accounts can hold what a human reads as one address. Zero-width
 * characters do the same trick with no visible difference at all.
 *
 * That is inert today, because e-mail is contact data that does not
 * authenticate anything. It stops being inert the moment a recovery-by-mail
 * flow exists (`verified_at` in core/db/schema.ts already anticipates one), at
 * which point "which account owns this address" would have two answers.
 *
 * ── THE ORDER, WHICH MATTERS ─────────────────────────────────────────────
 * 1. drop zero-width characters, which normalisation would preserve;
 * 2. NFKC, the same choice `maskUnknownUsername` makes, so compatibility forms
 *    (fullwidth `＠`, ligatures) fold onto what everybody else types;
 * 3. trim, AFTER folding — NFKC turns some compatibility spaces into U+0020,
 *    which only `trim` can then remove;
 * 4. validate, so the pattern judges the string that will actually be stored;
 * 5. lowercase, then normalise once more: case folding can leave a composed
 *    character in a non-canonical form, and the stored value must be exactly
 *    what a later lookup produces.
 */
function normalizeEmail(value: string): string | null {
  const folded = value.replace(ZERO_WIDTH, "").normalize("NFKC").trim();
  if (folded.length === 0) return null;
  if (folded.length > MAX_EMAIL_LENGTH) {
    throw new ValidationError("E-posta adresi çok uzun", "EMAIL_TOO_LONG");
  }
  if (!EMAIL_PATTERN.test(folded)) {
    throw new ValidationError("Geçerli bir e-posta adresi girin", "EMAIL_INVALID");
  }
  // Lowercased because the uniqueness index is on lower(email): storing the
  // typed casing would let the stored value disagree with what collides.
  return folded.toLowerCase().normalize("NFKC");
}

function normalizeDisplayName(value: string): string | null {
  const trimmed = normalizeOptional(value);
  if (trimmed !== null && trimmed.length > MAX_DISPLAY_NAME_LENGTH) {
    throw new ValidationError("Ad çok uzun", "DISPLAY_NAME_TOO_LONG");
  }
  return trimmed;
}

/**
 * Update the signed-in user's own name and/or e-mail.
 *
 * Only the keys present in `input` are written, so the form can send one field
 * without blanking the other.
 */
export async function updateAccountProfile(
  userId: string,
  input: AccountProfileInput,
): Promise<AccountProfile> {
  const patch: Partial<typeof users.$inferInsert> = {};
  if (input.displayName !== undefined) {
    patch.displayName = normalizeDisplayName(input.displayName);
  }
  if (input.email !== undefined) {
    patch.email = normalizeEmail(input.email);
  }

  if (Object.keys(patch).length === 0) return getAccountProfile(userId);

  const db = getDb();

  // The address as it stands, read only when the write could move it. It is
  // what makes the audit row say what CHANGED rather than only what it became,
  // and it is what stops a no-op re-save from writing a row at all.
  const previousEmail =
    "email" in patch ? (await readRow(userId)).email : undefined;

  // Pre-check for a friendly, specific error. The partial unique index is
  // still the authority — this check and the write are not atomic, so the
  // catch below is what actually guarantees uniqueness under a race.
  if (patch.email) {
    const [clash] = await db
      .select({ id: users.id })
      .from(users)
      .where(
        and(
          sql`lower(${users.email}) = ${patch.email}`,
          ne(users.id, userId),
        ),
      );
    if (clash) {
      throw new ConflictError(
        "Bu e-posta adresi başka bir hesapta kayıtlı",
        "EMAIL_TAKEN",
      );
    }
  }

  try {
    const [row] = await db
      .update(users)
      .set(patch)
      .where(eq(users.id, userId))
      .returning();
    if (!row) {
      throw new NotFoundError("Kullanıcı bulunamadı", "USER_NOT_FOUND");
    }

    /**
     * The contact channel moved, so it leaves a permanent trace (#43 review,
     * finding 5).
     *
     * BEST-EFFORT, not atomic: `recordAuditEvent` never throws, so a log
     * outage does not refuse a profile edit. That matches the auth category
     * this action sits in; only directory actions (`ATOMIC_AUDIT_ACTIONS`) are
     * worth failing over.
     *
     * Only the e-mail. Display name and language are display preferences and
     * are deliberately not recorded — see the note on `user_email_change` in
     * core/db/schema.ts. Both addresses are contact data, already normalised
     * above and sanitised again by `toRow`.
     */
    if (previousEmail !== undefined && previousEmail !== row.email) {
      await recordAuditEvent({
        action: "user_email_change",
        actorUserId: row.id,
        actorUsername: row.username,
        metadata: { previousEmail, newEmail: row.email },
      });
    }

    return toProfile(row);
  } catch (err) {
    if (isUniqueViolation(err)) {
      throw new ConflictError(
        "Bu e-posta adresi başka bir hesapta kayıtlı",
        "EMAIL_TAKEN",
      );
    }
    throw err;
  }
}

/**
 * Bind the interface language to the account, or clear it (T43).
 *
 * `null` restores "no preference", handing the decision back to the
 * `kb_locale` cookie — see resolveEffectiveLocale for the precedence rule.
 */
export async function setAccountLocale(
  userId: string,
  locale: string | null,
): Promise<AccountProfile> {
  if (locale !== null && !isLocale(locale)) {
    throw new ValidationError(`Desteklenmeyen dil: ${locale}`, "LOCALE_INVALID");
  }

  const db = getDb();
  const [row] = await db
    .update(users)
    .set({ uiLocale: locale })
    .where(eq(users.id, userId))
    .returning();
  if (!row) {
    throw new NotFoundError("Kullanıcı bulunamadı", "USER_NOT_FOUND");
  }
  return toProfile(row);
}
