import { describe, expect, it } from "vitest";

describe("test harness sanity", () => {
  it("adds numbers", () => {
    expect(1 + 1).toBe(2);
  });
});
