import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

import { smPostsSchema } from "./pipeline/schemas";
import {
  DEFAULT_PLATFORM,
  normalizePlatform,
  PLATFORMS,
  PLATFORM_CODES,
  platformDef,
  sortPlatforms,
} from "./platforms";

// web/src/core -> web/prompts
const PROMPTS_DIR = join(dirname(fileURLToPath(import.meta.url)), "../../prompts");

/**
 * The registry is only worth having if everything really derives from it. These
 * assert the derivation rather than the contents, so adding LinkedIn or TikTok
 * needs no edits here — but registering a platform whose prompt file does not
 * exist, or whose code the schema would reject, fails immediately instead of at
 * generation time against a paid API call.
 */
describe("platform registry", () => {
  it("registers at least one platform, with unique codes", () => {
    expect(PLATFORMS.length).toBeGreaterThan(0);
    expect(new Set(PLATFORM_CODES).size).toBe(PLATFORM_CODES.length);
  });

  it("ships a prompt file for every registered platform", () => {
    for (const p of PLATFORMS) {
      expect(
        existsSync(join(PROMPTS_DIR, `${p.postPrompt}.md`)),
        `${p.code}: prompts/${p.postPrompt}.md is missing`,
      ).toBe(true);
    }
  });

  it("uses lowercase codes, since tags are normalised to lowercase", () => {
    for (const code of PLATFORM_CODES) {
      expect(code).toBe(code.toLowerCase());
    }
  });

  it("accepts every registered code in the post schema", () => {
    for (const code of PLATFORM_CODES) {
      const parsed = smPostsSchema.safeParse({
        posts: [
          {
            platform: code,
            theme: "t",
            hook: "h",
            caption: "c",
            cta: "x",
            hashtags: ["#a"],
          },
        ],
      });
      expect(parsed.success, `${code} rejected by smPostsSchema`).toBe(true);
    }
  });

  it("rejects a code that is not registered", () => {
    const parsed = smPostsSchema.safeParse({
      posts: [
        {
          platform: "myspace",
          theme: "t",
          hook: "h",
          caption: "c",
          cta: "x",
          hashtags: ["#a"],
        },
      ],
    });
    expect(parsed.success).toBe(false);
  });

  it("defaults to the first registered platform", () => {
    expect(DEFAULT_PLATFORM).toBe(PLATFORMS[0].code);
  });

  it("normalises case and whitespace, and falls back on junk", () => {
    const code = PLATFORM_CODES[0];
    expect(normalizePlatform(` ${code.toUpperCase()} `)).toBe(code);
    expect(normalizePlatform("myspace")).toBe(DEFAULT_PLATFORM);
    expect(normalizePlatform(undefined)).toBe(DEFAULT_PLATFORM);
    expect(normalizePlatform(42)).toBe(DEFAULT_PLATFORM);
  });

  it("looks up a registered code and misses an unregistered one", () => {
    expect(platformDef(PLATFORM_CODES[0])?.code).toBe(PLATFORM_CODES[0]);
    expect(platformDef("myspace")).toBeUndefined();
  });

  it("sorts into registry order, dropping junk and duplicates", () => {
    const reversed = [...PLATFORM_CODES].reverse();
    expect(sortPlatforms([...reversed, "myspace", PLATFORM_CODES[0]])).toEqual([
      ...PLATFORM_CODES,
    ]);
    expect(sortPlatforms([])).toEqual([]);
  });
});
