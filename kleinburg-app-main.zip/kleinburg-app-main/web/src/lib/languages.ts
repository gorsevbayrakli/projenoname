import type { ProjectLanguage } from "@/core/tenancy/projects";

/**
 * The 7 CONTENT languages — the languages the ENGINE generates content in
 * (projects.language). This is NOT the interface language: the UI chrome is
 * translated separately via next-intl (see src/i18n/), and a user may well run
 * the interface in English while generating Turkish content.
 *
 * T25 moved the DISPLAY NAMES into the message catalogs
 * (`contentLanguages.<code>` in messages/{tr,en}.json) so the badge and the
 * dropdown read in the interface language. The CODES stay here and remain the
 * stable identity — they are what is persisted and what the pipeline reads;
 * nothing about the stored value changed.
 *
 * Kept DB-free (only a type-only import of ProjectLanguage) so this module can
 * be imported from client components without pulling the `pg`-backed projects
 * module — and therefore Node built-ins — into the browser bundle. The Record
 * type still fails to compile if a code in PROJECT_LANGUAGES is missing, so the
 * two stay in sync.
 */
const LANGUAGE_CODES: Record<ProjectLanguage, true> = {
  en: true,
  tr: true,
  fr: true,
  de: true,
  es: true,
  it: true,
  pt: true,
};

/** The content languages in a stable display order, for <Select>. */
export const LANGUAGE_OPTIONS: ProjectLanguage[] = Object.keys(
  LANGUAGE_CODES,
) as ProjectLanguage[];
