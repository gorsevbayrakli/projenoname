import { describe, expect, it } from "vitest";

import {
  DEMO_BRAND_CONTEXT,
  DEMO_CREATIVE_SPARKS,
  DEMO_PASSWORD,
  DEMO_PILLARS,
  DEMO_PILLAR_SELECTED_INDICES,
  DEMO_PLATFORMS,
  DEMO_POSTS,
  DEMO_POST_COUNTS,
  DEMO_SECONDARY_DATA,
} from "./demo-seed";
import {
  creativeSparksSchema,
  secondaryDataSchema,
  smPillarsSchema,
  smPostsSchema,
} from "@/core/pipeline/schemas";
import {
  PILLAR_FLOOR_PER_CATEGORY,
  PILLAR_TOTAL,
} from "@/core/pipeline/run-step";
import { POSTS_PER_PILLAR } from "@/core/pipeline/inputs";
import { MIN_BRAND_CONTEXT_CHARS } from "./wizard-status";
import { MIN_PASSWORD_LENGTH } from "@/core/auth/password-policy";

/**
 * The demo fixtures are DATA THE APP WILL LOAD, not illustrations. If they do
 * not satisfy the same schemas and count rules a real model run has to satisfy,
 * `seed demo` produces a project the app itself rejects — a local environment
 * that disagrees with production, which is the exact problem the command exists
 * to fix.
 *
 * So these assertions are pinned against the REAL constants (imported, never
 * retyped), which also means a future change to PILLAR_TOTAL or the floor turns
 * this red instead of leaving stale fixtures behind.
 */

describe("demo seed fixtures", () => {
  /**
   * Read from the policy constant, never a retyped number. The demo password is
   * the one credential in this repo written in source, and it is the example a
   * reader copies. Login does not enforce the policy today — correctly, since a
   * policy change must not lock out an existing account — so a short demo
   * password would work right up until login started checking, and then the
   * documented login would break in a way that looks like a seed bug.
   */
  it("uses a demo password the app's own policy would accept", () => {
    expect(DEMO_PASSWORD.length).toBeGreaterThanOrEqual(MIN_PASSWORD_LENGTH);
  });

  it("the pillars satisfy the sm_pillars schema", () => {
    expect(() => smPillarsSchema.parse({ pillars: DEMO_PILLARS })).not.toThrow();
  });

  it("there are exactly PILLAR_TOTAL pillars", () => {
    expect(DEMO_PILLARS).toHaveLength(PILLAR_TOTAL);
  });

  it("every category clears PILLAR_FLOOR_PER_CATEGORY", () => {
    for (const category of [
      "INSPIRATIONAL",
      "ENTERTAINING",
      "INFORMATIONAL",
    ]) {
      const n = DEMO_PILLARS.filter((p) => p.category === category).length;
      expect(
        n,
        `${category} has ${n} pillars, floor is ${PILLAR_FLOOR_PER_CATEGORY}`,
      ).toBeGreaterThanOrEqual(PILLAR_FLOOR_PER_CATEGORY);
    }
  });

  it("the distribution is NOT equal across categories", () => {
    // The 7/7/7 quota was removed on 2026-07-21 precisely because it produced
    // manufactured copy. A fixture that happens to be equal would let the old
    // rule be re-imposed without a single test noticing.
    const counts = ["INSPIRATIONAL", "ENTERTAINING", "INFORMATIONAL"].map(
      (c) => DEMO_PILLARS.filter((p) => p.category === c).length,
    );
    expect(new Set(counts).size).toBeGreaterThan(1);
  });

  it("every pillar title is unique", () => {
    // resolvePillar in build-calendar.ts matches posts to pillars BY TITLE, so
    // duplicate titles would make step 9 non-deterministic.
    const titles = DEMO_PILLARS.map((p) => p.title);
    expect(new Set(titles).size).toBe(titles.length);
  });

  it("the stored pillar selection is in range and non-empty", () => {
    expect(DEMO_PILLAR_SELECTED_INDICES.length).toBeGreaterThan(0);
    for (const i of DEMO_PILLAR_SELECTED_INDICES) {
      expect(i).toBeGreaterThanOrEqual(0);
      expect(i).toBeLessThan(DEMO_PILLARS.length);
    }
    expect(new Set(DEMO_PILLAR_SELECTED_INDICES).size).toBe(
      DEMO_PILLAR_SELECTED_INDICES.length,
    );
  });

  it("the stored selection is a strict SUBSET, so step 7 has something unchecked", () => {
    // Step 7 opens with the stored selection pre-checked (2026-07-21). A
    // fixture that selected everything would render identically to a fixture
    // with no selection rule at all, and could not show the bug the product
    // owner hit.
    expect(DEMO_PILLAR_SELECTED_INDICES.length).toBeLessThan(
      DEMO_PILLARS.length,
    );
  });

  it("the posts satisfy the sm_posts schema", () => {
    expect(() => smPostsSchema.parse({ posts: DEMO_POSTS })).not.toThrow();
  });

  it("posts = selected pillars x POSTS_PER_PILLAR", () => {
    expect(DEMO_POSTS).toHaveLength(
      DEMO_PILLAR_SELECTED_INDICES.length * POSTS_PER_PILLAR,
    );
  });

  it("every post's theme starts with a SELECTED pillar's title", () => {
    // build-calendar.ts resolves a post to a pillar by finding the title in the
    // theme's head. A theme that resolves to nothing lands in
    // `unresolvedPillars` and step 9 reports drift on freshly seeded data.
    const selectedTitles = DEMO_PILLAR_SELECTED_INDICES.map(
      (i) => DEMO_PILLARS[i].title,
    );
    for (const post of DEMO_POSTS) {
      const head = post.theme.split("—")[0];
      const match = selectedTitles.some((t) => head.includes(t));
      expect(match, `theme has no selected pillar: ${post.theme}`).toBe(true);
    }
  });

  it("every post is on a platform the demo project actually enables", () => {
    for (const post of DEMO_POSTS) {
      expect(DEMO_PLATFORMS).toContain(post.platform);
    }
  });

  it("the per-platform post counts are exactly met, so step 9 has no shortfall", () => {
    for (const platform of DEMO_PLATFORMS) {
      const n = DEMO_POSTS.filter((p) => p.platform === platform).length;
      expect(n, `${platform}`).toBe(DEMO_POST_COUNTS[platform]);
    }
  });

  it("the brand context is long enough to complete wizard step 2", () => {
    // Under MIN_BRAND_CONTEXT_CHARS the wizard forward-locks at step 2 and the
    // whole walk-through is impossible — the exact failure this seed prevents.
    expect(DEMO_BRAND_CONTEXT.length).toBeGreaterThanOrEqual(
      MIN_BRAND_CONTEXT_CHARS,
    );
  });

  it("secondary_data and creative_sparks satisfy their schemas", () => {
    expect(() =>
      secondaryDataSchema.parse({ items: DEMO_SECONDARY_DATA }),
    ).not.toThrow();
    expect(() =>
      creativeSparksSchema.parse({ items: DEMO_CREATIVE_SPARKS }),
    ).not.toThrow();
  });

  it("the demo password is a constant in the source, and that is the point", () => {
    // Not an incidental check. This password is public by construction; the
    // ONLY thing that makes it acceptable is core/db/local-only.ts. If this
    // test is ever failing because someone parameterised the password, read
    // that module before "fixing" it.
    expect(typeof DEMO_PASSWORD).toBe("string");
    expect(DEMO_PASSWORD.length).toBeGreaterThan(0);
  });
});
