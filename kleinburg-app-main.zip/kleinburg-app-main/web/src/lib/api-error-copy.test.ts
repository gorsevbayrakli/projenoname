import { createTranslator } from "next-intl";
import { describe, expect, it } from "vitest";

import en from "../../messages/en.json";
import tr from "../../messages/tr.json";
import { MIN_PASSWORD_LENGTH } from "@/core/auth/password-policy";
import { apiErrorMessage, type ApiErrorTranslator } from "./api-error-copy";

/**
 * The contract: a CODE decides the copy, and a code we cannot translate must
 * degrade to the server's own message — never to a blank error box.
 */
function translator(catalog: Record<string, string>): ApiErrorTranslator {
  // Stands in for next-intl's ICU interpolation, so a message that declares a
  // placeholder is rendered here the way it will be rendered in the app.
  const t = (key: string, values?: Record<string, string | number | Date>) =>
    (catalog[key] ?? "").replace(/\{(\w+)\}/g, (whole, name: string) =>
      values && name in values ? String(values[name]) : whole,
    );
  return Object.assign(t, { has: (key: string) => key in catalog });
}

const trT = translator(tr.apiErrors);
const enT = translator(en.apiErrors);

describe("apiErrorMessage", () => {
  it("renders a known code in the interface language", () => {
    const body = { error: "Bu isimde bir proje zaten var", code: "PROJECT_NAME_TAKEN" };

    expect(apiErrorMessage(body, enT, "fallback")).toBe(
      "A project with this name already exists. Choose another name.",
    );
    expect(apiErrorMessage(body, trT, "fallback")).toBe(
      "Bu isimde bir proje zaten var. Başka bir isim seçin.",
    );
  });

  it("falls back to the raw server message for an UNKNOWN code", () => {
    // This is what a code shipped ahead of its catalog entry looks like: the
    // user reads the wrong language, but never an empty box.
    expect(
      apiErrorMessage(
        { error: "Sunucu tarafı gerçek", code: "SOME_FUTURE_CODE" },
        enT,
        "fallback",
      ),
    ).toBe("Sunucu tarafı gerçek");
  });

  it("falls back to the raw server message when there is no code", () => {
    expect(apiErrorMessage({ error: "Beklenmeyen hata" }, enT, "fallback")).toBe(
      "Beklenmeyen hata",
    );
  });

  /**
   * #40 review, finding 6. The server says "Şifre en az 12 karakter olmalı";
   * the client used to answer "Şifre çok kısa" and drop the ONE fact that lets
   * the user fix it. The number comes from MIN_PASSWORD_LENGTH, so the two can
   * never disagree.
   */
  it("fills in the minimum length on PASSWORD_TOO_SHORT", () => {
    const body = { error: "Şifre en az 12 karakter olmalı", code: "PASSWORD_TOO_SHORT" };

    for (const t of [enT, trT]) {
      const message = apiErrorMessage(body, t, "fallback");
      expect(message).toContain(String(MIN_PASSWORD_LENGTH));
      expect(message).not.toContain("{min}");
    }
  });

  it("uses the caller's fallback when there is neither code nor message", () => {
    expect(apiErrorMessage({}, enT, "Could not save")).toBe("Could not save");
    expect(apiErrorMessage(null, enT, "Could not save")).toBe("Could not save");
    expect(apiErrorMessage({ error: "   " }, enT, "Could not save")).toBe(
      "Could not save",
    );
  });
});

/* ── The spend cap keeps its four facts at the boundary (#51 review, 3) ──── */

/**
 * These use next-intl's REAL translator rather than the stub above, because
 * what is being tested is precisely that the catalog's ICU renders the numbers
 * the server sent — plurals, dates and all. The stub would happily "pass" a
 * message that dropped every placeholder.
 */
function realTranslator(
  locale: string,
  messages: Record<string, unknown>,
): ApiErrorTranslator {
  // `createTranslator` is typed against the app's own message shape, which
  // these fixtures deliberately are not. The cast keeps the RUNTIME behaviour
  // (real ICU, real locale data) that is the whole point of using it here.
  const t = (
    createTranslator as unknown as (o: {
      locale: string;
      messages: unknown;
      namespace: string;
    }) => (k: string, v?: unknown) => string
  )({ locale, messages, namespace: "apiErrors" });
  return Object.assign(
    (key: string, values?: Record<string, string | number | Date>) =>
      t(key, values),
    { has: (key: string) => key in (messages.apiErrors as object) },
  );
}

/** What the server sends alongside a refusal at the cap. */
const BLOCKED_BODY = {
  error: "sunucu tarafı Türkçe gerçek",
  code: "SPEND_CAP_EXCEEDED",
  details: {
    brand: "Kleinburg",
    cap: "$50.00",
    spent: "$50.12",
    measured: "$41.03",
    estimated: "$9.09",
    // 7, not 3: "$41.03" already contains a "3", so a count of 3 would let
    // a message that dropped the call count pass this assertion anyway.
    estimatedCalls: 7,
    resetsAt: "2026-09-01T00:00:00.000Z",
  },
};

describe("apiErrorMessage: the spend cap refusal", () => {
  for (const [locale, catalog] of [
    ["tr", tr],
    ["en", en],
  ] as const) {
    it(`keeps all four facts in ${locale}`, () => {
      // THE FINDING. `describeRefusal` builds a sentence naming the brand, the
      // cap, the spend and the reset date — and the UI used to answer "this
      // brand hit its cap, see the Spend page", discarding every one of them.
      // An operator cannot act on that without opening a database, which is
      // the exact thing the module's header promises they will not have to do.
      const message = apiErrorMessage(
        BLOCKED_BODY,
        realTranslator(locale, catalog),
        "fallback",
      );

      expect(message).toContain("Kleinburg"); // which brand
      expect(message).toContain("$50.00"); // what the cap is
      expect(message).toContain("$50.12"); // what has been spent
      expect(message).toMatch(locale === "tr" ? /Eylül/ : /September/); // reset

      // And the measured/estimated split, which is the sentence the whole
      // honesty argument rests on.
      expect(message).toContain("$41.03");
      expect(message).toContain("$9.09");
      expect(message).toContain("7");

      // No placeholder may survive to the screen.
      expect(message).not.toMatch(/[{}]/);
    });

    it(`drops the estimate clause when nothing was estimated in ${locale}`, () => {
      const message = apiErrorMessage(
        {
          ...BLOCKED_BODY,
          details: {
            ...BLOCKED_BODY.details,
            measured: "$51.00",
            estimated: "$0.00",
            estimatedCalls: 0,
          },
        },
        realTranslator(locale, catalog),
        "fallback",
      );
      expect(message).not.toContain("$0.00");
      expect(message).not.toMatch(/[{}]/);
    });

    it(`says something DIFFERENT and true for unmeasurable in ${locale}`, () => {
      // The second half of the finding, and the worse half: `unmeasurable`
      // shared this code, so a broken pricing feed told the operator they had
      // hit a cap they might be nowhere near. That is a false statement about
      // a state the server had distinguished carefully.
      const unmeasurable = apiErrorMessage(
        {
          error: "sunucu tarafı Türkçe gerçek",
          code: "SPEND_CAP_UNMEASURABLE",
          details: {
            brand: "Kleinburg",
            cap: "$50.00",
            worstCase: "$90.00",
            unpricedCalls: 4,
            resetsAt: "2026-09-01T00:00:00.000Z",
          },
        },
        realTranslator(locale, catalog),
        "fallback",
      );
      const blocked = apiErrorMessage(
        BLOCKED_BODY,
        realTranslator(locale, catalog),
        "fallback",
      );

      expect(unmeasurable).not.toBe(blocked);
      expect(unmeasurable).toContain("Kleinburg");
      expect(unmeasurable).toContain("$90.00");
      expect(unmeasurable).toContain("$50.00");
      expect(unmeasurable).toContain("4");
      expect(unmeasurable).not.toMatch(/[{}]/);
    });
  }

  it("still degrades to the server's message when the code is unknown", () => {
    // The details bag must not become a way to lose the old guarantee.
    expect(
      apiErrorMessage(
        { error: "Sunucu gerçeği", code: "NOT_A_CODE", details: { a: 1 } },
        enT,
        "fallback",
      ),
    ).toBe("Sunucu gerçeği");
  });
});
