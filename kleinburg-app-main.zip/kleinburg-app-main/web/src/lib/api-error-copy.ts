/**
 * Turns an API error body into a sentence in the INTERFACE language.
 *
 * The server always answers a deliberate failure with
 * `{ error: <turkish message>, code }` (see lib/api-errors.ts). The code is the
 * only thing this module matches on — Turkish text is NEVER string-matched on
 * the client, so wording changes in core/ cannot silently break the UI copy.
 *
 * Degradation is deliberate and one-way:
 *   known code   -> translated copy
 *   unknown code -> the server's own `error` message (today's behaviour)
 *   no code      -> the server's own `error` message
 *   neither      -> the caller's fallback
 * A missing translation therefore costs a user the wrong LANGUAGE, never a
 * blank error box. `messages.test.ts` is what keeps that case theoretical.
 *
 * Pure module: the translator is passed IN, so this is unit-testable without a
 * React tree.
 */

import { MIN_PASSWORD_LENGTH } from "@/core/auth/password-policy";

/**
 * A translator scoped to the `apiErrors` namespace — i.e. what
 * `useTranslations("apiErrors")` returns, including next-intl's `has()`, which
 * is how we tell a known code from one this build's catalog does not carry.
 */
/**
 * The value types next-intl accepts for ICU interpolation. Kept narrow to match
 * its own signature exactly — a wider `unknown` here makes every `t` in the app
 * fail to satisfy this interface.
 */
export type ApiErrorValues = Record<string, string | number | Date>;

export interface ApiErrorTranslator {
  (key: string, values?: ApiErrorValues): string;
  has(key: string): boolean;
}

/**
 * Values available to EVERY `apiErrors.*` message as an ICU placeholder.
 *
 * A code's copy sometimes needs a number the server already knows — the point
 * of the exercise being that "Şifre çok kısa" drops the one fact the user
 * needs, while "Şifre en az 12 karakter olmalı" does not (#40 review,
 * finding 6). The number is read from the policy constant rather than typed
 * into two catalogs, so it cannot drift from what the server enforces.
 *
 * next-intl ignores values a message does not reference, so this bag is passed
 * unconditionally and messages opt in simply by naming a placeholder.
 */
const API_ERROR_VALUES: ApiErrorValues = {
  min: MIN_PASSWORD_LENGTH,
};

export interface ApiErrorBodyLike {
  error?: string;
  code?: string;
  /** Per-failure facts the code's copy interpolates; see lib/api-errors.ts. */
  details?: Record<string, string | number>;
}

/**
 * Detail keys carried as an ISO-8601 instant and rendered as a DATE.
 *
 * An explicit list rather than sniffing every string that parses as a date:
 * the catalog decides what a value means, so the coercion is written down in
 * one place next to the codes that use it. `resetsAt` travels as an instant
 * (not as pre-formatted text) so that "1 Eylül 2026" and "1 September 2026"
 * are both reachable from the same server response — which is the whole reason
 * the facts travel instead of the sentence.
 */
const DATE_DETAIL_KEYS = new Set(["resetsAt"]);

export function apiErrorMessage(
  data: ApiErrorBodyLike | null | undefined,
  t: ApiErrorTranslator,
  fallback: string,
): string {
  const code = data?.code;
  if (code && t.has(code)) {
    return t(code, { ...API_ERROR_VALUES, ...coerceDetails(data?.details) });
  }
  const error = data?.error?.trim();
  return error && error.length > 0 ? error : fallback;
}

/** Details as ICU values, with the known instants turned into Dates. */
function coerceDetails(
  details: Record<string, string | number> | undefined,
): ApiErrorValues {
  if (!details) return {};
  const out: ApiErrorValues = {};
  for (const [key, value] of Object.entries(details)) {
    if (DATE_DETAIL_KEYS.has(key) && typeof value === "string") {
      const parsed = new Date(value);
      // A malformed instant must not put "Invalid Date" in front of a user;
      // the raw string is wrong but readable, which is this module's whole
      // degradation rule applied one level down.
      out[key] = Number.isNaN(parsed.getTime()) ? value : parsed;
      continue;
    }
    out[key] = value;
  }
  return out;
}
