/**
 * Humanizes a failed generation job's raw error into a plain sentence in the
 * user's INTERFACE language, WITHOUT ever hiding the underlying reason (hard
 * rule 5: no silent swallowing, every failure keeps its true cause).
 *
 * ── WHY THE TRANSLATION HAPPENS HERE (T25) ───────────────────────────────
 * The engine's own messages (core/pipeline/inputs.ts precondition throws,
 * core/llm errors) stay Turkish and stay in core/, because core must remain
 * framework-neutral — it may not import next-intl (hard rule 1). This module is
 * the PRESENTATION SEAM: it matches on the engine text the pipeline actually
 * throws and returns copy in the interface language. The raw reason is always
 * the engine's own words; only the friendly line is localized.
 *
 * The contract callers rely on:
 *  - `message` is what the user reads first: non-technical, actionable.
 *  - `reason` is the raw error, rendered smaller/muted underneath. It is
 *    `undefined` ONLY when `message` already IS the raw text (unknown errors) —
 *    so the UI never prints the same sentence twice.
 *  - `stepNumber` is set for the known precondition failures, so the UI can link
 *    straight to the step that must be completed first.
 *
 * Pure module: no react/next, no DB. The translator is passed IN (see
 * JobErrorTranslator) rather than imported, which keeps this unit-testable
 * without a React tree.
 */

export interface JobErrorCopy {
  /** Plain, non-technical sentence shown first. */
  message: string;
  /** The raw underlying reason, when it differs from `message`. */
  reason?: string;
  /** Wizard step that must be completed first (precondition failures only). */
  stepNumber?: number;
}

/**
 * A translator scoped to the `jobError` namespace — i.e. exactly what
 * `useTranslations("jobError")` returns. It is called with the four top-level
 * keys and with `precondition.<key>` for the six precondition failures.
 */
export type JobErrorKey =
  | "fallback"
  | "missingApiKey"
  | "schema"
  | "transient"
  | `precondition.${PreconditionKey}`;

export type JobErrorTranslator = (key: JobErrorKey) => string;

/**
 * The precondition errors gatherVars throws, mapped to the catalog key that
 * says the same thing in the interface language and to the step that produces
 * the missing input. The record keys are the exact throws in
 * core/pipeline/inputs.ts — keep the two in sync.
 *
 * The engine's Turkish is NOT what the user reads any more (an English user saw
 * Turkish here): the friendly line is translated, and the engine's own sentence
 * is kept as `reason` so the true cause is still on screen (hard rule 5).
 * `stepNumber` is what gives the UI a link to the step to complete first.
 */
export type PreconditionKey =
  | "brandContext"
  | "secondaryData"
  | "userInput"
  | "creativeSparks"
  | "contentPillars"
  | "socialPosts";

const PRECONDITIONS: Record<string, { key: PreconditionKey; step: number }> = {
  "Önce marka bağlamı üretilmeli": { key: "brandContext", step: 2 },
  "Önce ikincil veri üretilmeli": { key: "secondaryData", step: 3 },
  "Önce kullanıcı girdisi sağlanmalı": { key: "userInput", step: 4 },
  "Önce yaratıcı kıvılcımlar üretilmeli": { key: "creativeSparks", step: 5 },
  "Önce içerik sütunları üretilmeli": { key: "contentPillars", step: 6 },
  "Önce sosyal medya gönderileri üretilmeli": { key: "socialPosts", step: 7 },
};

export function jobErrorCopy(
  raw: string | null | undefined,
  t: JobErrorTranslator,
): JobErrorCopy {
  const text = (raw ?? "").trim();
  if (text.length === 0) return { message: t("fallback") };

  // 1. Precondition: a recognised, human-readable engine message. The friendly
  //    line is translated; the engine's own sentence is kept as the reason, and
  //    the step that must be completed first is resolved for the UI link.
  const precondition = Object.hasOwn(PRECONDITIONS, text)
    ? PRECONDITIONS[text]
    : undefined;
  if (precondition !== undefined) {
    return {
      message: t(`precondition.${precondition.key}`),
      reason: text,
      stepNumber: precondition.step,
    };
  }

  // 2. Missing API key — a configuration problem, not something the user can
  //    retry their way out of.
  if (text.includes("OPENROUTER_API_KEY")) {
    return { message: t("missingApiKey"), reason: text };
  }

  // 3. Zod/schema violation — the model answered, but not in the shape the step
  //    requires, so nothing was saved (hard rule 4: no partial content).
  if (
    text.includes("beklenen şemaya uymadı") ||
    text.includes("geçerli JSON değil") ||
    text.includes("boş içerik döndürdü")
  ) {
    return { message: t("schema"), reason: text };
  }

  // 4. Transient / network: the retry loop gave up, or the SSE stream dropped.
  if (
    text.includes("denemeden sonra başarısız oldu") ||
    text.includes("Bağlantı") ||
    text.includes("Ağ hatası")
  ) {
    return { message: t("transient"), reason: text };
  }

  // 5. Unknown: show the raw message rather than invent a friendlier lie.
  return { message: text };
}
