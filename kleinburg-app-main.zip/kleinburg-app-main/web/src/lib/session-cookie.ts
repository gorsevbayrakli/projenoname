/**
 * The session cookie name, kept in its own dependency-free module so the edge
 * middleware can import it without dragging in node:crypto / argon2 (which the
 * edge runtime can't bundle). auth-server.ts re-exports it for convenience.
 */
export const SESSION_COOKIE = "kb_session";
