/**
 * The one reader of a step_contents row's `selections.selectedIndices`.
 *
 * This shape is written by every selectable step (secondary_data,
 * creative_sparks, sm_pillars) and read by their server wrappers — step-3,
 * step-5 and step-7 — which each carried a byte-identical private copy of this
 * function. That is exactly the arrangement where one copy gets a fix and the
 * others quietly keep the bug, so there is now one.
 *
 * NOT used by wizard-status: its `selectedCount` answers a different question
 * (how many indices are stored, with no item count to clamp against, since the
 * predicate runs off a row it has not rendered). If you ever give it the item
 * count, fold it in here.
 *
 * `itemCount` is not optional and the clamp is not cosmetic: content that
 * shrank (a regenerate producing fewer items) leaves stored indices pointing
 * past the end. Unclamped they would inflate the "N / M seçili" counter, mark
 * cards that do not exist, and — on the steps whose "Devam →" reads the
 * seeded selection — unlock a step with nothing visibly checked.
 *
 * Anything that is not an in-range integer is dropped rather than coerced;
 * malformed stored data yields [], never a guess.
 */
export function extractSelectedIndices(
  selections: unknown,
  itemCount: number,
): number[] {
  if (
    selections &&
    typeof selections === "object" &&
    "selectedIndices" in selections &&
    Array.isArray((selections as { selectedIndices: unknown }).selectedIndices)
  ) {
    return (selections as { selectedIndices: unknown[] }).selectedIndices.filter(
      (i): i is number =>
        Number.isInteger(i) && (i as number) >= 0 && (i as number) < itemCount,
    );
  }
  return [];
}
