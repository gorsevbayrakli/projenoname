import type { Platform } from "@/core/platforms";
import type { SmPillars, SmPosts } from "@/core/pipeline/schemas";

/**
 * The demo account and the content behind it — everything `npm run seed demo`
 * writes, as plain data.
 *
 * ── WHY THIS EXISTS ──────────────────────────────────────────────────────
 * The local database had ZERO users, so nobody could sign in, and therefore
 * nobody could walk the wizard locally. Production became the test environment:
 * a step-7 UX problem was found by the product owner in a live run, and a UI
 * change shipped visually unverified because there was no way to log in. This
 * data closes that: one command and the whole 9-step wizard is walkable, with
 * NO MODEL CALL anywhere in the path.
 *
 * ── WHY IT IS DATA, IN ITS OWN MODULE ────────────────────────────────────
 * Because it has to be TESTED. These fixtures are not illustrations; the app
 * loads them and applies the same schemas and count rules it applies to a real
 * model run. Fixtures that violate those rules would give a local environment
 * that disagrees with production — the very problem the command is meant to
 * fix. `demo-seed.test.ts` therefore parses them through the real Zod schemas
 * and checks them against the real, IMPORTED constants (PILLAR_TOTAL, the
 * per-category floor, POSTS_PER_PILLAR, MIN_BRAND_CONTEXT_CHARS), so a change
 * to any of those turns this red rather than leaving stale data behind.
 *
 * ── THE BRAND IS INVENTED ────────────────────────────────────────────────
 * "Demo Marka" is a made-up subscription filter-coffee service. Deliberately
 * not a client's real brand material: this file is public in the repository and
 * gets pasted into screenshots. Turkish, because the product's users are, and
 * short, because it is here to be looked at rather than read.
 */

/** The demo account's username. */
export const DEMO_USERNAME = "demo";

/**
 * The demo account's password — WRITTEN DOWN, IN PUBLIC, ON PURPOSE.
 *
 * `scripts/seed.ts` goes out of its way to keep passwords out of argv and shell
 * history, because that is how the first production admin credential leaked.
 * This constant is the opposite of that and it is not an exception to the
 * reasoning — it is only acceptable because `core/db/local-only.ts` makes the
 * account unreachable outside a local database. Read that module before
 * touching this line. If you need an account on a real database,
 * `seed create-admin` prompts for a password nobody else knows.
 *
 * Length satisfies MIN_PASSWORD_LENGTH on purpose, even though login does not
 * enforce the policy (only change-password and the admin panel do, which is
 * correct — a policy change must not lock out an existing account). A seeded
 * example that violated the app's own rule would be a trap: it works today
 * precisely because of a gap, so the day login starts checking, the documented
 * demo login breaks and the failure looks like a bug in the seed.
 *
 * The account is deliberately NOT flagged `must_change_password`: being asked
 * to rotate a throwaway local password on every fresh seed is friction with
 * nothing on the other side of it.
 */
export const DEMO_PASSWORD = "demo12345678";

/** The brand the demo user is a member of. */
export const DEMO_BRAND_NAME = "Demo Marka";

/** The project under that brand. */
export const DEMO_PROJECT_NAME = "Demo Kampanya";

/**
 * The platforms the demo project generates for.
 *
 * TWO, not one and not all four: one platform cannot show the per-platform
 * split that steps 8 and 9 are built around, and four makes the seeded post set
 * large enough to stop being readable. Instagram and LinkedIn also differ most
 * in register, so a copy change that reads well on one and badly on the other
 * is visible locally.
 */
export const DEMO_PLATFORMS: Platform[] = ["instagram", "linkedin"];

/**
 * Posts per platform. These are the numbers step 9 measures the calendar
 * against, and the seeded posts meet them EXACTLY — a freshly seeded project
 * must not open step 9 already reporting a shortfall, or the shortfall warning
 * stops meaning anything. Well under the per-platform defaults (16/10) to keep
 * the seeded set small.
 */
export const DEMO_POST_COUNTS: Record<string, number> = {
  instagram: 6,
  linkedin: 4,
};

/**
 * Step 1's document. A real upload is the thing to exercise by hand (the pptx
 * extractor is where this week's Node-version bug lived), but with no documents
 * row at all the wizard forward-locks at step 1 and nothing downstream is
 * reachable — so the seed provides one and leaves the upload path free to be
 * tested on top of it.
 */
export const DEMO_DOCUMENT = {
  filename: "demo-marka-brief.pdf",
  kind: "pdf" as const,
  extractedText:
    "Demo Marka, şehirli ofis çalışanlarına aylık abonelikle taze kavrulmuş filtre kahve gönderen bir servistir. " +
    "Kahve, gönderimden en fazla üç gün önce kavrulur. Hedef kitle: 25-40 yaş, büyük şehirlerde çalışan, " +
    "kahveyi bir rutin olarak gören, üçüncü nesil kahvecilere gidecek vakti olmayan profesyoneller. " +
    "Ton: sakin, bilgili, öğretici ama kibirli değil. Rakipler: market rafı markaları ve kahve dükkânı abonelikleri.",
};

/**
 * Step 2's brand context. Must clear MIN_BRAND_CONTEXT_CHARS (200) or the
 * wizard forward-locks at step 2 — asserted in the test rather than eyeballed.
 */
export const DEMO_BRAND_CONTEXT = [
  "**Marka Özü:** Demo Marka, iyi kahveyi bir ayrıcalık olmaktan çıkarıp bir rutin haline getirir.",
  "",
  "**Hedef Kitle:** 25-40 yaş, büyük şehirlerde ofiste ya da hibrit çalışan profesyoneller. Kahveyi seviyorlar ama seçim yapmak için ne vakitleri ne de sözlükleri var.",
  "",
  "**Ton:** Sakin, bilgili, öğretici. Kahve jargonunu açıklar, jargonla övünmez.",
  "",
  "**Fark:** Kavurma tarihi paketin üstünde yazar; gönderimden en fazla üç gün önce kavrulur.",
  "",
  "**Rakipler:** Market rafı markaları (ucuz, bayat) ve kahve dükkânı abonelikleri (pahalı, ritüel gerektirir).",
  "",
  "**Engel:** Kitle, evde iyi kahve yapmanın zor ve ekipman isteyen bir iş olduğuna inanıyor.",
].join("\n");

/** Step 3's researched entries. Sources are invented, like the brand. */
export const DEMO_SECONDARY_DATA = [
  {
    title: "Evde kahve tüketimi hibrit çalışmayla birlikte arttı",
    description:
      "Ofise gitmeyen günlerde kahve tüketimi eve kaydı; kitle aynı kaliteyi evde arıyor ama nasıl elde edeceğini bilmiyor.",
    sources: [
      {
        url: "https://example.com/demo/hibrit-calisma-kahve",
        title: "Hibrit çalışma ve ev içi kahve tüketimi (demo kaynak)",
      },
    ],
  },
  {
    title: "Kavurma tarihi, satın alma kararında son kullanma tarihinden önemli",
    description:
      "Kahve alıcıları tazeliği giderek kavurma tarihinden okuyor; raf ömrü etiketi güven vermiyor.",
    sources: [
      {
        url: "https://example.com/demo/kavurma-tarihi",
        title: "Tazelik sinyalleri üzerine tüketici anketi (demo kaynak)",
      },
    ],
  },
  {
    title: "Abonelik yorgunluğu gerçek ama kahve istisna",
    description:
      "Tüketiciler abonelik sayısını azaltıyor; düzenli tükettikleri sarf malzemelerinde ise aboneliği sürdürüyor.",
    sources: [
      {
        url: "https://example.com/demo/abonelik-yorgunlugu",
        title: "Abonelik iptal nedenleri (demo kaynak)",
      },
    ],
  },
  {
    title: "Ekipman algısı en büyük giriş engeli",
    description:
      "Evde kahve yapmayı düşünenlerin çoğu pahalı ekipman gerektiğine inanıyor; asıl fark öğütme ve tazelikten geliyor.",
    sources: [
      {
        url: "https://example.com/demo/ekipman-algisi",
        title: "Ev kahvesi giriş engelleri (demo kaynak)",
      },
    ],
  },
];

/** Step 5's insight bullets. */
export const DEMO_CREATIVE_SPARKS = [
  {
    title: "Kimse kahve uzmanı olmak istemiyor",
    description:
      "Kitle iyi kahve istiyor, hobi istemiyor. Uzmanlık vaadi satmıyor; zahmetsizlik satıyor.",
  },
  {
    title: "Sabahın ilk on dakikası bir ritüel değil, bir pazarlık",
    description:
      "Kahve, güne başlamakla uyumaya devam etmek arasındaki pazarlığın parçası. Reklamdaki huzurlu sabah sahnesi yalan.",
  },
  {
    title: "Tazelik görünmez, o yüzden kanıt ister",
    description:
      "Taze kahveyi tatmadan anlamak zor. Kavurma tarihi, markanın tek elle tutulur kanıtı.",
  },
  {
    title: "Kötü kahve bir alışkanlık, tercih değil",
    description:
      "İnsanlar kötü kahveyi sevmiyor; sadece daha iyisini denemenin zahmetli olduğunu sanıyor.",
  },
];

/** Step 4's user input, verbatim as a user would type it. */
export const DEMO_USER_INPUT =
  "Bu dönem odak: yeni abone kazanımı. Kavurma tarihi vaadini öne çıkaralım. " +
  "Ekipman gerektirmediğini anlatmak önemli. İndirim dili kullanmayalım.";

/**
 * Step 7's pillars. Exactly PILLAR_TOTAL (21), every category above the floor
 * of 3, and DELIBERATELY UNEQUAL (5/6/10).
 *
 * The unequal split is the fixture doing real work: the 7/7/7 quota was removed
 * on 2026-07-21 because it produced manufactured copy, and an equal fixture
 * would let that quota be re-imposed without a test noticing. A brand whose
 * strength is explanation genuinely has more INFORMATIONAL to say than
 * INSPIRATIONAL, which is exactly what the new rule is for.
 *
 * ORDER IS LOAD-BEARING: DEMO_PILLAR_SELECTED_INDICES indexes into this array.
 */
export const DEMO_PILLARS: SmPillars["pillars"] = [
  // ── INSPIRATIONAL (5) ────────────────────────────────────────────────
  {
    category: "INSPIRATIONAL",
    title: "Sıradan Sabahın Hakkı",
    topicBlend: "Günlük rutin + küçük kalite yükseltmesi",
    creativeSpark: "Kimse kahve uzmanı olmak istemiyor",
    hook: "Sabahını değiştirmek için hayatını değiştirmen gerekmiyor.",
    contentBrief:
      "Küçük bir iyileştirmenin bütün günü nasıl taşıdığını anlatan sakin bir hikâye.",
  },
  {
    category: "INSPIRATIONAL",
    title: "Zahmetsiz İyi",
    topicBlend: "Kalite + erişilebilirlik",
    creativeSpark: "Kitle hobi değil sonuç istiyor",
    hook: "İyi kahve bir yetenek değil, bir tedarik meselesi.",
    contentBrief:
      "Uzmanlık vaadini reddeden, sonuca odaklanan manifesto tonlu içerik.",
  },
  {
    category: "INSPIRATIONAL",
    title: "Üç Gün Önce",
    topicBlend: "Tazelik vaadi + üretim şeffaflığı",
    creativeSpark: "Tazelik görünmez, kanıt ister",
    hook: "Fincanındaki kahve geçen hafta hâlâ çekirdekti.",
    contentBrief:
      "Kavurma tarihinden fincana kadar geçen süreyi görünür kılan içerik.",
  },
  {
    category: "INSPIRATIONAL",
    title: "Kendi Mutfağında",
    topicBlend: "Ev + yetkinlik hissi",
    creativeSpark: "Kötü kahve bir alışkanlık, tercih değil",
    hook: "En iyi kahveci senin mutfağında olabilir.",
    contentBrief: "Evde yapmanın kısıtlama değil kontrol olduğunu anlatan içerik.",
  },
  {
    category: "INSPIRATIONAL",
    title: "Acele Etmeyen Bir Şey",
    topicBlend: "Yavaşlık + günlük tempo",
    creativeSpark: "Sabahın ilk on dakikası bir pazarlık",
    hook: "Günde dört dakika, hiçbir şeyin seni beklemediği bir an.",
    contentBrief: "Demleme süresini bir mola olarak çerçeveleyen içerik.",
  },

  // ── ENTERTAINING (6) ─────────────────────────────────────────────────
  {
    category: "ENTERTAINING",
    title: "Ofis Kahvesi İtirafları",
    topicBlend: "Ofis mizahı + ortak deneyim",
    creativeSpark: "Kötü kahve bir alışkanlık",
    hook: "Ofis makinesinin o kokusunu hepimiz tanıyoruz.",
    contentBrief: "Ortak kötü kahve deneyimi üzerine kısa, tanıdık mizah.",
  },
  {
    category: "ENTERTAINING",
    title: "Kahve Sözlüğü Çeviri Servisi",
    topicBlend: "Jargon + mizah",
    creativeSpark: "Kitle jargondan korkuyor",
    hook: "\"Meyvemsi asidite\" ne demek, düz Türkçesiyle.",
    contentBrief: "Kahve jargonunu güldürerek çeviren kısa format.",
  },
  {
    category: "ENTERTAINING",
    title: "Kahvesiz Geçen İlk Yarım Saat",
    topicBlend: "Günlük hayat + abartı",
    creativeSpark: "Sabah bir pazarlıktır",
    hook: "Kahveden önceki ben ile sonraki ben aynı kişi değil.",
    contentBrief: "Öncesi/sonrası kurgusuyla abartılı ama tanıdık mizah.",
  },
  {
    category: "ENTERTAINING",
    title: "Yanlış Yaptığımız Şeyler",
    topicBlend: "Hata mizahı + hafif öğreti",
    creativeSpark: "Ekipman algısı yanlış yerde",
    hook: "Yıllardır kaynar suyla kahve yakıyoruz.",
    contentBrief: "Yaygın hataları utandırmadan, gülerek gösteren içerik.",
  },
  {
    category: "ENTERTAINING",
    title: "Paket Açma Ama Dürüst",
    topicBlend: "Unboxing + samimiyet",
    creativeSpark: "Tazelik kanıt ister",
    hook: "Paketi açınca ilk bakılacak yer: tarih.",
    contentBrief: "Abartısız, tek çekimde paket açma; odak kavurma tarihinde.",
  },
  {
    category: "ENTERTAINING",
    title: "Fincan Kimin",
    topicBlend: "Ofis kültürü + oyun",
    creativeSpark: "Ortak deneyim bağ kurar",
    hook: "Mutfaktaki o sahipsiz fincanın hikâyesi.",
    contentBrief: "Takipçiyi tahmine davet eden hafif, oyunlu içerik.",
  },

  // ── INFORMATIONAL (10) ───────────────────────────────────────────────
  {
    category: "INFORMATIONAL",
    title: "Kavurma Tarihi Nasıl Okunur",
    topicBlend: "Tazelik + etiket okuma",
    creativeSpark: "Tazelik görünmez, kanıt ister",
    hook: "Paketteki tek önemli tarih, son kullanma tarihi değil.",
    contentBrief: "Etiketteki tarihleri karşılaştıran net, öğretici içerik.",
  },
  {
    category: "INFORMATIONAL",
    title: "Öğütme Kalınlığı Rehberi",
    topicBlend: "Teknik + pratik",
    creativeSpark: "Küçük değişken, büyük fark",
    hook: "Kahven acıysa sorun çekirdekte olmayabilir.",
    contentBrief: "Demleme yöntemine göre öğütme kalınlığını gösteren rehber.",
  },
  {
    category: "INFORMATIONAL",
    title: "Su Sıcaklığı Meselesi",
    topicBlend: "Teknik + yaygın hata",
    creativeSpark: "Ekipman değil, yöntem",
    hook: "Kaynar su kahveyi yakar.",
    contentBrief: "Termometresiz sıcaklık ayarlamayı anlatan kısa içerik.",
  },
  {
    category: "INFORMATIONAL",
    title: "Ekipmansız Başlangıç",
    topicBlend: "Giriş engeli + maliyet",
    creativeSpark: "Ekipman algısı en büyük engel",
    hook: "İyi kahve için gereken en pahalı şey nedir? Hiçbiri.",
    contentBrief: "Minimum ekipmanla başlamayı gösteren pratik içerik.",
  },
  {
    category: "INFORMATIONAL",
    title: "Saklama Koşulları",
    topicBlend: "Tazelik + günlük pratik",
    creativeSpark: "Tazelik kolay kaybedilir",
    hook: "Buzdolabı kahvenin dostu değil.",
    contentBrief: "Doğru ve yanlış saklama yöntemlerini karşılaştıran içerik.",
  },
  {
    category: "INFORMATIONAL",
    title: "Kahve Oranı Hesabı",
    topicBlend: "Ölçü + tekrarlanabilirlik",
    creativeSpark: "Tutarlılık tesadüf değildir",
    hook: "Her seferinde aynı tadı yakalamanın tek yolu ölçmek.",
    contentBrief: "Basit su-kahve oranını tartısız anlatan içerik.",
  },
  {
    category: "INFORMATIONAL",
    title: "Tek Yöre ve Harman Farkı",
    topicBlend: "Ürün bilgisi + seçim",
    creativeSpark: "Kitle seçim yapmak için sözlük istiyor",
    hook: "Hangisini seçmelisin: tek yöre mi, harman mı?",
    contentBrief: "İki kategoriyi kısa ve yargısız karşılaştıran içerik.",
  },
  {
    category: "INFORMATIONAL",
    title: "Abonelik Sıklığı Nasıl Seçilir",
    topicBlend: "Ürün + tüketim alışkanlığı",
    creativeSpark: "Abonelik yorgunluğu gerçek",
    hook: "Ayda kaç paket? Günlük fincan sayın söylüyor.",
    contentBrief: "Tüketime göre abonelik sıklığı seçmeyi anlatan içerik.",
  },
  {
    category: "INFORMATIONAL",
    title: "Kafein Ne Zaman Biter",
    topicBlend: "Sağlık + günlük plan",
    creativeSpark: "Kahve günü şekillendirir",
    hook: "Öğleden sonraki kahve, gece uykunu hâlâ etkiliyor.",
    contentBrief: "Kafeinin gün içindeki seyrini anlatan bilgilendirici içerik.",
  },
  {
    category: "INFORMATIONAL",
    title: "Filtre Kâğıdı Farkı",
    topicBlend: "Teknik detay + tat",
    creativeSpark: "Küçük değişken, büyük fark",
    hook: "Filtre kâğıdını ıslatmak gerçekten fark yaratıyor mu?",
    contentBrief: "Küçük bir adımın tada etkisini gösteren kısa deney içeriği.",
  },
];

/**
 * The pillar selection stored on step 7 — what the step opens with ALREADY
 * CHECKED since 2026-07-21.
 *
 * A STRICT SUBSET (10 of 21), and that is the point of the fixture. Selecting
 * everything would render identically to having no selection rule at all and
 * could not show the pre-checked state the product owner went to step 7 to
 * look at. Ten also happens to be what the seeded posts need: posts = selected
 * pillars x POSTS_PER_PILLAR.
 *
 * Indexes into DEMO_PILLARS, spread across all three categories.
 */
export const DEMO_PILLAR_SELECTED_INDICES = [0, 2, 5, 6, 7, 11, 12, 14, 16, 18];

/**
 * Step 8's posts, one per selected pillar.
 *
 * Each `theme` BEGINS WITH ITS PILLAR'S TITLE, because build-calendar.ts
 * resolves a post to its pillar by finding the title in the theme's head. A
 * theme that resolves to nothing lands in `unresolvedPillars`, and a freshly
 * seeded project reporting drift would make that warning meaningless.
 *
 * Split 6 Instagram / 4 LinkedIn to match DEMO_POST_COUNTS exactly, so step 9
 * opens with a complete calendar and no shortfall.
 */
export const DEMO_POSTS: SmPosts["posts"] = [
  // ── Instagram (6) ────────────────────────────────────────────────────
  {
    platform: "instagram",
    theme: "Sıradan Sabahın Hakkı — Reel: tek çekim sabah rutini",
    hook: "Sabahını değiştirmek için hayatını değiştirmen gerekmiyor.",
    caption:
      "Dört dakika. Su ısınırken geçen o kısa boşluk, günün geri kalanına verdiğin tek moladır.",
    cta: "Sabah rutinini yorumlarda anlat.",
    hashtags: ["#filtrekahve", "#sabahrutini", "#demomarka"],
  },
  {
    platform: "instagram",
    theme: "Üç Gün Önce — Carousel: kavurmadan fincana",
    hook: "Fincanındaki kahve geçen hafta hâlâ çekirdekti.",
    caption:
      "Kavuruyoruz, üç gün içinde yola çıkıyor. Tazelik bir iddia değil, pakette yazan bir tarih.",
    cta: "Paketindeki tarihe bak.",
    hashtags: ["#tazekahve", "#kavurmatarihi", "#demomarka"],
  },
  {
    platform: "instagram",
    theme: "Ofis Kahvesi İtirafları — Reel: ortak deneyim mizahı",
    hook: "Ofis makinesinin o kokusunu hepimiz tanıyoruz.",
    caption:
      "Kimse o kahveyi sevmiyor. Herkes içiyor. Alışkanlık, tercihten daha güçlü.",
    cta: "Ofisindeki kahveyi etiketle.",
    hashtags: ["#ofishayati", "#kahvemolasi", "#demomarka"],
  },
  {
    platform: "instagram",
    theme: "Kahve Sözlüğü Çeviri Servisi — Carousel: jargon sözlüğü",
    hook: "\"Meyvemsi asidite\" ne demek, düz Türkçesiyle.",
    caption:
      "Kahve tarifleri bazen başka bir dilde yazılmış gibi. Üç terim, üç cümlelik karşılığı.",
    cta: "Anlamadığın terimi yaz, çevirelim.",
    hashtags: ["#kahvesozlugu", "#kahvebilgisi", "#demomarka"],
  },
  {
    platform: "instagram",
    theme: "Kahvesiz Geçen İlk Yarım Saat — Reel: öncesi ve sonrası",
    hook: "Kahveden önceki ben ile sonraki ben aynı kişi değil.",
    caption: "Yarım saat. Aradaki tek fark bir fincan.",
    cta: "Kendini hangisinde gördün?",
    hashtags: ["#sabahmodu", "#kahvesiz", "#demomarka"],
  },
  {
    platform: "instagram",
    theme: "Kavurma Tarihi Nasıl Okunur — Carousel: etiket rehberi",
    hook: "Paketteki tek önemli tarih, son kullanma tarihi değil.",
    caption:
      "Son kullanma tarihi kahvenin bozulmadığını söyler. Kavurma tarihi ise hâlâ iyi olduğunu.",
    cta: "Dolabındaki paketi kontrol et.",
    hashtags: ["#kavurmatarihi", "#kahvebilgisi", "#demomarka"],
  },

  // ── LinkedIn (4) ─────────────────────────────────────────────────────
  {
    platform: "linkedin",
    theme: "Öğütme Kalınlığı Rehberi — Document post: yöntem tablosu",
    hook: "Kahven acıysa sorun çekirdekte olmayabilir.",
    caption:
      "Aynı çekirdek, iki farklı öğütme, iki farklı içecek. Yöntemine göre kalınlık seçmek, kahve değiştirmekten daha etkili.",
    cta: "Hangi yöntemle demliyorsun?",
    hashtags: ["#kahve", "#filtrekahve"],
  },
  {
    platform: "linkedin",
    theme: "Ekipmansız Başlangıç — Text post: giriş engeli",
    hook: "İyi kahve için gereken en pahalı şey nedir? Hiçbiri.",
    caption:
      "Evde iyi kahvenin önündeki engel ekipman değil, ekipman gerektiğine dair inanç. Taze çekirdek ve doğru su sıcaklığı, çoğu pahalı makineden fazlasını yapar.",
    cta: "Neyle başladığını yaz.",
    hashtags: ["#kahve", "#evdekahve"],
  },
  {
    platform: "linkedin",
    theme: "Kahve Oranı Hesabı — Document post: basit ölçü",
    hook: "Her seferinde aynı tadı yakalamanın tek yolu ölçmek.",
    caption:
      "Tutarlılık yetenek değil, ölçü meselesi. Tartın yoksa bile çalışan tek bir oran var; onu bir kez öğrenmek yeter.",
    cta: "Kendi oranını paylaş.",
    hashtags: ["#kahve", "#demleme"],
  },
  {
    platform: "linkedin",
    theme: "Abonelik Sıklığı Nasıl Seçilir — Text post: tüketim hesabı",
    hook: "Ayda kaç paket? Günlük fincan sayın söylüyor.",
    caption:
      "Abonelik yorgunluğu gerçek, ama düzenli tükettiğin bir şeyde abonelik işe yarıyor. Doğru sıklık, elinde hiç bayat kahve kalmayan sıklıktır.",
    cta: "Günde kaç fincan içiyorsun?",
    hashtags: ["#abonelik", "#kahve"],
  },
];
