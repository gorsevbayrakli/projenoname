import { AttemptLimiter } from "@/core/auth/attempt-limiter";

/**
 * The ceiling on e-mail-existence probing through `/api/account/profile`
 * (#43 review, finding 4).
 *
 * ── THE ORACLE ───────────────────────────────────────────────────────────
 * `updateAccountProfile` pre-checks the address and answers 409 `EMAIL_TAKEN`
 * when another account holds it. That is a yes/no on somebody else's contact
 * details, and the endpoint had no limiter at all — unlike `/api/auth/login`
 * and `/api/auth/change-password`, which both carry one. Any authenticated
 * user could walk a list of addresses and learn which ones belong to accounts
 * here, unbounded, on the one endpoint in T43 that writes on every call.
 *
 * It leaks no brand and no project, so it is not a brand-isolation problem.
 * It is still unbounded confirmation of third-party PII, and bounded is
 * cheap.
 *
 * ── WHY ONLY THE 409 IS CHARGED ──────────────────────────────────────────
 * A 200 means the address was FREE, and the caller had to actually take it to
 * find out — their own row now holds it, so the next probe needs a different
 * address and the answer confirms nothing about anybody else. The 409 is the
 * informative half: it names an address as belonging to another account
 * without changing anything. So the counter charges conflicts only, which also
 * means a user editing their own profile repeatedly never approaches it.
 *
 * ── SCOPE ────────────────────────────────────────────────────────────────
 * Keyed by the SESSION's user id, never by anything in the body: the body is
 * attacker-controlled and could otherwise be varied to dodge the counter.
 *
 * In-process and in-memory, exactly like the other two limiters and for the
 * same reason — render.yaml pins `numInstances: 1`. The day that becomes two,
 * all three have to move to shared storage or an attacker simply spreads the
 * probes across instances.
 *
 * It lives in its own module rather than inside the route file because a Next
 * route module may only export HTTP verbs, and the reset below has to be
 * reachable from a test.
 */

/** Conflicts one account may provoke per window. */
export const EMAIL_PROBE_MAX_ATTEMPTS = 10;

/** The window. Matches the change-password limiter, for one story to tell. */
export const EMAIL_PROBE_WINDOW_MS = 15 * 60 * 1000;

let limiter = new AttemptLimiter({
  maxAttempts: EMAIL_PROBE_MAX_ATTEMPTS,
  windowMs: EMAIL_PROBE_WINDOW_MS,
});

export function emailProbeLimiter(): AttemptLimiter {
  return limiter;
}

/**
 * TEST-ONLY. Starts a fresh window.
 *
 * A suite that drives more than `EMAIL_PROBE_MAX_ATTEMPTS` conflicts would
 * otherwise leave the counter hot for every later test in the process, making
 * them order-dependent. Never call this from application code: it would hand a
 * caller the cap.
 */
export function resetEmailProbeLimiter(): void {
  limiter = new AttemptLimiter({
    maxAttempts: EMAIL_PROBE_MAX_ATTEMPTS,
    windowMs: EMAIL_PROBE_WINDOW_MS,
  });
}
