/**
 * Relative-time formatter for the project cards. No DB, no locale libraries.
 *
 * Returns short human strings for recent past instants, in the user's INTERFACE
 * language (T25):
 *   < 1 min   -> "az önce"        / "just now"
 *   < 1 hour  -> "N dakika önce"  / "N minutes ago"
 *   < 1 day   -> "N saat önce"    / "N hours ago"
 *   < 7 days  -> "N gün önce"     / "N days ago"
 *   otherwise -> an absolute date string ("18.07.2026")
 *
 * Future dates (date after `now`) also fall back to the absolute date string,
 * since "N ... ago" would be nonsensical.
 *
 * Pure module: like lib/job-error-copy.ts, the translator is passed IN rather
 * than imported, so this stays unit-testable without a React tree and free of
 * any next-intl import.
 *
 * The ABSOLUTE date deliberately stays day.month.year in BOTH locales. It is a
 * compact, unambiguous stamp on a card, and switching to a locale-aware format
 * would silently turn "07.08.2026" into a different day for an English reader
 * mid-session — worse than one consistent format in an internal tool.
 *
 * The ZONE that day is read in is a separate question from the format, and one
 * the header used to leave unanswered: it is `APP_TIMEZONE`. See `absoluteDate`
 * and #66.
 */

import { APP_TIMEZONE } from "@/core/i18n/timezone";

const MINUTE_MS = 60 * 1000;
const HOUR_MS = 60 * MINUTE_MS;
const DAY_MS = 24 * HOUR_MS;
const WEEK_MS = 7 * DAY_MS;

/**
 * A translator scoped to the `relativeTime` namespace — i.e. exactly what
 * `useTranslations("relativeTime")` / `getTranslations("relativeTime")` return.
 */
export type RelativeTimeTranslator = (
  key: "justNow" | "minutes" | "hours" | "days",
  values?: { n: number },
) => string;

/**
 * The day is read on the Istanbul calendar, not the process's (#66).
 *
 * `getDate()`/`getMonth()`/`getFullYear()` read the Node process zone, and
 * every caller of `relativeTime` is a server component, so on Render — which
 * sets no TZ — the day was read in UTC. A project edited at 01:30 Istanbul
 * (22:30Z the day before) was stamped with yesterday's date on the projects
 * list, and the same off-by-one hit the account page's member-since date.
 * Anything between local midnight and 03:00 was affected.
 *
 * `APP_TIMEZONE` rather than a local constant: it is the same zone the spend
 * cap draws its month boundary in, and one application should not have two
 * answers to "what day is it". The FORMAT is still assembled by hand from
 * parts, because the day.month.year order above is deliberate in both locales
 * and must not follow the locale.
 */
const ABSOLUTE_DATE_PARTS = new Intl.DateTimeFormat("en-GB", {
  timeZone: APP_TIMEZONE,
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
});

/** Absolute date fallback, e.g. "18.07.2026" (day.month.year). */
function absoluteDate(date: Date): string {
  const parts = ABSOLUTE_DATE_PARTS.formatToParts(date);
  const part = (type: Intl.DateTimeFormatPartTypes) =>
    parts.find((p) => p.type === type)?.value ?? "";
  return `${part("day")}.${part("month")}.${part("year")}`;
}

export function relativeTime(
  date: Date,
  t: RelativeTimeTranslator,
  now: Date = new Date(),
): string {
  const diffMs = now.getTime() - date.getTime();

  // Future or older than a week -> absolute date.
  if (diffMs < 0 || diffMs >= WEEK_MS) {
    return absoluteDate(date);
  }

  if (diffMs < MINUTE_MS) {
    return t("justNow");
  }

  if (diffMs < HOUR_MS) {
    return t("minutes", { n: Math.floor(diffMs / MINUTE_MS) });
  }

  if (diffMs < DAY_MS) {
    return t("hours", { n: Math.floor(diffMs / HOUR_MS) });
  }

  return t("days", { n: Math.floor(diffMs / DAY_MS) });
}
