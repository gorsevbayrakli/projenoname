import { cookies } from "next/headers";
import type { NextResponse } from "next/server";

import { isSuperAdmin } from "@/core/auth/roles";
import { validateSession } from "@/core/auth/session";
import type { User } from "@/core/db/schema";
import { apiError, type ApiErrorBody } from "./api-errors";
import { SESSION_COOKIE } from "./session-cookie";

// Re-export so existing importers (route handlers) keep a single import site.
export { SESSION_COOKIE };

/** Cookie lifetime in seconds (7 days), matching the absolute session cap. */
const COOKIE_MAX_AGE = 7 * 24 * 60 * 60;

/**
 * A cookie store that can be mutated. In Next 15 route handlers the object
 * returned by `await cookies()` supports set/delete; this is the minimal shape
 * we depend on so the helpers stay easy to test.
 */
type MutableCookieStore = {
  set: (
    name: string,
    value: string,
    options?: Record<string, unknown>,
  ) => void;
  delete: (name: string) => void;
};

/** Shared cookie flags. Secure is only forced in production (localhost is http). */
function baseCookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    path: "/",
    secure: process.env.NODE_ENV === "production",
  };
}

/**
 * Read the session cookie, validate it against the database, and return the
 * current user (or null). Used by protected pages and route handlers.
 */
export async function getCurrentUser(): Promise<User | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const result = await validateSession(token);
  return result?.user ?? null;
}

/**
 * The standard API guard (T40). Returns either the user or the response to
 * send back — so a route handler is one `if ("response" in gate)` away from
 * being correctly authorized.
 *
 * It enforces TWO things:
 *  - a valid session (401 UNAUTHENTICATED);
 *  - that the account is not still sitting on an admin-set temporary password
 *    (403 PASSWORD_CHANGE_REQUIRED).
 *
 * The second check is what makes the forced change real rather than cosmetic.
 * Redirecting the browser would otherwise leave every JSON endpoint reachable
 * with a password a second person knows, and "the UI sends you elsewhere" is
 * not authorization.
 *
 * The change-password endpoint itself must NOT use this (it would refuse the
 * very request that fixes the condition) and calls `getCurrentUser` directly.
 */
export async function requireApiUser(): Promise<
  { user: User } | { response: NextResponse<ApiErrorBody> }
> {
  const user = await getCurrentUser();
  if (!user) {
    return { response: apiError("Oturum gerekli", "UNAUTHENTICATED", 401) };
  }
  if (user.mustChangePassword) {
    return {
      response: apiError(
        "Devam etmeden önce şifrenizi değiştirmelisiniz",
        "PASSWORD_CHANGE_REQUIRED",
        403,
      ),
    };
  }
  return { user };
}

/**
 * As `requireApiUser`, but additionally requires the super admin role
 * (403 ADMIN_REQUIRED).
 *
 * The admin service guards itself too — this is not the only line of defence,
 * it is the one that stops an unauthorized request before it reaches a query.
 */
export async function requireApiAdmin(): Promise<
  { user: User } | { response: NextResponse<ApiErrorBody> }
> {
  const gate = await requireApiUser();
  if ("response" in gate) return gate;
  if (!isSuperAdmin(gate.user)) {
    return {
      response: apiError(
        "Bu işlem için yönetici yetkisi gerekiyor",
        "ADMIN_REQUIRED",
        403,
      ),
    };
  }
  return gate;
}

/** Write the session cookie onto a mutable cookie store (route handlers). */
export function setSessionCookie(
  store: MutableCookieStore,
  token: string,
  expiresAt: Date,
): void {
  // maxAge governs cookie lifetime; the server slides/expires the session row
  // independently. `expiresAt` is intentionally not set as the cookie `expires`
  // to avoid a misleading second lifetime source (Max-Age wins anyway).
  void expiresAt;
  store.set(SESSION_COOKIE, token, {
    ...baseCookieOptions(),
    maxAge: COOKIE_MAX_AGE,
  });
}

/** Clear the session cookie on a mutable cookie store (logout). */
export function clearSessionCookie(store: MutableCookieStore): void {
  store.set(SESSION_COOKIE, "", {
    ...baseCookieOptions(),
    maxAge: 0,
  });
}
