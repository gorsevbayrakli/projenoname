/**
 * CSV / XLSX export for the content calendar (wizard step 9).
 *
 * Lives in lib/ rather than core/ because it is a browser-side concern: the
 * downloads are produced from the already-parsed table in the client component
 * (Blob + object URL), with no server round-trip. Only `toXlsxWorkbookBlob`
 * touches a browser API, so `toCsv` / `calendarFilename` stay unit-testable
 * under node.
 */

/** UTF-8 BOM. Without it Excel reads the CSV as cp1252 and mangles ş/ğ/ı. */
const BOM = "﻿";

/**
 * RFC4180-ish CSV: CRLF row endings, a cell quoted when it contains a comma, a
 * double quote or a line break, and inner quotes doubled. Prefixed with a BOM
 * so Excel opens Turkish characters correctly (the whole reason this helper
 * exists rather than a naive join).
 */
export function toCsv(headers: string[], rows: string[][]): string {
  const lines = [headers, ...rows].map((row) => row.map(csvCell).join(","));
  return BOM + lines.join("\r\n");
}

/**
 * Characters that make Excel/Sheets treat a cell as a live formula. Calendar
 * cells are model output derived from user-uploaded brand documents, so a
 * poisoned upload could plant `=HYPERLINK(...)`/`=WEBSERVICE(...)` and have it
 * execute when the downloaded CSV is opened. Neutralized with a leading
 * apostrophe, the standard mitigation (the XLSX path is unaffected: aoa_to_sheet
 * types these as strings, never formulas).
 */
const FORMULA_LEAD = /^[=+\-@\t\r]/;

function csvCell(value: string): string {
  let s = value ?? "";
  if (FORMULA_LEAD.test(s)) s = `'${s}`;
  if (/[",\r\n]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

/** One worksheet's worth of data: its tab name plus its table. */
export interface CalendarSheet {
  /** Desired tab name (a platform's `promptName`); sanitized before writing. */
  name: string;
  headers: string[];
  rows: string[][];
}

/**
 * Column widths by INDEX, matching the T33 seven-column layout produced by
 * content-calendar-step:
 *
 *   0 Day · 1 Format · 2 Pillar · 3 Hook · 4 Caption · 5 CTA · 6 Hashtags
 *
 * Caption (4) is the long freeform cell, Hook (3) and CTA (5) are medium, the
 * rest are short. If the header set ever changes, this array must change with
 * it — a mismatched length falls back to a uniform width rather than mis-sizing
 * silently.
 */
const COLUMN_WIDTHS = [12, 14, 18, 40, 80, 28, 24];
const DEFAULT_COLUMN_WIDTH = 18;

/**
 * Index of the one long freeform column (Caption) in the layout above.
 *
 * Exported because the on-screen table needs the same answer: it is the column
 * that wraps and gets a minimum width, while every other column stays on one
 * line. Sharing the constant is what stops the sheet widths here and the table
 * styling in content-calendar-step from drifting apart — before T33 the table
 * assumed "the last column is the long one", which silently became Hashtags.
 */
export const CAPTION_COLUMN = 4;

function columnWidths(headers: string[]) {
  const known = headers.length === COLUMN_WIDTHS.length;
  return headers.map((_, i) => ({
    wch: known ? COLUMN_WIDTHS[i] : DEFAULT_COLUMN_WIDTH,
  }));
}

/** Excel forbids these inside a sheet name; a stray one corrupts the workbook. */
const ILLEGAL_SHEET_CHARS = /[:\\/?*[\]]/g;
/**
 * C0 control characters other than the whitespace ones (\t \n \v \f \r), which
 * the whitespace collapse below has already turned into spaces by the time this
 * runs. SheetJS does not drop these: it escapes them to `_x0001_`, which both
 * renders as literal junk in the tab ("Insta_x0001_gram") and is six characters
 * longer than what we counted, pushing the name past the 31-character limit
 * this function exists to enforce.
 */
const CONTROL_SHEET_CHARS = /[\u0000-\u0008\u000e-\u001f]/g;
/** Excel's hard limit on sheet-name length. */
const MAX_SHEET_NAME = 31;
/** Used when sanitizing leaves nothing at all (e.g. a name of only "[]"). */
const FALLBACK_SHEET_NAME = "Sheet";
/**
 * Excel reserves this name (case-insensitively) for the change-tracking log of
 * a shared workbook and refuses to open a file that reuses it.
 */
const RESERVED_SHEET_NAME = "history";

/**
 * Truncate without ever splitting a surrogate pair.
 *
 * `.slice()` counts UTF-16 code units, so it can cut an astral character (an
 * emoji, a rare CJK ideograph) in half and leave a LONE SURROGATE. SheetJS does
 * not reject that: it passes the name through and the UTF-8 encoder writes
 * U+FFFD in its place. So two names that differ only in their (distinct)
 * trailing astral character encode to the SAME string in the file, while the
 * de-dup below — which compares the pre-encoding strings, where they still
 * differ — adds no `~2`. The result is a workbook with two identically named
 * sheets: exactly the failure uniqueSheetNames promises to prevent, and one
 * neither of SheetJS's own guards catches.
 *
 * `max` stays a count of CODE UNITS, because that is what Excel's 31-character
 * limit and SheetJS's own check measure; a whole character that would cross the
 * boundary is dropped rather than half-included.
 */
function truncateSheetName(value: string, max: number): string {
  let out = "";
  for (const char of value) {
    if (out.length + char.length > max) break;
    out += char;
  }
  return out;
}

/**
 * A single name made safe for Excel: illegal and control characters removed,
 * whitespace collapsed and trimmed, capped at 31 characters, never empty, never
 * the reserved name "History".
 *
 * Excel also rejects a name that starts or ends with an apostrophe, so those
 * are trimmed too. Exported for tests; the writer applies it for you.
 */
export function sanitizeSheetName(name: string): string {
  const collapsed = (name ?? "")
    .replace(ILLEGAL_SHEET_CHARS, "")
    .replace(/\s+/g, " ")
    .replace(CONTROL_SHEET_CHARS, "")
    .replace(/^['\s]+|['\s]+$/g, "");
  const cleaned = truncateSheetName(collapsed, MAX_SHEET_NAME)
    // Truncation can expose a trailing apostrophe/space again.
    .replace(/['\s]+$/g, "");
  if (cleaned === "") return FALLBACK_SHEET_NAME;
  // Renamed rather than replaced, so the tab still says which platform it is.
  if (cleaned.toLowerCase() === RESERVED_SHEET_NAME) return `${cleaned}_`;
  return cleaned;
}

/**
 * Sanitize a whole set of names AND make them unique, which Excel also
 * requires (case-insensitively). Duplicates get a `~2`, `~3` … suffix, with the
 * base shortened as needed so the result still fits in 31 characters.
 *
 * This matters more than it looks: two platforms whose names collide after
 * truncation would produce a workbook Excel refuses to open, which is a
 * silent-ish failure at download time rather than an error we can show.
 */
export function uniqueSheetNames(names: readonly string[]): string[] {
  const taken = new Set<string>();
  return names.map((raw) => {
    const base = sanitizeSheetName(raw);
    let candidate = base;
    let n = 2;
    while (taken.has(candidate.toLowerCase())) {
      const suffix = `~${n}`;
      candidate =
        truncateSheetName(base, MAX_SHEET_NAME - suffix.length) + suffix;
      n += 1;
    }
    taken.add(candidate.toLowerCase());
    return candidate;
  });
}

/**
 * The calendars as ONE .xlsx workbook with a worksheet per platform, in the
 * order given (T33 item 3: a single download, one tab per platform — CSV
 * cannot carry sheets, so only the XLSX path is multi-sheet).
 *
 * Generated client-side; the cells keep the real newlines that the parser
 * restored from "<br>". Column widths are set (the community SheetJS build
 * writes `!cols` but ignores per-cell styles, so there is no point setting
 * wrapText here).
 *
 * ASYNC ON PURPOSE: SheetJS is ~100 kB gzipped and would otherwise land in the
 * wizard's first-load bundle for every step (measured: 9 kB → 105 kB on
 * /projects/[id]/step/[n]). The dynamic import keeps it in its own chunk,
 * fetched only when someone actually clicks "XLSX indir". Do not hoist it back
 * to a top-level import.
 */
export async function toXlsxWorkbookBlob(
  sheets: ReadonlyArray<CalendarSheet>,
): Promise<Blob> {
  // A workbook with zero worksheets is not a valid xlsx file; writing one would
  // hand the user a file Excel rejects. Fail loudly instead (hard rule 5).
  if (sheets.length === 0) {
    throw new Error("toXlsxWorkbookBlob: at least one sheet is required");
  }

  // NOTE on `npm audit`: xlsx@0.18.5 carries two advisories (prototype
  // pollution, ReDoS). Both live in the PARSING path (XLSX.read/readFile). This
  // code is write-only — aoa_to_sheet/book_new/write over data we produced
  // ourselves, in the browser — so neither is reachable. Documented here so the
  // next audit doesn't re-litigate it; a fixed release exists only on the
  // SheetJS CDN, not npm.
  const XLSX = await import("xlsx");
  const book = XLSX.utils.book_new();
  const names = uniqueSheetNames(sheets.map((s) => s.name));

  sheets.forEach((entry, i) => {
    const sheet = XLSX.utils.aoa_to_sheet([entry.headers, ...entry.rows]);
    sheet["!cols"] = columnWidths(entry.headers);
    XLSX.utils.book_append_sheet(book, sheet, names[i]);
  });

  const buffer = XLSX.write(book, { bookType: "xlsx", type: "array" }) as ArrayBuffer;
  return new Blob([buffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}

/**
 * Download filename: `marka-proje-dil-platform.csv|xlsx`, each part slugified. Turkish
 * characters are transliterated (ş→s, ğ→g, ı→i, …) rather than dropped, so
 * "Kleinburg Türkiye" stays readable as "kleinburg-turkiye".
 */
export function calendarFilename(
  brandName: string,
  projectName: string,
  language: string,
  ext: "csv" | "xlsx",
  /** T29: without it, two platforms' downloads land on the same filename. */
  platform?: string,
): string {
  const parts = [brandName, projectName, language, platform ?? ""]
    .map((p) => slugify(p ?? ""))
    .filter((p) => p !== "");
  const stem = parts.length > 0 ? parts.join("-") : "icerik-takvimi";
  return `${stem}.${ext}`;
}

/** Turkish letters that Unicode decomposition alone would not resolve well. */
const TR_MAP: Record<string, string> = {
  ı: "i",
  İ: "i",
  ğ: "g",
  Ğ: "g",
  ş: "s",
  Ş: "s",
  ç: "c",
  Ç: "c",
  ö: "o",
  Ö: "o",
  ü: "u",
  Ü: "u",
};

/** "Kleinburg Türkiye!" → "kleinburg-turkiye". */
export function slugify(value: string): string {
  return value
    .replace(/[ıİğĞşŞçÇöÖüÜ]/g, (ch) => TR_MAP[ch] ?? ch)
    .toLowerCase()
    // Strip any remaining diacritics (é, å, ñ …) after decomposing them.
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}
