import { Space_Grotesk } from "next/font/google";

// Stand-in for Baikal (commercial); swap via typography.fontFamily token
export const spaceGrotesk = Space_Grotesk({
  variable: "--font-sans",
  subsets: ["latin"],
});
