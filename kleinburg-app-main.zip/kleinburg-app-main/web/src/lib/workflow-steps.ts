/**
 * The 9-step wizard metadata — the fixed ordering of the content workflow.
 *
 * Pure module: NO DB / core imports, and (T25) no next-intl import either — it
 * is read from server components, client components and plain tests alike.
 *
 * `key` is the storage key for the step:
 *  - step 1 -> "documents" (the documents table; NOT a workflow_step enum value)
 *  - step 6 -> "platforms" (the projects.platforms column; like step 1, NOT a
 *    workflow_step enum value — the platform set is a property of the project,
 *    not the output of a generation)
 *  - the other steps -> the matching workflow_step enum value in step_contents.
 *
 * It is ALSO the translation key for the step's display label: the label lives
 * in `stepLabels.<key>` in messages/{tr,en}.json, so a step carries no baked-in
 * Turkish. Callers render it with `useTranslations("stepLabels")(step.key)` —
 * see wizard-rail.tsx. messages.test.ts asserts every key has a label in every
 * locale, so a step added here without a label fails CI.
 *
 * Keep this list in sync with the workflow_step enum in core/db/schema.ts.
 */
export type WizardStep = { n: number; key: string };

export const WIZARD_STEPS: WizardStep[] = [
  { n: 1, key: "documents" },
  { n: 2, key: "brand_context" },
  { n: 3, key: "secondary_data" },
  { n: 4, key: "user_input" },
  { n: 5, key: "creative_sparks" },
  { n: 6, key: "platforms" },
  { n: 7, key: "sm_pillars" },
  { n: 8, key: "sm_posts" },
  { n: 9, key: "content_calendar" },
];

export const TOTAL_STEPS = 9;

/** The step whose `n` matches, or undefined for an out-of-range number. */
export function stepByNumber(n: number): WizardStep | undefined {
  return WIZARD_STEPS.find((s) => s.n === n);
}
