import { createTranslator } from "next-intl";
import { describe, expect, it } from "vitest";

import tr from "../../messages/tr.json";
import { withTimeZone } from "@/test/with-timezone";
import { relativeTime as format } from "./relative-time";

const now = new Date("2026-07-18T12:00:00.000Z");

/**
 * T25 made the formatter locale-aware by taking a translator. The assertions
 * below are UNCHANGED — they still assert the exact Turkish a user reads — but
 * the strings now come from the real tr.json catalog through next-intl's own
 * ICU translator, so this test also proves the catalog is wired up.
 */
const t = createTranslator({
  locale: "tr",
  messages: tr,
  namespace: "relativeTime",
});

/** The Turkish formatter, matching the pre-T25 (date, now) signature. */
const relativeTime = (date: Date, at: Date) => format(date, t, at);

describe("relativeTime", () => {
  it('returns "az önce" for instants under a minute ago', () => {
    expect(relativeTime(new Date(now.getTime() - 1_000), now)).toBe("az önce");
    expect(relativeTime(now, now)).toBe("az önce");
    // Just under a minute is still "az önce".
    expect(relativeTime(new Date(now.getTime() - 59_000), now)).toBe("az önce");
  });

  it('returns "N dakika önce" between one minute and one hour', () => {
    // Exactly one minute is the lower boundary.
    expect(relativeTime(new Date(now.getTime() - 60_000), now)).toBe(
      "1 dakika önce",
    );
    expect(relativeTime(new Date(now.getTime() - 45 * 60_000), now)).toBe(
      "45 dakika önce",
    );
    // Just under an hour.
    expect(relativeTime(new Date(now.getTime() - 59 * 60_000), now)).toBe(
      "59 dakika önce",
    );
  });

  it('returns "N saat önce" between one hour and one day', () => {
    // Exactly one hour is the lower boundary.
    expect(relativeTime(new Date(now.getTime() - 60 * 60_000), now)).toBe(
      "1 saat önce",
    );
    expect(relativeTime(new Date(now.getTime() - 5 * 60 * 60_000), now)).toBe(
      "5 saat önce",
    );
    // Just under a day.
    expect(relativeTime(new Date(now.getTime() - 23 * 60 * 60_000), now)).toBe(
      "23 saat önce",
    );
  });

  it('returns "N gün önce" between one day and one week', () => {
    // Exactly one day is the lower boundary.
    expect(relativeTime(new Date(now.getTime() - 24 * 60 * 60_000), now)).toBe(
      "1 gün önce",
    );
    expect(relativeTime(new Date(now.getTime() - 3 * 24 * 60 * 60_000), now)).toBe(
      "3 gün önce",
    );
    // Just under a week.
    expect(relativeTime(new Date(now.getTime() - 6 * 24 * 60 * 60_000), now)).toBe(
      "6 gün önce",
    );
  });

  it("falls back to an absolute date at one week and older", () => {
    // Exactly a week ago -> absolute date (2026-07-11).
    expect(relativeTime(new Date(now.getTime() - 7 * 24 * 60 * 60_000), now)).toBe(
      "11.07.2026",
    );
    expect(relativeTime(new Date("2026-01-05T12:00:00.000Z"), now)).toBe(
      "05.01.2026",
    );
  });

  it("falls back to an absolute date for future dates", () => {
    expect(relativeTime(new Date(now.getTime() + 60_000), now)).toBe(
      "18.07.2026",
    );
  });

  /**
   * #66. Every case above is anchored at noon UTC, which is the same calendar
   * day in every zone this app is read in — so they passed whether the date
   * was read in the process zone or in Istanbul, and proved nothing about
   * which. These pin the process zone instead.
   *
   * 2026-07-21T22:30Z is 01:30 on the 22nd in Istanbul. A project edited then
   * must stamp "22.07.2026" on the projects list, because that is the date on
   * the calendar of the person who edited it. Read in the process zone it
   * stamps the 21st — and on Render the process zone is UTC, since render.yaml
   * sets no TZ.
   */
  describe("absolute date is read on the Istanbul calendar", () => {
    // 01:30 on 22 July, Istanbul. Older than a week, so this takes the
    // absolute-date branch.
    const lateNightIstanbul = new Date("2026-07-21T22:30:00.000Z");
    const muchLater = new Date("2026-08-05T09:00:00.000Z");

    it("stamps the Istanbul day when the process runs in UTC (Render)", () => {
      expect(
        withTimeZone("UTC", () => relativeTime(lateNightIstanbul, muchLater)),
      ).toBe("22.07.2026");
    });

    it("stamps the same day whatever zone the process runs in", () => {
      // Behind UTC as well as ahead of it: a zone-independent stamp is the
      // point, not "happens to agree with the developer's laptop".
      for (const zone of ["UTC", "America/New_York", "Asia/Tokyo", "Europe/Istanbul"]) {
        expect(
          withTimeZone(zone, () => relativeTime(lateNightIstanbul, muchLater)),
        ).toBe("22.07.2026");
      }
    });

    it("keeps the day.month.year order and zero padding", () => {
      // 01:30 on 5 January Istanbul — single-digit day and month, so a padding
      // or ordering regression cannot hide behind two-digit numbers, and still
      // inside the 00:00-03:00 window so it discriminates on the zone too.
      expect(
        withTimeZone("UTC", () =>
          relativeTime(new Date("2026-01-04T22:30:00.000Z"), muchLater),
        ),
      ).toBe("05.01.2026");
    });
  });
});
