/**
 * Where a signed-in visitor to a PUBLIC page belongs (T45).
 *
 * The root URL and /login are reachable with no session, so both have to
 * answer "what if there already is one?". The answer is not simply
 * "/projects": an account still holding an admin-set temporary password owes a
 * change first (T40), and the (app) layout would bounce it to
 * /change-password anyway. Sending it there directly means these public pages
 * cooperate with that gate instead of ping-ponging through /projects.
 *
 * This is a routing convenience, NOT the gate itself. The (app) layout and
 * `requireApiUser` remain the authoritative checks; nothing here can grant
 * access, only choose a destination for someone who already has a session.
 *
 * Pure (no next/react imports) so the rule can be tested on its own.
 */
export function signedInDestination(
  user: { mustChangePassword: boolean } | null,
): string | null {
  if (!user) return null;
  if (user.mustChangePassword) return "/change-password";
  return "/projects";
}
