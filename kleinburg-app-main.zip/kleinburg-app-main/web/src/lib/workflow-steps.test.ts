import { describe, expect, it } from "vitest";

import {
  TOTAL_STEPS,
  WIZARD_STEPS,
  stepByNumber,
} from "./workflow-steps";

describe("workflow-steps", () => {
  it("has exactly 9 steps in fixed order 1..9", () => {
    expect(TOTAL_STEPS).toBe(9);
    expect(WIZARD_STEPS).toHaveLength(9);
    expect(WIZARD_STEPS.map((s) => s.n)).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9]);
  });

  // Two keys are NOT workflow_step enum values: "documents" (step 1, its own
  // table) and "platforms" (step 6, a projects column). Both are wizard steps
  // that store outside step_contents.
  it("orders the step keys with platforms before the pillars", () => {
    expect(WIZARD_STEPS.map((s) => s.key)).toEqual([
      "documents",
      "brand_context",
      "secondary_data",
      "user_input",
      "creative_sparks",
      "platforms",
      "sm_pillars",
      "sm_posts",
      "content_calendar",
    ]);
  });

  // T25: the display label moved into messages/{tr,en}.json under
  // stepLabels.<key>, so what this module must guarantee is a usable, unique
  // label KEY per step. That the label itself exists (and is non-empty) is
  // asserted for BOTH locales in src/i18n/messages.test.ts.
  it("has a non-empty, unique label key for every step", () => {
    for (const step of WIZARD_STEPS) {
      expect(step.key.length).toBeGreaterThan(0);
    }
    expect(new Set(WIZARD_STEPS.map((s) => s.key)).size).toBe(
      WIZARD_STEPS.length,
    );
  });

  it("stepByNumber returns the matching step or undefined out of range", () => {
    expect(stepByNumber(1)?.key).toBe("documents");
    expect(stepByNumber(6)?.key).toBe("platforms");
    expect(stepByNumber(9)?.key).toBe("content_calendar");
    expect(stepByNumber(0)).toBeUndefined();
    expect(stepByNumber(10)).toBeUndefined();
  });
});
