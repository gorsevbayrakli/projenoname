import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq, inArray } from "drizzle-orm";

import { closeDb, getDb } from "@/core/db/client";
import {
  brands,
  documents,
  projects,
  stepContents,
  users,
} from "@/core/db/schema";
import { getWizardStatus, MIN_BRAND_CONTEXT_CHARS } from "./wizard-status";

import { hasDb } from "@/test/db-gate";

const createdUserIds: string[] = [];
const createdBrandIds: string[] = [];

async function seedProject() {
  const db = getDb();
  const [user] = await db
    .insert(users)
    .values({ username: `t13-${randomUUID()}`, passwordHash: "x" })
    .returning();
  createdUserIds.push(user.id);
  const [brand] = await db
    .insert(brands)
    .values({ name: `brand-${randomUUID()}` })
    .returning();
  createdBrandIds.push(brand.id);
  const [project] = await db
    .insert(projects)
    .values({ brandId: brand.id, name: `proj-${randomUUID()}`, createdBy: user.id })
    .returning();
  return project;
}

/** A schema-shaped sm_posts entry. */
const POST = {
  platform: "instagram",
  theme: "t",
  hook: "h",
  caption: "c",
  cta: "cta",
  hashtags: ["#a"],
};

/**
 * Seed everything steps 1–6 need to be complete, so a step-7 assertion is not
 * masked by an earlier incomplete step (`current` is the FIRST incomplete step).
 */
async function seedThroughStep6(projectId: string) {
  const db = getDb();
  await db.insert(documents).values({
    projectId,
    filename: "brief.pdf",
    kind: "pdf",
    extractedText: "hello",
  });
  await db.insert(stepContents).values([
    {
      projectId,
      step: "brand_context",
      content: { brandContext: "x".repeat(MIN_BRAND_CONTEXT_CHARS) },
    },
    {
      projectId,
      step: "secondary_data",
      content: { items: [{ title: "t", description: "d" }] },
      selections: { selectedIndices: [0] },
    },
    { projectId, step: "user_input", content: { text: "yaz" } },
    {
      projectId,
      step: "creative_sparks",
      content: { items: [{ title: "t", description: "d" }] },
      selections: { selectedIndices: [0] },
    },
    {
      projectId,
      step: "sm_pillars",
      content: { pillars: [{ category: "INSPIRATIONAL", title: "t" }] },
      selections: { selectedIndices: [0] },
    },
  ]);
}

describe.skipIf(!hasDb)("wizard-status", () => {
  beforeAll(() => {
    getDb();
  });

  afterAll(async () => {
    const db = getDb();
    if (createdUserIds.length > 0) {
      await db.delete(users).where(inArray(users.id, createdUserIds));
    }
    if (createdBrandIds.length > 0) {
      // Cascades to projects, documents, step_contents.
      await db.delete(brands).where(inArray(brands.id, createdBrandIds));
    }
    await closeDb();
  });

  it("no data -> current 1, nothing completed", async () => {
    const project = await seedProject();
    const status = await getWizardStatus(project.id);
    expect(status.current).toBe(1);
    expect([...status.completed]).toEqual([]);
  });

  it("a documents row completes step 1 -> current 2", async () => {
    const project = await seedProject();
    const db = getDb();
    await db.insert(documents).values({
      projectId: project.id,
      filename: "brief.pdf",
      kind: "pdf",
      extractedText: "hello",
    });
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(1)).toBe(true);
    expect(status.current).toBe(2);
  });

  it("a brand_context under 200 chars does NOT complete step 2 -> current 2", async () => {
    const project = await seedProject();
    const db = getDb();
    await db.insert(documents).values({
      projectId: project.id,
      filename: "brief.pdf",
      kind: "pdf",
      extractedText: "hello",
    });
    await db.insert(stepContents).values({
      projectId: project.id,
      step: "brand_context",
      content: { brandContext: "kısa" },
    });
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(1)).toBe(true);
    expect(status.completed.has(2)).toBe(false);
    expect(status.current).toBe(2);
  });

  it("a brand_context of ≥200 chars completes step 2 -> current 3", async () => {
    const project = await seedProject();
    const db = getDb();
    await db.insert(documents).values({
      projectId: project.id,
      filename: "brief.pdf",
      kind: "pdf",
      extractedText: "hello",
    });
    await db.insert(stepContents).values({
      projectId: project.id,
      step: "brand_context",
      content: { brandContext: "x".repeat(MIN_BRAND_CONTEXT_CHARS) },
    });
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(1)).toBe(true);
    expect(status.completed.has(2)).toBe(true);
    expect(status.current).toBe(3);
  });

  it("a secondary_data row with no selection does NOT complete step 3", async () => {
    const project = await seedProject();
    const db = getDb();
    await db.insert(documents).values({
      projectId: project.id,
      filename: "brief.pdf",
      kind: "pdf",
      extractedText: "hello",
    });
    await db.insert(stepContents).values([
      {
        projectId: project.id,
        step: "brand_context",
        content: { brandContext: "x".repeat(MIN_BRAND_CONTEXT_CHARS) },
      },
      // items present, but selections null (fresh generation) — not completed.
      {
        projectId: project.id,
        step: "secondary_data",
        content: { items: [{ title: "t", description: "d" }] },
        selections: null,
      },
    ]);
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(2)).toBe(true);
    expect(status.completed.has(3)).toBe(false);
    expect(status.current).toBe(3);
  });

  it("an empty selectedIndices does NOT complete step 3", async () => {
    const project = await seedProject();
    const db = getDb();
    await db.insert(stepContents).values({
      projectId: project.id,
      step: "secondary_data",
      content: { items: [{ title: "t", description: "d" }] },
      selections: { selectedIndices: [] },
    });
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(3)).toBe(false);
  });

  it("a secondary_data row with ≥1 selected index completes step 3", async () => {
    const project = await seedProject();
    const db = getDb();
    await db.insert(documents).values({
      projectId: project.id,
      filename: "brief.pdf",
      kind: "pdf",
      extractedText: "hello",
    });
    await db.insert(stepContents).values([
      {
        projectId: project.id,
        step: "brand_context",
        content: { brandContext: "x".repeat(MIN_BRAND_CONTEXT_CHARS) },
      },
      {
        projectId: project.id,
        step: "secondary_data",
        content: { items: [{ title: "t", description: "d" }] },
        selections: { selectedIndices: [0] },
      },
    ]);
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(3)).toBe(true);
    expect(status.current).toBe(4);
  });

  it("a user_input row with EMPTY text completes step 4 -> current 5", async () => {
    const project = await seedProject();
    const db = getDb();
    await db.insert(documents).values({
      projectId: project.id,
      filename: "brief.pdf",
      kind: "pdf",
      extractedText: "hello",
    });
    await db.insert(stepContents).values([
      {
        projectId: project.id,
        step: "brand_context",
        content: { brandContext: "x".repeat(MIN_BRAND_CONTEXT_CHARS) },
      },
      {
        projectId: project.id,
        step: "secondary_data",
        content: { items: [{ title: "t", description: "d" }] },
        selections: { selectedIndices: [0] },
      },
      // Step 4 is OPTIONAL: "Devam" always writes the row, so an empty text
      // still counts as done (the default row-existence predicate).
      { projectId: project.id, step: "user_input", content: { text: "" } },
    ]);
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(4)).toBe(true);
    expect(status.current).toBe(5);
  });

  it("a creative_sparks row with no selection does NOT complete step 5", async () => {
    const project = await seedProject();
    const db = getDb();
    await db.insert(documents).values({
      projectId: project.id,
      filename: "brief.pdf",
      kind: "pdf",
      extractedText: "hello",
    });
    await db.insert(stepContents).values([
      {
        projectId: project.id,
        step: "brand_context",
        content: { brandContext: "x".repeat(MIN_BRAND_CONTEXT_CHARS) },
      },
      {
        projectId: project.id,
        step: "secondary_data",
        content: { items: [{ title: "t", description: "d" }] },
        selections: { selectedIndices: [0] },
      },
      { projectId: project.id, step: "user_input", content: { text: "yaz" } },
      // items present, but selections null (fresh generation) — not completed.
      {
        projectId: project.id,
        step: "creative_sparks",
        content: { items: [{ title: "t", description: "d" }] },
        selections: null,
      },
    ]);
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(4)).toBe(true);
    expect(status.completed.has(5)).toBe(false);
    expect(status.current).toBe(5);
  });

  it("an empty selectedIndices does NOT complete step 5", async () => {
    const project = await seedProject();
    const db = getDb();
    await db.insert(stepContents).values({
      projectId: project.id,
      step: "creative_sparks",
      content: { items: [{ title: "t", description: "d" }] },
      selections: { selectedIndices: [] },
    });
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(5)).toBe(false);
  });

  it("a creative_sparks row with ≥1 selected index completes step 5 -> current 6", async () => {
    const project = await seedProject();
    const db = getDb();
    await db.insert(documents).values({
      projectId: project.id,
      filename: "brief.pdf",
      kind: "pdf",
      extractedText: "hello",
    });
    await db.insert(stepContents).values([
      {
        projectId: project.id,
        step: "brand_context",
        content: { brandContext: "x".repeat(MIN_BRAND_CONTEXT_CHARS) },
      },
      {
        projectId: project.id,
        step: "secondary_data",
        content: { items: [{ title: "t", description: "d" }] },
        selections: { selectedIndices: [0] },
      },
      { projectId: project.id, step: "user_input", content: { text: "yaz" } },
      {
        projectId: project.id,
        step: "creative_sparks",
        content: { items: [{ title: "t", description: "d" }] },
        selections: { selectedIndices: [0] },
      },
    ]);
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(5)).toBe(true);
    expect(status.current).toBe(6);
  });


/** Everything steps 1-5 need, leaving step 6 (platforms) as the first gap. */
async function seedThroughStep5(projectId: string) {
  const db = getDb();
  await db.insert(documents).values({
    projectId,
    filename: "brief.pdf",
    kind: "pdf",
    extractedText: "hello",
  });
  await db.insert(stepContents).values([
    {
      projectId,
      step: "brand_context",
      content: { brandContext: "x".repeat(MIN_BRAND_CONTEXT_CHARS) },
    },
    {
      projectId,
      step: "secondary_data",
      content: { items: [{ title: "t", description: "d" }] },
      selections: { selectedIndices: [0] },
    },
    { projectId, step: "user_input", content: { text: "yaz" } },
    {
      projectId,
      step: "creative_sparks",
      content: { items: [{ title: "t", description: "d" }] },
      selections: { selectedIndices: [0] },
    },
  ]);
}

/**
 * A project with step 6 already satisfied. T29 put platform selection before
 * the pillars, so every assertion about steps 7-9 needs it set or `current`
 * stops at 6 and the assertion measures the wrong thing.
 */
async function seedProjectWithPlatforms() {
  const project = await seedProject();
  await getDb()
    .update(projects)
    .set({ platforms: ["instagram"] })
    .where(eq(projects.id, project.id));
  return project;
}

  // ── Step 6 (platforms): at least one chosen (T29) ─────────────────────────
  //
  // The only step whose state lives on the project row rather than in
  // step_contents, so it is also the only one a step_contents-shaped seed
  // cannot accidentally satisfy.
  it("a project with no platforms chosen does NOT complete step 6", async () => {
    const project = await seedProject();
    await seedThroughStep5(project.id);

    const status = await getWizardStatus(project.id);

    expect(status.completed.has(6)).toBe(false);
    expect(status.current).toBe(6);
  });

  it("one chosen platform completes step 6 -> current 7", async () => {
    const project = await seedProject();
    await seedThroughStep5(project.id);
    await getDb()
      .update(projects)
      .set({ platforms: ["facebook"] })
      .where(eq(projects.id, project.id));

    const status = await getWizardStatus(project.id);

    expect(status.completed.has(6)).toBe(true);
    expect(status.current).toBe(7);
  });

  // Step 7 (sm_pillars) — the completion predicate reads the PERSISTED
  // selection. It was independent of the step-7 UI, which opened with nothing
  // checked under legacy's conscious-repick rule; that rule was removed on
  // 2026-07-21 and the UI now seeds from the same persisted value. These cases
  // pin the persistence side, which is unchanged by that.
  it("an sm_pillars row with no selection does NOT complete step 7", async () => {
    const project = await seedProjectWithPlatforms();
    const db = getDb();
    await db.insert(stepContents).values({
      projectId: project.id,
      step: "sm_pillars",
      content: { pillars: [{ category: "INSPIRATIONAL", title: "t" }] },
      selections: null,
    });
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(7)).toBe(false);
  });

  it("an empty selectedIndices does NOT complete step 7", async () => {
    const project = await seedProjectWithPlatforms();
    const db = getDb();
    await db.insert(stepContents).values({
      projectId: project.id,
      step: "sm_pillars",
      content: { pillars: [{ category: "INSPIRATIONAL", title: "t" }] },
      selections: { selectedIndices: [] },
    });
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(7)).toBe(false);
  });

  it("an sm_pillars row with ≥1 selected index completes step 7 -> current 8", async () => {
    const project = await seedProjectWithPlatforms();
    const db = getDb();
    await db.insert(documents).values({
      projectId: project.id,
      filename: "brief.pdf",
      kind: "pdf",
      extractedText: "hello",
    });
    await db.insert(stepContents).values([
      {
        projectId: project.id,
        step: "brand_context",
        content: { brandContext: "x".repeat(MIN_BRAND_CONTEXT_CHARS) },
      },
      {
        projectId: project.id,
        step: "secondary_data",
        content: { items: [{ title: "t", description: "d" }] },
        selections: { selectedIndices: [0] },
      },
      { projectId: project.id, step: "user_input", content: { text: "yaz" } },
      {
        projectId: project.id,
        step: "creative_sparks",
        content: { items: [{ title: "t", description: "d" }] },
        selections: { selectedIndices: [0] },
      },
      {
        projectId: project.id,
        step: "sm_pillars",
        content: { pillars: [{ category: "INSPIRATIONAL", title: "t" }] },
        selections: { selectedIndices: [0] },
      },
    ]);
    const status = await getWizardStatus(project.id);
    expect(status.completed.has(7)).toBe(true);
    expect(status.current).toBe(8);
  });

  it("all steps present -> current 9, all completed", async () => {
    const project = await seedProjectWithPlatforms();
    const db = getDb();
    await db.insert(documents).values({
      projectId: project.id,
      filename: "brief.pdf",
      kind: "pdf",
      extractedText: "hello",
    });
    await db.insert(stepContents).values([
      {
        projectId: project.id,
        step: "brand_context",
        content: { brandContext: "x".repeat(MIN_BRAND_CONTEXT_CHARS) },
      },
      {
        projectId: project.id,
        step: "secondary_data",
        content: { items: [{ title: "t", description: "d" }] },
        selections: { selectedIndices: [0] },
      },
      { projectId: project.id, step: "user_input", content: {} },
      {
        projectId: project.id,
        step: "creative_sparks",
        content: { items: [{ title: "t", description: "d" }] },
        selections: { selectedIndices: [0] },
      },
      {
        projectId: project.id,
        step: "sm_pillars",
        content: { pillars: [{ category: "INSPIRATIONAL", title: "t" }] },
        selections: { selectedIndices: [0] },
      },
      // Step 7 needs ≥1 post, not merely a row (the calendar is grounded in them).
      { projectId: project.id, step: "sm_posts", content: { posts: [POST] } },
      // Step 8 needs a non-empty calendar string, not merely a row.
      {
        projectId: project.id,
        step: "content_calendar",
        content: { calendar: "| Day | Post |\n| --- | --- |\n| Day 1 | x |" },
      },
    ]);
    const status = await getWizardStatus(project.id);
    expect([...status.completed].sort((a, b) => a - b)).toEqual([
      1, 2, 3, 4, 5, 6, 7, 8, 9,
    ]);
    expect(status.current).toBe(9);
  });

  // ── Step 8 (sm_posts): ≥1 post, either platform ───────────────────────────
  it("an sm_posts row with ZERO posts does NOT complete step 8", async () => {
    const project = await seedProjectWithPlatforms();
    await seedThroughStep6(project.id);
    await getDb()
      .insert(stepContents)
      .values({ projectId: project.id, step: "sm_posts", content: { posts: [] } });

    const status = await getWizardStatus(project.id);
    expect(status.completed.has(8)).toBe(false);
    expect(status.current).toBe(8);
  });

  it("an sm_posts row with no posts key at all does NOT complete step 8", async () => {
    const project = await seedProjectWithPlatforms();
    await seedThroughStep6(project.id);
    await getDb()
      .insert(stepContents)
      .values({ projectId: project.id, step: "sm_posts", content: {} });

    const status = await getWizardStatus(project.id);
    expect(status.completed.has(8)).toBe(false);
    expect(status.current).toBe(8);
  });

  it("an sm_posts row with ≥1 post completes step 8 -> current 9", async () => {
    const project = await seedProjectWithPlatforms();
    await seedThroughStep6(project.id);
    await getDb()
      .insert(stepContents)
      .values({
        projectId: project.id,
        step: "sm_posts",
        content: { posts: [POST] },
      });

    const status = await getWizardStatus(project.id);
    expect(status.completed.has(8)).toBe(true);
    expect(status.current).toBe(9);
  });

  it("facebook-only posts complete step 8 just the same (no platform requirement)", async () => {
    const project = await seedProjectWithPlatforms();
    await seedThroughStep6(project.id);
    await getDb()
      .insert(stepContents)
      .values({
        projectId: project.id,
        step: "sm_posts",
        content: { posts: [{ ...POST, platform: "facebook" }] },
      });

    const status = await getWizardStatus(project.id);
    expect(status.completed.has(8)).toBe(true);
  });

  // ── Step 9 (content_calendar): a non-empty calendar STRING ────────────────
  //
  // Step 8 is the last step, so `current` is 8 whether or not it completes
  // (the loop falls through to TOTAL_STEPS). Only the rail's ✓ changes.
  async function seedThroughStep7(projectId: string) {
    await seedThroughStep6(projectId);
    await getDb()
      .insert(stepContents)
      .values({ projectId, step: "sm_posts", content: { posts: [POST] } });
  }

  it("a content_calendar row with an EMPTY calendar string does NOT complete step 9", async () => {
    const project = await seedProjectWithPlatforms();
    await seedThroughStep7(project.id);
    await getDb()
      .insert(stepContents)
      .values({
        projectId: project.id,
        step: "content_calendar",
        content: { calendar: "" },
      });

    const status = await getWizardStatus(project.id);
    expect(status.completed.has(9)).toBe(false);
    expect(status.current).toBe(9);
  });

  it("a content_calendar row with only whitespace does NOT complete step 9", async () => {
    const project = await seedProjectWithPlatforms();
    await seedThroughStep7(project.id);
    await getDb()
      .insert(stepContents)
      .values({
        projectId: project.id,
        step: "content_calendar",
        content: { calendar: "   \n  " },
      });

    expect((await getWizardStatus(project.id)).completed.has(9)).toBe(false);
  });

  it("a content_calendar row with no calendar key at all does NOT complete step 9", async () => {
    const project = await seedProjectWithPlatforms();
    await seedThroughStep7(project.id);
    await getDb()
      .insert(stepContents)
      .values({ projectId: project.id, step: "content_calendar", content: {} });

    expect((await getWizardStatus(project.id)).completed.has(9)).toBe(false);
  });

  it("a pre-T29 single-table calendar still completes step 9", async () => {
    // Rows written before the per-platform split use { calendar: string }.
    // Reading only the new shape would silently un-tick a finished project.
    const project = await seedProjectWithPlatforms();
    await seedThroughStep7(project.id);
    await getDb()
      .insert(stepContents)
      .values({
        projectId: project.id,
        step: "content_calendar",
        content: { calendar: "| Day | Post |\n| --- | --- |\n| Day 1 | x |" },
      });

    expect((await getWizardStatus(project.id)).completed.has(9)).toBe(true);
  });

  it("a non-empty calendar string completes step 9, current stays 9", async () => {
    const project = await seedProjectWithPlatforms();
    await seedThroughStep7(project.id);
    await getDb()
      .insert(stepContents)
      .values({
        projectId: project.id,
        step: "content_calendar",
        content: { calendar: "| Day | Post |\n| --- | --- |\n| Day 1 | x |" },
      });

    const status = await getWizardStatus(project.id);
    expect(status.completed.has(9)).toBe(true);
    expect(status.current).toBe(9);
  });
});
