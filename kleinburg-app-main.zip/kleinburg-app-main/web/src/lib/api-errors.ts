import { NextResponse } from "next/server";

import type { ApiErrorCode } from "@/core/errors/codes";
import { describeErrorForLog } from "@/core/errors/redact";
import { SpendCapExceededError, capRefusalDetails } from "@/core/llm/cap";
import {
  AccessError,
  ConflictError,
  NotFoundError,
  TooManyAttemptsError,
  ValidationError,
} from "@/core/tenancy/errors";

/**
 * The shape EVERY deliberate API failure returns:
 *  - `error` — the Turkish message, the honest server-side truth (hard rule 5).
 *  - `code`  — a stable identifier the client maps to interface-language copy
 *    (see lib/api-error-copy.ts). Turkish is never string-matched on the client.
 *
 * Both are always present, so a client that does not know a code still has a
 * real message to show instead of a blank box.
 */
export interface ApiErrorBody {
  error: string;
  code: ApiErrorCode;
  /**
   * Facts the code's own copy interpolates, when a failure has any (#51
   * review, finding 3).
   *
   * A code alone can only ever produce a generic sentence, and for some
   * failures the generic sentence drops the very thing the operator needs —
   * which cap, how much was spent, when it resets. So the numbers travel and
   * the CATALOG writes the sentence, which keeps the interface language
   * without losing the facts.
   *
   * Values only, never prose: nothing here is displayed unless a message in
   * the catalog names it as a placeholder, so this cannot become a second,
   * untranslated channel for server text.
   */
  details?: Record<string, string | number>;
}

/** Build the standard error body + response in one place. */
export function apiError(
  error: string,
  code: ApiErrorCode,
  status: number,
  details?: Record<string, string | number>,
): NextResponse<ApiErrorBody> {
  return NextResponse.json(
    details ? { error, code, details } : { error, code },
    { status },
  );
}

/**
 * Map a thrown error to an HTTP JSON response.
 *  - AccessError     -> 403
 *  - NotFoundError   -> 404
 *  - ValidationError -> 400 (surfacing its deliberate message)
 *  - ConflictError   -> 409 (surfacing its deliberate message)
 *  - TooManyAttemptsError -> 429 (surfacing its deliberate message)
 *  - anything else   -> 500 generic (message NOT echoed — could be an infra
 *    error leaking internals; honest 5xx per hard rule 5) AND logged, see below
 *
 * Only errors we deliberately own surface their message; unexpected throws
 * become an honest, opaque 500 with code UNEXPECTED.
 *
 * ── WHY THE 500 BRANCH LOGS ──────────────────────────────────────────────
 * The four branches above hand the operator a real reason in the response
 * itself. The fifth does not — and used to discard `e` entirely, so an
 * exhausted pool or a surprise constraint violation produced "Beklenmeyen
 * hata" on screen and NOTHING anywhere else. That is the silent swallow hard
 * rule 5 forbids, so the unexpected case (and only the unexpected case) writes
 * a line to the server log.
 *
 * It logs `describeErrorForLog(e)`, never `e`. That helper reads only
 * name/message/stack and masks credential shapes, so this path cannot become
 * the way a password reaches a log file. See core/errors/redact.ts.
 */
export function errorResponse(e: unknown): NextResponse<ApiErrorBody> {
  if (e instanceof AccessError) return apiError(e.message, e.code, 403);
  if (e instanceof NotFoundError) return apiError(e.message, e.code, 404);
  if (e instanceof ValidationError) return apiError(e.message, e.code, 400);
  // Before the general ConflictError branch, because it is one, and because it
  // is the one failure so far that carries facts its copy needs. See
  // `capRefusalDetails` for why the facts travel instead of the sentence.
  if (e instanceof SpendCapExceededError) {
    return apiError(e.message, e.code, 409, capRefusalDetails(e.status));
  }
  if (e instanceof ConflictError) return apiError(e.message, e.code, 409);
  if (e instanceof TooManyAttemptsError) {
    return apiError(e.message, e.code, 429);
  }
  console.error("[api] unexpected error ->", describeErrorForLog(e));
  return apiError("Beklenmeyen hata", "UNEXPECTED", 500);
}
