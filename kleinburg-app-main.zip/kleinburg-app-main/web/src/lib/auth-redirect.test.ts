import { describe, expect, it } from "vitest";

import { signedInDestination } from "./auth-redirect";

/**
 * T45. The root URL is the login page, so it has to decide where an ALREADY
 * signed-in visitor goes. The danger is not the happy path — it is quietly
 * routing around the forced password change (T40): a user still holding an
 * admin-set temporary password must land on /change-password, never on
 * /projects, no matter which public entry point they arrive at.
 */
describe("signedInDestination", () => {
  it("sends a signed-out visitor nowhere (they stay on the login page)", () => {
    expect(signedInDestination(null)).toBeNull();
  });

  it("sends a normal signed-in user to their projects", () => {
    expect(signedInDestination({ mustChangePassword: false })).toBe("/projects");
  });

  it("sends a user who owes a password change to /change-password", () => {
    expect(signedInDestination({ mustChangePassword: true })).toBe(
      "/change-password",
    );
  });
});
