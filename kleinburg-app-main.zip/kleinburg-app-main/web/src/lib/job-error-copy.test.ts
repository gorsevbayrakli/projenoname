import { describe, expect, it } from "vitest";

import en from "../../messages/en.json";
import tr from "../../messages/tr.json";
import { jobErrorCopy as mapCopy, type JobErrorTranslator } from "./job-error-copy";

/**
 * The contract that matters here is hard rule 5: friendlier copy NEVER replaces
 * the truth. Every mapped class must keep the raw reason reachable — either as
 * `reason`, or because `message` IS the raw text.
 *
 * T25 made the mapper locale-aware by taking a translator. The assertions below
 * are UNCHANGED — they still assert the exact Turkish sentences a user reads —
 * but the expected text now comes from the real tr.json catalog via this
 * translator, so the test additionally proves the catalog is wired up.
 */
const t: JobErrorTranslator = (key) => {
  if (key.startsWith("precondition.")) {
    return tr.jobError.precondition[
      key.slice("precondition.".length) as keyof typeof tr.jobError.precondition
    ];
  }
  return tr.jobError[key as "fallback" | "missingApiKey" | "schema" | "transient"];
};

/** The Turkish-locale mapper, matching the pre-T25 single-argument signature. */
const jobErrorCopy = (raw: string | null | undefined) => mapCopy(raw, t);

describe("jobErrorCopy", () => {
  it("maps a schema violation to plain copy and keeps the raw reason", () => {
    const raw = "Model çıktısı beklenen şemaya uymadı";
    const copy = jobErrorCopy(raw);

    expect(copy.message).toBe(
      "Model beklenen yapıda içerik üretmedi. Tekrar deneyin; sorun sürerse adım girdilerini gözden geçirin.",
    );
    expect(copy.reason).toBe(raw);
    expect(copy.stepNumber).toBeUndefined();
  });

  it("maps invalid JSON and empty content to the same schema copy", () => {
    expect(jobErrorCopy("Model çıktısı geçerli JSON değil").message).toContain(
      "beklenen yapıda içerik üretmedi",
    );
    expect(jobErrorCopy("Model boş içerik döndürdü").reason).toBe(
      "Model boş içerik döndürdü",
    );
  });

  it("maps a missing API key to a configuration message, reason retained", () => {
    const raw = "OPENROUTER_API_KEY tanımlı değil";
    const copy = jobErrorCopy(raw);

    expect(copy.message).toBe(
      "Yapay zekâ servisi yapılandırılmamış. Yöneticinizle görüşün.",
    );
    expect(copy.reason).toBe(raw);
  });

  it("translates precondition errors, keeps the raw reason and the step", () => {
    // The friendly line comes from the catalog (so an English user reads
    // English); the engine's own sentence survives as `reason`.
    expect(jobErrorCopy("Önce marka bağlamı üretilmeli")).toEqual({
      message: "Önce marka bağlamı üretilmeli.",
      reason: "Önce marka bağlamı üretilmeli",
      stepNumber: 2,
    });
    expect(jobErrorCopy("Önce içerik sütunları üretilmeli").reason).toBe(
      "Önce içerik sütunları üretilmeli",
    );
    expect(jobErrorCopy("Önce ikincil veri üretilmeli").stepNumber).toBe(3);
    expect(jobErrorCopy("Önce kullanıcı girdisi sağlanmalı").stepNumber).toBe(4);
    expect(jobErrorCopy("Önce yaratıcı kıvılcımlar üretilmeli").stepNumber).toBe(
      5,
    );
    expect(jobErrorCopy("Önce içerik sütunları üretilmeli").stepNumber).toBe(6);
    expect(
      jobErrorCopy("Önce sosyal medya gönderileri üretilmeli").stepNumber,
    ).toBe(7);
  });

  it("maps transient/network failures, reason retained", () => {
    const raw = "OpenRouter isteği 3 denemeden sonra başarısız oldu: ETIMEDOUT";
    const copy = jobErrorCopy(raw);

    expect(copy.message).toBe("Bağlantı sorunu. Tekrar deneyin.");
    expect(copy.reason).toBe(raw);

    expect(jobErrorCopy("Bağlantı kesildi").message).toBe(
      "Bağlantı sorunu. Tekrar deneyin.",
    );
    expect(jobErrorCopy("Ağ hatası, tekrar deneyin").reason).toBe(
      "Ağ hatası, tekrar deneyin",
    );
  });

  it("shows an unknown error raw rather than inventing friendlier copy", () => {
    const raw = "Beklenmedik bir şey oldu: ECONNRESET at layer 8";
    const copy = jobErrorCopy(raw);

    expect(copy.message).toBe(raw);
    // No duplicated second line when the message already is the raw text.
    expect(copy.reason).toBeUndefined();
  });

  it("translates preconditions into EN when given the EN catalog", () => {
    const copy = mapCopy("Önce ikincil veri üretilmeli", (key) =>
      key.startsWith("precondition.")
        ? en.jobError.precondition[
            key.slice(
              "precondition.".length,
            ) as keyof typeof en.jobError.precondition
          ]
        : en.jobError[key as "fallback" | "missingApiKey" | "schema" | "transient"],
    );
    expect(copy.message).toBe("The secondary data must be generated first.");
    // Hard rule 5: the engine's Turkish is still on screen as the reason.
    expect(copy.reason).toBe("Önce ikincil veri üretilmeli");
    expect(copy.stepNumber).toBe(3);
  });

  it("falls back to a stated failure when there is no message at all", () => {
    expect(jobErrorCopy(null).message).toBe("Üretim başarısız oldu.");
    expect(jobErrorCopy("   ").message).toBe("Üretim başarısız oldu.");
  });
});
