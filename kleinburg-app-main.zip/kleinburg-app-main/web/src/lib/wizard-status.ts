import { eq } from "drizzle-orm";

import { getDb } from "@/core/db/client";
import { documents, projects, stepContents } from "@/core/db/schema";
import { TOTAL_STEPS, WIZARD_STEPS } from "./workflow-steps";

/**
 * Legacy guard: the secondary-data step refuses a brand context shorter than
 * this. We enforce it as step 2's completion rule, which (via the T13
 * forward-lock redirect) automatically keeps step 3 locked until the brand
 * context is long enough — no separate guard needed.
 */
export const MIN_BRAND_CONTEXT_CHARS = 200;

/** The state each completion predicate reads: documents/row existence, content + selections. */
type StepFacts = {
  hasDocuments: boolean;
  content: unknown;
  hasRow: boolean;
  selections: unknown;
  platforms: string[];
};

/**
 * Per-step completion predicates, keyed by WizardStep.key. Steps not listed
 * here fall back to plain row-existence (the default for the content steps, refined by
 * their own tasks T16–T21). Structured this way so a step's rule is one entry.
 */
const COMPLETION: Record<string, (f: StepFacts) => boolean> = {
  // Step 1: the project has ≥1 documents row.
  documents: (f) => f.hasDocuments,
  // Step 2: a brand_context row whose content.brandContext is ≥ 200 chars.
  brand_context: (f) => brandContextLength(f.content) >= MIN_BRAND_CONTEXT_CHARS,
  // Step 3: a secondary_data row with ≥1 selected index (legacy "pick at least
  // one" gate). This forward-locks step 4 until a selection is made.
  secondary_data: (f) => selectedCount(f.selections) >= 1,
  // Step 6: at least one platform chosen (T29). Read from projects.platforms,
  // not step_contents — the platform set is a property of the project. This
  // forward-locks step 7, which is the point: the pillars are generated FOR the
  // chosen platforms, so generating them with none chosen is meaningless.
  platforms: (f) => f.platforms.length >= 1,
  // Step 5: a creative_sparks row with ≥1 selected index — identical rule to
  // secondary_data, because the SELECTED sparks are what feed the sm_pillars
  // prompt. This forward-locks step 6 until a selection is made.
  creative_sparks: (f) => selectedCount(f.selections) >= 1,
  // Step 7: an sm_pillars row with ≥1 PERSISTED selected index — the selected
  // pillars are what feed the sm_posts prompt.
  //
  // This predicate has always read persistence. It used to be deliberately
  // SPLIT from the step-7 UI, which opened with nothing checked under legacy's
  // "pick consciously every time" rule, so the rail and the page could disagree
  // about whether step 7 was done. The product owner removed that rule on
  // 2026-07-21 and the UI now seeds its checkboxes from the same persisted
  // selection, so the two halves simply agree. Nothing here changed; what
  // changed is that it no longer needs defending as a discrepancy. See
  // sm-pillars-step.tsx for the full rationale.
  sm_pillars: (f) => selectedCount(f.selections) >= 1,
  // Step 8: an sm_posts row whose content.posts has ≥1 entry. Row-existence
  // alone is not enough — the content_calendar step (9) is grounded in the
  // posts, so an empty posts array means step 8 has nothing to work from. Note
  // there is no selection gate here: the posts are ALL used, and the platform
  // slices (instagram/facebook) both count toward the same ≥1 rule.
  sm_posts: (f) => postsCount(f.content) >= 1,
  // Step 9: a content_calendar row with at least one NON-EMPTY table. A job
  // that produced only empty strings gives the step 9 UI nothing to render or
  // export, and the rail must not claim it is done. This is the last step, so
  // `current` stays at TOTAL_STEPS either way; the predicate only drives the ✓.
  content_calendar: (f) => calendarRowCount(f.content) > 0,
};

/**
 * How many scheduled posts the calendar holds, across every platform.
 *
 * Accepts all three shapes this field has had: structured rows (current),
 * one markdown table per platform (T29), and a single merged table (pre-T29).
 * A project generated under an older shape must keep its ✓ rather than look
 * unfinished because the schema moved on.
 */
function calendarRowCount(content: unknown): number {
  if (!content || typeof content !== "object") return 0;

  const list = (content as { calendars?: unknown }).calendars;
  if (Array.isArray(list)) {
    return list.reduce<number>((total, entry) => {
      if (!entry || typeof entry !== "object") return total;
      const { rows, calendar } = entry as { rows?: unknown; calendar?: unknown };
      if (Array.isArray(rows)) return total + rows.length;
      // A pre-T33 markdown table counts as one non-empty calendar.
      if (typeof calendar === "string" && calendar.trim() !== "") return total + 1;
      return total;
    }, 0);
  }

  const legacy = (content as { calendar?: unknown }).calendar;
  return typeof legacy === "string" && legacy.trim() !== "" ? 1 : 0;
}

/** Number of entries in content.posts, safe on malformed content. */
function postsCount(content: unknown): number {
  if (
    content &&
    typeof content === "object" &&
    "posts" in content &&
    Array.isArray((content as { posts: unknown }).posts)
  ) {
    return (content as { posts: unknown[] }).posts.length;
  }
  return 0;
}

/** Number of selected indices in a selections jsonb value, safe on malformed input. */
function selectedCount(selections: unknown): number {
  if (
    selections &&
    typeof selections === "object" &&
    "selectedIndices" in selections &&
    Array.isArray((selections as { selectedIndices: unknown }).selectedIndices)
  ) {
    return (selections as { selectedIndices: unknown[] }).selectedIndices.length;
  }
  return 0;
}

/** Length of content.brandContext when it is a string, else 0. */
function brandContextLength(content: unknown): number {
  if (
    content &&
    typeof content === "object" &&
    "brandContext" in content &&
    typeof (content as { brandContext: unknown }).brandContext === "string"
  ) {
    return (content as { brandContext: string }).brandContext.length;
  }
  return 0;
}

/**
 * Wizard position derived from persisted data (spec acceptance:
 * "adım durumu step_contents'ten türetilir"). Server-only (touches the DB).
 *
 * A step is "completed" per its predicate in COMPLETION (default: a
 * step_contents row exists for its workflow_step key). `current` is the first
 * step that is NOT completed, or TOTAL_STEPS when every step is done. Callers
 * gate forward navigation on `current` (back is free).
 *
 * This does NOT enforce access; callers must have already passed
 * requireProjectAccess for the project.
 */
export async function getWizardStatus(
  projectId: string,
): Promise<{ completed: Set<number>; current: number }> {
  const db = getDb();

  const [docRows, stepRows, projectRows] = await Promise.all([
    db
      .select({ id: documents.id })
      .from(documents)
      .where(eq(documents.projectId, projectId))
      .limit(1),
    db
      .select({
        step: stepContents.step,
        content: stepContents.content,
        selections: stepContents.selections,
      })
      .from(stepContents)
      .where(eq(stepContents.projectId, projectId)),
    db
      .select({ platforms: projects.platforms })
      .from(projects)
      .where(eq(projects.id, projectId))
      .limit(1),
  ]);

  const hasDocuments = docRows.length > 0;
  const platforms = projectRows[0]?.platforms ?? [];
  const rowByKey = new Map<string, { content: unknown; selections: unknown }>(
    stepRows.map((r) => [
      r.step as string,
      { content: r.content, selections: r.selections },
    ]),
  );

  const completed = new Set<number>();
  for (const step of WIZARD_STEPS) {
    const row = rowByKey.get(step.key);
    const facts: StepFacts = {
      hasDocuments,
      platforms,
      content: row?.content,
      hasRow: rowByKey.has(step.key),
      selections: row?.selections,
    };
    const predicate = COMPLETION[step.key] ?? ((f: StepFacts) => f.hasRow);
    if (predicate(facts)) completed.add(step.n);
  }

  let current = TOTAL_STEPS;
  for (const step of WIZARD_STEPS) {
    if (!completed.has(step.n)) {
      current = step.n;
      break;
    }
  }

  return { completed, current };
}
