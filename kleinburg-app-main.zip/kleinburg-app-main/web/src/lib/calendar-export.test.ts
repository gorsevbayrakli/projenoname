import { describe, expect, it } from "vitest";

import {
  calendarFilename,
  sanitizeSheetName,
  slugify,
  toCsv,
  toXlsxWorkbookBlob,
  uniqueSheetNames,
} from "./calendar-export";

const BOM = "﻿";

describe("toCsv", () => {
  it("prepends a UTF-8 BOM and joins rows with CRLF", () => {
    const csv = toCsv(["Day", "Post"], [["Day 1", "Merhaba"]]);
    expect(csv.startsWith(BOM)).toBe(true);
    expect(csv).toBe(`${BOM}Day,Post\r\nDay 1,Merhaba`);
  });

  it("quotes cells containing a comma, a quote or a newline", () => {
    const csv = toCsv(
      ["a", "b", "c"],
      [["x, y", 'he said "hi"', "line1\nline2"]],
    );
    const body = csv.slice(BOM.length).split("\r\n")[1];
    expect(body).toBe('"x, y","he said ""hi""","line1\nline2"');
  });

  it("leaves plain cells unquoted", () => {
    const csv = toCsv(["a"], [["plain"], ["ş-ğ-ı"]]);
    expect(csv.slice(BOM.length)).toBe("a\r\nplain\r\nş-ğ-ı");
  });

  it("keeps Turkish characters verbatim (the BOM is what makes Excel read them)", () => {
    const csv = toCsv(["Gün"], [["Şişli'de güzel bir gün"]]);
    expect(csv).toContain("Şişli'de güzel bir gün");
    expect(csv.codePointAt(0)).toBe(0xfeff);
  });

  it("handles a table with no data rows", () => {
    expect(toCsv(["a", "b"], [])).toBe(`${BOM}a,b`);
  });
});

describe("slugify", () => {
  it("transliterates Turkish characters instead of dropping them", () => {
    expect(slugify("Kleinburg Türkiye")).toBe("kleinburg-turkiye");
    expect(slugify("Şişli Ilıca Çağ")).toBe("sisli-ilica-cag");
    expect(slugify("İstanbul")).toBe("istanbul");
  });

  it("strips other diacritics and punctuation, collapsing separators", () => {
    expect(slugify("Café  —  Naïve!")).toBe("cafe-naive");
  });

  it("returns an empty string for nothing usable", () => {
    expect(slugify("!!!")).toBe("");
    expect(slugify("")).toBe("");
  });
});

describe("calendarFilename", () => {
  it("builds marka-proje-dil.ext", () => {
    expect(calendarFilename("Kleinburg", "Yaz Kampanyası", "tr", "csv")).toBe(
      "kleinburg-yaz-kampanyasi-tr.csv",
    );
    expect(calendarFilename("Kleinburg", "Yaz Kampanyası", "tr", "xlsx")).toBe(
      "kleinburg-yaz-kampanyasi-tr.xlsx",
    );
  });

  it("skips parts that slugify to nothing", () => {
    expect(calendarFilename("Kleinburg", "***", "en", "csv")).toBe(
      "kleinburg-en.csv",
    );
  });

  it("falls back to a generic stem when every part is unusable", () => {
    expect(calendarFilename("", "", "", "csv")).toBe("icerik-takvimi.csv");
  });
});

describe("sanitizeSheetName", () => {
  it("removes the characters Excel forbids in a sheet name", () => {
    expect(sanitizeSheetName("In:sta/gram?*[x]")).toBe("Instagramx");
  });

  it("caps the name at Excel's 31-character limit", () => {
    const name = sanitizeSheetName("A".repeat(40));
    expect(name).toHaveLength(31);
    expect(name).toBe("A".repeat(31));
  });

  it("collapses whitespace and trims apostrophes Excel rejects at the edges", () => {
    expect(sanitizeSheetName("  'Yaz   Kampanyası'  ")).toBe("Yaz Kampanyası");
  });

  it("falls back rather than returning an empty (invalid) name", () => {
    expect(sanitizeSheetName("[]")).toBe("Sheet");
    expect(sanitizeSheetName("")).toBe("Sheet");
  });

  it("never cuts an astral character in half when truncating", () => {
    // A plain .slice(0, 31) here would end in a LONE HIGH SURROGATE, which
    // SheetJS writes out as U+FFFD — silently merging names that differ.
    const name = sanitizeSheetName("A".repeat(30) + "\u{1F600}");
    expect(hasLoneSurrogate(name)).toBe(false);
    // The whole character is dropped rather than half-kept: it would have taken
    // the name to 32 code units, past Excel's (and SheetJS's) hard limit.
    expect(name).toBe("A".repeat(30));
    expect(name.length).toBeLessThanOrEqual(31);
  });

  it("strips C0 control characters, which SheetJS would escape to _x0001_", () => {
    // Not covered by \s: they would survive into the tab as literal
    // "Insta_x0001_gram" AND push the name past the 31-character cap.
    expect(sanitizeSheetName("Insta\u0001gram")).toBe("Instagram");
    expect(sanitizeSheetName("\u0000\u001fInstagram")).toBe("Instagram");
    // The whitespace controls still collapse to a space rather than vanishing.
    expect(sanitizeSheetName("Insta\tgram")).toBe("Insta gram");
  });

  it("renames Excel's reserved sheet name, case-insensitively", () => {
    expect(sanitizeSheetName("History")).toBe("History_");
    expect(sanitizeSheetName("history")).toBe("history_");
    expect(sanitizeSheetName("  'HISTORY'  ")).toBe("HISTORY_");
    // Only the exact reserved name; a name that merely contains it is fine.
    expect(sanitizeSheetName("History of Us")).toBe("History of Us");
  });
});

/** True if `s` contains an unpaired surrogate (i.e. a truncation that split a pair). */
function hasLoneSurrogate(s: string): boolean {
  for (let i = 0; i < s.length; i += 1) {
    const code = s.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = s.charCodeAt(i + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) return true;
      i += 1;
    } else if (code >= 0xdc00 && code <= 0xdfff) {
      return true;
    }
  }
  return false;
}

describe("uniqueSheetNames", () => {
  it("leaves distinct names alone", () => {
    expect(uniqueSheetNames(["Instagram", "Facebook"])).toEqual([
      "Instagram",
      "Facebook",
    ]);
  });

  it("de-duplicates collisions with a ~n suffix, case-insensitively", () => {
    expect(uniqueSheetNames(["Instagram", "instagram", "Instagram"])).toEqual([
      "Instagram",
      "instagram~2",
      "Instagram~3",
    ]);
  });

  it("de-duplicates names that only collide AFTER truncation", () => {
    // Both truncate to the same 31 characters; without the suffix Excel would
    // reject the workbook outright.
    const long = "A".repeat(31);
    expect(uniqueSheetNames([`${long}one`, `${long}two`])).toEqual([
      long,
      `${"A".repeat(29)}~2`,
    ]);
  });

  it("keeps names distinct when they differ only in a trailing astral character", () => {
    // The dangerous pair: two names identical for 30 characters, differing only
    // in an emoji vs. an astral CJK ideograph at the end. Truncated by code
    // unit they would each end in a DIFFERENT lone high surrogate — different
    // enough for the de-dup below to leave both alone, identical once SheetJS
    // encodes both to U+FFFD, i.e. a workbook with two same-named sheets.
    const prefix = "A".repeat(30);
    const names = uniqueSheetNames([`${prefix}\u{1F600}`, `${prefix}\u{20000}`]);
    expect(new Set(names).size).toBe(2);
    for (const n of names) {
      expect(hasLoneSurrogate(n)).toBe(false);
      expect(n.length).toBeLessThanOrEqual(31);
    }
  });

  it("keeps every de-duplicated name within the 31-character limit", () => {
    const names = uniqueSheetNames(Array.from({ length: 3 }, () => "B".repeat(35)));
    for (const n of names) expect(n.length).toBeLessThanOrEqual(31);
    expect(new Set(names).size).toBe(3);
  });
});

const CAL_HEADERS = [
  "Gün",
  "Format",
  "Sütun",
  "Kanca",
  "Metin",
  "Harekete çağrı",
  "Etiketler",
];

function calRow(day: string, caption: string): string[] {
  return [day, "Reel", "İlham", "Kanca", caption, "Kaydet", "#etiket"];
}

/** Parse a produced workbook back. Safe here: the input is our own fixture. */
async function readBack(blob: Blob) {
  const XLSX = await import("xlsx");
  const buffer = new Uint8Array(await blob.arrayBuffer());
  // cellStyles: without it the reader does not repopulate `!cols`, so the
  // column-width assertion below would have nothing to check.
  return XLSX.read(buffer, { type: "array", cellStyles: true });
}

describe("toXlsxWorkbookBlob", () => {
  it("writes one worksheet per entry, in order, with the real cells", async () => {
    const blob = await toXlsxWorkbookBlob([
      {
        name: "Instagram",
        headers: CAL_HEADERS,
        rows: [calRow("Day 1", "Şişli'de güzel bir gün")],
      },
      {
        name: "Facebook",
        headers: CAL_HEADERS,
        rows: [calRow("Day 2", "Facebook metni")],
      },
    ]);

    const book = await readBack(blob);
    expect(book.SheetNames).toEqual(["Instagram", "Facebook"]);

    const ig = book.Sheets["Instagram"];
    expect(ig["A1"].v).toBe("Gün");
    expect(ig["A2"].v).toBe("Day 1");
    // Turkish text survives, and the long caption keeps its own column.
    expect(ig["E2"].v).toBe("Şişli'de güzel bir gün");
    expect(ig["G2"].v).toBe("#etiket");

    const fb = book.Sheets["Facebook"];
    expect(fb["A2"].v).toBe("Day 2");
    expect(fb["E2"].v).toBe("Facebook metni");
  });

  it("sizes the columns for the T33 layout (Caption widest, Hashtags short)", async () => {
    const blob = await toXlsxWorkbookBlob([
      { name: "Instagram", headers: CAL_HEADERS, rows: [calRow("Day 1", "x")] },
    ]);

    const book = await readBack(blob);
    const cols = book.Sheets["Instagram"]["!cols"];
    expect(cols?.map((c) => c?.wch)).toEqual([12, 14, 18, 40, 80, 28, 24]);
  });

  it("truncates, strips illegal characters and de-duplicates the tab names", async () => {
    const blob = await toXlsxWorkbookBlob([
      { name: "My/Platform:1", headers: ["a"], rows: [["1"]] },
      { name: "C".repeat(40), headers: ["a"], rows: [["2"]] },
      { name: "C".repeat(40), headers: ["a"], rows: [["3"]] },
    ]);

    const book = await readBack(blob);
    expect(book.SheetNames).toEqual([
      "MyPlatform1",
      "C".repeat(31),
      `${"C".repeat(29)}~2`,
    ]);
    expect(book.Sheets[`${"C".repeat(29)}~2`]["A2"].v).toBe("3");
  });

  it("falls back to a uniform width when the header set is not the T33 layout", async () => {
    // The guard against silent mis-sizing: with a different number of headers
    // the per-index widths no longer describe these columns, so every column
    // gets DEFAULT_COLUMN_WIDTH rather than a Caption-sized column landing on
    // whatever happens to sit at index 4.
    const blob = await toXlsxWorkbookBlob([
      { name: "Instagram", headers: ["a", "b", "c"], rows: [["1", "2", "3"]] },
    ]);

    const book = await readBack(blob);
    expect(book.Sheets["Instagram"]["!cols"]?.map((c) => c?.wch)).toEqual([
      18, 18, 18,
    ]);
  });

  it("writes two readable sheets for names differing only in a trailing emoji", async () => {
    // End to end: the pair that used to encode down to the same U+FFFD-ended
    // name must still produce two separately addressable worksheets.
    const prefix = "A".repeat(30);
    const blob = await toXlsxWorkbookBlob([
      { name: `${prefix}\u{1F600}`, headers: ["a"], rows: [["1"]] },
      { name: `${prefix}\u{20000}`, headers: ["a"], rows: [["2"]] },
    ]);

    const book = await readBack(blob);
    expect(new Set(book.SheetNames).size).toBe(2);
    expect(book.SheetNames.some((n) => n.includes("�"))).toBe(false);
    const values = book.SheetNames.map((n) => book.Sheets[n]["A2"].v);
    expect(values).toEqual(["1", "2"]);
  });

  it("throws rather than writing a workbook with no sheets", async () => {
    await expect(toXlsxWorkbookBlob([])).rejects.toThrow(
      /at least one sheet is required/,
    );
  });

  it("produces a real xlsx blob (zip container, xlsx mime type)", async () => {
    const blob = await toXlsxWorkbookBlob([
      { name: "Instagram", headers: CAL_HEADERS, rows: [calRow("Day 1", "x")] },
    ]);
    expect(blob.type).toContain("spreadsheetml.sheet");
    const bytes = new Uint8Array(await blob.arrayBuffer());
    expect([bytes[0], bytes[1]]).toEqual([0x50, 0x4b]);
  });
});

describe("toCsv — formula injection", () => {
  it("neutralizes cells that would execute as formulas in Excel", () => {
    const csv = toCsv(["Post"], [["=HYPERLINK(\"http://evil\",\"x\")"], ["+1"], ["-5"], ["@cmd"]]);
    expect(csv).toContain("'=HYPERLINK");
    expect(csv).toContain("'+1");
    expect(csv).toContain("'-5");
    expect(csv).toContain("'@cmd");
  });

  it("leaves ordinary cells untouched", () => {
    expect(toCsv(["Post"], [["Yaz kampanyası"]])).toContain("Yaz kampanyası");
  });
});
