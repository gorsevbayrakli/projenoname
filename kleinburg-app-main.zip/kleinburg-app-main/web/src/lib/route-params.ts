import type { NextResponse } from "next/server";
import { z } from "zod";

import { apiError, type ApiErrorBody } from "./api-errors";

const uuidSchema = z.string().uuid();

/**
 * Validate the `[id]`-style path segments of a dynamic route (#64).
 *
 * ── WHY THIS EXISTS ──────────────────────────────────────────────────────
 * Every path segment named `id` / `documentId` ends up in a Drizzle comparison
 * against a `uuid` column. Postgres answers a non-UUID string with SQLSTATE
 * 22P02, which is none of the classes `errorResponse` owns, so it fell through
 * to the generic branch: the caller got a 500 UNEXPECTED for what is plainly a
 * client input error, and every malformed URL wrote a `console.error` line the
 * operator then had to triage. An id arriving in a BODY has always been
 * `.uuid()`-checked (projects POST, admin/users/[id]/brands), so the gap was an
 * oversight, and this gives the path-borne ones the same treatment.
 *
 * ── WHY A SHARED HELPER RATHER THAN THE PARSE REPEATED ───────────────────
 * There are ~15 handlers across projects, documents, steps, jobs and admin.
 * Spelled out in each of them, the check drifts: one route returns 404, another
 * 400, a new route forgets it entirely. One function means one answer.
 *
 * ── RETURNS ──────────────────────────────────────────────────────────────
 * `null` when every value is a UUID — the caller proceeds. Otherwise the
 * ready-made 400 response, so the call site is two lines:
 *
 *   const { id } = await ctx.params;
 *   const invalid = invalidUuidParams(id);
 *   if (invalid) return invalid;
 *
 * ── WHAT IT DELIBERATELY DOES NOT DO ─────────────────────────────────────
 * It does not say WHICH segment was malformed, and it does not run before the
 * auth gate. A well-formed id and a malformed one must look the same to an
 * unauthenticated caller, so `requireApiUser` / `requireApiAdmin` stays first
 * in every handler and this check sits immediately after `await ctx.params`.
 * The generic "Geçersiz istek" is the same message a bad body already gets.
 */
export function invalidUuidParams(
  ...values: string[]
): NextResponse<ApiErrorBody> | null {
  const allValid = values.every((v) => uuidSchema.safeParse(v).success);
  return allValid ? null : apiError("Geçersiz istek", "INVALID_REQUEST", 400);
}
