import { describe, expect, it } from "vitest";

import { extractSelectedIndices } from "./selected-indices";

describe("extractSelectedIndices", () => {
  it("returns [] for missing / malformed selections", () => {
    expect(extractSelectedIndices(null, 3)).toEqual([]);
    expect(extractSelectedIndices(undefined, 3)).toEqual([]);
    expect(extractSelectedIndices({}, 3)).toEqual([]);
    expect(extractSelectedIndices({ selectedIndices: "0,1" }, 3)).toEqual([]);
    expect(extractSelectedIndices("nope", 3)).toEqual([]);
  });

  it("returns the stored indices", () => {
    expect(extractSelectedIndices({ selectedIndices: [0, 2] }, 3)).toEqual([
      0, 2,
    ]);
  });

  it("drops indices that no longer address an item", () => {
    // The whole point of the itemCount clamp: content that shrank must not
    // leave a selection pointing past the end (which would inflate the counter
    // and mark cards that do not exist).
    expect(
      extractSelectedIndices({ selectedIndices: [0, 5, -1, 1.5, "2"] }, 3),
    ).toEqual([0]);
  });

  it("clamps everything away when there are no items", () => {
    expect(extractSelectedIndices({ selectedIndices: [0, 1] }, 0)).toEqual([]);
  });
});
