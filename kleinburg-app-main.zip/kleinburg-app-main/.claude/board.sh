#!/bin/bash
# Usage: board.sh <issue-number> <Todo|In Progress|Done>
#
# GitHub Project (number 3, owner elifc) üstünde bir issue'nun durum sütununu değiştirir.
# 24 Tem 2026: repo elifc/kleinburg-app'e taşındıktan sonra proje hem eski fork'un (kleinburg,
# arşiv) hem yeni reponun (kleinburg-app) issue'larını içeriyor ve NUMARALAR ÇAKIŞIYOR
# (eski #3 = T3, yeni #3 = maxTokens). Bu yüzden sorgu repo'ya göre FİLTRELİ: sadece
# elifc/kleinburg-app. Yeni bir aktif issue board'da yoksa: gh project item-add 3 --owner elifc --url <issue-url>
PROJECT_ID="PVT_kwHOALRtcs4BdyOi"
FIELD_ID="PVTSSF_lAHOALRtcs4BdyOizhYRP9g"
REPO="elifc/kleinburg-app"
case "$2" in
  Todo) OPT="f75ad846";;
  "In Progress") OPT="47fc9ee4";;
  Done) OPT="98236657";;
  *) echo "bad status"; exit 1;;
esac
ITEM_ID=$(gh api graphql -f query='query{user(login:"elifc"){projectV2(number:3){items(first:100){nodes{id content{... on Issue{number repository{nameWithOwner}}}}}}}}' --jq ".data.user.projectV2.items.nodes[] | select(.content.number==$1 and .content.repository.nameWithOwner==\"$REPO\") | .id")
if [ -z "$ITEM_ID" ]; then echo "issue #$1 ($REPO) board'da yok — önce ekle: gh project item-add 3 --owner elifc --url https://github.com/$REPO/issues/$1"; exit 1; fi
gh api graphql -f query="mutation{updateProjectV2ItemFieldValue(input:{projectId:\"$PROJECT_ID\",itemId:\"$ITEM_ID\",fieldId:\"$FIELD_ID\",value:{singleSelectOptionId:\"$OPT\"}}){projectV2Item{id}}}" >/dev/null && echo "#$1 -> $2"
