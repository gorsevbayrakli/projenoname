# Çok Dilli Üretim Denetimi — RUBRIC (taslak, Elif onayına)

- **Tarih:** 2026-07-24 · **İlgili:** [#17](https://github.com/elifc/kleinburg-app/issues/17) · Spec: `2026-07-24-multilang-content-audit-design.md`
- **Durum:** TASLAK — Elif onayı bekliyor. Bu, kodun okuyacağı rubric'in insan-okunur kaynağıdır.

---

## 0. "Bilmediğim dilde nasıl onaylarım?" — bu rubric'in cevabı

Sen bir Almanca cümlenin iyi Almanca olup olmadığını bilemezsin — **bu normal, kimse tek başına
4 dili denetleyemez.** Rubric bu yüzden işi ikiye ayırır:

1. **Senin onayladığın şey = KRİTERLER (bu doküman).** "Resmiyet tutarlı olmalı", "marka
   yasak-kelimeleri geçmemeli", "çeviri gibi durmamalı" — bunlar **editoryal/iş kararları**,
   dil bilgisi değil. Bunları sen tam yetkiyle onaylarsın.
2. **Judge'ın ürettiği her bulgu KENDİNİ İNGİLİZCE KANITLAR.** Judge asla "Almancası kötü"
   demez; şöyle der: *"Post 1'de 'Sie', Post 3'te 'du' — resmiyet tutarsız"* + **birebir alıntı**
   + **düzeltme önerisi**. Sen dili bilmeden bu **gerekçenin mantıklı olup olmadığını** okursun.
3. **Gerçek yer-gerçeği (ground truth) = ana dili konuşan.** Rapor bunu **ortadan kaldırmaz,
   ucuzlatır**: ülke ekibin 8 çıktıyı sıfırdan okumaz, sadece işaretli pasajları dakikalar içinde
   teyit eder. Rapor zaten tam da bunun için EN + kendi dilinde alıntılı tasarlandı.

**Dürüst sınır:** LLM-judge'ın kendisi de bir *iddiadır* ve iddia kanıt değildir (senin kuralın).
Bu yüzden §5'te judge'ı köreltmeyen doğrulama var. Ama "Almanca native mi" sorusunun nihai cevabı
bir insandır; rubric o insanın işini yapmıyor, önüne hazır ve kanıtlı koyuyor.

---

## 1. Dört boyut (hepsi 1–5 puan)

Fixture marka = **Köken** (briefّinden: ses "sakin ve bilgili, öğretmen değil komşu";
abartılı sağlık iddiası yok, nostalji satmıyor). Rubric bu sese göre kalibre.

### D1 — Native akıcılık ("çeviri değil")  · varsayılan ağırlık %35
Metin o dilin ana dili konuşanı tarafından **yazılmış** gibi mi, yoksa İngilizce/Türkçe'den
**çevrilmiş** gibi mi duruyor.
- **Aranan hatalar (translation-smell):** birebir çevrilmiş deyim (kelime kelime doğru, kulağa
  yanlış); İngilizce/Türkçe cümle dizilimi; doğal olmayan eş-dizim (collocation); markanın
  "komşu" tonunu bozan yapay/kurumsal ifade.
- **5:** akıcı, native, ritmi doğru. **3:** anlaşılıyor ama yer yer çeviri kokuyor.
  **1:** açıkça makine çevirisi hissi.

### D2 — Kültürel/deyimsel uygunluk · varsayılan ağırlık %15
Hedef dilde deyim, ifade ve mizah **doğal ve yerinde** mi; tabu/uygunsuz/garip öğe yok mu.
- Not: marka yine Köken; içerik "yer değiştirmiyor" (Türk markası kalır) ama **dili** o dilin
  okuruna doğal gelmeli. Zorlama yerelleştirme de hata, hiç yerelleştirmeme de.

### D3 — Resmiyet (register) — brief'e uyum + tutarlılık · varsayılan ağırlık %20
Register bir rubric-düğmesi DEĞİL: **her brief kendi register'ını açıkça yazar** (§2), audit iki
şeyi ölçer:
- **(a) Brief'e uyum:** çıktı, brief'in ilan ettiği register'ı mı kullanıyor (brief "samimi/`du`"
  diyorsa çıktı `Sie`'ye kaçmış mı).
- **(b) Tutarlılık:** bir post içinde ve postlar arasında register **kaymıyor** mu.
- İkisi de dil bilmeden denetlenebilir: "brief `du` dedi, post 3 `Sie` kullanmış" = otomatik düşüş.

### D4 — Marka sesine sadakat · varsayılan ağırlık %30
Köken'in sesine sadık mı; **yasak kelimeler geçmiyor** mu; sahte sağlık iddiası / nostalji yok mu.
- **Yasak kelimeler (Köken brief) + dil karşılıkları** — judge çevrilmiş halini de arar:
  | TR | DE | FR | IT | ES |
  |---|---|---|---|---|
  | doğal | natürlich | naturel | naturale | natural |
  | katkısız | ohne Zusätze | sans additifs | senza additivi | sin aditivos |
  | %100 | 100% | 100% | 100% | 100% |
  | süper gıda | Superfood | superaliment | superfood | superalimento |
  | detoks | Detox | détox | detox | detox |
  | mucize | Wunder | miracle | miracolo | milagro |
  | atalık | — | — | — | — |
- Bu liste, dil bilmeden bile **denetlenebilir** (kelime var/yok). En sağlam boyut budur.

## 2. Register brief'ten gelir (Elif'in kararı — 2026-07-24)

**Ton, rubric'te değil FIXTURE BRIEF'inde tanımlanır.** Sen tek bir marka-persona kararı
verirsin — **"Köken samimi mi konuşur, resmi mi"** — bu her dilin brief'ine o dilde açıkça yazılır,
audit de çıktının brief'e uyup uymadığını ölçer (D3). Böylece sana "FR'de tu mu vous mu" diye
dil-sorusu sormuyoruz; soru marka tonu sorusu olarak brief'te çözülüyor.

- **Persona kararı (senin onayın):** Köken = **samimi/sıcak** (orijinal brief'in "komşu, öğretmen
  değil" sesi bunu zaten söylüyor). Onaylarsan dört brief'e de bu işlenir:
  DE `du` · FR `tu` · IT `tu` · ES `tú`.
- **Bu register kelimeleri BENİM brief-yerelleştirme kararım**, senin dil bilmen gerekmez. Brief'te
  açık yazıldığı için hem test edilebilir hem de istersen bir native brief'i (çıktıyı değil)
  tek bakışta teyit eder.
- **ES pazarı:** brief İspanya pazarına yazılır (`tú`, Avrupa İspanyolcası) — bu da fixture
  kararı, brief'te belirtilir. LatAm istenirse ayrı fixture olur.

Yani §2 artık senin için tek soru: **Köken samimi mi? (öneri: evet).** Gerisi brief'te.

## 3. Geçit kararı (GREEN / YELLOW / RED) — demo sinyali

Ağırlıklı toplam (1–5) + koruma kuralları:
- **RED (demo'ya hazır değil):** herhangi bir boyut ≤ 2, **veya** ağırlıklı toplam < 3.0,
  **veya** yasak kelime geçmiş (D4 otomatik RED).
- **YELLOW (düzeltmeyle olur):** ağırlıklı toplam 3.0–3.9, veya herhangi bir boyut = 3.
- **GREEN (demo'ya hazır):** ağırlıklı toplam ≥ 4.0 **ve** hiçbir boyut < 4.

Eşikler ilk gerçek koşudan sonra kalibre edilebilir (fazla RED/GREEN çıkarsa).

## 4. Judge'ın her çıktı için ürettiği yapı (Zod ile doğrulanır)

Her `(dil × model)` için (judge run'ın TÜM çıktısını birlikte görür, kanıtta hangi adım
olduğunu belirtir — granülerlik bütçe kararı: per-step 40 judge çağrısı ~$15 tavanı aşardı,
per-run 8 çağrı ~$3 tavanda kalır):
- Boyut başına: `score` (1–5) + `rationale` (EN, somut, kuralı işaret eder) + `evidence`
  (**birebir alıntı, orijinal dilde**) + score < 4 ise `suggestedFix` (düzeltilmiş öneri).
- `bannedTermsFound`: bulunan yasak kelimeler listesi (boş = temiz).
- `summary`: 2 cümle EN.

**`verdict` (GREEN/YELLOW/RED) judge'ın çıktısı DEĞİL — koddan hesaplanır** (`score`'lar +
`bannedTermsFound` + §3 eşikleri). Gate model görüşü değil, deterministik kod: aynı puanlar hep
aynı verdict'i verir. `suggestedFix` + `evidence` = senin ve native'in doğrulama kolu: öneri
mantıklıysa bulgu gerçek.

## 5. Judge'ı köreltmeyen doğrulama (senin "iddia ≠ kanıt" kuralın)

- **Sanity-probe (ucuz, gerçek koşudan önce):** judge, mevcut bir bake-off çıktısı üzerinde 1 kez
  koşulur; iyi-biçimli, kurala bağlı, alıntılı çıktı veriyor mu ölçülür. Vermezse judge değişir.
- **İsteğe bağlı çapraz-kontrol (maliyet artar):** en sert RED bulguları ikinci bağımsız bir
  modele teyit ettirmek. Varsayılan KAPALI; sen istersen açılır.
- **Nihai:** işaretli pasajlar ülke ekibine/native'e gider — rapor bunun için tasarlı.

## 6. Onayına sunulan kararlar (özet)
1. Dört boyut ve **varsayılan ağırlıklar** (%35/%15/%20/%30) — uygun mu?
2. **Köken persona = samimi mi?** (§2). Tek marka-tonu kararı; register kelimeleri her brief'e
   o dilde işlenir, audit uyumu ölçer. (Dil-başına soru YOK — brief çözer.)
3. Geçit eşikleri (§3) — makul mü, yoksa daha sıkı/gevşek mi?
4. Çapraz-kontrol (§5) varsayılan kapalı — öyle kalsın mı?
