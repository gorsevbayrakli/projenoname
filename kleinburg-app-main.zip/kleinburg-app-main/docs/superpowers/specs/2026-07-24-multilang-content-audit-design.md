# Çok Dilli Üretim Denetimi — Tasarım Dokümanı

- **Tarih:** 2026-07-24
- **İlgili issue:** [#17](https://github.com/elifc/kleinburg-app/issues/17)
- **Durum:** Onay bekliyor (Elif review)

---

## 1. Amaç

Motorun **DE / IT / FR / ES** içerik üretiminin kalitesini, demolardan **önce** ölçen bir
QA aracı. Elif'in net hedefi iki tanedir ve tasarımı bunlar yönlendirir:

1. **Demoda dilde problemli bir sonuç göstermemek.** Rapor bir *geçit*tir: bir dil kötü
   çıkıyorsa, o dil gösterilmeden önce fark edilmeli.
2. **Raporu gerekirse ülke ekiplerine göstermek.** Yani rapor paylaşılabilir, temiz ve
   kanıtlı bir artefakt olmalı — iç dökümü değil, sunulabilir bir belge.

Her dilin duygusal tonu, akışı ve yaklaşımı farklıdır; audit bunu "İngilizce'den çeviri"
tek kalıbına indirgemeden, **dil bağlamını koruyarak** ölçer.

## 2. Bu ne DEĞİL (kapsam dışı — YAGNI)

- Motorun prompt'larını **düzeltmek** değil. Audit önce **ölçer**; bulunan sorunların
  düzeltilmesi ayrı bir iş kalemidir.
- Uygulama içi admin ekranı değil. Çıktı bir **script + rapor dosyası** (bakeoff-runs
  formatına benzer). Kalıcı UI özelliği sonra tartışılır.
- İnsan-review akışı değil. Değerlendirme **otomatik LLM-jüri** ile yapılır. (Rapor insanın
  okuması için tasarlanır ama puanı model verir.)
- Topic #1 (UI arayüz dilleri) ile ilgisi yok — bağımsız iş.

## 3. Ana karar özeti (Elif onaylı)

| Karar | Seçim |
|---|---|
| Audit yöntemi | Otomatik LLM-jüri |
| Run kapsamı | Tüm pipeline, uçtan uca |
| Çıktı biçimi | Script + tarihli rapor dosyası |
| Rubric kaynağı | Claude taslaklar → Elif onaylar |
| Test girdisi | **4 dile özel native brief** (Köken, her dilde yerelleştirilmiş; ton brief'te yazılı) |
| Üretim modelleri | `anthropic/claude-sonnet-5` + `moonshotai/kimi-k3` (2 model, kıyas) |
| Judge modeli | **OpenAI modeli**, üretimden bağımsız — varsayılan `openai/gpt-4.1` (bkz. §7) |
| postsPerPlatform | 5 |
| Platform | Tek platform: **instagram** |
| Diller | de, it, fr, es |

## 4. Mimari

Uygulama davranışını değiştirmeyen, `web/scripts/` altında komutla çalışan bir harness.
Mevcut bake-off script'inin (aynı motoru dışarıdan koşturan yapı) kardeşi.

```
web/scripts/lang-audit/
  run.ts            # orkestrasyon: fixture yükle → her (dil×model) için pipeline koş → judge → rapor
  fixture/          # 4 dile özel native brief (de/it/fr/es), Köken yerelleştirilmiş, ton brief'te
  rubric/           # dil-başına rubric (de.md, it.md, fr.md, es.md) — Claude taslaklar, Elif onaylar
  judge.ts          # judge çağrısı + Zod şeması ile doğrulama (repo kuralı: LLM çıktısı şemayla)
  report.ts         # markdown/html rapor üretimi
  schemas.ts        # judge çıktısı Zod şemaları
```

### Akış
1. **Fixture yükle — dil başına NATIVE brief (Elif kararı, 2026-07-24).** Gerçek demo koşulu
   şudur: o dilin müşterisi dokümanı **kendi dilinde** verir. Bu yüzden fixture = Köken'in
   **her dile yerelleştirilmiş 4 ayrı native brief'i** (de/it/fr/es), tek Türkçe brief değil.
   **Ton/register brief'in içinde tanımlıdır** (Köken = samimi → DE `du`/FR `tu`/IT `tu`/ES `tú`);
   audit çıktının brief'e uyup uymadığını ölçer (rubric D3). Register artık bir rubric-düğmesi
   değil, fixture'ın parçası.
   - **Karşılaştırma sonucu:** model karşılaştırması **dil içinde saf** kalır (aynı brief, 2 model).
     Diller arası ölçüm "hangi dil daha iyi" değil, **"her dil demo-ready mi"** sorusudur — Elif'in
     gerçek hedefi bu.
   - Native brief'leri Claude yazar (yerelleştirir); brief girdi/fixture olduğu için nüans yükü
     çıktıyı denetlemekten düşüktür, ve istenirse bir native brief'i tek bakışta teyit eder.
2. **Üret.** Her `(dil × model)` = 8 kombinasyon için tüm pipeline koşulur:
   context → creative spark → pillar → post (instagram, 5 post) → calendar. Üretilen
   içerik `audits/lang-audit-<tarih>/<dil>/<model>/` altına yazılır.
3. **Denetle (judge).** Bağımsız judge her çıktıyı dil-başına rubric ile puanlar.
   Judge cevabı **Zod ile doğrulanır** — regex parse yok (repo hard-rule). Şema uymadıysa
   judge tekrar çağrılır.
4. **Raporla.** §6'daki paylaşılabilir rapor üretilir.

## 5. Rubric (4 boyut — Elif'in öncelikleri)

Her boyut **1–5** puan + **gerekçe** + **kanıt alıntısı** (değerlendirilen metinden, kendi
dilinde). Dil-başına ağırlıklar Claude tarafından taslaklanır, Elif onaylar.

1. **Native ton / "çeviri değil":** Metin o dilin ana dili konuşanı gibi mi akıyor, yoksa
   İngilizce/Türkçe'den çevrilmiş gibi mi duruyor. (İdiyom, ritim, cümle yapısı.)
2. **Kültürel uygunluk:** Yerel deyim, referans, mizah; tabu/uygunsuz öğe yok.
3. **Resmiyet tutarlılığı:** tu/vous (FR), du/Sie (DE), tü/Lei (IT), tú/usted (ES) register'ı
   markaya uygun ve metin boyunca tutarlı mı.
4. **Marka sesine sadakat:** Üretilen içerik markanın ses/ton rehberine sadık mı (dilden
   bağımsız — fixture'ın "kullanmadığımız kelimeler" listesi burada test edilir).

Her dil için ayrıca tek satırlık **YEŞİL / SARI / KIRMIZI** karar üretilir (eşikler rubric'te
tanımlanır) — demo-öncesi geçit sinyali budur.

## 6. Rapor (paylaşılabilir artefakt)

- **Dil:** Raporun tamamı **İngilizce** (Elif kararı — uluslararası ortak dil, ülke ekiplerine
  gösterilebilir). **Tek istisna: değerlendirilen içeriğin kanıt alıntıları kendi dilinde,
  BİREBİR kalır** — çünkü audit'in konusu tam da o metnin kendisi; çevrilirse denetlenen şey
  yok olur. Yani: başlıklar, gerekçe, karar, özet = EN; DE/IT/FR/ES üretilen metin alıntıları =
  orijinal dilde, değiştirilmeden.
- **Yapı:**
  - **Executive summary:** 4 dil × 2 model matrisi, her hücrede YEŞİL/SARI/KIRMIZI + toplam puan.
  - **Dil başına bölüm:** 4 boyut kırılımı, judge gerekçesi, en güçlü/en zayıf kanıt alıntıları.
  - **Model karşılaştırması:** "hangi model hangi dilde daha iyi" özeti.
- **Format:** Markdown (birincil) + opsiyonel tek-dosya HTML (paylaşım için).
- **Konum:** `web/audits/lang-audit-<ISO-tarih>/report.md` (+ ham çıktılar yanında).

## 7. Judge modeli (bağımsız — OpenAI)

Üretim modelleri sonnet-5 + kimi-k3. Judge bir **OpenAI modeli** olacak (Elif kararı) — böylece
üretim modellerinin **ikisinden de bağımsız**, öz-değerlendirme yanlılığı yok (bir model kendi
çıktısını puanlamaz).

- **Varsayılan:** `openai/gpt-4.1` — Elif'in OpenRouter allowlist'inde zaten var (erişim + şema +
  Türkçe prob'undan geçmişti; bkz. [[kleinburg-rebuild]] model notları). Bu yüzden sürtünmesiz.
- **Allowlist şartı:** OpenRouter, allowlist dışı modele `404 No endpoints...` döner (ve bunu
  "veri politikası" gibi gizler — geçmiş ders: 404'te ÖNCE allowlist'e bak). Farklı/daha güçlü
  bir OpenAI modeli (ör. gpt-5-sınıfı) istenirse Elif onu **Allowed Models**'a ekler ve ID'yi
  verir; harness model-agnostik (`config`'ten okur).
- **Doğrulama:** Seçilen judge, gerçek koşudan önce **sanity-probe** ile ölçülür (§9) —
  katalog bayrağına güvenmek yok (global kural: ölç, çıkarım yapma).

## 8. Maliyet (ölçülen veriye dayalı)

Kaynak: `web/bakeoff-runs/*/00-meta.json` içindeki gerçek `costUsd` toplamları (TR, ppp=10,
2 platform).

| | Ölçülen tam koşu (ppp=10, 2 platform) | Bu audit (ppp=5, 1 platform ≈ %40–50 daha ucuz) |
|---|---|---|
| claude-sonnet-5 | $1.05 | ~$0.55 × 4 dil = ~$2.2 |
| kimi-k3 | $2.05 | ~$1.10 × 4 dil = ~$4.4 |
| Judge (`openai/gpt-4.1`, 8 koşu) | — | ~$3.0 |
| **Toplam** | — | **~$10 (tampon dahil ≤ $18)** |

20 doları geçmez. Kredi mevcut; sorun çıkarsa Elif uyarılır, artırır.

## 9. Doğrulama (harness'in kendisi nasıl kanıtlanır)

- **Mock testler ($0):** fixture yükleme, orkestrasyon, Zod şema doğrulama, rapor üretimi —
  hepsi mock LLM cevaplarıyla test edilir. Judge şema-red yolu (bozuk cevap → tekrar) dahil.
- **Test-diş kontrolü:** her yeni test kasten kırılıp kırmızıya döndüğü görülür, sonra geri
  alınır (global kural: sahte test üretmemek).
- **Judge sanity-probe (çok ucuz):** gerçek büyük koşudan önce, judge mevcut bir bake-off
  çıktısı üzerinde 1 kez çalıştırılır → makul, iyi-biçimli puan üretiyor mu ölçülür. Judge
  model seçimi buradan doğrulanır.
- **Lint + typecheck + test yeşil** olmadan iş bitmiş sayılmaz.

## 10. Onay kapıları (Elif)

1. **Rubric onayı** (kâğıt üstü, küçük): Claude dil-başına rubric taslağını yazınca Elif bir
   bakar. İstenirse atlanır.
2. **Gerçek koşuyu tetikleme** (tek gerçek kapı): Harness mock testlerle yeşile gelince,
   parayı harcayan komutu Elif tetikler ("başlat"). Claude otonom olarak canlı OpenRouter
   çağrısı yapıp para harcamaz (Kleinburg guardrail'i).

## 11. Açık uçlar / sonra

- Judge varsayılanı `openai/gpt-4.1` (allowlist'te); daha güçlü bir OpenAI modeli istenirse
  Elif allowlist'e ekler + §9 sanity-probe ile doğrulanır.
- Bulunan sorunların **düzeltilmesi** (prompt iyileştirme) ayrı issue olacak.
- Ülke-dili rapor varyantı ve uygulama içi admin ekranı — sonraki faz, istenirse.
