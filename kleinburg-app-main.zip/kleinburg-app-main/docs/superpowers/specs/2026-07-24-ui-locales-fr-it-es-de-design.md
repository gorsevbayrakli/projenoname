# UI Çoklu Dil: FR / IT / ES / DE — Tasarım Dokümanı

- **Tarih:** 2026-07-24 · **İlgili issue:** [#16](https://github.com/elifc/kleinburg-app/issues/16)
- **Durum:** Onay bekliyor (Elif review)

---

## 1. Amaç
Uygulamanın **arayüz dilini** (UI chrome) mevcut TR/EN'e ek olarak **Fransızca, İtalyanca,
İspanyolca, Almanca**'da desteklemek ve dil seçimini login dahil her yerde bir **dropdown** ile
sunmak. Demolar bu dilleri konuşan native profesyonellere yapılacağı için çeviriler **kültürel
bağlam ve tutarlı resmiyet** gözetilerek yapılır — mekanik makine çevirisi değil.

**Not:** Bu, motorun içerik ürettiği "content language"dan ([#17](https://github.com/elifc/kleinburg-app/issues/17))
tamamen ayrıdır. Bu iş yalnız arayüz dilidir.

## 2. Mevcut durum (kod incelendi)
- `next-intl`; `web/messages/{tr,en}.json` **birebir 481 anahtar** (parite tam), 26 namespace.
- `web/src/core/i18n/locales.ts`: `LOCALES = ["tr","en"]`, `DEFAULT_LOCALE="tr"`, cookie
  (`kb_locale`) + hesap alanı (`resolveEffectiveLocale`: hesap > cookie).
- `LocaleSwitcher` **6 yerde**: login-screen, wizard-rail (×2), projects (×3), change-password.
  Şu an TR/EN **buton toggle**; etiket mantığı 2 dile hardcoded (`t(locale==='tr'?'trFull':'enFull')`).
- `locale` namespace 2 dile sabit: `label, tr, en, trFull, enFull, saveFailed`.

## 3. Kararlar (Elif, 2026-07-24)
| Karar | Seçim |
|---|---|
| Diller | +fr, +it, +es, +de (toplam 6) |
| Arayüz resmiyeti | **Resmi/profesyonel:** FR vous · DE Sie · IT Lei · ES usted |
| Dropdown kapsamı | **Her yerde** (tek bileşen, 6 konum) |
| Çeviri üretimi | Claude üretir, **"native-review bekliyor"** işaretiyle; demo öncesi native göz |
| Varsayılan dil | Değişmez (`tr`) |

## 4. Mimari değişiklikler
1. **`core/i18n/locales.ts`:** `LOCALES = ["tr","en","fr","it","es","de"]`. `isLocale`,
   `resolveLocale`, `resolveEffectiveLocale`, cookie mantığı zaten `LOCALES`'ten türüyor —
   ekleme yeterli, imza değişmez. `locales.test.ts` yeni dilleri kapsar.
2. **Mesaj katalogları:** `messages/{fr,it,es,de}.json`, her biri 481 anahtar. Kaynak: **en
   pivot** (semantik oturmuş), **tr ile niyet çapraz-kontrol** (tr birincil/otoritatif).
   `contentLanguages`, `apiErrors`, `auditActions` vb. dahil TÜM namespace'ler.
3. **`locale` namespace:** her katalogda `fr/it/es/de` kısa etiket + `frFull/itFull/esFull/deFull`
   tam ad. `label` ve `saveFailed` de çevrilir.
4. **`LocaleSwitcher` → dropdown.** Buton grubu 6 dilde sığmaz. Mevcut davranış KORUNUR:
   server action ile cookie+hesap yazımı, başarısızlıkta `saveFailed` mesajı, başarıda
   `router.refresh()`. Sabit-2-dil etiket mantığı `LOCALES.map` + `t(\`${locale}Full\`)` ile
   genelleştirilir. Tek bileşen, 6 konumda aynı.
5. `next-intl` request config: **DOĞRULANDI** — `i18n/request.ts` mesajları
   `import(\`../../messages/${locale}.json\`)` ile **dinamik yüklüyor**, locale de
   `resolveEffectiveLocale`'ten geliyor. Yani 4 JSON dosyası + `LOCALES` girişi yeterli;
   request config'te kod değişmez. Middleware locale'i cookie tabanlı (URL öneki yok),
   dokunulmaz.

## 5. Çeviri yaklaşımı (kalite)
- **Resmiyet:** §3'teki resmi register tüm cümlelerde tutarlı. UI etiketlerinin çoğu mastar/isim
  (register görünmez: "Enregistrer", "Speichern") — register yalnız kullanıcıya hitap eden
  cümlelerde çıkar; oralarda vous/Sie/Lei/usted.
- **Terminoloji tutarlılığı:** aynı kavram (ör. "brand", "pillar", "project", "run") her dilde
  tek karşılıkla; namespace içi ve arası tutarlı sözlük.
- **Kültürel bağlam:** buton fiilleri, tarih/sayı ifadeleri, hata tonları o dilin yazılım
  konvansiyonuna göre. `relativeTime`, `stepLabels`, `apiErrors` özel dikkat.
- **native-review işareti:** çeviriler bir native tarafından demo öncesi gözden geçirilmek üzere
  işaretlenir (issue/PR notu). Bu, #17'deki aynı "nihai ground-truth insandır" ilkesi.

## 6. Testler
- **Parite testi (kritik, YENİ):** Özel bir mesaj-paritesi testi yok — yazılacak. 6 katalogun
  tümü tr ile **birebir aynı anahtar setine** sahip — eksik/fazla anahtar = kırmızı.
  Bu testi kasten kır (bir anahtar sil), kırmızıya döndüğünü gör, geri al — sahte test olmasın.
- **Dropdown davranışı:** 6 dil listeleniyor; seçim server action'ı çağırıp cookie+hesap yazıyor;
  başarısızlıkta `saveFailed` görünüyor; aktif dil işaretli.
- `locales.test.ts`: yeni diller `isLocale`/`resolveLocale`'de geçerli.
- Yeşil: `npm run lint && npm run typecheck && npm test`.

## 7. Kapsam dışı (YAGNI)
- URL dil öneki yok (mevcut cookie tabanlı mimari korunur).
- İçerik dili ([#17](https://github.com/elifc/kleinburg-app/issues/17)) bu işe dahil değil.
- Yeni dillerde otomatik/CI çeviri boru hattı yok (şimdilik elle + native review).

## 8. Kabul kriteri
- 6 dilde arayüz eksiksiz render; hiçbir namespace'te eksik anahtar yok (parite testi yeşil).
- Login dahil 6 konumda dropdown ile dil seçilebiliyor; seçim cookie+hesaba yazılıyor; refresh
  sonrası server-component metinleri yeni dilde.
- Resmi register 4 yeni dilde tutarlı.
- lint + typecheck + test yeşil.

## 9. Açık uç
- **Native review:** 4 dilin native gözden geçirmesi demo öncesi Elif'in ayarlayacağı adım
  (kod tarafı hazır, işaretli).
