# UI Locales FR/IT/ES/DE Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add French, Italian, Spanish and German as interface languages and replace the TR/EN toggle with a language dropdown available everywhere including login.

**Architecture:** The i18n stack is already locale-agnostic — `i18n/request.ts` dynamically imports `messages/${locale}.json` and locale resolution derives from `LOCALES`. So the work is: add four full message catalogs, expand the `LOCALES` vocabulary, widen the `locale` namespace with the six language names, convert the switcher to a native `<select>`, and add a parity test that guards catalog completeness. No routing, middleware or server-action changes.

**Tech Stack:** Next.js 15, next-intl (no-i18n-routing / cookie+account flavour), TypeScript, Vitest + Testing Library (jsdom).

## Global Constraints

- **Work only inside `web/`.** Commit after every task. End each commit message with `Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>`.
- **ICU integrity:** every catalog value must preserve, byte-for-byte, all `{placeholder}` tokens, ICU `plural`/`select` structures and any rich-text tags (`<b>…`). NEVER translate a placeholder identifier or an ICU keyword (`one`, `other`, `#`).
- **Key parity:** every file in `web/messages/*.json` must have the EXACT same set of (flattened) keys as `tr.json`. No missing, no extra.
- **Register (interface tone, professional):** FR `vous` · DE `Sie` · IT `Lei` · ES `usted` in every user-addressing **sentence** and instructional micro-copy, consistent. **Buttons / single short imperatives follow native UI convention (Elif, 2026-07-24): a short imperative on a button is fine and preferred — IT `Salva`/`Annulla`/`Scegli`, ES `Guardar`/`Cancelar` — do NOT force the formal 3rd-person form onto single-word buttons.** Full sentences still use the formal register (e.g. IT sentence ends "…Riprovi", but the retry BUTTON is "Riprova"). FR/DE buttons are infinitive/noun, so register does not surface there.
- **Terminology consistency:** one fixed target-language term per domain concept (brand, pillar, project, run, calendar, spend, audit…), identical within and across namespaces of a given catalog.
- **Language names are endonyms:** `frFull="Français"`, `deFull="Deutsch"`, `itFull="Italiano"`, `esFull="Español"`, `trFull="Türkçe"`, `enFull="English"` — the SAME values in every catalog (a language's own name does not change with the UI language). Short codes `TR/EN/FR/IT/ES/DE` likewise identical everywhere.
- **`core/` is framework-neutral:** `core/i18n/locales.ts` must not import react/next (ESLint enforces).
- **native-review flag:** the four new catalogs ship marked "native-review pending" (noted in the final task's commit + issue) — a native speaker reviews before any demo.
- **Verification commands:**
  - Per-file, no DB needed: `cd web && npx vitest run <path>`
  - Full suite (final task): `cd web && npm run db:up` then `export DATABASE_URL=postgres://kleinburg:kleinburg@localhost:5432/kleinburg && npm run lint && npm run typecheck && npm test`
- **Test-teeth:** after writing a test, deliberately break the thing it guards, watch it go red, then revert — a test that stays green is fake.

---

### Task 1: Message-catalog parity test (the guard for every later task)

**Files:**
- Create: `web/src/i18n/message-parity.test.ts`

**Interfaces:**
- Consumes: `LOCALES` from `@/core/i18n/locales`; the JSON files in `web/messages/`.
- Produces: nothing importable — a standing guard. After this task, any catalog whose key set drifts from `tr.json`, or any `LOCALES` entry without a matching file, fails CI.

- [ ] **Step 1: Write the failing test**

```ts
// web/src/i18n/message-parity.test.ts
import fs from "node:fs";
import path from "node:path";

import { describe, expect, it } from "vitest";

import { LOCALES } from "@/core/i18n/locales";

const MESSAGES_DIR = path.join(process.cwd(), "messages");

function flatten(obj: unknown, prefix = ""): string[] {
  if (obj === null || typeof obj !== "object") return [prefix];
  return Object.entries(obj as Record<string, unknown>).flatMap(([k, v]) =>
    flatten(v, prefix ? `${prefix}.${k}` : k),
  );
}

function keysOf(file: string): Set<string> {
  const raw = fs.readFileSync(path.join(MESSAGES_DIR, file), "utf8");
  return new Set(flatten(JSON.parse(raw)));
}

const files = fs
  .readdirSync(MESSAGES_DIR)
  .filter((f) => f.endsWith(".json"))
  .sort();
const reference = keysOf("tr.json");

describe("message catalog parity", () => {
  for (const file of files) {
    it(`${file} has exactly the tr.json key set`, () => {
      const keys = keysOf(file);
      const missing = [...reference].filter((k) => !keys.has(k)).sort();
      const extra = [...keys].filter((k) => !reference.has(k)).sort();
      expect({ missing, extra }).toEqual({ missing: [], extra: [] });
    });
  }

  it("LOCALES and message files correspond one-to-one", () => {
    const fileLocales = new Set(files.map((f) => f.replace(/\.json$/, "")));
    const localesWithoutFile = [...LOCALES].filter((l) => !fileLocales.has(l));
    const filesWithoutLocale = [...fileLocales].filter(
      (l) => !(LOCALES as readonly string[]).includes(l),
    );
    expect({ localesWithoutFile, filesWithoutLocale }).toEqual({
      localesWithoutFile: [],
      filesWithoutLocale: [],
    });
  });
});
```

- [ ] **Step 2: Run it — expect PASS (tr/en already parity, LOCALES=[tr,en])**

Run: `cd web && npx vitest run src/i18n/message-parity.test.ts`
Expected: PASS (3 tests: tr.json, en.json, correspondence).

- [ ] **Step 3: Prove the teeth — break parity, watch it fail**

Temporarily add `"__probe__": "x"` to the top level of `web/messages/en.json`, then rerun.
Expected: `en.json has exactly the tr.json key set` FAILS with `extra: ["__probe__"]`.
Then remove `"__probe__"` and rerun → PASS.

- [ ] **Step 4: Commit**

```bash
git add web/src/i18n/message-parity.test.ts
git commit -m "test: message-catalog parity guard for i18n locales (#16)

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

### Task 2: Widen the `locale` namespace to all six languages (tr + en)

**Files:**
- Modify: `web/messages/tr.json` (`locale` object)
- Modify: `web/messages/en.json` (`locale` object)

**Interfaces:**
- Consumes: nothing.
- Produces: keys `locale.fr`, `locale.it`, `locale.es`, `locale.de`, `locale.frFull`, `locale.itFull`, `locale.esFull`, `locale.deFull` present in tr.json and en.json (and, by Task 3–6, every catalog). The switcher (Task 8) reads `locale.<code>Full` for its option labels.

- [ ] **Step 1: Add the eight keys to `web/messages/tr.json`**

Keep the existing `label`, `tr`, `en`, `trFull`, `enFull`, `saveFailed` untouched; add the new short codes and endonym full names so the object becomes:

```jsonc
"locale": {
  "label": "<existing tr value — do not change>",
  "tr": "TR",
  "en": "EN",
  "fr": "FR",
  "it": "IT",
  "es": "ES",
  "de": "DE",
  "trFull": "Türkçe",
  "enFull": "English",
  "frFull": "Français",
  "itFull": "Italiano",
  "esFull": "Español",
  "deFull": "Deutsch",
  "saveFailed": "<existing tr value — do not change>"
}
```

- [ ] **Step 2: Add the SAME eight keys to `web/messages/en.json`**

Identical values (codes + endonyms are language-independent); leave en's own `label`/`saveFailed` untouched.

- [ ] **Step 3: Run parity — expect PASS**

Run: `cd web && npx vitest run src/i18n/message-parity.test.ts`
Expected: PASS — tr.json and en.json still match each other (both gained the same 8 keys).

- [ ] **Step 4: Commit**

```bash
git add web/messages/tr.json web/messages/en.json
git commit -m "i18n: add six-language names to locale namespace (tr, en) (#16)

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

### Task 3: French catalog (`messages/fr.json`) — register `vous`

**Files:**
- Create: `web/messages/fr.json`

**Interfaces:**
- Consumes: `web/messages/en.json` (pivot source, post-Task-2), `web/messages/tr.json` (intent cross-check for any ambiguous string).
- Produces: `web/messages/fr.json` — a complete catalog with the exact tr.json key set.

- [ ] **Step 1: Create the full French catalog**

Produce `web/messages/fr.json` by translating EVERY value of `en.json` into French. Rules:
- Copy the JSON structure of `en.json` exactly (same nesting, same keys). Only values change.
- Preserve every `{placeholder}`, ICU `plural`/`select` block and rich-text tag verbatim (Global Constraints).
- Register **`vous`** in every user-addressing sentence; consistent throughout.
- Fixed terminology, e.g.: brand → « marque », pillar → « pilier », project → « projet », run → « exécution », calendar → « calendrier », spend → « dépense », audit → « audit ». Pick one and keep it.
- `locale` namespace: `label` → "Langue de l'interface"; short codes and `*Full` endonyms exactly as in Global Constraints; `saveFailed` → a `vous`-form sentence, e.g. "Votre préférence de langue n'a pas pu être enregistrée. Veuillez réessayer."

**Register anchors** (translate these keys to exactly this register so the whole file stays consistent — verify these specific strings after generating):
- `auth.*` (username/password/sign-in prompts) → `vous` where a sentence addresses the user.
- `apiErrors.*` and `errorNotice.*` → polite `vous` error tone.
- `changePassword.*`, `account.*` → `vous`.

- [ ] **Step 2: Run parity — expect PASS for fr.json**

Run: `cd web && npx vitest run src/i18n/message-parity.test.ts`
Expected: `fr.json has exactly the tr.json key set` PASSES. (The `LOCALES` correspondence test still passes because fr is not in LOCALES yet AND fr.json is on disk — wait: correspondence requires every FILE be a known locale. `fr` IS a known key here only once added to LOCALES. See note.)

> NOTE: the `LOCALES and message files correspond one-to-one` test will FAIL now, because `fr.json` exists but `fr` is not yet in `LOCALES`. That is expected and is fixed in Task 7. To keep this task's gate green in isolation, run only the parity `it(...)` for the file:
> Run: `cd web && npx vitest run src/i18n/message-parity.test.ts -t "fr.json has exactly"`
> Expected: PASS.

- [ ] **Step 3: Typecheck (catalog is valid JSON and imports)**

Run: `cd web && npx tsc --noEmit` (or `npm run typecheck`)
Expected: no errors introduced.

- [ ] **Step 4: Commit**

```bash
git add web/messages/fr.json
git commit -m "i18n: French interface catalog (vous), native-review pending (#16)

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

### Task 4: Italian catalog (`messages/it.json`) — register `Lei`

**Files:**
- Create: `web/messages/it.json`

**Interfaces:**
- Consumes: `en.json` (pivot), `tr.json` (intent).
- Produces: `web/messages/it.json` with the exact tr.json key set.

- [ ] **Step 1: Create the full Italian catalog**

Same procedure as Task 3, into Italian. Rules:
- Structure identical to `en.json`; preserve all placeholders/ICU/tags.
- Register **`Lei`** (formal third-person) in every user-addressing sentence; consistent (e.g. verb forms and possessives agree with `Lei`).
- Fixed terminology, e.g.: brand → "brand"/"marchio" (pick one, keep it), pillar → "pilastro", project → "progetto", run → "esecuzione", calendar → "calendario", spend → "spesa", audit → "audit".
- `locale.label` → "Lingua dell'interfaccia"; codes/endonyms per Global Constraints; `locale.saveFailed` → `Lei`-form, e.g. "Non è stato possibile salvare la Sua preferenza di lingua. Riprovi."

**Register anchors:** `auth.*`, `apiErrors.*`, `errorNotice.*`, `changePassword.*`, `account.*` → consistent `Lei`.

- [ ] **Step 2: Run parity — expect PASS for it.json**

Run: `cd web && npx vitest run src/i18n/message-parity.test.ts -t "it.json has exactly"`
Expected: PASS.

- [ ] **Step 3: Typecheck**

Run: `cd web && npm run typecheck`
Expected: no new errors.

- [ ] **Step 4: Commit**

```bash
git add web/messages/it.json
git commit -m "i18n: Italian interface catalog (Lei), native-review pending (#16)

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

### Task 5: Spanish catalog (`messages/es.json`) — register `usted` (Spain market)

**Files:**
- Create: `web/messages/es.json`

**Interfaces:**
- Consumes: `en.json` (pivot), `tr.json` (intent).
- Produces: `web/messages/es.json` with the exact tr.json key set.

- [ ] **Step 1: Create the full Spanish catalog**

Same procedure, into Peninsular (Spain) Spanish. Rules:
- Structure identical to `en.json`; preserve all placeholders/ICU/tags.
- Register **`usted`** in every user-addressing sentence; consistent verb/possessive agreement.
- Fixed terminology, e.g.: brand → "marca", pillar → "pilar", project → "proyecto", run → "ejecución", calendar → "calendario", spend → "gasto", audit → "auditoría".
- `locale.label` → "Idioma de la interfaz"; codes/endonyms per Global Constraints; `locale.saveFailed` → `usted`-form, e.g. "No se ha podido guardar su preferencia de idioma. Inténtelo de nuevo."

**Register anchors:** `auth.*`, `apiErrors.*`, `errorNotice.*`, `changePassword.*`, `account.*` → consistent `usted`.

- [ ] **Step 2: Run parity — expect PASS for es.json**

Run: `cd web && npx vitest run src/i18n/message-parity.test.ts -t "es.json has exactly"`
Expected: PASS.

- [ ] **Step 3: Typecheck**

Run: `cd web && npm run typecheck`
Expected: no new errors.

- [ ] **Step 4: Commit**

```bash
git add web/messages/es.json
git commit -m "i18n: Spanish interface catalog (usted, Spain), native-review pending (#16)

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

### Task 6: German catalog (`messages/de.json`) — register `Sie`

**Files:**
- Create: `web/messages/de.json`

**Interfaces:**
- Consumes: `en.json` (pivot), `tr.json` (intent).
- Produces: `web/messages/de.json` with the exact tr.json key set.

- [ ] **Step 1: Create the full German catalog**

Same procedure, into German. Rules:
- Structure identical to `en.json`; preserve all placeholders/ICU/tags.
- Register **`Sie`** (formal) in every user-addressing sentence; consistent.
- Fixed terminology, e.g.: brand → "Marke", pillar → "Säule", project → "Projekt", run → "Lauf"/"Durchlauf" (pick one), calendar → "Kalender", spend → "Ausgaben", audit → "Audit". Respect German noun capitalisation.
- `locale.label` → "Sprache der Oberfläche"; codes/endonyms per Global Constraints; `locale.saveFailed` → `Sie`-form, e.g. "Ihre Spracheinstellung konnte nicht gespeichert werden. Bitte versuchen Sie es erneut."

**Register anchors:** `auth.*`, `apiErrors.*`, `errorNotice.*`, `changePassword.*`, `account.*` → consistent `Sie`.

- [ ] **Step 2: Run parity — expect PASS for de.json**

Run: `cd web && npx vitest run src/i18n/message-parity.test.ts -t "de.json has exactly"`
Expected: PASS.

- [ ] **Step 3: Typecheck**

Run: `cd web && npm run typecheck`
Expected: no new errors.

- [ ] **Step 4: Commit**

```bash
git add web/messages/de.json
git commit -m "i18n: German interface catalog (Sie), native-review pending (#16)

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

### Task 7: Add the four locales to the vocabulary

**Files:**
- Modify: `web/src/core/i18n/locales.ts` (the `LOCALES` tuple)
- Modify: `web/src/core/i18n/locales.test.ts` (extend coverage)

**Interfaces:**
- Consumes: the four catalog files from Tasks 3–6 (they must exist first, so `i18n/request.ts`'s dynamic `import(\`../../messages/${locale}.json\`)` resolves for every offered locale).
- Produces: `LOCALES = ["tr","en","fr","it","es","de"]`. Everything deriving from `LOCALES` (isLocale/resolveLocale/resolveEffectiveLocale, request config, the switcher) now covers six languages.

- [ ] **Step 1: Write the failing test additions**

Append to `web/src/core/i18n/locales.test.ts` (match the file's existing test style):

```ts
import { describe, expect, it } from "vitest";
import { LOCALES, isLocale, resolveLocale } from "./locales";

describe("expanded locale vocabulary (#16)", () => {
  it("offers the four new interface languages", () => {
    for (const l of ["fr", "it", "es", "de"] as const) {
      expect(LOCALES).toContain(l);
      expect(isLocale(l)).toBe(true);
      expect(resolveLocale(l)).toBe(l);
    }
  });

  it("still rejects an unknown locale to the default", () => {
    expect(isLocale("xx")).toBe(false);
    expect(resolveLocale("xx")).toBe("tr");
  });
});
```

- [ ] **Step 2: Run — expect FAIL**

Run: `cd web && npx vitest run src/core/i18n/locales.test.ts -t "expanded locale vocabulary"`
Expected: FAIL — `LOCALES` does not yet contain `fr`.

- [ ] **Step 3: Expand `LOCALES`**

In `web/src/core/i18n/locales.ts` change:

```ts
export const LOCALES = ["tr", "en"] as const;
```

to:

```ts
export const LOCALES = ["tr", "en", "fr", "it", "es", "de"] as const;
```

(Do not touch `DEFAULT_LOCALE`, cookie constants, or the resolver functions — they all derive from `LOCALES`.)

- [ ] **Step 4: Run both affected tests — expect PASS**

Run: `cd web && npx vitest run src/core/i18n/locales.test.ts src/i18n/message-parity.test.ts`
Expected: PASS — including `LOCALES and message files correspond one-to-one` (all six files now exist and all six locales are listed).

- [ ] **Step 5: Commit**

```bash
git add web/src/core/i18n/locales.ts web/src/core/i18n/locales.test.ts
git commit -m "i18n: enable fr/it/es/de as interface locales (#16)

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

### Task 8: Convert `LocaleSwitcher` to a native `<select>` dropdown

**Files:**
- Modify: `web/src/components/locale-switcher.tsx`
- Modify: `web/src/components/locale-switcher.test.tsx`

**Interfaces:**
- Consumes: `LOCALES`, `setLocale` (unchanged — already narrows via `resolveLocale` and writes cookie+account for any locale), `useLocale`/`useTranslations`, `locale.<code>Full` labels.
- Produces: same public component `LocaleSwitcher({ className })` used unchanged by all six call sites; behaviour preserved (writes preference, `router.refresh()` on success, `role="alert"` message on failure) but rendered as one `<select>` listing all six endonyms.

- [ ] **Step 1: Update the test to drive a select instead of buttons**

Replace the three interaction tests' trigger. The button lookup `getByRole("button", { name: "EN" })` becomes a change on the combobox, and add an option-count assertion. Full replacement for the `describe` body:

```tsx
describe("LocaleSwitcher", () => {
  it("lists all six interface languages as options", () => {
    setLocale.mockResolvedValue({ ok: true });
    renderWithIntl(<LocaleSwitcher />);
    const options = screen.getAllByRole("option");
    expect(options).toHaveLength(6);
    expect(options.map((o) => (o as HTMLOptionElement).value)).toEqual([
      "tr", "en", "fr", "it", "es", "de",
    ]);
  });

  it("switches and says nothing when the preference is stored", async () => {
    setLocale.mockResolvedValue({ ok: true });
    renderWithIntl(<LocaleSwitcher />);

    fireEvent.change(screen.getByRole("combobox"), {
      target: { value: "en" },
    });

    await waitFor(() => expect(refresh).toHaveBeenCalled());
    expect(setLocale).toHaveBeenCalledWith("en");
    expect(screen.queryByRole("alert")).toBeNull();
  });

  it("tells the user when the preference could not be saved", async () => {
    setLocale.mockResolvedValue({
      ok: false,
      reason: "PREFERENCE_WRITE_FAILED",
    });
    renderWithIntl(<LocaleSwitcher />);

    fireEvent.change(screen.getByRole("combobox"), {
      target: { value: "en" },
    });

    const alert = await screen.findByRole("alert");
    expect(alert.textContent).toBe(FAILURE_TEXT);
  });

  it("tells the user when the server action itself throws", async () => {
    setLocale.mockRejectedValue(new Error("boom"));
    renderWithIntl(<LocaleSwitcher />);

    fireEvent.change(screen.getByRole("combobox"), {
      target: { value: "en" },
    });

    const alert = await screen.findByRole("alert");
    expect(alert.textContent).toBe(FAILURE_TEXT);
  });
});
```

Keep the file's existing imports, mocks (`refresh`, `setLocale`, `FAILURE_TEXT`) and `afterEach`. If the fourth test ("throws") is already present with a click trigger, replace its trigger the same way.

- [ ] **Step 2: Run — expect FAIL**

Run: `cd web && npx vitest run src/components/locale-switcher.test.tsx`
Expected: FAIL — the component still renders buttons; `getByRole("combobox")` not found / option count wrong.

- [ ] **Step 3: Rewrite the component as a native select**

Replace the body of `web/src/components/locale-switcher.tsx` (keep the top doc-comment; update its "TR / EN toggle" wording to "six-language dropdown"):

```tsx
"use client";

import { useLocale, useTranslations } from "next-intl";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";

import { LOCALES, type Locale } from "@/i18n/locales";
import { setLocale } from "@/i18n/set-locale";

export function LocaleSwitcher({ className = "" }: { className?: string }) {
  const t = useTranslations("locale");
  const active = useLocale() as Locale;
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [failed, setFailed] = useState(false);

  function choose(next: Locale) {
    if (next === active || isPending) return;
    startTransition(async () => {
      let ok = false;
      try {
        // A thrown action (transport, redeploy mid-flight) is the same story
        // for the user as a rejected write: the preference did not stick.
        ok = (await setLocale(next)).ok;
      } catch (e) {
        console.error("[i18n] setLocale action failed", e);
      }
      setFailed(!ok);
      // Only refresh on success; re-rendering after a failure would repaint the
      // page in the unchanged language and make the change look accepted.
      if (ok) router.refresh();
    });
  }

  return (
    <div className={"inline-flex flex-col items-start gap-1 " + className}>
      <label htmlFor="locale-switcher" className="sr-only">
        {t("label")}
      </label>
      <select
        id="locale-switcher"
        aria-label={t("label")}
        value={active}
        disabled={isPending}
        onChange={(e) => choose(e.target.value as Locale)}
        className="rounded-lg border border-border bg-bg px-2 py-1 text-xs font-medium text-fg outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:opacity-60"
      >
        {LOCALES.map((locale) => (
          <option key={locale} value={locale}>
            {t(`${locale}Full`)}
          </option>
        ))}
      </select>
      {failed ? (
        <p role="alert" className="text-xs text-destructive">
          {t("saveFailed")}
        </p>
      ) : null}
    </div>
  );
}
```

- [ ] **Step 4: Run — expect PASS**

Run: `cd web && npx vitest run src/components/locale-switcher.test.tsx`
Expected: PASS (4 tests).

- [ ] **Step 5: Full verification (lint + typecheck + whole suite)**

```bash
cd web && npm run db:up
export DATABASE_URL=postgres://kleinburg:kleinburg@localhost:5432/kleinburg
npm run lint && npm run typecheck && npm test
```
Expected: all green. If any pre-existing snapshot/test referenced the old TR/EN buttons elsewhere, update it to the select interaction the same way.

- [ ] **Step 6: Commit**

```bash
git add web/src/components/locale-switcher.tsx web/src/components/locale-switcher.test.tsx
git commit -m "i18n: language dropdown (six locales) replacing TR/EN toggle (#16)

Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>"
```

---

## Post-implementation

- **Browser check (production-like):** start the dev server, open `/login`, pick each of FR/IT/ES/DE from the dropdown, confirm the heading/labels switch and no missing-key warnings appear in the console; confirm the choice persists across a refresh (cookie) and, signed in, across sign-out/in (account).
- **native-review:** flag on issue #16 that the four catalogs are machine-drafted to a professional register and need a native pass before any demo.
- **Out of scope (do not do here):** content-language audit (#17); URL locale prefixes; automated translation CI.

---

### Task 9: Update pre-existing tests that hard-coded the two-locale world (plan gap)

**Discovered during Task 8.** Three existing tests asserted the old TR/EN-only reality and fail once `LOCALES` has six entries. This is NOT a functional bug: `setAccountLocale` validates via `isLocale` (derives from `LOCALES`) and the `ui_locale` DB column is plain `text` (no enum/check), so FR/IT/ES/DE persist fine — verified by the very failure (`setAccountLocale(userId,"de")` resolved and wrote `uiLocale:"de"`). The tests, not the code, are stale.

**Files:**
- Modify: `web/src/i18n/messages.test.ts` (catalog map + a stale "both catalogs" comment)
- Modify: `web/src/i18n/set-locale.test.ts` (unsupported-value fixture)
- Modify: `web/src/core/account/service.test.ts` (unsupported-value fixture)

- [ ] Import the four new catalogs in `messages.test.ts` and extend `const catalogs = { tr, en }` to `{ tr, en, fr, it, es, de }`. This makes "ships a catalog for every supported locale" pass AND runs the whole battery (non-empty values, apiErrors copy for every code, `{min}` placeholder, audit/wizard/workflow labels) across all six — a real strengthening. Update the "carries the product description in both catalogs" comment to "every catalog".
- [ ] In `set-locale.test.ts` "narrows an unsupported value", change `setLocale("de")` to `setLocale("zz")` (a genuinely unsupported code; still narrows to `tr`).
- [ ] In `account/service.test.ts` "refuses a locale outside the supported set", change `setAccountLocale(userId, "de")` to `setAccountLocale(userId, "zz")`.
- [ ] Full suite green: `cd web && npm run db:up && export DATABASE_URL=... && npm run lint && npm run typecheck && npm test`. If the battery now flags a real gap in a new catalog (empty value, missing copy), fix that catalog value.
