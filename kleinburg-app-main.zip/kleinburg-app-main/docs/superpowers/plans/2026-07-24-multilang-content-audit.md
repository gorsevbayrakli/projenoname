# Çok Dilli Üretim Denetimi (lang-audit) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A command-line QA harness that runs the engine end-to-end in DE/IT/FR/ES (native brief per language, two models), has an independent OpenAI judge score each run against a per-language rubric, and writes a shareable comparative report — so a demo never shows linguistically weak output.

**Architecture:** A sibling of `web/scripts/bakeoff.ts`. The money-spending parts (running the pipeline per lang×model, calling the judge) live in a thin CLI (`run.ts`) that is NOT in the test suite — exactly like bakeoff. Everything with logic — Zod schemas, the GREEN/YELLOW/RED verdict, the rubric/judge-prompt, the report generator, and the audit orchestration (with an injected judge fn) — is a pure, unit-tested module built and proven with mocks at $0. The paid run is Elif's trigger.

**Tech Stack:** TypeScript, `tsx` scripts, Zod (repo hard-rule: LLM output validated by schema, no regex), Vitest, existing pipeline (`core/pipeline/run-step.ts`) and OpenRouter client (`core/llm`).

## Global Constraints

- **Work only inside `web/`.** Commit after every task, message ending `Co-Authored-By: Claude Opus 4.8 <noreply@anthropic.com>`.
- **No live OpenRouter calls during build/test.** Building and testing this harness must cost $0: every test uses mock/fixture data. Only `run.ts`'s real invocation spends money, and that invocation is **Elif's trigger** (Kleinburg guardrail — Claude never spends autonomously).
- **`core/` stays framework-neutral and untouched.** This harness lives under `scripts/`; it CONSUMES `core/` (runStep, openrouter) but does not modify it. Do NOT refactor `bakeoff.ts`.
- **LLM output via Zod (hard-rule 4):** the judge's JSON is validated by a Zod schema; a non-conforming response is retried, then fails loudly. No regex/prose parsing.
- **Models:** generation = `anthropic/claude-sonnet-5` and `moonshotai/kimi-k3` (via `OPENROUTER_MODEL`, per bakeoff). Judge = `openai/gpt-4.1` (independent of both; must be in Elif's OpenRouter allowlist — a non-allowlisted model 404s).
- **Judge granularity = per (lang × model), NOT per step.** The judge sees a run's full output at once and cites the step in its evidence. Rationale: 2 models × 4 langs = 8 judge calls (~$3, within the ~$18 ceiling); per-step would be 40 calls (~$15, over budget). The rubric doc §4 is updated to match in Task 0.
- **Rubric = the approved doc.** `docs/superpowers/specs/2026-07-24-multilang-content-audit-rubric.md` is the source: 4 dimensions, weights 35/15/20/30, banned-term table per language, GREEN/YELLOW/RED thresholds (banned term or any dim ≤2 or weighted <3.0 → RED; 3.0–3.9 → YELLOW; ≥4.0 and no dim <4 → GREEN).
- **Register comes from the brief, not the rubric** (Elif decision): each fixture brief declares Köken's register in its own language; the judge scores adherence.
- **Report is English narrative + verbatim original-language evidence quotes** (Elif decision).
- **Verify:** per-file `cd web && npx vitest run <path>`; full suite `npm run test:db` before the last task's completion.
- **Test-teeth:** after writing a test, break the thing it guards, watch it go red, then revert.

---

### Task 0: Align the rubric doc to per-run judging (stale-claim fix)

**Files:**
- Modify: `docs/superpowers/specs/2026-07-24-multilang-content-audit-rubric.md` (§4)

- [ ] In §4, change "Her `(dil × model × adım)` için" to "Her `(dil × model)` için (judge run'ın tüm çıktısını birlikte görür, kanıtta adımı belirtir)". Add one line: "Granülerlik bütçe kararı: per-step 40 judge çağrısı (~$15) tavanı aşardı; per-run 8 çağrı (~$3) tavanda kalır." This keeps the doc from asserting a granularity the harness does not implement (self-audit rule 1).
- [ ] Commit.

---

### Task 1: Zod schemas + verdict logic

**Files:**
- Create: `web/scripts/lang-audit/schemas.ts`
- Create: `web/scripts/lang-audit/verdict.ts`
- Test: `web/scripts/lang-audit/verdict.test.ts`

**Interfaces:**
- Produces:
  - `DIMENSIONS = ["nativeTone","cultural","register","brandVoice"] as const` and `type Dimension`.
  - `WEIGHTS: Record<Dimension, number>` = `{ nativeTone:0.35, cultural:0.15, register:0.20, brandVoice:0.30 }`.
  - `DimensionScoreSchema` (Zod): `{ score: 1..5 int, rationale: string(min1), evidence: string(min1), suggestedFix: string | null }`.
  - `JudgeResultSchema` (Zod): `{ scores: Record<Dimension, DimensionScore>, bannedTermsFound: string[], summary: string(min1) }` — note: NO verdict field from the judge; verdict is computed deterministically in `verdict.ts` so the gate is code, not model opinion.
  - `type JudgeResult = z.infer<typeof JudgeResultSchema>`.
  - `computeVerdict(result: JudgeResult): { verdict: "GREEN"|"YELLOW"|"RED"; weightedTotal: number }`.

- [ ] **Step 1: Write the failing test** (`verdict.test.ts`)

```ts
import { describe, expect, it } from "vitest";
import { computeVerdict } from "./verdict";
import type { JudgeResult } from "./schemas";

function res(scores: [number, number, number, number], banned: string[] = []): JudgeResult {
  const [nativeTone, cultural, register, brandVoice] = scores;
  const mk = (score: number) => ({ score, rationale: "r", evidence: "e", suggestedFix: null });
  return {
    scores: { nativeTone: mk(nativeTone), cultural: mk(cultural), register: mk(register), brandVoice: mk(brandVoice) },
    bannedTermsFound: banned,
    summary: "s",
  };
}

describe("computeVerdict", () => {
  it("RED when a banned term is found, regardless of scores", () => {
    expect(computeVerdict(res([5, 5, 5, 5], ["Superfood"])).verdict).toBe("RED");
  });
  it("RED when any dimension is <=2", () => {
    expect(computeVerdict(res([5, 5, 2, 5])).verdict).toBe("RED");
  });
  it("RED when the weighted total is <3.0", () => {
    // 3,3,3,2 -> .35*3+.15*3+.20*3+.30*2 = 2.7
    expect(computeVerdict(res([3, 3, 3, 2])).verdict).toBe("RED");
  });
  it("YELLOW for a mid run (total 3.0–3.9, no dim <=2, no banned)", () => {
    // 4,3,3,4 -> 1.4+.45+.6+1.2 = 3.65
    expect(computeVerdict(res([4, 3, 3, 4])).verdict).toBe("YELLOW");
  });
  it("GREEN only when total >=4.0 AND no dimension <4", () => {
    expect(computeVerdict(res([4, 4, 4, 4])).verdict).toBe("GREEN");
  });
  it("not GREEN if a dimension is 3 even when the total is >=4.0", () => {
    // 5,5,3,5 -> 1.75+.75+.6+1.5 = 4.6 total, but register=3 -> YELLOW
    expect(computeVerdict(res([5, 5, 3, 5])).verdict).toBe("YELLOW");
  });
});
```

- [ ] **Step 2: Run — expect FAIL** (`npx vitest run scripts/lang-audit/verdict.test.ts`), module not found.
- [ ] **Step 3: Implement `schemas.ts`** with the exact shapes in Interfaces (Zod, `z.number().int().min(1).max(5)` for score, `.nullable()` for suggestedFix).
- [ ] **Step 4: Implement `verdict.ts`**

```ts
import { DIMENSIONS, WEIGHTS, type JudgeResult } from "./schemas";

export function computeVerdict(result: JudgeResult): {
  verdict: "GREEN" | "YELLOW" | "RED";
  weightedTotal: number;
} {
  const weightedTotal = DIMENSIONS.reduce(
    (sum, d) => sum + result.scores[d].score * WEIGHTS[d],
    0,
  );
  const anyLow = DIMENSIONS.some((d) => result.scores[d].score <= 2);
  const anyBelow4 = DIMENSIONS.some((d) => result.scores[d].score < 4);
  if (result.bannedTermsFound.length > 0 || anyLow || weightedTotal < 3.0) {
    return { verdict: "RED", weightedTotal };
  }
  if (weightedTotal >= 4.0 && !anyBelow4) return { verdict: "GREEN", weightedTotal };
  return { verdict: "YELLOW", weightedTotal };
}
```

- [ ] **Step 5: Run — expect PASS.** Then prove teeth: flip `< 3.0` to `< 0`, watch the "RED when weighted <3.0" test fail, revert.
- [ ] **Step 6: Commit** `schemas.ts`, `verdict.ts`, `verdict.test.ts`.

---

### Task 2: Rubric data + judge-prompt builder

**Files:**
- Create: `web/scripts/lang-audit/rubric.ts`
- Test: `web/scripts/lang-audit/rubric.test.ts`

**Interfaces:**
- Consumes: `DIMENSIONS` from `schemas.ts`.
- Produces:
  - `type AuditLang = "de" | "it" | "fr" | "es"`.
  - `BANNED_TERMS: Record<AuditLang, string[]>` — copied verbatim from the rubric doc §1 D4 table (e.g. `de: ["natürlich","ohne Zusätze","100%","Superfood","Detox","Wunder"]`, and the fr/it/es rows).
  - `buildJudgePrompt(lang: AuditLang, generated: string): string` — returns the judge instruction: the 4 dimensions with their definitions, the language's banned-term list, the rule "score the register the BRIEF declared, and consistency", the demand for verbatim original-language evidence + a suggestedFix when a dimension <4, and a strict instruction to return ONLY JSON matching the schema (fields: scores.{nativeTone,cultural,register,brandVoice}.{score,rationale,evidence,suggestedFix}, bannedTermsFound, summary).

- [ ] **Step 1: Write the failing test**

```ts
import { describe, expect, it } from "vitest";
import { BANNED_TERMS, buildJudgePrompt } from "./rubric";

describe("rubric", () => {
  it("carries the banned-term list for every audit language", () => {
    for (const lang of ["de", "it", "fr", "es"] as const) {
      expect(BANNED_TERMS[lang].length).toBeGreaterThan(0);
    }
    expect(BANNED_TERMS.de).toContain("Superfood");
    expect(BANNED_TERMS.fr).toContain("superaliment");
  });

  it("builds a judge prompt that names the four dimensions and the language's banned terms", () => {
    const p = buildJudgePrompt("de", "GENERATED_CONTENT_HERE");
    for (const marker of ["nativeTone", "cultural", "register", "brandVoice"]) {
      expect(p).toContain(marker);
    }
    expect(p).toContain("Superfood");
    expect(p).toContain("GENERATED_CONTENT_HERE");
    // evidence must be verbatim, original-language
    expect(p.toLowerCase()).toContain("verbatim");
  });
});
```

- [ ] **Step 2: Run — expect FAIL.**
- [ ] **Step 3: Implement `rubric.ts`** — the `BANNED_TERMS` map (verbatim from the rubric doc table) and `buildJudgePrompt` producing the instruction described in Interfaces. Keep the prompt text in one template; include the dimension keys literally so the test and the schema stay aligned.
- [ ] **Step 4: Run — expect PASS.** Teeth: remove "Superfood" from `BANNED_TERMS.de`, watch the test fail, revert.
- [ ] **Step 5: Commit.**

---

### Task 3: Report generator

**Files:**
- Create: `web/scripts/lang-audit/report.ts`
- Test: `web/scripts/lang-audit/report.test.ts`

**Interfaces:**
- Consumes: `AuditLang`, `JudgeResult` (`schemas.ts`), `computeVerdict` (`verdict.ts`).
- Produces:
  - `type RunResult = { lang: AuditLang; model: string; judge: JudgeResult }`.
  - `buildReport(results: RunResult[]): string` — English markdown: (1) an executive-summary table of lang × model cells each showing GREEN/YELLOW/RED + weighted total; (2) a per-language section with the 4-dimension breakdown, rationale, and the verbatim evidence quotes; (3) a "which model is stronger per language" summary. RED cells/verdicts must be visually unmistakable (e.g. `**RED**`).

- [ ] **Step 1: Write the failing test**

```ts
import { describe, expect, it } from "vitest";
import { buildReport, type RunResult } from "./report";
import type { JudgeResult } from "./schemas";

const green: JudgeResult = {
  scores: {
    nativeTone: { score: 5, rationale: "reads native", evidence: "»Ihre Marke«", suggestedFix: null },
    cultural: { score: 4, rationale: "ok", evidence: "x", suggestedFix: null },
    register: { score: 4, rationale: "Sie throughout", evidence: "y", suggestedFix: null },
    brandVoice: { score: 4, rationale: "on voice", evidence: "z", suggestedFix: null },
  },
  bannedTermsFound: [],
  summary: "Solid German run.",
};
const red: JudgeResult = { ...green, bannedTermsFound: ["Superfood"], summary: "Banned term used." };

it("renders a lang×model matrix and surfaces RED verdicts", () => {
  const results: RunResult[] = [
    { lang: "de", model: "claude-sonnet-5", judge: green },
    { lang: "de", model: "kimi-k3", judge: red },
  ];
  const md = buildReport(results);
  expect(md).toContain("GREEN");
  expect(md).toContain("RED");
  expect(md).toContain("Superfood"); // banned term surfaced
  expect(md).toContain("»Ihre Marke«"); // verbatim evidence, original language
  expect(md).toContain("claude-sonnet-5");
  expect(md).toContain("kimi-k3");
});
```

- [ ] **Step 2: Run — expect FAIL.**
- [ ] **Step 3: Implement `report.ts`** producing the three sections; call `computeVerdict` per result for the matrix and section headers.
- [ ] **Step 4: Run — expect PASS.** Teeth: make `buildReport` omit `bannedTermsFound`, watch the "Superfood" assertion fail, revert.
- [ ] **Step 5: Commit.**

---

### Task 4: Audit orchestrator (mock-tested)

**Files:**
- Create: `web/scripts/lang-audit/audit.ts`
- Test: `web/scripts/lang-audit/audit.test.ts`

**Interfaces:**
- Consumes: `AuditLang`, `JudgeResult`, `RunResult`, `buildReport`.
- Produces:
  - `type GeneratedRun = { lang: AuditLang; model: string; content: string }`.
  - `type JudgeFn = (lang: AuditLang, content: string) => Promise<JudgeResult>`.
  - `async function auditRuns(runs: GeneratedRun[], judge: JudgeFn): Promise<RunResult[]>` — maps each generated run through the injected judge, preserving lang+model. This is the orchestration the spec requires to be tested with mocks — the injected `judge` is the seam.

- [ ] **Step 1: Write the failing test** (mock judge; no network)

```ts
import { describe, expect, it, vi } from "vitest";
import { auditRuns, type GeneratedRun, type JudgeFn } from "./audit";
import type { JudgeResult } from "./schemas";

const stub: JudgeResult = {
  scores: {
    nativeTone: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    cultural: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    register: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    brandVoice: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
  },
  bannedTermsFound: [],
  summary: "s",
};

it("judges every generated run and preserves lang+model", async () => {
  const judge = vi.fn<JudgeFn>().mockResolvedValue(stub);
  const runs: GeneratedRun[] = [
    { lang: "de", model: "claude-sonnet-5", content: "DE-A" },
    { lang: "fr", model: "kimi-k3", content: "FR-B" },
  ];
  const results = await auditRuns(runs, judge);
  expect(judge).toHaveBeenCalledTimes(2);
  expect(judge).toHaveBeenCalledWith("de", "DE-A");
  expect(results.map((r) => `${r.lang}:${r.model}`)).toEqual([
    "de:claude-sonnet-5",
    "fr:kimi-k3",
  ]);
  expect(results[0].judge).toEqual(stub);
});
```

- [ ] **Step 2: Run — expect FAIL.**
- [ ] **Step 3: Implement `audit.ts`** — a simple sequential (or `Promise.all`) map applying `judge` to each run and returning `RunResult[]`.
- [ ] **Step 4: Run — expect PASS.** Teeth: make `auditRuns` skip the last run, watch the length/order assertion fail, revert.
- [ ] **Step 5: Commit.**

---

### Task 5: Real judge call + schema-validated retry

**Files:**
- Create: `web/scripts/lang-audit/judge.ts`
- Test: `web/scripts/lang-audit/judge.test.ts`

**Interfaces:**
- Consumes: `buildJudgePrompt` (`rubric.ts`), `JudgeResultSchema` (`schemas.ts`), `AuditLang`, `JudgeFn`.
- Produces: `function makeJudge(callModel: (prompt: string) => Promise<string>): JudgeFn` — builds the prompt, calls `callModel`, parses+validates the JSON with `JudgeResultSchema`; on a validation failure it retries once, then throws (hard-rule 4/5: loud failure, no partial). The real wiring passes a `callModel` that hits `openai/gpt-4.1` via the OpenRouter client; the test passes a fake `callModel`.

- [ ] **Step 1: Write the failing test** (fake `callModel`, no network)

```ts
import { describe, expect, it, vi } from "vitest";
import { makeJudge } from "./judge";

const valid = JSON.stringify({
  scores: {
    nativeTone: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    cultural: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    register: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
    brandVoice: { score: 4, rationale: "r", evidence: "e", suggestedFix: null },
  },
  bannedTermsFound: [],
  summary: "s",
});

it("validates the judge JSON and returns the parsed result", async () => {
  const judge = makeJudge(vi.fn().mockResolvedValue(valid));
  const out = await judge("de", "content");
  expect(out.scores.nativeTone.score).toBe(4);
});

it("retries once on a schema-invalid response, then succeeds", async () => {
  const call = vi.fn().mockResolvedValueOnce('{"scores":{}}').mockResolvedValueOnce(valid);
  const judge = makeJudge(call);
  await judge("de", "content");
  expect(call).toHaveBeenCalledTimes(2);
});

it("throws after a second invalid response (no silent partial)", async () => {
  const call = vi.fn().mockResolvedValue('{"nope":true}');
  const judge = makeJudge(call);
  await expect(judge("de", "content")).rejects.toThrow();
  expect(call).toHaveBeenCalledTimes(2);
});
```

- [ ] **Step 2: Run — expect FAIL.**
- [ ] **Step 3: Implement `judge.ts`** — `makeJudge` builds the prompt via `buildJudgePrompt`, calls `callModel`, `JSON.parse` inside try/catch, validates with `JudgeResultSchema.safeParse`; on failure retry once (re-call), on second failure throw an Error naming the validation issue. Strip markdown code fences if present before parsing.
- [ ] **Step 4: Run — expect PASS.** Teeth: change retry to zero attempts, watch the "retries once" test fail, revert.
- [ ] **Step 5: Commit.**

---

### Task 6: Four native fixture briefs (Köken, register declared)

**Files:**
- Create: `web/scripts/lang-audit/fixture/de.txt`
- Create: `web/scripts/lang-audit/fixture/it.txt`
- Create: `web/scripts/lang-audit/fixture/fr.txt`
- Create: `web/scripts/lang-audit/fixture/es.txt`

**Interfaces:**
- Consumed by `run.ts` (Task 7) as the per-language brief fed to generation.

- [ ] **Step 1: Write four native briefs** — each a localized version of the Köken brand (`web/bakeoff-brief.txt` is the Turkish source) fully in that language: brand summary, product/price, audience, competition, **brand voice**, business goal. Each brief must EXPLICITLY declare the register in its own language (Köken = warm/informal → DE `du` · FR `tu` · IT `tu` · ES `tú`) in the brand-voice section, and carry the "words we don't use" list in that language (from the rubric doc banned-term table) so adherence is testable. Keep them equivalent in substance across languages (same brand, localized).
- [ ] **Step 2: Sanity-check** each file is non-empty and names the register: `grep -l` for the register word (`du`/`tu`/`tú`) in each. (No unit test — these are content fixtures; quality is native-review scope, flagged like the UI catalogs.)
- [ ] **Step 3: Commit** the four briefs with a "native-review pending" note in the message.

---

### Task 7: `run.ts` CLI (generation + audit + report; money-spending, Elif-triggered)

**Files:**
- Create: `web/scripts/lang-audit/run.ts`
- Create: `web/scripts/lang-audit/README.md`

**Interfaces:**
- Consumes: `runStep`/`upsertStepContent`/`recommendPostCounts` (as `bakeoff.ts` does), `makeJudge` + OpenRouter client, `auditRuns`, `buildReport`, the four fixtures, `BANNED_TERMS`/rubric.
- Produces: an executable that, for each `lang ∈ {de,it,fr,es}` and each `model ∈ {sonnet-5, kimi-k3}`, runs the full pipeline on that lang's brief (throwaway brand+project, like bakeoff), collects the generated content, then runs `auditRuns(runs, realJudge)` and writes `web/audits/lang-audit-<ISO>/report.md` plus the raw generated outputs.

- [ ] **Step 1: Implement `run.ts`** mirroring `bakeoff.ts`'s pipeline-running scaffolding (do NOT modify bakeoff): guard on `OPENROUTER_API_KEY`; loop lang×model; set `process.env.OPENROUTER_MODEL` per model; generate; concatenate each run's step outputs into one `content` string tagged by step; build `GeneratedRun[]`; construct `realJudge = makeJudge(promptForGpt41)` where `promptForGpt41` calls `openai/gpt-4.1` through the existing OpenRouter client; `await auditRuns(runs, realJudge)`; `buildReport`; write the dated dir. Accept `--langs`, `--models`, `--posts` (default 5), `--platforms` (default instagram) flags so cost is controllable; log the model list and estimated call count before starting.
- [ ] **Step 2: `README.md`** — documents the exact command, the ~$18 ceiling (from measured bakeoff costs), that it spends real OpenRouter credit, that the judge must be allowlisted, and that **the run is Elif's trigger**. Include the judge sanity-probe idea (run the judge once over an existing `bakeoff-runs/*` output first).
- [ ] **Step 3: Typecheck only** — `cd web && npm run typecheck` must pass. Do NOT execute `run.ts` (it spends money; that is Elif's trigger). This task's deliverable is verified by typecheck + the fact that every module it wires (Tasks 1–5) is unit-tested; the end-to-end money run is the acceptance Elif performs.
- [ ] **Step 4: Full suite** — `cd web && npm run test:db` green (the lang-audit unit tests included; run.ts is not in the suite, like bakeoff). lint + typecheck green.
- [ ] **Step 5: Commit.**

---

## Acceptance
- All logic modules (Tasks 1–5) unit-tested and green; full suite + lint + typecheck green; typecheck covers `run.ts`.
- Four native briefs exist with declared register (native-review pending).
- `run.ts` + README complete; the paid end-to-end run is **not** executed by Claude — it is handed to Elif with the exact command and the cost/allowlist notes.

## Out of scope (YAGNI)
- In-app admin screen; human-review workflow; fixing the engine's prompts (audit measures first); cross-check second judge (rubric §5, default off).
