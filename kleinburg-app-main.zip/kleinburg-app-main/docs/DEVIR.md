# Devir ve Operasyon Runbook — Kleinburg

Bu doküman projeyi devralan ekip içindir. Amaç: bir geliştiricinin ilk gün ortama girip,
güvenle değişiklik yapıp prod'a çıkarabilmesi. Detayları tekrar etmez, doğru dosyaya yönlendirir:
kod ve içindeki yorumlar > [`../README.md`](../README.md) > [`../CLAUDE.md`](../CLAUDE.md).

**Hosting notu:** Bu doküman yazıldığında (24 Tem 2026) sistem Render'da çalışıyordu; o kurulum
(`render.yaml`, `DEPLOY_RENDER.md`) tamamen kaldırıldı ve sistem başka bir yere taşınıyor. Aşağıdaki
bölümlerden Render'a özgü olanlar (2, 3'ün Render satırı, 6) artık **tarihsel** — o günkü mimariyi
anlatıyor, bugünün deploy hedefini değil. Yeni hosting netleşince bu doküman (özellikle bölüm 2 ve 6)
yeniden yazılmalı.

## 1. Sistem tek paragrafta

Marka dokümanlarını 9 adımlı bir akışla sosyal medya kampanyasına çeviren, çok kiracılı
(brand → project → content) içerik motoru. Next.js 15 + TypeScript, tek web servisi +
Postgres (hosting belirlenmedi — bkz. üstteki not). Uzun üretimler `pg-boss` iş kuyruğunda
**aynı process** içinde koşar (ayrı worker yok).
LLM erişimi OpenRouter üzerinden; çıktılar Zod şemasıyla doğrulanır. Uygulamanın tamamı `web/`
altında.

## 2. Ortamlar

| Ortam | URL | Dal | Servis / DB | Not |
|---|---|---|---|---|
| **prod** | belirlenmedi | `rebuild` | belirlenmedi | canlı, gerçek harcama |
| **test** | belirlenmedi | `test` | belirlenmedi | staging, ayrı DB + ayrı OpenRouter anahtarı |
| **local** | http://localhost:3000 | herhangi | docker Postgres | model çağrısı yapmaz |

**İlke, hosting'ten bağımsız ve değişmeden kalmalı:** prod ve test **tam izole** olacak — ayrı
veritabanı, ayrı secret'lar, ayrı harcama, `test`'e push edilen prod'u etkilemeyecek. Yeni hosting
seçildiğinde bu tablonun URL/Servis sütunları doldurulur, izolasyon ilkesi aynı kalır.

## 3. Erişimler (devir sırasında verilecek)

- **GitHub:** `elifc/kleinburg-app` reposuna yazma (contributor) erişimi. Erişim: **Elif C** (repo owner).
  - Arşiv (read-only, geçmiş): `elifc/kleinburg` — kapalı issue'lar, PR'lar, legacy `main`.
- **Hosting:** Render kurulumu (Elif C'nin hesabındaydı) kaldırıldı, yeni sağlayıcı belirlenmedi.
  Hosting provider seçimi/değişikliği **Serhat A ve Alper B'nin ortak kararıyla** alınır — bu kural
  hâlâ yürürlükte ve şu anki geçişin kendisi de bu kurala tabi.
- **OpenRouter:** **şirket organizasyon hesabı**; adminler: Elif C, Alper B, Serhat A. prod ve
  test için **ayrı** API anahtarları (harcama izolasyonu).
- **İş takibi:** GitHub Issues (ayrı bir Project board kullanılmıyor). Detay: bölüm 7.

## 4. İlk gün — local kurulum

```bash
nvm use                      # Node 22 (kökteki .nvmrc; CI ile aynı, esnetme)
cd web && npm ci             # `npm install` DEĞİL — aşağıdaki tuzağa bak
npm run db:up && npm run db:migrate
npm run seed demo            # demo hesabı + 9 adımı model çağrısı olmadan yürünebilir proje
npm run dev                  # http://localhost:3000, giriş: demo / demo12345678
```

Detay ve testler: [`../README.md`](../README.md) → "Çalıştırma". `seed demo` yalnız local DB'de
çalışır (parola kaynak kodda; guard uzak DB'yi reddeder).

## 5. Değişiklik yapmak — feature → test → rebuild

Tam adımlar ve koruma kuralları: [`../CLAUDE.md`](../CLAUDE.md) → "Branch akışı ve katkı". Özet:

1. `test`'ten feature dalı → değişiklik → lokal doğrulama yeşil → PR base **`test`** → merge → **test ortamında dene**.
2. Onaylanınca PR base **`rebuild`** → lokal doğrulama yeşil → merge → prod deploy.

Lokal doğrulama: `npm run lint && npm run typecheck && npm run build && npm run test:db` (GitHub'da
CI kapalı, bunu koşturan başka bir mekanizma yok).

`rebuild` (prod) korumalı: doğrudan push kapalı, PR şart (eskiden yeşil `ci` de şarttı; CI kapalı
olduğu için artık işlemez). Otomatik deploy, yeni hosting seçilip bağlanınca geri gelecek; o ana
kadar merge sonrası çıkış manuel.

## 6. Deploy ve ortam değişkenleri

**Bu bölüm tarihsel — Render kurulumu kaldırıldı, runbook yok.** Eski kurulumun ilkeleri
(yeni hosting da bunlara uymalı):

- Migration'lar sunucu ayağa kalkmadan ÖNCE koşmalı (`db:migrate && start` gibi bir sıra) —
  "Live"/"Ready" görmek migration'ın geçtiğini kanıtlamalı, ayrı bir manuel adım olmamalı.
- Secret'lar **repoda değil**, hosting'in kendi ortam değişkeni mekanizmasında tutulmalı.

Eskiden Render'da her serviste ayrı ayrı girilen (`sync: false`) secret'lar:

| Değişken | Nerede (yeni hosting'de belirlenecek) | Yoksa ne olur |
|---|---|---|
| `OPENROUTER_API_KEY` | prod/test ayrı anahtar | üretim adımları "servis yapılandırılmamış" der |
| `AUDIT_MASK_KEY` | 32+ karakter | **uygulama boot etmez** |
| `DATABASE_URL` | hosting'in DB'si / local `.env` | DB testleri atlanır, prod açılmaz |

## 7. İş takibi

**GitHub Issues** (`elifc/kleinburg-app`) ile ilerlenir; ayrı bir Project board kullanılmıyor.
Numaralar fork'tan taşınırken yeniden atandı:

  | Eski (arşiv fork) | Yeni | Konu |
  |---|---|---|
  | #24 | **#1** | Playwright E2E + canlı üretim turu |
  | #36 | **#2** | İlerleme kaydı (pinned, buradan takip) |
  | #72 | **#3** | Kapsız model çağrıları (`maxTokens`) |
  | #77 | **#4** | Takvimde kayıtsız platform |
  | #78 | **#5** | Dişsiz testler |
  | #79 | **#6** | Tekrar üretilemeyen test hatası |
  | #85 | **#7** | Devam eden üretim görünmezliği |

  Koddaki/commit'lerdeki eski `#NN` referansları arşiv fork'a redirect'le çözülür.

Kalıcı ilerleme kaydı: pinned issue **#2**.

## 8. Değiştirmeden önce oku — esnemez kurallar

[`../CLAUDE.md`](../CLAUDE.md) → "Hard rules" ve "Teslim öncesi öz-denetim". Kısaca:

- **Marka izolasyonu kutsaldır** — proje-kapsamlı her sorgu `requireProjectAccess`'ten geçer.
- **Yapılandırılmış çıktı tek yoldur** — Zod'u geçmeyen LLM çıktısı = başarısız iş, kısmi kayıt yok.
- **Sessiz hata yasak** — her iş succeeded/failed + gerçek neden.
- **`core/` UI import edemez** (ESLint zorlar), **tema elle düzenlenmez** (`design/tokens.json`).
- Kodda **"Elif'in kararı"** işaretli yerler bilinçli tercihlerdir; bug gibi görünse de gerekçesi
  yazılmadan değiştirilmez.
- **En sık hata:** bir davranış değişir, onu anlatan yorum değişmez → sonraki okuyucu yalana güvenir.
  Davranışı değiştirdiğinde onun hakkındaki her cümleyi ara ve düzelt.

## 9. Bilinen tuzaklar (operasyonel)

- **`npm install` çalıştırma (macOS'ta), `npm ci` kullan.** Düz `npm install` lockfile'dan
  `@emnapi/*` kayıtlarını siler ve CI/deploy'u kırar (bu kayıtlar yalnız Linux'ta çözülür).
  Bozulursa lockfile'ı geri al.
- **Node 22'ye sabit, beş yerde** (kök + `web/` `.nvmrc`, CI, `package.json` engines,
  `docker-compose.dev.yml`). `nvmrc-sync.test.ts` senkron tutar. Farklı Node major'ında sessizce
  kırılan hatalar buradan çıktı (ör. yalnız Node 22'de düşen `.pptx` yükleme). Yeni hosting
  seçilince onun da bir Node sürüm pini olacak — `nvmrc-sync.test.ts`'e altıncı bir kontrol olarak
  eklenmeli (render.yaml için olan tam olarak buydu, hosting kaldırılınca o kontrol de kaldırıldı).
- **`npm test` DB testlerini atlar** (DATABASE_URL kabukta yoksa); tam suite `npm run test:db`.
  Atlanınca koşu sonunda gürültülü uyarı basılır — uyarıyı gördüysen tam suite'i koşmamışsındır.
- **Yeni test yazınca kasten kır, kırmızıya döndüğünü gör.** Kırmızıya dönmeyen test sahtedir;
  üretime giden üç sahte test yalnız bu adımla yakalandı.

## 10. İletişim

- Ürün sahibi / karar mercii: **Elif C** (repo owner). İletişim kanalı: **Teams grubu**.
- Devir tarihi: **24 Temmuz 2026**. Devralan ekip: **HCX Ist — Dev Team**.
