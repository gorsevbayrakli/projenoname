# Kleinburg — Legacy Sistem Analizi

> Tarih: 2026-07-18 · Analiz edilen nokta: `legacy-snapshot` tag'i (commit `817e507`)
> Amaç: Sistemi legacy referans olarak çözümlemek ve akışı sıfırdan inşa etmeden önce
> neyin taşınacağına / atılacağına karar vermek.

---

## 1. Sistem Nedir?

Kleinburg, marka dokümanlarını sosyal medya kampanyalarına dönüştüren, **Azure'da canlı**,
çok kiracılı (multi-tenant) bir **Streamlit** uygulaması. Replit prototipinden evrilmiş,
sonradan disiplinli bir refactor ile `core/` motoruna ayrıştırılmış (~14K satır Python, 69 dosya).

**Sabit 8 adımlı iş akışı:**

1. Document Upload (PDF/DOCX/PPTX/URL)
2. Brand Context (LLM ile marka analizi — "Brand Key" modeli)
3. Secondary Data (Perplexity araştırması)
4. Additional Input (insan içgörüsü)
5. Creative Sparks (30+ fikir kıvılcımı)
6. SM Pillars (3 kategoride 30 içerik teması)
7. SM Posts (Instagram + opsiyonel Facebook)
8. Content Calendar (30 günlük takvim)

**Sağlayıcılar:** Generation → Gemini (varsayılan, `gemini-2.5-pro`), OpenAI, Anthropic, Grok, Kimi.
Research → Perplexity (varsayılan, `sonar-pro`), Brave, Gemini.
**Diller:** EN, TR, FR, DE, ES, IT, PT (7 dil; İngilizce byte-identical eski davranış).

**Tenancy modeli:** brand → project → content. Admin, kullanıcılara marka erişimini
allowlist (`user_brands`) ile verir. Her marka için adım başına LLM/model seçimi ve
marka başına şifreli API anahtarı yapılandırılabilir (kendi faturası).

---

## 2. Mimari

### Katmanlar

```
[Tarayıcı / Streamlit WebSocket]
        |
     app.py (315)          — gate zinciri: auth → admin → walkthrough → picker → workflow
        |
  VIEW KATMANI (kök .py'ler, streamlit import eder)
     workflow.py (1888)       8 adımın UI + orkestrasyonu
     auth_postgres.py (1951)  auth + session + admin UI (god file)
     llm_utils.py (703)       üretim çağrılarının view sarmalayıcısı
     brand_project_ui / content_manager_ui / walkthrough_ui / ui_utils
        |
  core/ — FRAMEWORK-NÖTR MOTOR (streamlit import ETMEZ — hard rule 6)
     providers/ (gemini, openai, anthropic, grok, kimi, perplexity, brave)
     generation_config, extraction, languages, posts, tenancy, schema
     security, crypto, provider_keys, config, db (pool), reporting, text
        |
  [PostgreSQL — Azure Flexible Server, SSL zorunlu]
```

### Legacy'nin "Hard Rule"ları (önceki geliştiricinin CLAUDE.md'sinden)

1. `prompts/` dondurulmuş — yaratıcı çıktı korunur (yalnızca 2 takvim promptu onaylı düzenlendi)
2. PostgreSQL kesin veritabanı (SQLite yolu ölü)
3. Marka izolasyonu kutsal — hiçbir okuma/yazma marka sınırını geçemez
4. `core/` hiçbir zaman `streamlit` import edemez

### Üretim pipeline deseni (her adımda)

prompt dosyası oku (`lru_cache`) → `.format(...)` → `_apply_language` (EN'de no-op) →
`(provider, model)` çöz (`brand_step_model_config` → yoksa varsayılan) → backend çağır →
regex ile prose parse → `reconcile` ile native JSON extraction (Faz 7; regex fallback) → sonuç.

---

## 3. Veri Katmanı

### Şema (iki kaynağa bölünmüş — "split-brain")

- **Çekirdek tablolar** `auth_postgres.py:93-278` içinde inline DDL: `users`,
  `registration_keys`, `user_sessions`, `user_activities`, `document_uploads`,
  `content_generation`, `user_content_storage`
- **Tenancy/config tabloları** `core/schema.py`: `brands`, `user_brands`, `projects`,
  `brand_step_model_config`, `brand_research_config`, `brand_provider_keys`, `token_usage`
- Gerçek migration aracı yok; değişiklikler idempotent `ALTER ... IF NOT EXISTS` yamaları.
- **İçerik tablolarındaki `brand_id`/`project_id` FK'sız "soft pointer"** — bütünlük
  tamamen uygulama koduna emanet (`core/tenancy.py:63-75` elle silme yapmak zorunda).

### Auth

- Parola: PBKDF2-HMAC-SHA256, 600k iterasyon (`core/security.py`); eski SHA-256'dan
  login'de şeffaf rehash.
- Oturum: opak `secrets.token_urlsafe(32)` token, DB'de yalnızca hash; 4 saat mutlak
  timeout; 30 dk'da token rotasyonu + 3 dk grace (`auth_postgres.py:779-858`).
- Kabul edilmiş risk: Streamlit HttpOnly cookie kuramadığından token XSS'e açık;
  CSP proxy'de eklenecekti (hiç eklenmedi).
- Roller: ikili (`is_admin` 0/1); `require_admin()` sunucu taraflı gate.

### İzolasyon

Tüm içerik I/O `_active_scope()` üzerinden `project_id` ile filtreli
(`content_storage.py:39-106`); token restore'da marka erişimi canlı allowlist'e karşı
yeniden doğrulanır. Ama DB kısıtı yok — `_active_scope()` `None` dönerse sorgular
sessizce yanlış kapsama düşebilir.

### API anahtarı şifreleme

MultiFernet (`core/crypto.py`), master anahtar(lar) `KEY_ENCRYPTION_SECRET` env'inden
(virgülle rotasyon). Marka anahtarı env'i override eder; düz metin asla DB'ye yazılmaz.

---

## 4. KRİTİK: Son commit üretimi kırıyor (doğrulandı)

Son commit (`817e507`, token-usage raporu) `llm_utils.py:143,164,185` ve
`core/extraction.py:92`'de backend'lere **koşulsuz** `usage_sink=` geçiriyor; ancak
`core/providers/gemini.py` (üç metot: `generate:49`, `generate_json:96`, `research:150`)
ve `brave.py:40` bu parametreyi kabul etmiyor (`**kwargs` da yok). Sadece
OpenAI/Anthropic/Grok/Kimi/Perplexity güncellenmiş.

**Sonuç:** Varsayılan provider Gemini olduğundan, yapılandırılmamış her markada her
üretim adımı `TypeError: unexpected keyword argument 'usage_sink'` ile patlar. Bu
`ProviderError` değil, dolayısıyla retry/handling katmanlarını bypass eder. Ayrıca
Gemini token usage yakalama hiç yazılmamış (raporlama tablosu Gemini'de boş) ve maliyet
($) hesabı yok — sadece ham token sayısı.

---

## 5. Teknik Borç Envanteri

### God dosyalar
- `auth_postgres.py` (1951): DDL + veri erişimi + auth çekirdeği + **~%50'si admin UI**
- `workflow.py` (1888): 8 adımın hepsi; her adımda UI + LLM + loglama + kaydetme iç içe

### Ölü / yanıltıcı kod
- `session_manager.py` (155 satır) **hiç import edilmiyor** — tamamen ölü
- `get_client_ip()` (`auth_postgres.py:280`): sabit `"Production_User_IP"` döndüren,
  spoof edilebilir header okuyan kalıntı
- `add_user_postgres.py:16` **hâlâ salt'sız SHA-256** ile kullanıcı yaratıyor (ops riski)
- `execute_with_retry` (`db_utils_postgres.py`) canlı çağıranı yok; non-idempotent
  INSERT'te çift ekleme riski
- `gemini_diagnostic.py`, `test_gemini_simple.py`: Faz 5 öncesi manuel problar
- `content_manager_ui.py:113-120` adım etiketleri gerçek sırayla uyuşmuyor

### State yönetimi
- Merkezi durum nesnesi yok; ~35 `session_state` anahtarı dosyalar arası serbest dolaşıyor.
  Yeni anahtar `_WORKFLOW_DEFAULTS`'a eklenmezse **projeler arası içerik sızıntısı**
  (belgelenmiş hata sınıfı).
- `app.py:36-109` 20+ tekrar eden init bloğu; `current_step` iki kez başlatılıyor.

### Kırılganlık
- Parser'lar prose + regex'e bağlı (pillar parser 3 ayrı format; posts parser ```` ```css ````
  bloklarına ve EN/TR literal etiketlere bağımlı — ES/IT/PT'de extraction'a mahkûm).
- Promptlar `str.format` ile — literal `{}` kaçış sorunu; bazı promptlar parametre,
  bazıları sabit yol (tutarsız).
- Gemini eski `google.generativeai` SDK'sı süreç-global config kullanıyor →
  `_CONFIGURE_LOCK` tüm eşzamanlı Gemini üretimini serileştiriyor.
- Safety-block tespiti string eşleşmesiyle (`"safety" in str(e)`).
- `_record_usage`/`_log_generation` best-effort `except: pass` — sessiz veri kaybı.

### Performans (kabul edilmiş yapısal sınırlar)
- Streamlit tek-thread: her etkileşimde script baştan; uzun LLM çağrıları bloke ediyor.
- Extraction her adıma ikinci model çağrısı ekliyor; gemini-2.5-pro'da tek ağır adım
  ~757s, tam pro run **~40 dakika**.
- `ui_utils.animated_transition` `time.sleep()` ile 15+ yerde yapay gecikme.
- DB pool 1-10 sabit; DDL her instance açılışında koşuyor (yatay ölçek sorunu).

---

## 6. Test & Deploy Durumu

- **CI:** ruff + pytest, gerçek efemeral PostgreSQL 16'ya karşı; requirements/uv.lock
  senkron guard'ı. Deploy workflow'u CI'a **gate'li değil** (bağımsız).
- **Testler:** ~25 dosya / 145+ test. Güçlü: security, crypto, tenancy, izolasyon,
  provider key'ler, guard'lar. Zayıf: canlı API yanıtları, Streamlit-coupled akışlar
  (manuel doğrulanmış), client-side JS.
- **Deploy:** Azure App Service B1 Linux (native Python 3.12, North Europe), Azure
  PostgreSQL Flexible Server, GitHub Actions → main'den deploy, OIDC. Key Vault ve
  Front Door+CSP bilinçli atlandı ("Havas göçünde ilk madde" notuyla).

---

## 7. Yeni İnşa İçin Değerlendirme

### Taşımaya değer (kavram ve/veya kod olarak)

| Ne | Neden |
| --- | --- |
| **8 adımlı yaratıcı akış + dondurulmuş promptlar** | Ürünün kalbi; çıktı kalitesi bu prompt zincirinde. Prompt'lar olduğu gibi taşınmalı. |
| **brand → project → content tenancy modeli** | İş modeli gereksinimi; kavram doğru, uygulaması (FK'lı) yeniden yapılmalı. |
| **Provider soyutlaması fikri** (`core/providers/` registry, adım başına model çözümü, marka başına şifreli anahtar) | Tasarım sağlam; kod modern SDK'larla yeniden yazılmalı. |
| **`core/` motor / view ayrımı ilkesi** | Doğru karar; yeni mimaride de motor UI-agnostik kalmalı. |
| **Güvenlik pratikleri** (PBKDF2, token hash+rotasyon, MultiFernet, allowlist yeniden doğrulama) | Kanıtlanmış desenler. |
| **Test disiplini** (efemeral PG'ye karşı CI, izolasyon testleri) | Aynen devam. |

### Atılacak / değiştirilecek

| Ne | Yerine |
| --- | --- |
| Streamlit (tek-thread, 40 dk bloke, HttpOnly cookie yok) | Async iş kuyruğu olan bir mimari (ör. FastAPI + frontend; üretim adımları arka planda) |
| Prose + regex parsing | Native structured output (JSON schema) **birincil** yol; regex tamamen atılır |
| Split-brain şema + inline DDL | Tek migration aracı (ör. Alembic), FK'lı gerçek şema |
| God dosyalar (`auth_postgres`, `workflow`) | Sorumluluk bazlı modüller; admin UI ayrı |
| ~35 serbest session_state anahtarı | Tipli, merkezi workflow state modeli |
| Eski `google.generativeai` SDK + global config | Yeni `google.genai` Client (zaten kısmen var) |
| Salt'sız SHA-256 ops script'i, ölü kod (`session_manager`, `get_client_ip`, retry helper) | Silinir |
| Token sayımı (maliyetsiz, Gemini'siz, kırık) | Baştan: her çağrıda provider-bağımsız usage + birim fiyat → maliyet |

### Açık sorular (yeni tasarım öncesi karar gerekli)

1. Kullanıcı tabanı ve eşzamanlılık hedefi ne? (Streamlit tavanı gerçekten sorun mu?)
2. Mevcut Azure kurulumu / DB verisi taşınacak mı, yoksa temiz başlangıç mı?
3. SSO (Entra ID) bu sefer isteniyor mu?
4. "Havas göçü" notları var — hedef ortam değişiyor mu?
5. Prompt'lar gerçekten dondurulmuş mu kalacak, yoksa yeni sistemde iyileştirme
   serbest mi?
