# Design Tokens — HAVAI UI Kit

`tokens.json` bu projenin tema kaynağıdır (source of truth). Uygulama teması bu
dosyadan üretilir: `tokens.json → CSS custom properties → Tailwind @theme → shadcn/ui`.

## Kaynak

Figma dosyası: "HAVAI - UI Kit & Screens (Copy)" (`O7PDMx7jeO6OgqviON6UuS`),
Theme sayfası. Tokens Studio tarama exportlarından çıkarıldı (2026-07-18):

- Export 1: `Semantic Tokens_light` section — semantik eşlemeler + light hex'ler
- Export 2: `Tokens` (Global Tokens) section — renk rampaları 50→950

## Doğrulanmış / varsayılan ayrımı

**Figma'dan doğrulanmış:** gray, red, pink, purple, cyan, blue rampaları (tam);
teal 50-600; tüm `bg.*`, `fg.*`, `border.*` semantik alias'ları; marka moru
`purple.600 = #6642FF`.

**Varsayım (`$note` ile işaretli):**
- teal 700-950, green, yellow, orange rampaları → Tailwind varsayılanları
  (export 300 katman sınırında kesildi; doğrulanmış kısımlar Tailwind ile birebir
  örtüştüğü için düşük risk)
- Dark mod semantikleri → henüz export edilmedi; tema CSS değişkenleri dark'a
  hazır kurulacak, değerler geldiğinde doldurulacak
- Radius/spacing ölçeği → ekran görüntülerinden türetildi
- Text Styles ölçeği → henüz export edilmedi

## Font

Figma'daki aile: **Baikal** (ticari; webfont lisansı yok). Onaylanan geçici
karar: **Space Grotesk** (açık kaynak) ile başla; lisans gelirse
`typography.fontFamily` token'ından tek noktadan değiştir.

## Güncelleme süreci

Figma'da token değişince: ilgili section'ı seçip Tokens Studio taramasını tekrar
çalıştır → JSON'u karşılaştır → `tokens.json`'u güncelle → tema build'i yeniden
üret. Elle tema dosyası düzenlenmez; her şey `tokens.json`'dan akar.
